# Jalon 5.12 — fenêtre Bliss (maquettes PC)
- `blissWindow()` enveloppe la vue (aperçu seulement) : Fiche patron (bleu), Ajout (bleu), Documentation (vert), Favoris (jaune), Espace projet (vert WIP / jaune terminé / rose en attente), Outils (bleu), Réglages (bleu). Bibliothèque, Projets et Idées restent sans fenêtre, comme les maquettes.
- Téléphone : barre de titre masquée (maquettes mobiles sans fenêtre).
- Non repris : boutons – □ × (aucune action réelle).
- Espace projet : l'ordre des blocs diffère encore des maquettes (prototype iPhone prime ; Compteurs/Journal côte à côte = Jalon 6).
- Constat : un projet sans date de départ affiche « NaN j » (donnée de test incomplète ; à rendre robuste en Jalon 6, pas modifié ici).
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-28, cache v56.
