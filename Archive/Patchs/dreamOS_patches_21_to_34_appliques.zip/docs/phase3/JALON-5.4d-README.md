# Jalon 5.4d — Espace projet : fils, couleurs, inspirations, patron lié (aperçu Bliss)

**Voir** : `?bliss=1` → Projets → ouvrir un projet. Par défaut : inchangé.
**Converti** : liste des fils (nom, marque, couleur, pelotes prévues et utilisées), palette de couleurs (ouverture, choix, couleur personnalisée), couleurs de fil prévues (projet en attente), inspirations (grille, ajout de photos, depuis mes idées), sélecteur de patron lié (recherche), liens « objectif de rangs / choisir x ».
**Espace projet** : avec 5.4b et 5.4c il est maintenant entièrement converti dans l'aperçu, sauf le dossier WIP island (inchangé, par règle).
**Méthode** : les fonctions de ces fragments passent par le convertisseur `dz()` (identité hors aperçu). Les sélecteurs JavaScript qui retrouvent ces éléments (point de couleur, palette, liste du patron) reconnaissent maintenant les deux noms de classe (ancien et nouveau) : aucun changement hors aperçu.
**Les inspirations** utilisent les mêmes classes que celles qui serviront à l'écran Idées (jalon 5.6).
**À regarder chez vous** : choisir une couleur (pastille et nom mis à jour), ajouter / retirer un fil, ajouter une pelote, lier un patron avec la recherche, ajouter une photo d'inspiration ; téléphone et clavier.
**Retour arrière** : remettre les fichiers du PATCH-19 (cache v47).
