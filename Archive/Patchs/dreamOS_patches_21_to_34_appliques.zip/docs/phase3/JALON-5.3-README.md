# Jalon 5.3a — Bibliothèque (aperçu Bliss)

**Voir** : `?bliss=1`. Retour : `?bliss=0`. Par défaut : inchangé (capture identique au pixel).
**Converti** : titre « Ma bibliothèque », 3 statistiques, compteurs « Mes projets » (En attente / En cours (WIP) / Terminé, cliquables comme avant), bandeau de sauvegarde, recherche, filtres de statut, regroupement (Pièces / Auteurs / Tous / Dossiers), Tout plier / déplier, création de dossier, cartes de patron (mode « Tous »), états vides (restauration de sauvegarde incluse).
**5.3b (ajouté)** : les vues regroupées (Pièces / Auteurs / Dossiers) : chaque groupe est un panneau avec un vrai bouton plier / déplier (clavier et lecteur d'écran), le nombre de patrons, favori d'auteur, renommer / supprimer / enregistrer un dossier. Les icônes pixel-art par type de pièce (pull, robe…) sont remplacées par l'icône dossier du nouveau jeu (il n'existe pas d'icône par pièce dans le jeu d'icônes fourni) : à valider.
**Reste de la Bibliothèque** : rien d'ancien dans l'aperçu ; les fiches s'ouvrent encore dans l'ancien habillage jusqu'au jalon 5.4 (Projets) / Fiche patron.
**Mêmes données, mêmes actions** : aucune clé ni donnée touchée ; les `data-act` sont identiques (testé).
**À valider / questions**
1. Les maquettes montrent aussi « REPRENDRE » (dernier projet) et une grille « Mes dossiers » avec comptes : fonctions nouvelles (jalon 6) ; rien n'est inventé ici.
2. Textes d'en-tête repris des maquettes, mis au vouvoiement comme le reste de l'application : OK ?
3. Compteurs : libellés des décisions (« En cours (WIP) », « Terminé ») plutôt que ceux des maquettes (« WIP », « Terminés »).
**Limites** : couleurs d'accent et polices viennent encore de l'ancien CSS (7 variables communes) ; tablette 834 px et clavier à regarder chez vous.
**Retour arrière** : remettre les fichiers du PATCH-14 (cache v42).
