# Jalon 5.10 — audit des classes restantes
- Constat : le **sélecteur de document** et l'écran **« PDF illisible »** n'existent pas dans le code actuel (PDF introuvable = simple message `toast`). Ce sont des fonctions nouvelles : jalon 6 (document switcher), pas une conversion.
- Audit en aperçu (Chrome sans interface, tous les onglets, données vides) : seules classes non `dos-` encore présentes : cadre `dream-window*` (à retirer au passage en permanent), `body` (contenu des sections, stylé via `.dos-disclosure .body`), `ok`/`warn` (modificateurs, stylés). Corrigé : `.dos-note.warn`.
- À refaire avec des données (projets, photos, épingles) lors de la suppression de l'ancien CSS : `card` et `row` y apparaissent (anciennes classes génériques conservées).
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-26, cache v54.
