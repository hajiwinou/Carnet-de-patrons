# Jalon 5.4c — Espace projet : cartes (aperçu Bliss)

**Voir** : `?bliss=1` → Projets → ouvrir un projet (En attente, WIP ou Terminé). Par défaut : inchangé.
**Converti** : photo de couverture, statistiques, taille tricotée, aiguilles, champs figés (projet terminé), stitch markers, chronomètre, avis (étoiles, « je le retricoterais », note), suppression du projet.
**Méthode** : une fonction `dz()` (aperçu seulement) transforme les classes de ces fragments vers le nouveau jeu `dos-` ; elle ne touche ni aux textes, ni aux attributs `data-*`, ni aux identifiants (testé). Les styles en ligne statiques sont retirés ; seul le nombre de colonnes des statistiques (valeur dynamique) reste.
**Pas encore converti (5.4d)** : fils (liste et palette de couleurs), couleurs prévues (projet en attente), inspirations (partagées avec l'écran Idées), sélecteur de patron lié, liens « objectif de rangs / choisir x », dossier WIP island (inchangé volontairement).
**Reste à regarder chez vous** : téléphone et tablette ; clavier ; contraste des étoiles vides (gris moyen) ; saisie d'un marqueur et d'un avis.
**Retour arrière** : remettre les fichiers du PATCH-18 (cache v46).
