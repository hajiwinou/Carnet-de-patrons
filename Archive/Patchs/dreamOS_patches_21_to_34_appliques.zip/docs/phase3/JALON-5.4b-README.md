# Jalon 5.4b — Espace projet (aperçu Bliss)

**Voir** : `?bliss=1` → Projets → ouvrir un projet. Par défaut : inchangé.
**Décision WIP = A** (22-23 nov.) : seulement ce que l'application enregistre déjà ; aucun champ ajouté (voir DECISIONS-THEME).
**Converti** : en-tête (retour + nom), vignette et patron lié (le sélecteur de patron garde son rendu actuel), panneau « Infos du projet » (avancement En attente / En cours (WIP) / Terminé, envoi à WIP island), photos (carrousel), compteur de rangs (mise à jour en direct conservée), journal (saisie, photos, modification, suppression).
**Pas encore converti (5.4c)** : photo de couverture, statistiques, taille et aiguilles, fils, couleurs prévues, marqueurs, chronomètre, inspirations, avis (projet terminé), suppression du projet, sélecteur de patron. Ils s'affichent encore à l'ancienne dans l'aperçu : l'écran est donc mixte jusqu'au 5.4c.
**Identifiants et actions conservés** : `pjName pjDraft pjPhotos pjAddPh pjEditTs pjEditText`, actions identiques (testé).
**Retour arrière** : remettre les fichiers du PATCH-17 (cache v45).
