# Jalon 5.17 — Calculatrice et Documentation (aperçu `?bliss=1`)
- Touches de la calculatrice : police du thème, opérateurs en couleur d'accent.
- Documentation : titre de page « Documentation ».
Rendu par défaut inchangé. 5.16.0, cache v62.
