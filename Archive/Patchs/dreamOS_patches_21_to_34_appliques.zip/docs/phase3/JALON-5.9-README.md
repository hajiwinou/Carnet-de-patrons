# Jalon 5.9 — écrans restants (aperçu Bliss)
- Convertis (`?bliss=1` seulement) : Favoris, Recherche, Ajout de patron, Documentation, fiche patron, boîtes de dialogue (confirmation / nom). `dzp()` = `dz()` + titres h1. Mêmes id, data-act, data-*.
- Nouveaux alias : dropzone, import-files, ai, core, seg, blog-post, blog-content, search. Dialogues : `#dlg .box` habillé par `.bliss-preview #dlg`.
- Non traités : sélecteur de document et écran « PDF illisible » du lecteur ; classes génériques `card` / `row` conservées telles quelles (à auditer à l'étape « suppression de l'ancien CSS »).
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-25, cache v53.
