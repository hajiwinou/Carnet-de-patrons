# Jalon 5.8 — Réglages (aperçu Bliss)
- Converti (`?bliss=1` seulement) : titre, sections repliables, cartes IA, pastilles, verrou, sauvegarde, WIP island (inchangé), statistiques. Même id et data-*.
- Retiré de l'affichage en aperçu : section « Apparence, police et fond d'écran » (thème clair/sombre/auto, accent, couleurs, palettes dreamOS, polices, voile, fond). Les clés `carnet.ui` et `wp_*` restent lues et sauvegardées ; le code des anciens réglages reste pour le rendu par défaut jusqu'à validation.
- Pas encore proposés (jalons 6-7) : nouveaux choix de polices, thèmes Doodle/Classique 95/Pixel RPG, fond d'écran en Bliss, accessibilité. Le fond d'écran n'était déjà pas proposé avec le thème dreamOS par défaut.
- Liste des IA inchangée (décision). « Plus » mobile, états de sync, verrouillage maquette : non traités.
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-24, cache v52.
