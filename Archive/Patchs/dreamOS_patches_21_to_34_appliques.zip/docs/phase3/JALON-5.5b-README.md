# Jalon 5.5b — volet « Mes outils » (aperçu Bliss)
- Converti (`?bliss=1` seulement) : en-tête du volet, poignée, panneau, feuille de note. Mêmes id et actions (pdfToolsReturn, pdfNoteSave, pdfNoteClear, toolSub).
- Hooks JS à double sélecteur ancien/nouveau.
- Inchangé : contenu des outils (→ 5.7), sélecteur de document et écran « PDF illisible » (→ 5.9).
- Rendu par défaut inchangé. Retour arrière : restaurer les fichiers du PATCH-21, cache v49.
- Version 5.5.1, cache v50.
