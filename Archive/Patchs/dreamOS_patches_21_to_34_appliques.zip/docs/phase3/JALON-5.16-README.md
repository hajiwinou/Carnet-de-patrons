# Jalon 5.16 — mobile : largeur et hub d'outils
- Planches à 3 colonnes (maquette dossier / prototype iPhone / application) : les maquettes mobiles du dossier et le prototype sont identiques pour Bibliothèque, Outils et Réglages.
- Corrigé (aperçu) : remplissage horizontal hérité du corps de page ; tuiles projets verticales ; hub d'outils une colonne avec pastilles colorées ; titre du hub.
- Écarts restants, nouveautés ou refontes de navigation (à décider) : grille de dossiers + page « Dossier » ; carte REPRENDRE ; recherche et filtres d'outils, « Récemment », étoiles favorites ; Réglages en menu de cartes (Apparence, Polices, Fond, Verrouillage, Sauvegarde) au lieu des sections repliables ; onglet « Plus ».
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-32, cache v60.
