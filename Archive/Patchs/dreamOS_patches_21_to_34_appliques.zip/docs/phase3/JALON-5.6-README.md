# Jalon 5.6 — Idées (aperçu Bliss)
- Converti (`?bliss=1` seulement) : titre « Idées », bloc-note, formulaire d'épinglage, tableaux et filtres, épingles, sélection multiple, bandeau et barre « Ajouter au projet ».
- Méthode : `dz()` sur le HTML existant (mêmes id, data-act, data-*). Nouveaux alias : sec, selbar, pin-pick, picked, empty, chips, note.
- `.dos-masonry` en double → un seul ; variante `--sm` pour l'inspiration d'un projet.
- Non fait : détail d'une idée et « Lier à un projet » en pages dédiées des maquettes (mockups 02, 05) : pas de nouveau champ ni écran (décision « A »).
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-22, cache v50.
