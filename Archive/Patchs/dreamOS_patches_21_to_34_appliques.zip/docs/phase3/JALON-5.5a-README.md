# Jalon 5.5a — Lecteur PDF : barre et compteur (aperçu Bliss)

**Voir** : `?bliss=1`, ouvrir un PDF depuis une fiche patron ou un projet. Par défaut : inchangé.
**Converti** : barre du haut (fermer, titre, page n / m, Mes outils, repère, surlignage, marqueur de rang, zoom − / +), compteur de rangs flottant (− / rang / +1), menu du compteur (+10, −10, +x, choisir x, objectif, note, total, remise à 0 avec confirmation, réduire), ligne d'état, sous-compteur d'objectif.
**Inchangé** : les pages du PDF, les repères, les surlignages et les marqueurs dessinés sur le PDF (rendu actuel) ; le tiroir « Mes outils » (5.5b) ; le glisser-déplacer et la réduction du compteur, qui continuent d'utiliser les mêmes éléments.
**Méthode** : en aperçu, les éléments statiques du lecteur sont remplacés au chargement par les mêmes éléments avec les nouvelles classes (mêmes `id`, `data-act`, `data-r` ; testé). Le remplacement se fait avant que les événements du compteur soient branchés.
**Écarts avec la maquette (non faits, fonctions nouvelles)** : sélecteur « Changer de document » dans la barre, ligne « ▶ rang » sur la page, vitesse « 1 s / rang » sous forme de pastille avec icône : la ligne d'état existante est conservée telle quelle.
**Icônes** : repère = épingle, surligner = crayon, marqueur = anneau, ce sont des choix de ma part parmi les icônes fournies (à valider).
**À regarder chez vous** : ouvrir un vrai PDF ; compter, ouvrir le menu, réduire, déplacer le compteur ; téléphone en tenant l'appareil debout et couché ; clavier.
**Note** : `.dos-masonry` est défini deux fois (modèle d'origine et ajout 5.4d) ; à unifier au jalon 5.6 (Idées).
**Retour arrière** : remettre les fichiers du PATCH-20 (cache v48).
