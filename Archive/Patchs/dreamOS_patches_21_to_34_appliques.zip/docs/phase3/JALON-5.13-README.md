# Jalon 5.13 — barre du haut et Bibliothèque
- Champ `#tbq` (PC) : Entrée → onglet Recherche avec le texte (S.fq). Sur téléphone la loupe reste.
- Onglets pleine largeur, colonne centrée (1152 px), boutons sans retour à la ligne.
- Tuiles « Mes projets » avec icônes (chrono, WIP, étoile).
- Non repris (nouveautés, Jalon 6) : pastille « Synchronisé », carte REPRENDRE, bouton « Nouveau dossier » en haut, grille de dossiers (l'app garde les groupes repliables), bouton Documentation absent des maquettes mais conservé.
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-29, cache v57.
