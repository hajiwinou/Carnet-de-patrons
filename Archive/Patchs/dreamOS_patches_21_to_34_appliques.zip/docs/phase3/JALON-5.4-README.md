# Jalon 5.4a — Liste des projets (aperçu Bliss)

**Voir** : `?bliss=1`, onglet Projets. Par défaut : inchangé.
**Converti** : titre « Mes projets », bouton « Nouveau projet », onglets En attente (n) / En cours (WIP) (n) / Terminé (n) (couleurs d'état), cartes de projet (pastille d'état, nom, informations, Ouvrir, Commencer / Marquer terminé, Voir le PDF), état vide.
**Inchangé volontairement** : le dossier « WIP island » (note, dossier, vue île) garde son rendu actuel (règle : WIP Island inchangée) ; l'espace projet (fiche d'un projet) sera le 5.4b.
**Écart avec la maquette** : la maquette montre un bouton « Compteurs » sur chaque carte et des lignes « Corps · 42 / 120 », « 14 h 20 · 118 rangs · 3 pelotes ». Je n'ai pas ajouté « Compteurs » (fonction nouvelle) ; la carte affiche les mêmes informations qu'avant (patron, jours, entrées, temps, pelotes selon vos réglages de statistiques).
**Mêmes actions** : openPj, pjStep, viewPdf, newPj, pjStage identiques (testé).
**Retour arrière** : remettre les fichiers du PATCH-16 (cache v44).
