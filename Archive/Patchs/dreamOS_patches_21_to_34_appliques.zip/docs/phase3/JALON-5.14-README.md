# Jalon 5.14 — Projets et Idées plus fidèles
- Fiche projet : bandeau coloré (en attente / WIP / terminé) avec icône et statut ; photo affichée seulement si elle existe ; boutons inchangés (Ouvrir, étape, Voir le PDF).
- Idées : titre « Mes idées » + sous-titre (vouvoiement, à valider), colonne « Tableaux » avec compteurs, grille 3 colonnes, formulaire « Épingler une inspiration » et bloc-note repliables (formulaire ouvert s'il y a un brouillon).
- Non repris : « Tag / Couleur / Reliées à un projet », compteur « 48 idées · 5 tableaux », bouton « + Épingler une idée » (nouveautés, Jalon 6), boutons Compteurs des fiches projet.
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-30, cache v58.
