# Jalon 5.15 — espace projet mobile d'après le prototype iPhone
- Source : `dreamos-iphone-navigable/projets.html` (prime sur le dossier 02 pour l'iPhone, décision de l'utilisatrice).
- Fait (aperçu, ≤ 900 px) : barre verte/jaune/rose avec retour + nom + statut ; ordre Infos (statut, chiffres) → patron lié → compteur → journal → photos ; statut sur une ligne ; barre du haut masquée.
- Pas repris, car données ou fonctions nouvelles (Jalon 6, décision « A ») : trio rangs/avancement/reste (exige un total de rangs), onglets Suivi/Notes, taille en pastilles, chrono + matériel + marqueurs groupés, compteurs multiples (augmentations, répétitions), mini-lecteur de photos.
- Sur PC : ordre actuel conservé (la version PC suit le dossier 02, à traiter à part).
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-31, cache v59.
