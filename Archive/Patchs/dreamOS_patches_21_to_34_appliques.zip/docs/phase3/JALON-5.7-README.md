# Jalon 5.7 — Outils (aperçu Bliss)
- Converti (`?bliss=1` seulement) : hub (7 tuiles + icônes), en-tête des pages d'outils, calculatrice, blocs résultat, grilles de points, étapes, aperçu vidéo, note « Ajouter au journal d'un WIP ».
- Méthode : `dz()` + alias (hub, hubt, top, kc*, calc-res, scroll-x, ccell, chunk, pcol, ig-prev). Même id et data-act. Crochet `.calc-res` à double sélecteur.
- Le style de `#cgrid` commence par grid-template-columns pour survivre à `dz()`.
- Retiré : règles de compatibilité `.hub/.hubt` du volet PDF (remplacées par `.dos-toolhub/.dos-tooltile`).
- Non fait (nouveautés Jalon 6, décision « A ») : recherche d'outil, filtres Tous/Tricot/…, « Récemment », « 3 à venir ».
- Rendu par défaut inchangé. Retour arrière : fichiers du PATCH-23, cache v51.
