# CHANGELOG

## 5.15.0 — 25 nov. 2026
- Aperçu `?bliss=1` : plus de marges parasites de l'ancien CSS (barre pleine largeur), tuiles « Mes projets » verticales sur téléphone, hub d'outils en liste (pastilles colorées), titre « Ma boîte à outils ».
## 5.14.0 — 25 nov. 2026
- Aperçu `?bliss=1` : espace projet mobile réordonné d'après le prototype iPhone (barre colorée + statut, infos, patron, compteur, journal, photos), barre du haut masquée sur cet écran.
## 5.13.0 — 25 nov. 2026
- Aperçu `?bliss=1` : fiches projet à bandeau coloré (icône + statut), Idées avec colonne « Tableaux » (compteurs) et grille, formulaire d'épinglage et bloc-note repliables.
## 5.12.0 — 25 nov. 2026
- Aperçu `?bliss=1` : champ de recherche dans la barre (PC ; Entrée ouvre l'onglet Recherche), onglets pleine largeur, colonne centrée 1152 px, tuiles de projets avec icônes.
## 5.11.0 — 25 nov. 2026
- Aperçu `?bliss=1` : fenêtre Bliss des maquettes PC (titre coloré vert/bleu/jaune/rose selon l'écran), masquée sur téléphone. Boutons – □ × non repris (décoratifs).
## 5.10.0 — 25 nov. 2026
- Aperçu `?bliss=1` : `data-theme="bliss"`, tokens/polices rechargés après l'ancien CSS, anciens réglages d'apparence ignorés (non supprimés), cadre « dream » retiré. Comparaison avec les maquettes : voir JALON-5.11-README.
## 5.9.1 — 24 nov. 2026
- Aperçu `?bliss=1` : état « avertissement » des notes ; audit des classes restantes.
## 5.9.0 — 24 nov. 2026
- Aperçu `?bliss=1` : Favoris, Recherche, Ajout de patron, Documentation, fiche patron et boîtes de dialogue au rendu Bliss ; mêmes actions.
## 5.8.0 — 24 nov. 2026
- Réglages (aperçu `?bliss=1`) : rendu Bliss ; la section « Apparence, police et fond d'écran » n'est plus affichée (aucune donnée supprimée).
## 5.7.0 — 24 nov. 2026
- Outils (aperçu `?bliss=1`) : hub à tuiles avec icônes, pages d'outils, calculatrice, résultats, grilles au rendu Bliss ; le volet « Mes outils » du lecteur en profite aussi. Mêmes actions.
## 5.6.0 — 24 nov. 2026
- Idées (aperçu `?bliss=1`) : titre, bloc-note, formulaire d'épinglage, tableaux et filtres, épingles, barre de sélection au rendu Bliss ; mêmes actions. Grille « masonry » unifiée.
## 5.5.1 — 24 nov. 2026
- Lecteur PDF (aperçu `?bliss=1`) : volet « Mes outils » et feuille de note au rendu Bliss (poignée, en-tête, Fermer). Contenu des outils inchangé jusqu'au 5.7.
## 5.5.0 — 23 nov. 2026
- Lecteur PDF (aperçu `?bliss=1`) : barre du haut (fermer, titre, page, Mes outils, repère, surlignage, marqueur, zoom) et compteur de rangs flottant au rendu Bliss ; mêmes boutons, mêmes actions, déplacement et réduction du compteur conservés.
## 5.4.3 — 23 nov. 2026
- Espace projet (aperçu `?bliss=1`) : fils, palette de couleurs, couleurs prévues, inspirations, sélecteur de patron et liens d'objectif de rangs au rendu Bliss.
## 5.4.2 — 23 nov. 2026
- Espace projet (aperçu `?bliss=1`) : couverture, statistiques, taille tricotée, aiguilles, stitch markers, chronomètre, avis et suppression au rendu Bliss.
## 5.4.1 — 23 nov. 2026
- Espace projet (aperçu `?bliss=1`) : en-tête, patron lié, panneau Infos et avancement, photos, compteur de rangs et journal au rendu Bliss ; mêmes actions et mêmes identifiants.
## 5.4.0 — 22 nov. 2026
- Projets (aperçu `?bliss=1`) : liste, onglets d'état, cartes de projet et état vide au rendu Bliss ; mêmes actions ; WIP Island inchangée.
## 5.3.1 — 22 nov. 2026
- Bibliothèque (aperçu `?bliss=1`) : les vues groupées (Pièces, Auteurs, Dossiers) passent au rendu Bliss ; vrais boutons pour plier / déplier ; mêmes actions.
## 5.3.0 — 22 nov. 2026
- Bibliothèque : rendu Bliss (aperçu `?bliss=1`) pour l'en-tête, les statistiques, les compteurs de projets, la recherche, les filtres, les cartes de patrons et les états vides. Mêmes actions qu'avant ; affichage par défaut inchangé.
## 5.2.0 — 22 nov. 2026
- Aperçu optionnel de la barre du haut et de la barre du bas Bliss (`?bliss=1` pour activer, `?bliss=0` pour revenir). Par défaut : ancien affichage, capture identique au pixel.
## 5.1.0 — 22 nov. 2026
- Le thème Bliss (variables + polices) est chargé par l'application, avant l'ancien CSS qui garde la priorité : aucun changement visuel (captures identiques).
## 5.0.1 — 22 nov. 2026
- DM Sans hébergée (`fonts/`) ; page de test sans Internet ; images de l'ancien thème (`themes/bliss/`) retirées du précache ; décisions du 22 nov. consignées (`DECISIONS-THEME.md`).
## 5.0.0 — 22 nov. 2026
- 5.0 : restauration de `assets/` ; ajout du thème Bliss (`theme/`), des icônes (`icones/`), de Pixelify Sans (`fonts/`) et de la page de test interne `theme-test.html` ; décisions de l'utilisatrice (`docs/project/DECISIONS-THEME.md`). L'application garde son habillage actuel.
## 4.9.1 — 21 nov. 2026 (bilan)
- 4.10 : bilan du Jalon 4 (`docs/project/JALON-4-BILAN.md`) ; aucun changement de code.
## 4.9.1 — 21 nov. 2026
- 4.9b : Settings modifie lui-même les valeurs de réglages (apparence, palette, île, statistiques, fond d'écran, fournisseurs d'IA, préférences, options).
## 4.9.0 — 21 nov. 2026
- 4.9a : nouveau module Settings (`dreamOS/settings/`) : il écrit les réglages (`carnet.ui`, `carnet.theme`, `carnet.opts`, `carnet.ai`, `carnet.pwHash`, `carnet.pwFail`, `carnet.lastBackup`) et le fond d'écran `wp_*`.
## 4.8.0 — 21 nov. 2026
- 4.8 : le lecteur PDF possède l'écriture de ses données (position de reprise, repère de rang, marqueurs de marge, surlignages, position et état réduit du compteur) et leurs modifications.
## 4.7.3 — 21 nov. 2026
- 4.7d : Patterns crée les patrons (nouveau, restauré depuis une sauvegarde) et les dossiers, renomme un dossier, enregistre `analysis` après l'analyse par IA, et possède les préférences `carnet.favAuthors`, `carnet.collapsed`, `carnet.group`.
## 4.7.2
- 4.7c : champs d'un patron modifiés par le module.
## 4.7.1
- 4.7b : médias de patrons `pdf_` / `th_` / `img_`.
## 4.7.0
- 4.7a : liste des patrons et dossiers.

## 4.6.4 — 20 nov. 2026 (base de référence)
- 4.6e : Projects crée les projets, change l'étape, gère les drapeaux de l'île (`islandPin`, `leftIsland`) et les liens avec les patrons.
## 4.6.3
- 4.6d : champs, fils, couleurs prévues, pelotes prévues, rangs au total, raisons de l'île, abandon d'objectif, simulation de pause.
## 4.6.2
- 4.6c : journal, photos, couverture, inspiration, chrono (remise à zéro / temps ajouté), acquittement de l'île.
## 4.6.1
- 4.6b : médias de projets `pjc_` / `pjp_` / `pji_` (passerelle unique).
## 4.6.0
- 4.6a : liste de projets possédée par le module (+ persistance `pjStage`, `migPj`).
## 4.1 à 4.5
- Documentation (articles, médias), Library (idées, tableaux, médias), Tools (grilles, valeurs d'interface), Downloads (réglages Instagram).
## 3.x
- Huit modules métier en place (strangler, hôtes, tests d'équivalence).
- 2026-11-21 — PATCH-1 : inventaire du modèle de données d'un projet (documentation seule).
- 2026-11-21 — PATCH-2 / 4.7.0 : Patterns autorité d'écriture de la liste des patrons et des dossiers et de leur enregistrement.
- 2026-11-21 — PATCH-3 : documentation de l'ordre des travaux (Jalon 4 complet, puis porte de préparation et jalons 5 à 10).
- 2026-11-21 — PATCH-4 / 4.7.1 : Patterns autorité d'écriture et de suppression des médias de patrons.
- 2026-11-21 — PATCH-5 / 4.7.2 : commandes de modification directe d'un patron (titre, texte, statut, dossier, étape, source PDF, miniature, photos, fiche, variantes).
