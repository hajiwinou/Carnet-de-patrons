# PATCH-LOG

| Id | Date | Contenu | Base | Empreintes |
|---|---|---|---|---|
| **BASE-4.6.4** | 2026-11-20 | Base ZIP complète (code, tests, docs, outils). **Hors `assets/` et pack de thème, absents** (voir PROJECT-STATUS). | — | `docs/project/BASE-MANIFEST.sha256` |

Les livraisons suivantes sont des **patches** : fichiers nouveaux ou modifiés uniquement, avec `PATCH-MANIFEST.md` (modèle : `docs/project/PATCH-MANIFEST.template.md`), README d'intégration, résultats de tests et retour arrière. Avant application : `node tools/manifest.mjs verify docs/project/BASE-MANIFEST.sha256` doit être propre (ou ne différer que par les patches déjà appliqués).
| **PATCH-1** | 2026-11-21 | Documentation seule : `WIP-DATA-MODEL-AUDIT.md`, statut mis à jour. Aucun code. | BASE-4.6.4 | `PATCH-MANIFEST.md` |
| **PATCH-2** | 2026-11-21 | Jalon 4.7a : Patterns possède la liste des patrons et des dossiers (`patterns-store.js`), 4.7.0, cache v32. | BASE-4.6.4 + PATCH-1 | `PATCH-MANIFEST.md` |
| **PATCH-3** | 2026-11-21 | Documentation seule : ordre des travaux décidé (terminer le Jalon 4, puis reprendre le plan d'avant). Aucun code. | PATCH-2 | `PATCH-MANIFEST.md` |
| **PATCH-4** | 2026-11-21 | Jalon 4.7b : Patterns possède les médias de patrons (`patterns-media.js`), 4.7.1, cache v33. | PATCH-3 | `PATCH-MANIFEST.md` |
| **PATCH-5** | 2026-11-21 | Jalon 4.7c : Patterns modifie lui-même les champs d'un patron (`patterns-commands.js`), 4.7.2, cache v34. | PATCH-4 | `PATCH-MANIFEST.md` |
| **PATCH-6** | 2026-11-21 | Jalon 4.7d : Patterns crée patrons / dossiers, enregistre l'analyse par IA et les préférences d'affichage, 4.7.3, cache v35. | PATCH-5 | `PATCH-MANIFEST.md` |
| **PATCH-7** | 2026-11-21 | Jalon 4.8 : PDF Reader possède l'écriture de ses données (`pdf-reader-store.js`, `pdf-reader-commands.js`), 4.8.0, cache v36. | PATCH-6 | `PATCH-MANIFEST.md` |
| **PATCH-8** | 2026-11-21 | Jalon 4.9a : Settings écrit les réglages et le fond d'écran wp_* (`dreamOS/settings/`), 4.9.0, cache v37. | PATCH-7 | `PATCH-MANIFEST.md` |
| **PATCH-9** | 2026-11-21 | Jalon 4.9b : Settings modifie les valeurs de réglages (`settings-commands.js`), 4.9.1, cache v38. | PATCH-8 | `PATCH-MANIFEST.md` |
| **PATCH-10** | 2026-11-21 | Jalon 4.10 : bilan du Jalon 4 (documentation seule, aucun code). | PATCH-9 | `PATCH-MANIFEST.md` |
| **PATCH-11** | 2026-11-22 | Jalon 5.0 : porte de préparation (assets, thème, icônes, polices, page de test interne, décisions), 5.0.0, cache v39. Application non modifiée. | PATCH-10 | `PATCH-MANIFEST.md` |
| **PATCH-12** | 2026-11-22 | Jalon 5.0.1 : DM Sans hébergée, `themes/bliss/` retiré du précache, décisions du 22 nov. consignées, 5.0.1, cache v40. | PATCH-11 | `PATCH-MANIFEST.md` |
| **PATCH-13** | 2026-11-22 | Jalon 5.1 : `index.html` charge `theme/tokens.css` et `theme/fonts.css` (avant l'ancien CSS). Aucun écran modifié. 5.1.0, cache v41. | PATCH-12 | `PATCH-MANIFEST.md` |
| **PATCH-14** | 2026-11-22 | Jalon 5.2 : barre du haut Bliss en aperçu opt-in (`?bliss=1`), barre du bas mobile, 5.2.0, cache v42. Affichage par défaut inchangé. | PATCH-13 | `PATCH-MANIFEST.md` |
| **PATCH-15** | 2026-11-22 | Jalon 5.3a : écran Bibliothèque en aperçu Bliss (en-tête, statistiques, compteurs de projets, recherche, filtres, cartes patron, états vides). Défaut inchangé. 5.3.0, cache v43. | PATCH-14 | `PATCH-MANIFEST.md` |
| **PATCH-16** | 2026-11-22 | Jalon 5.3b : groupes de la bibliothèque (Pièces / Auteurs / Dossiers : en-têtes, plier / déplier, favori d'auteur, renommer / supprimer un dossier) en aperçu Bliss. Défaut inchangé. 5.3.1, cache v44. | PATCH-15 | `PATCH-MANIFEST.md` |
| **PATCH-17** | 2026-11-22 | Jalon 5.4a : liste des projets (En attente / En cours (WIP) / Terminé, cartes, état vide) en aperçu Bliss. WIP Island et espace projet inchangés. 5.4.0, cache v45. | PATCH-16 | `PATCH-MANIFEST.md` |
| **PATCH-18** | 2026-11-23 | Jalon 5.4b : espace projet (en-tête, patron lié, infos, avancement, photos, compteur de rangs, journal) en aperçu Bliss ; décision WIP « A » consignée. 5.4.1, cache v46. | PATCH-17 | `PATCH-MANIFEST.md` |
| **PATCH-19** | 2026-11-23 | Jalon 5.4c : cartes de l'espace projet (couverture, statistiques, taille, aiguilles, marqueurs, chronomètre, avis, suppression) en aperçu Bliss via un convertisseur de classes testé. 5.4.2, cache v47. | PATCH-18 | `PATCH-MANIFEST.md` |
| **PATCH-20** | 2026-11-23 | Jalon 5.4d : fils, palette de couleurs, couleurs prévues, inspirations, patron lié et liens d'objectif de rangs en aperçu Bliss. Espace projet entièrement converti (hors WIP Island). 5.4.3, cache v48. | PATCH-19 | `PATCH-MANIFEST.md` |
| **PATCH-21** | 2026-11-23 | Jalon 5.5a : lecteur PDF en aperçu Bliss — barre du haut et compteur de rangs flottant (menu, objectif, sous-compteur). Mêmes id et actions. 5.5.0, cache v49. | PATCH-20 | `PATCH-MANIFEST.md` |
| **PATCH-22** | 2026-11-24 | Jalon 5.5b : volet « Mes outils » et feuille de note du lecteur PDF en aperçu Bliss (en-tête, poignée, panneau). Contenu des outils inchangé (→ 5.7). 5.5.1, cache v50. | PATCH-21 | `PATCH-MANIFEST.md` |
| **PATCH-23** | 2026-11-24 | Jalon 5.6 : onglet Idées en aperçu Bliss (bloc-note, formulaire d'épingle, tableaux/filtres, épingles, barre de sélection). Mêmes id et actions. 5.6.0, cache v51. | PATCH-22 | `PATCH-MANIFEST.md` |
| **PATCH-24** | 2026-11-24 | Jalon 5.7 : onglet Outils en aperçu Bliss (hub, pages d'outils, calculatrice, résultats, grilles). Règles de compatibilité `.hub/.hubt` retirées. 5.7.0, cache v52. | PATCH-23 | `PATCH-MANIFEST.md` |
| **PATCH-25** | 2026-11-24 | Jalon 5.8 : Réglages en aperçu Bliss (titre, sections, cartes IA ; section Apparence masquée en aperçu, aucune donnée supprimée). 5.8.0, cache v53. | PATCH-24 | `PATCH-MANIFEST.md` |
| **PATCH-26** | 2026-11-24 | Jalon 5.9 : écrans restants en aperçu Bliss (Favoris, Recherche, Ajout de patron, Documentation, fiche patron, boîtes de dialogue). 5.9.0, cache v54. | PATCH-25 | `PATCH-MANIFEST.md` |
| **PATCH-27** | 2026-11-24 | Jalon 5.10 : audit des classes restantes en aperçu Bliss (état d'avertissement `.dos-note.warn`) ; constat sur sélecteur de document / « PDF illisible ». 5.9.1, cache v55. | PATCH-26 | `PATCH-MANIFEST.md` |
| **PATCH-28** | 2026-11-25 | Jalon 5.11 : en aperçu Bliss, les couleurs, polices et fond du thème l'emportent enfin sur l'ancien habillage (accent framboise, fond rose, DM Sans) ; cadre de fenêtre « dream » retiré en aperçu. 5.10.0, cache v56. | PATCH-27 | `PATCH-MANIFEST.md` |
| **PATCH-29** | 2026-11-25 | Jalon 5.12 : fenêtre Bliss des maquettes PC (barre de titre colorée) autour de Fiche patron, Ajout, Documentation, Favoris, Espace projet, Outils, Réglages ; masquée sur téléphone. 5.11.0, cache v57. | PATCH-28 | `PATCH-MANIFEST.md` |
| **PATCH-30** | 2026-11-25 | Jalon 5.13 : barre du haut (champ de recherche sur PC, onglets pleine largeur, colonne centrée) et tuiles de projets avec icônes. 5.12.0, cache v58. | PATCH-29 | `PATCH-MANIFEST.md` |
| **PATCH-31** | 2026-11-25 | Jalon 5.14 : fiches projet à bandeau coloré, en-têtes de pages dégagés des onglets, Idées avec colonne « Tableaux » et grille (aperçu Bliss). 5.13.0, cache v59. | PATCH-30 | `PATCH-MANIFEST.md` |
| **PATCH-32** | 2026-11-25 | Jalon 5.15 : espace projet sur téléphone selon le prototype iPhone (barre colorée avec statut, ordre statut → patron → compteur → journal → photos, barre du haut masquée). 5.14.0, cache v60. | PATCH-31 | `PATCH-MANIFEST.md` |
| **PATCH-33** | 2026-11-25 | Jalon 5.16 : mobile pleine largeur (fin de l'ancien remplissage), tuiles de projets verticales, hub d'outils en liste avec pastilles colorées, titre « Ma boîte à outils ». 5.15.0, cache v61. | PATCH-32 | `PATCH-MANIFEST.md` |
| **PATCH-34** | 2026-11-25 | Jalon 5.17 : touches de la calculatrice (police, opérateurs en accent) et titre Documentation (aperçu Bliss). 5.16.0, cache v62. | PATCH-33 | `PATCH-MANIFEST.md` |
