# PATCH-34 — Jalon 5.17 calculatrice et Documentation (5.16.0, cache v62)
Prérequis : PATCH-33. Copier ces fichiers par-dessus le projet.
Contenu : touches de calculatrice et titre Documentation en aperçu `?bliss=1`. Rendu par défaut inchangé.
Test : `for t in tests/*.test.mjs; do node $t; done`
Retour arrière : restaurer les fichiers du PATCH-33 (cache v61).
