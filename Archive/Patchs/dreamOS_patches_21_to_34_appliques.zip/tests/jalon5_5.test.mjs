// Jalon 5.5a : lecteur PDF (barre du haut + compteur de rangs) en aperçu Bliss.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), idx=fs.readFileSync('index.html','utf8'), css=fs.readFileSync('theme/components.css','utf8');
const a=app.indexOf('  function blissViewerInit()'), b=app.indexOf('\n  }\n',a); assert.ok(a>0&&b>a);
const fn=app.slice(a,b);
const vi=idx.indexOf('<div id="viewer" hidden>'), ve=idx.indexOf('<script src="app.js">'); const stat=idx.slice(vi,ve);
const attr=(s,n)=>new Set([...s.matchAll(new RegExp(n+'="([^"]*)"','g'))].map(m=>m[1]));
// mêmes id, data-act, data-r que le HTML statique
const idsStatic=attr(stat,'id'), idsB=attr(fn,'id');
for(const i of ['vtitle','vpage','vmark','vhl','vsm','vrc','vrcMenu','vrcPj','vrcXb','vrcGoalDrop','vrcReset','vrcSt','vrcN','vrcV','vrcSub','vscroll']){ assert.ok(idsStatic.has(i),'statique '+i); if(i!=='vrc'&&i!=='vscroll') assert.ok(idsB.has(i),'Bliss '+i); }
for(const k of ['data-act','data-r']){ const s=attr(stat,k), n=attr(fn,k); for(const v of s) assert.ok(n.has(v),k+' perdu : '+v); }
// aria-label sur les boutons-icônes
for(const m of fn.matchAll(/<button[^>]*>(?:' \+ blissIco\([^)]*\) \+ ')?<\/button>/g)) assert.match(m[0],/aria-label=/,m[0]);
assert.ok((fn.match(/aria-label=/g)||[]).length>=9);
assert.equal(/class="(icon-btn|btn|vrc-[a-z]+|vhead|vtitle|sub|num)[ "]/.test(fn),false,'ancienne classe');
assert.equal(/style=|#[0-9a-f]{3,6}\b/i.test(fn),false);
// ordre : BLISS défini avant, init avant la liaison des événements du compteur
const iB=app.indexOf('var BLISS = '), iCall=app.indexOf('if (BLISS) blissViewerInit();'), iBind=app.indexOf("var el = $('#vrc'), menu = $('#vrcMenu')");
assert.ok(iB>0&&iB<iCall&&iCall<iBind,'ordre BLISS / init / liaison');
assert.equal((app.match(/function blissViewerInit\(\)/g)||[]).length,1); assert.equal((app.match(/if \(BLISS\) blissViewerInit\(\);/g)||[]).length,1);
// boutons générés du sous-compteur
assert.match(app,/if \(BLISS\) box\.querySelectorAll\('button'\)\.forEach\(function\(b\) \{ b\.classList\.add\('dos-btn', 'dos-btn--chip'\); \}\);/);
// classes CSS définies
for(const c of ['dos-vhead','dos-vtitle','dos-vrc','dos-vrc__menu','dos-vrc__item','dos-vrc__pj','dos-vrc__st','dos-vrc__sub','dos-rangcounter__value']) assert.ok(css.includes('.'+c),c);
assert.match(css,/\.dos-vrc\.min \.dos-rangcounter > button:not\(\.dos-rangcounter__value\) \{ display: none; \}/);
assert.match(css,/\.dos-vrc__item\.arm/); assert.equal(/!important|#[0-9a-fA-F]{3,6}\b/.test(css),false);
// défaut : index.html inchangé (ancien viewer toujours présent)
assert.ok(stat.includes('class="vhead"')&&stat.includes('class="vrc-bar"'));
// 5.5b : volet outils
const sh=app.slice(app.indexOf('function sheetHeadHtml'),app.indexOf('function sheetHeadHtml')+1500);
assert.ok(sh.includes('data-act="pdfToolsReturn"')&&sh.includes('aria-label="Fermer et revenir au PDF"'));
const nb=app.slice(app.indexOf('function noteSheetHtml'),app.indexOf('function noteSheetHtml')+3000);
for(const k of ['pdfNoteText','pdfNoteSave','pdfNoteClear']) assert.ok(nb.includes(k),k);
assert.equal((app.match(/\.pdf-tool-top, \.dos-pdfsheet__top/g)||[]).length>=1,true);
assert.equal((app.match(/\.pdf-tool-panel, \.dos-pdfsheet__panel/g)||[]).length>=2,true);
for(const c of ['dos-pdfsheet','dos-pdfsheet__panel','dos-pdfsheet__top','dos-pdfsheet__head']) assert.ok(css.includes('.'+c),c);
console.log('jalon5_5 OK');
