// Jalon 5.8 : Réglages en aperçu Bliss (apparence retirée de l'affichage, données conservées).
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), css=fs.readFileSync('theme/components.css','utf8');
assert.match(app,/function viewSettings\(\) \{ return \(BLISS \? '<div class="dos-pagehead"><h1 class="dos-h1">Réglages<\/h1><\/div>' : ''\) \+ dz\(viewSettingsRaw\(\)\); \}/);
const a=app.indexOf('function viewSettingsRaw'), z=app.indexOf('\n  }\n',a), body=app.slice(a,z);
// la section Apparence n'est masquée qu'en aperçu, et seulement elle
assert.match(body,/\(BLISS \? '' : '<details class="sec" open>/);
assert.equal((body.match(/BLISS/g)||[]).length,1);
// toutes les autres sections et tous les réglages liés aux données restent
for(const k of ['data-stat=','data-island="on"','data-act="setPw"','data-act="lockNow"','data-aikey=','data-aipref="prefText"','data-act="fullBackup"','data-act="zip"','id="restoreIn"','data-act="devAge"','data-exp="valid"','data-act="testAi"']) assert.ok(body.includes(k),k);
// le code des anciens réglages (thème, police, couleurs, fond) reste dans la source pour le rendu par défaut
for(const k of ['data-ui="theme"','data-ui="font"','dreamColorsHtml(u)','genericColorsHtml(u)','data-act="clearWallpaper"']) assert.ok(body.includes(k),k);
// l'ancien chemin: sans BLISS, la chaîne est identique à l'originale (la section est bien dans la branche '<details...')
const i0=app.indexOf('  var DZ_MAP'), i1=app.indexOf('  /* Bibliothèques lourdes');
const mk=B=>new Function('BLISS',app.slice(i0,i1)+'\nreturn dz;')(B);
const f=mk(true), off=mk(false);
const h='<details class="sec" data-sec="x"><summary><h3>T</h3><span class="chip ok">A</span></summary><div class="prov-card active"><div class="hint">h</div><div class="note ok">n</div></div></details>';
assert.equal(off(h),h);
const o=f(h); for(const c of ['sec','prov-card','hint']) assert.ok(!new RegExp('class="(?:[^"]*\\s)?'+c+'[ "]').test(o),c);
assert.match(o,/dos-disclosure/); assert.match(o,/data-sec="x"/);
assert.match(app,/classList\.contains\('sec'\) \|\| d\.classList\.contains\('dos-disclosure'\)\) && d\.dataset\.sec/);
for(const c of ['dos-provcard','dos-tag.ok','dos-note.bad','dos-note.warn','dos-disclosure']) assert.ok(css.includes('.'+c),c);
console.log('jalon5_8 OK');
