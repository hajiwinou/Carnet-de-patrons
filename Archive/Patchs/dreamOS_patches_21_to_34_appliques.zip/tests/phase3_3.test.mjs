// Phase 3.3 — le moteur de thème est équivalent à applyAppearance() d'app.js (grille de configurations)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { computeAppearance, DREAM_PALETTES, FONTS, hexToRgba, luminance, mixHex, contrastRatio } from '../dreamOS/theme/theme-engine.js';
import { createThemeManager } from '../dreamOS/theme/theme-manager.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

// --- extraction du code historique (aucune modification d'app.js)
const grab = (re, what) => { const m = app.match(re); assert.ok(m, `introuvable dans app.js : ${what}`); return m[0]; };
const fontsSrc = grab(/var FONTS = \{[\s\S]*?\n  \};/, 'FONTS');
const palSrc = grab(/var DREAM_PALETTES = \[[\s\S]*?\n  \];/, 'DREAM_PALETTES');
const fnSrc = grab(/function hexToRgba[\s\S]*?\n  \}\n(?=\s*applyAppearance\(\);)/, 'applyAppearance');
const legacy = new Function('S', 'document', 'window', 'getBlobUrl', 'loadBlob', `var BLISS = false;\n${fontsSrc}\n${palSrc}\nfunction stDreamPalette(p) { S.ui.dream = Object.assign({}, p); }\n${fnSrc}\nreturn { FONTS, DREAM_PALETTES, applyAppearance, hexToRgba, lumOf, mixHex };`);

// --- les catalogues copiés dans le module sont identiques à ceux d'app.js
const probe = legacy({ ui: {} }, {}, {}, () => '', () => null);
assert.deepEqual(JSON.parse(JSON.stringify(FONTS)), JSON.parse(JSON.stringify(probe.FONTS)), 'FONTS a dérivé');
assert.deepEqual(JSON.parse(JSON.stringify(DREAM_PALETTES)), JSON.parse(JSON.stringify(probe.DREAM_PALETTES)), 'DREAM_PALETTES a dérivé');

// --- fonctions de couleur identiques
for (const h of ['#fff', '#315b91', '#F3F4F7', 'zz', '', undefined, '#12345']) {
  assert.equal(hexToRgba(h, 0.5), probe.hexToRgba(h, 0.5)); assert.equal(luminance(h), probe.lumOf(h));
}
assert.equal(mixHex('#f7f0e7', '#ffffff', 0.35), probe.mixHex('#f7f0e7', '#ffffff', 0.35));
assert.equal(Math.round(contrastRatio('#000', '#fff')), 21);

// --- grille de comparaison
const ALL_VARS = ['--dm', '--dm-ink', '--dd', '--dp', '--dpop', '--ink', '--muted', '--ink-in', '--accent', '--accent-soft', '--bg', '--surface', '--surface-alpha', '--bg-overlay', '--bg-image', '--font-body', '--font-head'];
const fakeRoot = () => { const style = new Map(ALL_VARS.map((v) => [v, 'initial'])); const attrs = new Map([['data-dream-palette', 'zzz'], ['data-theme', 'initial']]);
  return { style, attrs, root: { style: { setProperty: (k, v) => style.set(k, v), removeProperty: (k) => style.delete(k) }, setAttribute: (k, v) => attrs.set(k, v), removeAttribute: (k) => attrs.delete(k) } }; };
const old = DREAM_PALETTES.length && [{ main: '#527b70', desk: '#c0d6c9', paper: '#f5f2e8', pop: '#d9a7b2' }, { main: '#9f5578', desk: '#e8b9ca', paper: '#fbf2ed', pop: '#8da9c3' }];
const dreams = [undefined, {}, ...DREAM_PALETTES.map((p) => p[1]), ...old, { main: '#123456', desk: '#abcdef', paper: '#101010', pop: '#ff00ff' }, { main: '#ffffff', desk: '#000', paper: '#ffffff', pop: '#fff' }, { main: '#222' }];
const configs = [];
for (const theme of ['dreamos', 'dark', 'auto', 'light', undefined]) for (const dark of [false, true]) for (const font of ['jakarta', 'lora', 'system', 'inconnue', undefined])
  for (const extra of [{}, { accent: '#9D4E6C' }, { bgColor: '#223344', surfaceColor: '#ffeedd', overlayOpacity: 0.3 }, { wallpaperId: 'wp_abc', overlayOpacity: 0 }, { accent: '', bgColor: '', overlayOpacity: 'x' }])
    for (const dream of theme === 'dreamos' ? dreams : [undefined, DREAM_PALETTES[1][1]]) configs.push({ dark, ui: { theme, font, dream, ...extra } });
let n = 0;
for (const { dark, ui } of configs) {
  const a = fakeRoot(); const S = { ui: JSON.parse(JSON.stringify(ui)) }; const body = new Set();
  const doc = { documentElement: a.root, body: { classList: { add: (c) => body.add(c), remove: (c) => body.delete(c) } } };
  const win = { matchMedia: () => ({ matches: dark }) };
  legacy(S, doc, win, () => 'blob:wp', () => Promise.resolve(null)).applyAppearance();

  const b = fakeRoot(); const plan = computeAppearance(JSON.parse(JSON.stringify(ui)), { prefersDark: dark });
  createThemeManager().apply(b.root, plan);
  if (plan.dataTheme === null) b.attrs.delete('data-theme');
  const lw = a.style.get('--bg-image'); const pw = b.style.get('--bg-image');
  if (plan.hasWallpaper) { assert.equal(lw, 'url("blob:wp")'); assert.equal(plan.wallpaperId, ui.wallpaperId); b.style.set('--bg-image', lw); }
  const where = JSON.stringify({ dark, ui });
  assert.deepEqual([...b.style].sort(), [...a.style].sort(), `variables CSS différentes : ${where}`);
  assert.deepEqual([...b.attrs].sort(), [...a.attrs].sort(), `attributs différents : ${where}`);
  assert.equal(!plan.hasWallpaper && !!ui && ui.theme !== 'dreamos' ? 'no-wallpaper' : '', body.has('no-wallpaper') ? 'no-wallpaper' : '', `classe no-wallpaper : ${where}`);
  if (plan.dream) assert.deepEqual(plan.dream, S.ui.dream, `migration palette : ${where}`);
  n++;
}
// --- audit de contraste et catalogues du manager
const tm = createThemeManager();
assert.equal(tm.palettes().length, 6); assert.equal(tm.fonts().length, 6);
const audit = tm.auditContrast({ dream: DREAM_PALETTES[0][1] });
assert.equal(audit.length, 3); assert.ok(audit.every((x) => typeof x.ratio === 'number'));
assert.ok(!/themeManager|theme-engine/.test(app), 'app.js ne dépend pas du Theme Manager');
console.log(`phase3_3 : OK (${n} configurations comparées au code historique)`);
