// Phase 3.11 — module Documentation : logique pure équivalente au code d'app.js (code réel extrait), hôte absent / engagé
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installDocumentationHost } from '../dreamOS/documentation/documentation-host.js';
import { createDocumentationEngine } from '../dreamOS/documentation/documentation-engine.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const hostSrc = grab(/  function docHost\(\)[^\n]*\n/, 'docHost') + '\n';
const helperSrc = grab(/  function docsStore\(\)[\s\S]*?\n  function docmDiscard[^\n]*\n/, 'docsStore..docsReplace');
const viewSrc = grab(/  function viewDocsRaw\(\) \{[\s\S]*?\n  \}\n/, 'viewDocsRaw');
const igSrc = grab(/  async function igToDoc\(\)\{[\s\S]*?\n  \}\n/, 'igToDoc');
const saveSrc = grab(/    else if \(a === 'docSave'\) \{[\s\S]*?(?=\n    else if \(a === 'docDel'\))/, 'docSave').replace("    else if (a === 'docSave') {", '{');
const delSrc = grab(/    else if \(a === 'docDel'\) \{[\s\S]*?(?=\n    else if \(a === 'ideaAdd'\))/, 'docDel').replace("    else if (a === 'docDel') {", '{');
const mediaSrc = grab(/    if \(t\.id === 'docMediaIn' && t\.files[\s\S]*?\n      return;\n    \}\n/, 'docMediaIn');
const mk = (body, args) => new Function(...args, `${hostSrc}${helperSrc}\nreturn (async function(){ ${body} }).call(this);`);
const ARGS = ['window', 'S', 'uid', 'toast', 'keep', 'render', 'Date', 'saveBlob', 'shrink', 'deferDelete', 'IDB', 'b', 't', 'ig', 'esc', 'gkey', 'libHost', 'getBlobUrl', 'ico', '$'];

const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o));
const NOW = 1_800_000_000_000;
function world(withHost) {
  const win = {}; const log = [];
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installDocumentationHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); assert.equal(reg.ownerOf('logic', 'documentation-engine'), 'documentation'); }
  return { win, log };
}
const FakeDate = class extends Date { static now() { return NOW; } };
async function run(withHost, st, scenario) {
  const { win, log } = world(withHost); const S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  const ctx = { window: win, S, uid, toast: (m) => log.push(['toast', m]), keep: (k, v) => log.push(['save', k, JSON.stringify(v)]), render: () => log.push(['render']), Date: FakeDate,
    saveBlob: async (id, b) => log.push(['blob', id, b && b.k]), shrink: async (f) => ({ k: 'shrunk:' + f.name }), deferDelete: (msg, undo, done) => { log.push(['defer', msg]); undo(); log.push(['undone', JSON.stringify(S.docs)]); done(); }, IDB: { del: (id) => log.push(['idbdel', id]) },
    b: { dataset: { i: String(scenario.i ?? 0) } }, t: { id: 'docMediaIn', value: 'x', files: scenario.files }, ig: S.ig, esc: (x) => '«' + String(x ?? '') + '»', gkey: (x) => String(x).toLowerCase(), libHost: () => null, getBlobUrl: (id) => (id.length % 2 ? 'blob:' + id : ''), ico: (n) => '[' + n + ']', $: () => null };
  const bind = (src) => mk(src, ARGS).bind({}, ...ARGS.map((k) => ctx[k]));
  const out = {};
  if (scenario.kind === 'view') { const f = new Function(...ARGS, `${hostSrc}${helperSrc}\n${viewSrc}\nreturn viewDocsRaw();`); out.html = f(...ARGS.map((k) => ctx[k])); }
  if (scenario.kind === 'save') { S.ret = await bind(`var a='docSave';var r=(function(){ ${saveSrc} })(); return r;`)(); }
  if (scenario.kind === 'del') { await bind(`var a='docDel'; var rd = (function(){ ${delSrc} })();`)(); }
  if (scenario.kind === 'media') { await bind(`${mediaSrc}`)(); }
  if (scenario.kind === 'ig') { await new Function(...ARGS, `${hostSrc}${helperSrc}\n${igSrc}\nreturn igToDoc();`)(...ARGS.map((k) => ctx[k])); }
  return JSON.stringify({ S: { docs: S.docs, docDraft: S.docDraft, docEditorOpen: S.docEditorOpen, busy: S.busy, ig: S.ig }, log, out, n });
}
const pick = (r, a) => a[Math.floor(r() * a.length)];
function state(r) {
  const media = () => Array.from({ length: Math.floor(r() * 3) }, (_, i) => ({ id: 'docm_' + i + pick(r, ['', 'ab']), type: pick(r, ['video', 'image']) }));
  return { docs: Array.from({ length: Math.floor(r() * 5) }, (_, i) => ({ id: 'd' + i, title: pick(r, ['Montage', 'Point <b>', '']), category: pick(r, ['Technique', 'Autre', '', undefined]), content: pick(r, ['', 'texte & plus']), media: r() < .8 ? media() : undefined, created: NOW - Math.floor(r() * 4e10) })),
    docDraft: { title: pick(r, ['', ' ', '  Titre  ', 'T']), category: pick(r, ['Technique', 'Astuce Tricot', 'Autre']), content: pick(r, ['', ' ', 'corps']), media: r() < .5 ? [] : media() },
    docEditorOpen: r() < .6, docSearch: r() < .3, docQ: pick(r, ['', 'mont', ' zz ', 'a']),
    ig: { blob: r() < .8 ? { k: 'vid' } : null, title: pick(r, ['', '  Ma vidéo ', undefined, 'Titre']), src: 'https://ex.com/x', saved: false }, busy: '' };
}
let checks = 0;
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed), st = state(r);
  const files = Array.from({ length: Math.floor(r() * 4) + 1 }, (_, i) => ({ name: 'f' + i, type: pick(r, ['video/mp4', 'image/png', 'image/jpeg', 'application/pdf', '', 'video/']) }));
  for (const sc of [{ kind: 'view' }, { kind: 'save' }, { kind: 'del', i: Math.floor(r() * 7) }, { kind: 'media', files }, { kind: 'ig' }]) {
    const a = await run(false, st, sc), b = await run(true, st, sc);
    assert.equal(b, a, `${sc.kind} seed ${seed}`); checks++;
    if (sc.kind === 'del') { const doc = st.docs[sc.i]; const dels = JSON.parse(a).log.filter((l) => l[0] === 'idbdel').map((l) => l[1]); assert.deepEqual(dels, doc && doc.media ? doc.media.map((m) => m.id) : [], `médias supprimés avec l'article ${seed}`); checks++; }
    if (sc.kind === 'media') { const L = JSON.parse(a).log.filter((l) => l[0] === 'blob'); assert.equal(L.length, files.length, 'un blob écrit par fichier'); assert.ok(L.every((l) => /^docm_u\d+$/.test(l[1])), 'identifiants docm_'); checks++; }
    if (sc.kind === 'ig' && st.ig.blob) { const L = JSON.parse(a).log.filter((l) => l[0] === 'blob'); assert.equal(L.length, 1); assert.match(L[0][1], /^docm_u\d+$/); checks++; }
  }
}
// cas dirigés
const eng = createDocumentationEngine();
assert.deepEqual([...eng.CATEGORIES], ['Technique', 'Tutoriel Vidéo', 'Fils & Échantillons', 'Astuce Tricot', 'Autre']);
assert.equal(eng.draftIsEmpty({ title: ' ', content: '', media: [] }), true); assert.equal(eng.draftIsEmpty({ title: '', content: 'x', media: [] }), false); assert.equal(eng.draftIsEmpty({ title: '', content: '', media: [{}] }), false);
assert.equal(eng.buildPost({ title: ' ', category: 'Autre', content: 'c', media: [] }, 'i', 5).title, 'Article sans titre');
assert.equal(eng.buildVideoPost({ title: '', src: 's' }, 'm', 'i', 5).title, 'Vidéo téléchargée'); assert.equal(eng.buildVideoPost({ title: 'T', src: 's' }, 'm', 'i', 5).content, 'Source : s');
assert.equal(eng.isVideoFile({ type: 'video/mp4' }), true); assert.equal(eng.isVideoFile({ type: 'image/png' }), false); assert.equal(eng.isVideoFile({ type: 'xvideo/' }), false);
assert.equal(eng.categoryOf({}), 'Note'); assert.equal(eng.reinsertIndex(5, 2), 2); assert.equal(eng.reinsertIndex(1, 4), 1);
const code = fs.readFileSync(path.join(root, 'dreamOS/documentation/documentation-engine.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, '');
for (const bad of [/localStorage/, /indexedDB/, /\bdocument\b/, /\bwindow\b/, /\bfetch\(/, /\$\(/]) assert.ok(!bad.test(code), 'accès interdit : ' + bad);
console.log('phase3_11 OK —', checks, 'comparaisons de scénarios complets');
