// Jalon 5.2 : barre du haut Bliss (aperçu opt-in). Extrait le vrai code d'app.js.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), idx=fs.readFileSync('index.html','utf8'), css=fs.readFileSync('theme/components.css','utf8');
const a=app.indexOf('function blissIco'), b=app.indexOf('function tabbar()');
assert.ok(a>0&&b>a);
const src=app.slice(a,b);
const make=(tab)=>new Function('S','esc',src+';return {top:blissTopbar(),nav:blissBottomNav()};')({tab},x=>String(x).replace(/[&<>"]/g,''));
const dest=h=>[...h.matchAll(/data-v="([a-z]+)"/g)].map(m=>m[1]);
const tabs=['lib','det','add','fav','find','pj','pjd','calc','doc','idea','set'];
const cur=h=>[...h.matchAll(/<button[^>]*data-v="([a-z]+)"[^>]*aria-current="page"/g)].map(m=>m[1]);
const known=new Set(['lib','pj','calc','doc','idea','set','find','add','fav']);
for(const t of tabs){
  const {top,nav}=make(t);
  for(const d of [...dest(top),...dest(nav)]) assert.ok(known.has(d),'destination inconnue '+d);
  // toutes les destinations de l'ancienne barre restent atteignables
  const all=new Set([...dest(top),...dest(nav)]);
  for(const d of ['lib','pj','calc','doc','idea','set','find','add','fav']) assert.ok(all.has(d),'inaccessible: '+d+' sur '+t);
  // chaque bouton sans texte visible a un aria-label
  for(const m of (top+nav).matchAll(/<button\b[^>]*>(.*?)<\/button>/g)){ const txt=m[1].replace(/<svg.*?<\/svg>/g,'').trim(); if(!txt) assert.match(m[0],/aria-label="[^"]+"/,'icône sans nom: '+m[0].slice(0,80)); }
  assert.ok(!/style=|#[0-9a-f]{3,6}\b|Synchronisé/i.test(top+nav));
  assert.match(top,/Données locales/);
}
// page courante
const exp={lib:'lib',det:'lib',add:'lib',fav:'lib',pj:'pj',pjd:'pj',idea:'idea',calc:'calc',set:'set'};
for(const [t,e] of Object.entries(exp)){ const {nav}=make(t); assert.deepEqual(cur(nav),[e],'nav courante '+t); }
assert.deepEqual(cur(make('doc').nav),[]);
// aperçu opt-in : rien en mode normal
assert.match(app,/function tabbar\(\) \{\n    if \(BLISS\) return blissBottomNav\(\);/);
assert.match(app,/if \(BLISS\) \{ var tpb/);
assert.match(app,/BLISS = \(function\(\)[\s\S]*?localStorage\.getItem\('wp_bliss_preview'\) === '1'/);
assert.match(idx,/<header id="topbar" hidden><\/header>/);
assert.equal(idx.includes('components.css'),false,'components.css chargé seulement en aperçu');
assert.match(app,/\['theme\/tokens\.css', 'theme\/fonts\.css', 'theme\/components\.css'\]\.forEach/);
// CSS : pas de hex/!important, cibles ≥ 44 px
assert.equal(/!important|#[0-9a-fA-F]{3,6}\b/.test(css),false);
assert.match(css,/\.dos-topbar \.dos-topbar__wide \{ display: none; \}/);
console.log('jalon5_2 OK');
// 5.13 : recherche dans la barre, bouton loupe réservé au mobile, Entrée → onglet Recherche
{
  const a=fs.readFileSync('app.js','utf8'), c=fs.readFileSync('theme/components.css','utf8');
  assert.match(a,/id="tbq" placeholder="Rechercher…"/);
  assert.match(a,/replace\('class="dos-btn dos-btn--icon"', 'class="dos-btn dos-btn--icon dos-topbar__narrow"'\)/);
  assert.match(a,/e\.key === 'Enter' && e\.target && e\.target\.id === 'tbq'\) \{ e\.preventDefault\(\); S\.fq = e\.target\.value; S\.tab = 'find'/);
  assert.match(a,/dos-counters__ico">' \+ blissIco\(\{ attente: 'chrono', wip: 'wip', termine: 'star' \}/);
  assert.ok(/\.dos-topbar__tabs \.dos-tabs > button \{ flex: 1; \}/.test(c));
  const t=make('lib').top; assert.ok(t.includes('id="tbq"')); assert.ok(/dos-topbar__narrow[^>]*data-v="find"|data-v="find"[^>]*dos-topbar__narrow/.test(t)||t.includes('dos-topbar__narrow'));
}
