// Jalon 5.3 : Bibliothèque en aperçu Bliss ; mêmes actions que l'ancien rendu, ancien rendu intact par défaut.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8');
const fn=(name)=>{ const i=app.indexOf('  function '+name+'('); assert.ok(i>0,name); const j=app.indexOf('\n  }\n',i); return app.slice(i,j); };
const acts=s=>new Set([...s.matchAll(/data-act="([A-Za-z]+)"(?: data-v="([^"]*)")?/g)].map(m=>m[1]+(m[2]!==undefined?'|'+m[2]:'')));
const acts0=s=>new Set([...s.matchAll(/data-act="([A-Za-z]+)"/g)].map(m=>m[1]));
// carte : branche Bliss = bloc "if (BLISS) {...}" ; ancienne = le reste
for(const name of ['cardHtml','viewLib','listHtml']){
  const f=fn(name); const m=f.match(/if \(BLISS(?: && [^)]*)?\)/); assert.ok(m,name+': pas de branche BLISS');
}
{ const f=fn('cardHtml'); const i=f.indexOf('if (BLISS) {'), j=f.indexOf("return '<div class=\"pcard\">'"); const b=f.slice(i,j), o=f.slice(j);
  assert.deepEqual([...acts(b)].sort(),[...acts(o)].sort(),'cardHtml : actions identiques'); }
{ const f=fn('viewLib'); const i=f.indexOf('if (BLISS) {'), j=f.indexOf('var collapseBar'); const b=f.slice(i,j), o=f.slice(j);
  const ab=acts0(b), ao=acts0(o); for(const a of ao) assert.ok(ab.has(a)||a==='collapseAll'||a==='expandAll'||a==='addF','viewLib : action perdue '+a);
  for(const a of ['goPj','fStatus','grp','collapseAll','expandAll','addF']) assert.ok(acts0(b+fn('folderToolsBliss')).has(a),'viewLib bliss manque '+a);
  assert.match(b,/id="q"/); assert.ok(b.includes('En cours (WIP)')); assert.equal(/Synchronisé/.test(b),false); }
{ const f=fn('listHtml'); assert.equal((f.match(/for="restoreIn2"/g)||[]).length,2,'label de restauration dans les 2 rendus'); assert.equal((f.match(/id="restoreIn2"/g)||[]).length,2,'input de restauration dans les 2 rendus');
  for(const a of ['resetFilters']) assert.ok(f.split('if (!S.patterns.length)')[0].includes(a)); }
// l'ancien viewLib est resté tel quel (ancienne branche = après le bloc Bliss)
const v=fn('viewLib'); assert.ok(v.includes('<div class="stats">')&&v.includes('class="search" id="q"'));
// pas de style en ligne hors largeur dynamique, pas de classes anciennes dans les branches Bliss
const bl=[fn('folderToolsBliss'), fn('cardHtml').slice(fn('cardHtml').indexOf('if (BLISS) {'), fn('cardHtml').indexOf("return '<div class=\"pcard\">'")), v.slice(v.indexOf('if (BLISS) {'), v.indexOf('var collapseBar'))].join('');
assert.equal(/style="(?!width:)/.test(bl),false,'style en ligne');
assert.equal(/class="(btn|chip|seg|stat|stage|pcard|in|note|card)[ "]/.test(bl),false,'ancienne classe dans la branche Bliss');
// 5.3b : groupes. groupHead : branche Bliss = jusqu'à « var groupIcon » ; ancien = après
{ const f=fn('groupHead'); const i=f.indexOf('if (BLISS) {'), j=f.indexOf('var groupIcon'); assert.ok(i>0&&j>i);
  const b=f.slice(i,j), o=f.slice(j); assert.deepEqual([...acts(b)].sort(),[...acts(o)].sort(),'groupHead : actions identiques');
  assert.match(b,/aria-expanded/); assert.match(b,/id="renameIn"/); assert.match(b,/data-stop="1"/);
  assert.equal(/<div class="gh"|role="button"/.test(b),false,'pas de faux bouton');
  assert.equal(/style="/.test(b),false); assert.equal(/class="(btn|chip|row|in|gh)[ "]/.test(b),false,'ancienne classe'); }
{ const f=fn('listHtml'); const i=f.indexOf("if (BLISS) return '<div class=\"dos-groups\">'"); assert.ok(i>0,'branche groupes');
  const j=f.indexOf("return '<div class=\"library-groups"); const b=f.slice(i,j);
  assert.match(b,/groupHead\(g\)/); assert.match(b,/isGroupCollapsed\(g\)/); assert.match(b,/favFirst\(g\.ps\)\.map\(cardHtml\)/); assert.match(b,/Auteurs favoris/); assert.match(b,/Autres auteurs/);
  assert.equal(/class="(?:[^"]*\s)?(library[\w-]*|pgrid|favhead|sub|gh)[ "]/.test(b),false); }
// 5.4 : Projets (liste + carte). Île des WIP inchangée.
{ const f=fn('pjCardHtml'); const i=f.indexOf('if (BLISS) {'), j=f.indexOf("return '<div class=\"pcard\"><button class=\"cover\"");
  assert.ok(i>0&&j>i); const b=f.slice(i,j), o=f.slice(j);
  for(const a of ['openPj','pjStep','viewPdf']) assert.ok(acts0(b).has(a),'carte projet : '+a);
  for(const a of acts0(o)) assert.ok(acts0(b).has(a), 'carte projet : action perdue '+a);
  assert.match(b,/data-v="termine"/); assert.match(b,/data-v="wip"/); assert.match(b,/data-pj=/); assert.equal(/style="|class="(?:[^"]*\s)?(btn|chip|pcard|cover|ptitle|sub)[ "]/.test(b),false);
  assert.match(b,/STAGE_ONE\[st\]/); }
{ const f=fn('viewPj'); const i=f.indexOf('if (BLISS) return'); assert.ok(i>0); const j=f.indexOf("return '<div class=\"top top-clear\""); const b=f.slice(i,j), o=f.slice(j);
  for(const a of ['newPj','pjStage']) assert.ok(acts0(b).has(a),'viewPj : '+a);
  assert.match(b,/islandNoteHtml/); assert.match(b,/islandFolderHtml/);
  assert.ok(f.slice(0,i).includes('islandClose'),'vue île inchangée (avant la branche Bliss)');
  assert.match(b,/STAGE_ONE\[x\[0\]\]/); assert.equal(/Synchronisé/.test(b),false); assert.equal(/class="(?:[^"]*\s)?(btn|chip|seg|top|empty|pgrid)[ "]/.test(b),false); }
// 5.4b : espace projet. Chaque bloc Bliss garde les actions de son jumeau ancien.
{ const f=fn('viewPjd');
  const pairs=[ ['photos', f.indexOf("if (BLISS) h += '<section class=\"dos-panel dos-pj-photos\"><div class=\"dos-panel__head dos-row dos-between\"><h2 class=\"dos-h3\">Photos"), f.indexOf('/* chronomètre */')],
    ['compteur', f.indexOf("if (BLISS) h += '<section class=\"dos-panel dos-pj-counter\"><div class=\"dos-panel__head\"><h2 class=\"dos-h3\">Compteur"), f.indexOf('/* journal */')],
    ['journal', f.indexOf('if (BLISS) {\n      h += \'<section class="dos-panel dos-pj-journal"><div class="dos-panel__head"><h2 class="dos-h3">Journal'), f.indexOf("h += dz(pjDeleteCardHtml(pr)) + '</div>';")] ];
  const splitAt={photos:"    else h += '<div class=\"card stack\">",compteur:"      else h += '<div class=\"card stack\">",journal:'    } else {\n'};
  for(const [n,i,j] of pairs){ assert.ok(i>0&&j>i,'bloc '+n); const blk=f.slice(i,j); const k=blk.indexOf(splitAt[n]); assert.ok(k>0,'jumeau '+n);
    const b=blk.slice(0,k), o=blk.slice(k); assert.deepEqual([...acts(b)].sort(),[...acts(o)].sort(),n+' : actions identiques');
    assert.equal(/style="|class="(btn|card|seg|in|sub|top|icon-btn)[ "]/.test(b),false,n+' : ancienne classe'); }
  const jb=f.slice(pairs[2][1],pairs[2][2]); const jbb=jb.slice(0,jb.indexOf(splitAt.journal)); for(const id of ['pjDraft','pjPhotos','pjEditTs','pjEditText']) assert.ok(jbb.includes('id="'+id+'"'),'id '+id);
  const pb=f.slice(pairs[0][1],pairs[0][2]); assert.ok(pb.slice(0,pb.indexOf(splitAt.photos)).includes('id="pjAddPh"'),'pjAddPh');
  const cb=f.slice(pairs[1][1],pairs[1][2]); assert.ok(cb.slice(0,cb.indexOf(splitAt.compteur)).includes('data-rowcount'),'data-rowcount');
  const hd=f.slice(f.indexOf('var h = BLISS'),f.indexOf('var cv = pjCoverId')); assert.match(hd,/aria-label="Retour aux projets"/); assert.equal(/class="(btn|card|top|icon-btn|in)[ "]/.test(hd.slice(0,hd.indexOf(" :\n"))),false);
  const p0=f.indexOf('var pjHead = BLISS'), ph=f.slice(p0,f.indexOf("</section>' : '';",p0)); assert.equal(/class="(?:[^"]*\s)?(card|btn|sub|row|stack|primary|small)[ "]/.test(ph),false,'pjHead ancienne classe');
  assert.match(f,/STAGE_ONE\[x\[0\]\]/); }
assert.match(app,/querySelectorAll\('\.counter \.big, \[data-rowcount\]'\)/,'mise à jour en direct du compteur');
// 5.4c : convertisseur de classes dz() + appels
{ const i=app.indexOf('  var DZ_MAP'), j=app.indexOf('\n  }\n',app.indexOf('  function dz('))+5; assert.ok(i>0&&j>i);
  const mk=(B)=>new Function('BLISS',app.slice(i,j)+';return dz;')(B);
  const on=mk(true), off=mk(false);
  const src='<div class="card stack"><h3 class="grow">T</h3><button class="btn small primary" data-act="x">a</button><span class="chip mute num">1</span><div class="row card" style="padding:8px"><b class="num">r</b></div><label class="fl grow"><span class="n">n</span><select class="in" data-pj="size"></select></label><div class="pjst" style="grid-template-columns:repeat(2,minmax(0,1fr))"></div><button class="star on" data-act="rate">★</button><div class="timer-big" data-timer="j">0</div><button class="cvtile on" data-act="coverPick" aria-pressed="true"><span class="cvck">✓</span></button><div class="ro">x</div><label class="toggle"></label><div class="stars rrow"><div class="rl"></div></div><div class="cvrow cvgrp"></div><input id="pjCover" type="file" accept="image/*"></div>';
  assert.equal(off(src),src,'identité hors aperçu');
  const o=on(src);
  assert.match(o,/class="dos-panel dos-stackpanel"/); assert.match(o,/<h3 class="dos-h3">/); assert.match(o,/class="dos-btn dos-btn--primary"/); assert.match(o,/class="dos-tag"/);
  assert.match(o,/class="dos-row dos-wrap dos-panel dos-panel--row"/); assert.match(o,/class="dos-stack dos-grow"/); assert.match(o,/class="dos-input"/); assert.match(o,/class="dos-star dos-on"/);
  assert.match(o,/style="grid-template-columns:repeat\(2,minmax\(0,1fr\)\)"/,'style dynamique conservé'); assert.equal(/padding:8px/.test(o),false,'style statique retiré');
  assert.match(o,/id="pjCover" class="dos-sr-only"/);
  for(const c of ['dos-timer','dos-cvtile dos-on','dos-cvck','dos-readonly','dos-check','dos-stars dos-ratingrow','dos-ratinglabel','dos-cvrow dos-cvgrp']) assert.ok(o.includes('class="'+c+'"'),c);
  assert.equal([...src.matchAll(/data-[a-z]+="[^"]*"/g)].map(m=>m[0]).join()===[...o.matchAll(/data-[a-z]+="[^"]*"/g)].map(m=>m[0]).join(),true,'attributs data-* intacts');
  assert.equal(/class="[^"]*\b(card|btn|fl|in|sub|n|stack|row|small|chip|mute)\b/.test(o.replace(/dos-[a-z-]+/g,'')),false,'plus d\'ancienne classe'); }
{ const f=fn('viewPjd');
  for(const x of ['pjCoverCardHtml(pr)','pjStatsHtml(pr, st)','sizeSelectHtml(pr, p)','ratingHtml(pr)','stitchMarkersHtml(pr)','pjTimerCardHtml(pr)','pjDeleteCardHtml(pr)']) assert.ok(new RegExp('dz\\(\\s*'+x.replace(/[()]/g,'\\$&')).test(f),'dz( '+x);
  assert.equal((f.match(/dz\(pjTimerCardHtml\(pr\)\)/g)||[]).length,2); assert.equal((f.match(/dz\(pjDeleteCardHtml\(pr\)\)/g)||[]).length,2);
  assert.match(f,/dz\(st === 'termine' \? roFieldHtml\('Taille des aiguilles'/); assert.match(f,/dz\(roFieldHtml\('Taille tricotée'/); }
// 5.4d : fils, couleurs, inspirations, patron lié
for(const [n,a] of [['yarnRowHtml','y'],['colorBtnHtml','key, c, kind'],['colorPalHtml','key, hex'],['yarnsHtml','pr'],['yarnsLockedHtml','pr'],['plannedColorsHtml','pr'],['inspoHtml','pr'],['patPickHtml','pr, pats'],['pjSubHtml','pr']])
  assert.ok(app.includes('function '+n+'('+a+') { return dz('+n+'Raw('+a+')); }'),'enveloppe dz '+n);
assert.match(app,/btn\.querySelector\('\.cdot, \.dos-cdot'\)/); assert.match(app,/classList\.remove\('dos-none'\)/);
assert.equal((app.match(/querySelectorAll\('\.cpal, \.dos-cpal'\)/g)||[]).length,2);
for(const x of ['patpick-opt, .dos-patpick__opt','patpick-none, .dos-patpick__none','patpick-pop, .dos-patpick__pop','patpick-btn, .dos-patpick__btn']) assert.ok(app.includes(x),'hook '+x);
assert.equal((app.match(/ppRoot\.querySelector\('\.patpick-pop, \.dos-patpick__pop'\)/g)||[]).length,1);
{ const i=app.indexOf('  var DZ_MAP'), j=app.indexOf('\n  }\n',app.indexOf('  function dz('))+5; const dz=new Function('BLISS',app.slice(i,j)+';return dz;')(true);
  const g='<div class="yrow" data-yrow="y1"><div class="yl"><button class="ccbtn" data-act="colorOpen" data-key="y:y1"><i class="cdot none" style="background:#e3a9b8"></i><span data-cname>x</span></button></div><div class="cpal" data-cpal="y:y1" hidden></div><div class="cgrid"><button class="cswatch on" style="background:#fff" data-act="colorSet" data-hex="#fff"></button><label class="cswatch cmore">+<input type="color"></label></div><div class="masonry"><div class="pin inspo-pin"><button class="pin-x" data-act="inspoDel">x</button><div class="pin-body"><p class="sub" style="color:var(--ink)">n</p></div></div></div><button class="pj-lk" data-act="pjGoal">m</button><div class="fl patpick" id="patPick"><button class="in patpick-btn" data-act="patPickOpen"><span class="patpick-cur">c</span></button><div class="patpick-pop" hidden><div class="patpick-list"><button class="patpick-opt on" data-act="patPickSet"></button><div class="sub patpick-none" hidden></div></div></div></div></div>';
  const o=dz(g); assert.equal(dz(o),o,'idempotent');
  for(const c of ['dos-yrow','dos-yline','dos-btn dos-colorbtn','dos-cdot dos-none','dos-cpal','dos-cgrid','dos-swatch dos-on','dos-swatch dos-swatch--more','dos-masonry','dos-pin dos-pin--inspo','dos-pin__x','dos-pin__body','dos-linkbtn','dos-stack dos-patpick','dos-input dos-patpick__btn','dos-patpick__cur','dos-patpick__pop','dos-patpick__list','dos-patpick__opt dos-on','dos-muted dos-patpick__none']) assert.ok(o.includes('class="'+c+'"'),c);
  assert.equal((o.match(/style="background:#[0-9a-f]+"/g)||[]).length,2,'couleurs dynamiques conservées'); assert.equal(/color:var\(--ink\)/.test(o),false);
  assert.ok(o.includes('hidden></div><div class="dos-cgrid"')||o.includes('hidden>'),'hidden conservé'); assert.ok(/id="patPick"/.test(o)); }
// 5.5a : lecteur PDF. Mêmes id / data-act / data-r que le HTML statique.
{ const idx=fs.readFileSync('index.html','utf8'); const vi=idx.indexOf('<div id="viewer"'); const vb=idx.slice(vi, idx.indexOf('<script src="app.js">'));
  const f=fn('blissViewerInit'); const ids=x=>new Set([...x.matchAll(/\bid="([A-Za-z]+)"/g)].map(m=>m[1])); const ac=x=>[...x.matchAll(/data-(act|r)="([^"]+)"/g)].map(m=>m[1]+':'+m[2]).sort();
  const oldIds=ids(vb); oldIds.delete('viewer'); oldIds.delete('vscroll'); oldIds.delete('vrc');
  const nw=ids(f); for(const i of oldIds) assert.ok(nw.has(i),'id perdu '+i);
  assert.deepEqual(ac(f),ac(vb.replace(/<div class="vscroll"[^>]*><\/div>/,'')),'actions du lecteur identiques');
  assert.equal(/class="(icon-btn|btn|vhead|vtitle|vtl|vzb|vrc-[a-z]+|sub)[ "]/.test(f),false,'anciennes classes');
  for(const m of f.matchAll(/<button\b[^>]*>(.*?)<\/button>/g)){ const txt=m[1].replace(/' \+ blissIco\([^)]*\) \+ '/g,'').trim(); if(!txt) assert.match(m[0],/aria-label=/,'bouton sans nom: '+m[0].slice(0,70)); }
  assert.match(f,/data-bliss/);
  const call=app.indexOf('if (BLISS) blissViewerInit();'), bind=app.indexOf("var el = $('#vrc'), menu = $('#vrcMenu')"), top=app.indexOf('var BLISS = ');
  assert.ok(top>0&&top<call&&call<bind,'init du lecteur AVANT la liaison des événements du compteur');
  assert.match(app,/box\.querySelectorAll\('button'\)\.forEach\(function\(b\) \{ b\.classList\.add\('dos-btn', 'dos-btn--chip'\)/); }
console.log('jalon5_3 OK');
