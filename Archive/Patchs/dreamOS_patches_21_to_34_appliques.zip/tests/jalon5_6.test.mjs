// Jalon 5.6 : onglet Idées en aperçu Bliss (wrappers dz, mapping, CSS, crochets).
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), css=fs.readFileSync('theme/components.css','utf8');
// wrappers
assert.match(app,/function viewIdeas\(\) \{ return \(BLISS \? '<div class="dos-pagehead"><h1 class="dos-h1">Mes idées<\/h1><p class="dos-muted">Épinglez vos inspirations, rangez-les en tableaux, reliez-les à un projet\.<\/p><\/div>' : ''\) \+ dz\(viewIdeasRaw\(\)\); \}/);
for(const [w,r] of [['pinHtml','pinHtmlRaw'],['pinSelBar','pinSelBarRaw'],['inspoBannerHtml','inspoBannerRaw']])
  assert.ok(app.includes('function '+w+'('),w), assert.ok(new RegExp('function '+w+'\\([^)]*\\) \\{ return dz\\('+r+'\\(').test(app),'wrapper '+w);
// dz réel
const i0=app.indexOf('  var DZ_MAP'), i1=app.indexOf('  /* Bibliothèques lourdes');
const dz=new Function('BLISS',app.slice(i0,i1)+'\nreturn {dz,DZ_MAP};');
const {dz:f,DZ_MAP}=dz(true), off=dz(false).dz;
const src=[...['pinHtmlRaw','pinSelBarRaw','viewIdeasRaw','inspoBannerRaw','inspoPickBarHtml','inspoSendRowHtml'].map(n=>{const a=app.indexOf('function '+n+'(');return app.slice(a,app.indexOf('\n  }\n',a));})].join('\n');
const olds=new Set([...src.matchAll(/class="([^"]*)"/g)].flatMap(m=>m[1].split(/\s+/)).filter(x=>x&&!/[+'(]/.test(x)));
const html=[...olds].map(c=>`<i class="${c}" data-act="x"></i>`).join('');
assert.equal(off(html),html,'identité hors aperçu');
const out=f(html), outCls=new Set([...out.matchAll(/class="([^"]*)"/g)].flatMap(m=>m[1].split(/\s+/)).filter(Boolean));
for(const c of ['sec','selbar','pin-pick','picked','empty','chips','chip','pin','pin-body','masonry','btn','in','sub','card','row','stack','toggle','grow','primary','danger','on'])
  if(olds.has(c)) assert.ok(!outCls.has(c),'ancienne classe restante : '+c);
assert.equal((out.match(/data-act="x"/g)||[]).length,olds.size,'data-act conservés');
assert.equal(f(f(html)),f(html),'idempotent');
// classes dos- produites => définies
for(const c of outCls) if(c.startsWith('dos-')) assert.ok(css.includes('.'+c),'CSS manquant '+c);
for(const c of ['dos-tag.dos-on','dos-disclosure','dos-selbar','dos-pin__pick','dos-pin--picked','dos-masonry--sm']) assert.ok(css.includes('.'+c),c);
assert.equal((css.match(/^\.dos-masonry \{/gm)||[]).length,1,'masonry unique');
assert.equal(/!important|#[0-9a-fA-F]{3,6}\b/.test(css),false);
// crochets double sélecteur + marqueurs conservés
assert.match(app,/closest\('\.masonry, \.dos-masonry, \.pjph, \.pjcar'\)/);
for(const a of ['ideaAdd','ideaBoard','boardNew','pinSelMode','pinPick','pinBulk','ideaDel','pinBoards','inspoPickDone','inspoPickCancel']) assert.ok(src.includes('data-act="'+a+'"'),a);
console.log('jalon5_6 OK');
