// Jalon 5.9 : écrans restants (Favoris, Recherche, Ajout, Documentation, fiche patron, dialogues) en aperçu Bliss.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), css=fs.readFileSync('theme/components.css','utf8');
assert.ok(app.includes("function viewDocs() { return (BLISS ? '<div class=\"dos-pagehead\"><h1 class=\"dos-h1\">Documentation</h1></div>' : '') + dzp(viewDocsRaw()); }"),'titre Documentation');
for(const [w,r] of [['viewFav','viewFavRaw'],['viewFind','viewFindRaw'],['viewAdd','viewAddRaw'],['viewDet','viewDetRaw']])
  assert.match(app,new RegExp('function '+w+'\\(\\) \\{ return dzp\\('+r+'\\(\\)\\); \\}'),w);
assert.match(app,/el\.innerHTML = dz\('<div class="box" role="/,'dialogue via dz');
assert.match(app,/querySelectorAll\('input,button'\)/,'piège à focus du dialogue intact');
const i0=app.indexOf('  var DZ_MAP'), i1=app.indexOf('  /* Bibliothèques lourdes');
const dzp0=app.slice(app.indexOf('  function dzp('),app.indexOf('\n',app.indexOf('  function dzp(')));
const mk=B=>new Function('BLISS',app.slice(i0,i1)+'\n'+dzp0+'\nreturn {dz,dzp};')(B);
const on=mk(true), off=mk(false);
const html='<div class="top"><button class="icon-btn" data-act="tab" data-v="lib" aria-label="Retour">x</button><h1 class="grow">T</h1></div><h1>U</h1><div class="dropzone" id="pdfDrop"><input id="pdfIn" type="file"></div><article class="blog-post"><div class="blog-content">c</div></article><span class="ai">IA</span><span class="core"></span><div class="seg"><button class="on" data-act="sub" data-v="a">F</button></div><input class="search" id="docQ"><div class="import-files"></div>';
assert.equal(off.dz(html),html);
assert.equal(off.dzp(html),html,'dzp identité hors aperçu');
const o=on.dzp(html);
for(const c of ['top','icon-btn','dropzone','blog-post','blog-content','ai','core','seg','search','import-files']) assert.ok(!new RegExp('class="(?:[^"]*\\s)?'+c+'[ "]').test(o),'reste '+c);
assert.match(o,/<h1 class="dos-h1 dos-grow">T/); assert.match(o,/<h1 class="dos-h1">U/);
for(const k of ['id="pdfDrop"','id="pdfIn"','id="docQ"','data-act="tab"','data-act="sub"','aria-label="Retour"']) assert.ok(o.includes(k),k);
assert.equal(on.dzp(o),o,'idempotent');
const cls=new Set([...o.matchAll(/class="([^"]*)"/g)].flatMap(m=>m[1].split(/\s+/)).filter(c=>c.startsWith('dos-')));
for(const c of cls) assert.ok(css.includes('.'+c),'CSS manquant '+c);
for(const c of ['bliss-preview #dlg .box','dos-dropzone','dos-post','dos-aibadge','dos-seg > button.on']) assert.ok(css.includes(c),c);
console.log('jalon5_9 OK');
