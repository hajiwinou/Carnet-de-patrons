// Jalon 5.7 : Outils en aperçu Bliss.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), css=fs.readFileSync('theme/components.css','utf8');
assert.match(app,/function viewTools\(\) \{ return dz\(viewToolsRaw\(\)\)\.replace\(\/<h1 class="dos-grow">\/g, '<h1 class="dos-h1 dos-grow">'\); \}/);
assert.match(app,/function toolNoteHtml\(\) \{ return dz\(toolNoteRaw\(\)\); \}/);
assert.match(app,/querySelectorAll\('\.calc-res, \.dos-result'\)/);
assert.match(app,/id="cgrid" style="grid-template-columns:repeat\(/,'grille: style conservé par dz');
const i0=app.indexOf('  var DZ_MAP'), i1=app.indexOf('  /* Bibliothèques lourdes');
const mk=B=>new Function('BLISS',app.slice(i0,i1)+'\nreturn dz;')(B);
const f=mk(true), off=mk(false);
const a=app.indexOf('function viewToolsRaw'), z=app.indexOf('\n  }\n',a);
const names=['viewToolGauge','viewToolR3','viewToolRag','viewToolChart','viewToolIg','viewToolCalc','viewToolShortRows','toolNoteRaw','viewToolsRaw'];
let src='';for(const n of names){const p=app.indexOf('function '+n+'(');assert.ok(p>0,n);src+=app.slice(p,app.indexOf('\n  }\n',p));}
const olds=new Set([...src.matchAll(/class="([^"]*)"/g)].flatMap(m=>m[1].split(/\s+/)).filter(x=>x&&!/[+'(]/.test(x)));
for(const c of ['kc-k','kc-big','fn','op','eq','ccell','pcol','hubt']) olds.add(c);
const html=[...olds].map(c=>`<i class="${c}" data-act="x"></i>`).join('');
assert.equal(off(html),html);
const out=f(html), oc=new Set([...out.matchAll(/class="([^"]*)"/g)].flatMap(m=>m[1].split(/\s+/)).filter(Boolean));
for(const c of ['hub','hubt','top','kc','kc-disp','kc-expr','kc-big','kc-pad','kc-k','fn','op','eq','calc-res','scroll-x','ccell','chunk','pcol','ig-prev']) assert.ok(!oc.has(c),'reste '+c);
assert.equal((out.match(/data-act="x"/g)||[]).length,olds.size);
assert.equal(f(out),out);
for(const c of oc) if(c.startsWith('dos-')) assert.ok(css.includes('.'+c),'CSS manquant '+c);
assert.ok(css.includes('.dos-result .big'));
// ids et actions conservés
for(const k of ['kcExpr','kcRes','data-act="kcKey"','data-act="toolSub"','data-act="tnSave"','id="cgrid"']) assert.ok(src.includes(k)||app.includes(k),k);
// grille de la table : le style doit commencer par grid-template-columns pour survivre
assert.match(f('<div id="cgrid" style="grid-template-columns:repeat(3,30px);display:grid"></div>'),/style="grid-template-columns/);
assert.ok(!/style="display/.test(f('<div style="display:none"></div>')));
console.log('jalon5_7 OK');
