// Jalon 5.0 — porte de préparation : thème Bliss, icônes, polices et assets livrés, page de test interne, application non touchée
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8'); const exists = (f) => fs.existsSync(path.join(root, f));
const sw = read('sw.js'); const swList = [...sw.matchAll(/^\s*'([^']+)',?\s*$/gm)].map((m) => m[1]);

// 1. fichiers livrés
for (const f of ['theme/tokens.css', 'theme/components.css', 'theme/fonts.css', 'theme/theme-test.css', 'theme/CLAUDE.md', 'theme-test.html', 'icones/icones-sprite.svg', 'fonts/PixelifySans-Medium.ttf', 'fonts/PixelifySans-SemiBold.ttf', 'fonts/DMSans-Variable.ttf', 'fonts/OFL-PixelifySans.txt', 'fonts/OFL-DMSans.txt']) assert.ok(exists(f), f);
const icons = fs.readdirSync(path.join(root, 'icones')).filter((f) => f.endsWith('.svg') && f !== 'icones-sprite.svg').map((f) => f.replace('.svg', '')).sort();
const sprite = read('icones/icones-sprite.svg'); const symbols = [...sprite.matchAll(/<symbol id="(ic-[^"]+)"/g)].map((m) => m[1].slice(3)).sort();
assert.equal(icons.length, 59); assert.deepEqual(symbols, icons, 'le sprite contient exactement les icônes');

// 2. assets : 41 fichiers (32 icônes PNG + 9 images de l'île), tous listés par le précache, aucun fichier de remplissage
const assets = []; const walk = (d) => fs.readdirSync(path.join(root, d), { withFileTypes: true }).forEach((e) => (e.isDirectory() ? walk(d + '/' + e.name) : assets.push(d + '/' + e.name)));
walk('assets'); assert.equal(assets.length, 41); assert.equal(assets.filter((f) => /Spaceholder/i.test(f)).length, 0);
assert.equal(assets.filter((f) => f.startsWith('assets/island/') && f.endsWith('.webp')).length, 9); assert.equal(assets.filter((f) => f.startsWith('assets/icons/') && f.endsWith('.png')).length, 32);
assert.deepEqual(assets.slice().sort(), swList.filter((f) => f.startsWith('assets/')).sort(), 'assets/ = précache');

// 3. précache : cache v39 ; thème, polices et sprite listés et présents
assert.match(sw, /atelier-tricot-v55/);
for (const f of ['theme/tokens.css', 'theme/components.css', 'theme/fonts.css', 'fonts/PixelifySans-Medium.ttf', 'fonts/PixelifySans-SemiBold.ttf', 'fonts/DMSans-Variable.ttf', 'icones/icones-sprite.svg']) { assert.ok(swList.includes(f), 'précache : ' + f); assert.ok(exists(f), f); }

// 4. règles de code du thème
const strip = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '');
const tokens = strip(read('theme/tokens.css')); const files = { components: strip(read('theme/components.css')), fonts: strip(read('theme/fonts.css')), test: strip(read('theme/theme-test.css')) };
for (const [n, s] of Object.entries(files)) { assert.deepEqual(s.match(/!important/g) || [], [], n + ' : !important'); assert.deepEqual(s.match(/#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\(/g) || [], [], n + ' : couleur en dur'); }
assert.deepEqual(tokens.match(/!important/g) || [], []);
const defined = new Set([...tokens.matchAll(/(--[a-z0-9-]+)\s*:/g)].map((m) => m[1]));
for (const [n, s] of Object.entries(files)) for (const m of s.matchAll(/var\((--[a-z0-9-]+)/g)) assert.ok(defined.has(m[1]), n + ' : variable non définie ' + m[1]);
for (const t of ['bliss', 'doodle', 'classique95', 'pixelrpg']) assert.ok(new RegExp('\\[data-theme="' + t + '"\\]').test(tokens), 'thème ' + t);
{ const sel = tokens.replace(/@media[^{]*\{[\s\S]*?\n\}/g, '').match(/[^{}]+(?=\{)/g).map((x) => x.replace(/\s+/g, ' ').trim()); assert.deepEqual(sel, [':root, [data-theme="bliss"]', '[data-theme="doodle"]', '[data-theme="classique95"]', '[data-theme="pixelrpg"]'], 'tokens.css : seulement des blocs de variables par thème'); }
for (const m of tokens.matchAll(/@media[^{]*\{([\s\S]*?)\n\}/g)) assert.deepEqual(m[1].match(/[^{}]+(?=\{)/g).map((x) => x.trim()), [':root'], 'préférences système : variables seulement');
for (const t of ['doodle', 'classique95', 'pixelrpg']) { const blk = tokens.match(new RegExp('\\[data-theme="' + t + '"\\]\\s*\\{([\\s\\S]*?)\\n\\}'))[1]; assert.deepEqual(blk.match(/^\s*[^-\s{}:][^:]*\{/gm) || [], [], t + ' ne redéfinit que des variables'); }
for (const m of files.fonts.matchAll(/url\('\.\.\/([^']+)'\)/g)) assert.ok(exists(m[1]), 'police : ' + m[1]);
assert.equal((files.fonts.match(/@font-face/g) || []).length, 3); assert.ok(/font-family: 'DM Sans'; font-weight: 400 700/.test(files.fonts)); assert.deepEqual(swList.filter((f) => f.startsWith('themes/bliss/')), [], 'images de l\u2019ancien thème retirées du précache'); assert.ok(/font-display:\s*swap/.test(files.fonts));

// 5. page de test : chaque composant, états, accessibilité, aucun style en ligne sauf largeur dynamique
const page = read('theme-test.html'); const comps = [...new Set([...files.components.matchAll(/\.(dos-[a-z0-9_-]+)/g)].map((m) => m[1]))];
const usedClasses = new Set([...page.matchAll(/class="([^"]+)"/g)].flatMap((m) => m[1].split(/\s+/)));
assert.deepEqual(comps.filter((c) => !usedClasses.has(c)), [], 'composants non montrés'); assert.deepEqual([...usedClasses].filter((c) => c.startsWith('dos-') && !comps.includes(c)), [], 'classes dos- inconnues');
assert.deepEqual((page.match(/style="[^"]*"/g) || []).filter((s) => !/^style="(width:\d+%|background:#[0-9a-f]{6})"$/.test(s)), [], 'styles en ligne');
for (const m of page.matchAll(/<button[^>]*class="[^"]*dos-btn--icon[^"]*"[^>]*>/g)) assert.ok(/aria-label="[^"]+"/.test(m[0]), 'bouton icône sans nom');
const ctrl = page.match(/dos-window__controls">([\s\S]*?)<\/div>/g); assert.ok(ctrl.length >= 3); for (const c of ctrl) for (const b of c.match(/<button[^>]*>/g)) assert.ok(/aria-label="[^"]+"/.test(b), 'bouton de fenêtre sans nom');
for (const m of page.matchAll(/#(ic-[a-z0-9]+)"/g)) assert.ok(symbols.includes(m[1].slice(3)), 'icône inconnue ' + m[1]);
assert.equal((page.match(/<use /g) || []).length - symbols.length > 0, true); assert.ok(page.includes('En cours (WIP)')); assert.equal(/Synchronisé/.test(page.replace('on n’écrit pas « Synchronisé »', '')), false);
for (const s of ['waiting', 'wip', 'done']) assert.ok(page.includes('data-status="' + s + '"')); for (const s of ['local', 'syncing', 'offline', 'conflict', 'error']) assert.ok(page.includes('data-state="' + s + '"'));
assert.ok(/<html[^>]*data-theme="bliss"/.test(page)); assert.equal(/fonts\.googleapis/.test(page), false, 'la page de test n\u2019appelle plus Internet pour ses polices');

// 6. (5.0) index.html ne chargeait pas le thème ; depuis 5.1 il le charge : voir jalon5_1.test.mjs
console.log('jalon5_0 OK — thème, 59 icônes, polices, 41 assets, page de test (' + comps.length + ' composants)');
