# Inventaire app.js (généré — Phase 3.0)

- sha256 : `bd69480a8cbaad02…` · 7338 lignes · 660 déclarations de fonctions (622 de premier niveau)
- Répartition heuristique par plage de lignes (voir `RANGES` dans tools/audit-app.mjs).

| Module cible | Fonctions | Lignes | Appels vers d'autres modules |
|---|---:|---:|---:|
| engine:event-handlers | 23 | 1449 | 296 |
| projects | 135 | 697 | 62 |
| pdf-reader | 47 | 597 | 125 |
| patterns:views | 28 | 559 | 30 |
| patterns:fiche-ai | 53 | 518 | 79 |
| tools | 37 | 513 | 56 |
| service:backup | 28 | 378 | 46 |
| library | 17 | 286 | 24 |
| service:storage | 9 | 240 | 0 |
| service:media | 5 | 237 | 1 |
| service:ai | 30 | 201 | 23 |
| downloads | 4 | 191 | 1 |
| core:loader | 5 | 183 | 0 |
| settings | 21 | 174 | 27 |
| patterns:import-text | 60 | 165 | 20 |
| patterns:import-pdf | 13 | 135 | 1 |
| settings:theme | 59 | 134 | 32 |
| legacy:bridge | 4 | 113 | 22 |
| settings:lock | 3 | 112 | 3 |
| patterns:delete-folders | 12 | 112 | 5 |
| documentation | 11 | 102 | 25 |
| patterns:schema | 1 | 101 | 5 |
| service:notifications | 6 | 52 | 6 |
| core:utils | 6 | 47 | 7 |
| service:dialogs | 5 | 31 | 1 |

## Gestionnaires d'événements globaux
- l.933 `#unlockBtn` · click
- l.934 `#unlockInput` · keydown
- l.1071 `document` · visibilitychange
- l.1155 `#dlg` · click
- l.1156 `document` · keydown
- l.3731 `#vscroll` · pointerdown
- l.3790 `document` · visibilitychange
- l.3865 `#vscroll` · click
- l.4958 `document` · keydown
- l.5299 `document` · keydown
- l.6207 `document` · click
- l.6211 `document` · input
- l.6400 `document` · change
- l.6598 `document` · toggle
- l.6603 `document` · click
- l.7172 `document` · keydown
- l.7181 `document` · dragover
- l.7185 `document` · dragleave
- l.7189 `document` · drop

## Actions du gestionnaire de clic (168 distinctes ; classement heuristique par nom puis par appel, à valider)
- **dialogs** (2) : dlgYes, dlgNo
- **settings** (10) : dreamMin, dreamMax, dreamClose, testAi, dreamPal, setAccent, resetColors, lockNow, fullBackup, zip
- **navigation/engine** (5) : tab, open, back, grp, cancel
- **tools** (10) : toolSub, kcKey, gridSave, gridSaveNew, gridNew, gridOpen, gridDel, gridPng, ctool, cclear
- **downloads** (6) : igGo, igNew, igDevice, igDoc, igPick, igTest
- **projects** (47) : goPj, pjStage, tmToggle, tmReset, tmLog, islandBack, rate, islandReasonsToggle, colorOpen, colorSet, inspoFromIdeas, inspoPickDone, inspoPickCancel, inspoDel, newPj, newProjFor, openPj, pjStep, undoPj, pjRows, pjGoal, pjXSet, pjGoalDrop, devAge, devReset, islandOpen, islandClose, islandAck, pjEditEntry, pjEditCancel, pjEditSave, yarnInc, yarnAdd, yarnDel, pjAddNote, pjDelEntry, pjDelEntryNo, pjDelEntryYes, pjCar, pjPhotoDel, pjCoverDel, patPickOpen, patPickSet, pjDel, pjDelNo, pjDelYes, stage
- **library** (16) : ideaBoard, pinSelMode, pinPick, pinPickAll, pinPickNone, pinBulk, pinBoards, boardNew, boardRen, boardDel, lightbox, lbClose, lbPrev, lbNext, ideaAdd, ideaDel
- **indéterminé** (26) : plannedColorAdd, plannedColorDel, coverPick, rgRun, cell, toggleGrp, collapseAll, expandAll, clearWallpaper, setPw, removePw, copySr, undoStage, fileAuthor, dupOk, chip, paste, favAuth, tnSave, favPat, addF, renSave, viewPdf, addOpt, delPhoto, file
- **documentation** (5) : docFind, docSearch, docToggleEditor, docSave, docDel
- **engine** (12) : fStatus, fStage, bkHide, fDiff, resetFilters, toggleEdit, setActiveSize, tv, renF, renCancel, delAsk, delNo
- **patterns** (14) : undoDel, dupBoth, dupNo, dupBack, dupAllBoth, dupAllNew, dupAllOld, dupKeepOld, dupKeepNew, delF, autoAuthor, autoGarment, delOpt, delYes
- **service** (1) : resultPhoto
- **pdf-reader** (14) : sub, vclose, vzoomin, vzoomout, vmark, vhl, vsm, pdfNoteClear, pdfNoteSave, aiFill, aiRe, aiVisual, aiPhoto, aiRead

## Préfixes d'identifiants média réellement utilisés
`docm_`, `f_`, `ideam_`, `t_`, `wp_`

## Préfixes d'identifiants métier (`id: 'x' + uid()`)
`d`, `e`, `i`, `j`, `pc`, `sm`, `y`

## Clés carnet.*
- `carnet.ai` (2 occ.)
- `carnet.boards` (2 occ.)
- `carnet.chart` (8 occ.)
- `carnet.collapsed` (4 occ.)
- `carnet.docs` (3 occ.)
- `carnet.favAuthors` (2 occ.)
- `carnet.folders` (3 occ.)
- `carnet.grids` (3 occ.)
- `carnet.group` (2 occ.)
- `carnet.ideas` (2 occ.)
- `carnet.igApi` (2 occ.)
- `carnet.lastBackup` (2 occ.)
- `carnet.migPj` (2 occ.)
- `carnet.opts` (2 occ.)
- `carnet.patterns` (4 occ.)
- `carnet.pjStage` (3 occ.)
- `carnet.projects` (3 occ.)
- `carnet.pwFail` (1 occ.)
- `carnet.pwHash` (2 occ.)
- `carnet.r3` (2 occ.)
- `carnet.rowStep` (2 occ.)
- `carnet.scratchpad` (4 occ.)
- `carnet.theme` (1 occ.)
- `carnet.ts` (4 occ.)
- `carnet.ui` (5 occ.)
- `carnet.vhl.` (2 occ.)
- `carnet.vmark.` (3 occ.)
- `carnet.vpos.` (3 occ.)
- `carnet.vrcMin` (3 occ.)
- `carnet.vrcPos` (6 occ.)
- `carnet.vsm.` (2 occ.)

## Fonctions les plus volumineuses
- `refreshMeta` l.6201 · 1025 lignes · engine:event-handlers
- `resolveLazyMedia` l.259 · 173 lignes · service:media
- `needZip` l.50 · 145 lignes · core:loader
- `keep` l.440 · 139 lignes · service:storage
- `viewSettingsRaw` l.5381 · 139 lignes · patterns:views
- `viewPjd` l.2473 · 107 lignes · patterns:fiche-ai
- `callSingleProvider` l.1526 · 101 lignes · patterns:schema
- `handleFiles` l.3118 · 97 lignes · pdf-reader
- `lbClose` l.5219 · 88 lignes · patterns:views
- `viewToolGauge` l.4378 · 83 lignes · downloads
- `vrcAdd` l.3655 · 82 lignes · service:backup
- `applyAppearance` l.733 · 80 lignes · settings:lock
- `render` l.6134 · 67 lignes · engine:event-handlers
- `restoreBackup` l.4207 · 63 lignes · tools
- `computeShortRows` l.4270 · 62 lignes · downloads

## Fonctions de premier niveau avec le plus d'appels inter-modules
- `refreshMeta` (engine:event-handlers) → completeness, patPickClose, cur, patchFrom, viewFind, patPickFilter, curPj, pjSetPlannedCount
- `viewPjd` (patterns:fiche-ai) → curPj, viewPj, pjStageOf, patternOf, esc, ico, pjCoverId, blobImg
- `handleFiles` (pdf-reader) → toast, dupKey, findDup, persist, safetySnapshot, storageFailure, render, askDup
- `render` (engine:event-handlers) → syncLockScreen, viewPj, viewPjd, viewFind, viewFav, viewTools, viewDocs, viewIdeas
- `restoreFull` (tools) → patternsReplace, foldersReplace, projectsReplace, migratePjV32, saveProjects, gridsReplace, docsReplace, ideasReplace
- `vrcAdd` (service:backup) → rowsApply, vrcSubUi, saveProjectsQuiet, blissViewerInit, dlgOpen, pjSetRowsTotal, rowStepX, askStepX
- `analyze` (pdf-reader) → toast, proc, render, callAI, prompt1, applyAI, mergeOptions, persist
- `restoreFromMirror` (legacy:bridge) → load, patternsReplace, patKeep, projectsReplace, gridsReplace, foldersReplace, migrateStages, migratePjV32
- `restoreBackup` (tools) → render, needZip, toast, docsReplace, ideasReplace, boardsReplace, toolsSave, patmNewId
- `attachPdf` (pdf-reader) → render, pdfOpen, patEnsureSource, patmIdFor, patmSave, patSetSourcePdf, patSetSourceFileDefault, patSetSourcePages
- `aiVisual` (pdf-reader) → toast, render, callAI, promptVisual, applyAI, applyGrids, applyOptGrids, persist
- `viewToolsRaw` (library) → ico, blissIco, esc, viewToolGauge, viewToolR3, viewToolRag, viewToolChart, viewToolIg
- `pinBulk` (settings) → toast, askName, boardNameCheck, uid, pjStageOf, inspoAddIdeas, saveProjects, askConfirm
- `aiPhoto` (pdf-reader) → toast, render, loadBlob, specText, callAI, applyAI, persist, aiMsg
- `tryUnlock` (core:utils) → pwFailGet, checkPw, pwFailSet, stPwHash, hashPw, syncLockScreen, render
