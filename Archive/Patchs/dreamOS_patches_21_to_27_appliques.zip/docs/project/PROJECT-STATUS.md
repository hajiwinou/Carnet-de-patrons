# PROJECT-STATUS — 21 novembre 2026 · base 4.6.4 + PATCH-2 à 27 (5.9.1, cache v55)

## Décision de l'utilisatrice du 21 novembre 2026 — ordre des travaux (fait autorité sur la v6 §2 et la v8 §2 pour l'ordre)
**D'abord terminer le Jalon 4 au complet, ensuite reprendre exactement le plan prévu avant cette décision.** Rien du plan antérieur n'est abandonné ni modifié : il est seulement décalé après le Jalon 4.
1. **Jalon 4 — Propriété des données, jusqu'au bout** : 4.7a liste des patrons et dossiers (fait) → 4.7b médias de patrons (fait) → 4.7c champs d'un patron (fait) → 4.7d création, analyse par IA et préférences d'affichage (fait) → 4.8 PDF Reader (fait) → 4.9a Réglages : écriture des réglages et du fond d'écran (fait) → 4.9b Réglages : modification des valeurs (fait) → 4.10 bilan du Jalon 4 (fait : `docs/project/JALON-4-BILAN.md`). Règle conservée : aucun schéma de données inventé ; la question « modèle de données de la fiche WIP » reste ouverte et à trancher par l'utilisatrice.
2. **Ensuite, tout le plan d'avant, dans l'ordre de la v8** :
   - Porte de préparation (Jalon 5.0) : base ZIP et manifeste SHA-256 ; restaurer `assets/` (dont `assets/island/`) ; `tokens.css` et `components.css` à côté de l'ancien CSS ; page de test des composants ; vérification PC / tablette / téléphone ; documentation ; retour arrière.
   - Demande explicite à l'utilisatrice de transférer les fichiers UX/UI (message prévu v6 §9).
   - Jalons 5.1 à 5.10 (habillage Bliss écran par écran), puis Jalon 6 (nouvelles fonctions, une à la fois), 7 (autres thèmes), 8 (fin de la propriété des données, revendication des actions, retrait des replis), 9 (validation PC / tablette / téléphone), 10 (synchronisation, puis Mac et Android).
3. Règles inchangées : patches uniquement (PATCH-MANIFEST, README, tests, retour arrière) ; pas de suppression de fonctionnalité ; WIP Island inchangée ; pas de dépendance ajoutée sans accord ; aucune proposition présentée comme validée.

## Jalon actif
**Jalon 5.0 (porte de préparation) fait le 22 nov.** : `assets/`, thème, icônes, polices et maquettes reçus ; page de test interne `theme-test.html` ; décisions dans `docs/project/DECISIONS-THEME.md`. Prochaine étape : 5.1 (charger le thème, puis écran par écran). Décisions du 22 nov. : liste des IA inchangée, voile du fond d'écran et anciennes polices retirés (au 5.8), `themes/bliss/` abandonné, DM Sans hébergée. Question ouverte : modèle de données WIP.

Jalon 4 « Propriété des données » : **repris à la demande de l'utilisatrice (21 nov.)** pour le terminer avant la porte de préparation (jalon 5). 4.7a (liste des patrons et dossiers), 4.7b (médias de patrons), 4.7c (champs d'un patron) et 4.7d (création de patron / dossier, enregistrement de l'analyse, auteurs favoris, groupes repliés, groupement) faits, ainsi que 4.8 (données du lecteur PDF), 4.9a (écriture des réglages et du fond d'écran), 4.9b (modification des valeurs) et 4.10 (bilan : `docs/project/JALON-4-BILAN.md`). **Jalon 4 terminé** ; reste la porte de préparation, bloquée par vos fichiers (`assets/`, pack de thème) et votre décision sur le modèle de données WIP. Aucun schéma de données modifié.

## Fait et vérifié (tests Node exécutés ici, tous verts)
- Jalon 3 : 8 modules métier (3.0 à 3.11).
- Jalon 4 : 4.1 Documentation (articles), 4.2 médias Documentation, 4.3 Library, 4.4 Tools (+ correction de l'import « Plusieurs photos d'un coup »), 4.5 Downloads, **4.6a** liste de projets, **4.6b** médias de projets (`pjc_`, `pjp_`, `pji_` : création, lecture, suppression et référencement testés ; restauration de sauvegarde : écriture groupée de blobs volontairement laissée au futur service de sauvegarde), 4.6c à 4.6e (voir note), **4.7a** liste des patrons et des dossiers (PATCH-2), **4.7b** médias de patrons pdf_ / th_ / img_ (PATCH-4), **4.7c** champs d'un patron (PATCH-5).
- 24 fichiers de tests (phase2, phase3, jalon4), mutations injectées et détectées pour chaque étape.

## Fait mais non vérifié
- `tests/phase2_8_backup_format.test.mjs` : **ignoré ici** (jszip absent, réseau coupé) → à lancer chez l'utilisatrice à chaque livraison.
- `tests/phase2_8_regression.browser.mjs` et tous les parcours manuels dans un navigateur : jamais exécutés ici.
- Rendu réel sans `assets/` : icônes PNG et images de l'île manquantes.

## Commencé
- Jalon 5 — préparation : documentation projet (`docs/project/`), manifeste SHA-256 de la base (`BASE-MANIFEST.sha256`, `tools/manifest.mjs`).

## Bloqué (décision ou fichiers à fournir)
0. Inventaire du modèle actuel d'un projet disponible : `docs/project/WIP-DATA-MODEL-AUDIT.md` (constat, sans proposition) — à valider ou corriger par vos soins.
1. **Fiche WIP / modèle de données** : à arbitrer avant de reprendre **4.6c et Patterns** (décision v8). *Note de transparence :* 4.6c à 4.6e ont été livrées avant ce point d'arrêt. Elles **déplacent les écritures existantes sans changer aucun champ, identifiant ni format** (copie fidèle du code d'origine, vérifiée par comparaison absolue) ; si la fiche WIP change le modèle, seules les commandes de `projects-commands.js` seraient à adapter. Retour arrière : `?projects=legacy`.
2. ~~`assets/`~~ **reçu et restauré le 22 nov.** (41 fichiers, `assets/island/` préservé).
3. ~~Pack de thème~~ **reçu le 22 nov.** (tokens, components, 59 icônes + sprite, CLAUDE.md, 113 maquettes + prototype iPhone). Reste ouvert : modèle de données WIP (voir DECISIONS-THEME §6).

## À faire (ordre de la v8)
1. Porte de préparation : restaurer `assets/` ; charger `tokens.css` / `components.css` à côté de l'ancien CSS ; page interne de test des composants ; vérification PC / tablette / téléphone ; mise à jour de la documentation.
2. Message de demande des fichiers UX/UI (une fois la porte validée).
3. Jalons 5.1 à 5.10 (écran par écran), puis nouveautés (jalon 6), autres thèmes (7), fin de la propriété des données (8), validation (9), synchronisation (10).
4. À confirmer : présence du Desktop Engine dans les maquettes ; liste des fichiers UX/UI.
