# PATCH-27 — Jalon 5.10 audit (5.9.1, cache v55)
Prérequis : PATCH-26. Copier ces fichiers par-dessus le projet.
Contenu : état « avertissement » des notes en aperçu `?bliss=1` ; docs d'audit. Rendu par défaut inchangé.
Test : `for t in tests/*.test.mjs; do node $t; done`
Retour arrière : restaurer les fichiers du PATCH-26 (cache v54).
