# Jalon 5.1 — Thème chargé dans l'application

**Fait** : `index.html` charge `theme/tokens.css` et `theme/fonts.css` **avant** `styles.css`.
**Pourquoi avant** : 7 variables portent le même nom dans l'ancien CSS (`--accent --bg --font-body --ink --line --muted --surface`). L'ancien CSS, chargé après, garde donc la priorité : rien ne change à l'écran. Les nouvelles variables (les ~47 autres) deviennent disponibles pour les écrans convertis.
**Pas encore chargé** : `components.css` (arrivera avec le premier écran converti, la barre du haut).
**Vérifié** : test `tests/jalon5_1.test.mjs` (ordre, précache, pas de `data-theme="bliss"` posé par l'app, 3 mutations détectées) ; capture d'écran 1280×900 avant/après **identique au pixel** (Chrome sans interface).
**Limite** : la capture couvre l'écran de démarrage seulement ; à regarder chez vous sur PC / tablette / téléphone.
**Retour arrière** : retirer les 2 lignes `<link>` de `index.html`, cache v40.
**Collision connue** : quand un écran sera converti, il utilisera des variables à nouveau préfixées/nommées sans conflit ; les 7 noms communs seront traités à la suppression de l'ancien CSS.
