# Jalon 5.2 — Barre du haut (aperçu)

**Activer l'aperçu** : ouvrir l'application avec `?bliss=1` (mémorisé dans la clé `wp_bliss_preview`). **Revenir** : `?bliss=0`. Par défaut rien ne change (capture 1280×900 identique au pixel).
**Ce que montre l'aperçu**
- PC (> 900 px) : logo dreamOS, recherche, favoris, « + Ajouter un patron », Outils, Documentation, Paramètres, pastille « Données locales », puis onglets Bibliothèque / Projets / Idées.
- Téléphone et tablette étroite (≤ 900 px) : logo, recherche, favoris, documentation ; barre du bas : Bibliothèque, Projets, Idées, Outils, Réglages.
- Mêmes actions qu'avant (`data-act="tab"`) : aucun comportement changé ; toutes les anciennes destinations restent atteignables (testé).
**Écarts avec les maquettes, à valider**
1. Mobile : la maquette a un onglet « Plus » dont le contenu n'est pas défini ; j'ai mis « Réglages » à sa place et « Documentation » dans la barre du haut. Rien n'est retiré.
2. PC : la maquette a un champ de recherche dans la barre ; l'aperçu a un bouton loupe qui ouvre l'écran Recherche existant (le champ viendra avec l'écran Recherche).
3. Pastille : « Données locales » (libellé provisoire, jamais « Synchronisé »).
**Limites** : dans l'aperçu le reste de l'écran garde l'ancien habillage (fenêtre bleue), les 7 variables communes (couleur d'accent, polices…) restent celles de l'ancien CSS ; le mélange est normal avant conversion des écrans. `components.css` n'est chargé qu'en aperçu. Tablette 834 px et clavier : à regarder chez vous.
**Après votre validation** : l'aperçu devient le mode normal et l'ancienne barre (`.tabbar`) est retirée du CSS.
**Retour arrière** : retirer `<header id="topbar">`, le bloc `BLISS` d'app.js et les ajouts de components.css ; cache v41.
