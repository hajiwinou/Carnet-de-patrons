# Inventaire app.js (généré — Phase 3.0)

- sha256 : `a5a158e26ac914d0…` · 7165 lignes · 635 déclarations de fonctions (597 de premier niveau)
- Répartition heuristique par plage de lignes (voir `RANGES` dans tools/audit-app.mjs).

| Module cible | Fonctions | Lignes | Appels vers d'autres modules |
|---|---:|---:|---:|
| engine:event-handlers | 11 | 1287 | 286 |
| projects | 135 | 718 | 58 |
| tools | 42 | 586 | 62 |
| pdf-reader | 48 | 565 | 101 |
| patterns:fiche-ai | 49 | 523 | 68 |
| patterns:views | 31 | 510 | 30 |
| service:backup | 27 | 403 | 35 |
| service:ai | 23 | 267 | 13 |
| library | 18 | 256 | 34 |
| service:media | 5 | 237 | 0 |
| service:storage | 11 | 231 | 3 |
| settings | 9 | 213 | 18 |
| settings:theme | 53 | 203 | 25 |
| patterns:import-text | 66 | 193 | 18 |
| core:loader | 4 | 167 | 0 |
| patterns:import-pdf | 13 | 141 | 16 |
| downloads | 4 | 125 | 1 |
| documentation | 6 | 116 | 7 |
| legacy:bridge | 4 | 113 | 22 |
| patterns:delete-folders | 12 | 107 | 8 |
| service:notifications | 3 | 61 | 5 |
| service:dialogs | 8 | 52 | 2 |
| core:utils | 9 | 47 | 6 |
| settings:lock | 6 | 34 | 2 |

## Gestionnaires d'événements globaux
- l.916 `#unlockBtn` · click
- l.917 `#unlockInput` · keydown
- l.1054 `document` · visibilitychange
- l.1138 `#dlg` · click
- l.1139 `document` · keydown
- l.3644 `#vscroll` · pointerdown
- l.3703 `document` · visibilitychange
- l.3778 `#vscroll` · click
- l.4870 `document` · keydown
- l.5203 `document` · keydown
- l.6034 `document` · click
- l.6038 `document` · input
- l.6227 `document` · change
- l.6425 `document` · toggle
- l.6430 `document` · click
- l.6999 `document` · keydown
- l.7008 `document` · dragover
- l.7012 `document` · dragleave
- l.7016 `document` · drop

## Actions du gestionnaire de clic (168 distinctes ; classement heuristique par nom puis par appel, à valider)
- **dialogs** (2) : dlgYes, dlgNo
- **settings** (10) : dreamMin, dreamMax, dreamClose, testAi, dreamPal, setAccent, resetColors, lockNow, fullBackup, zip
- **navigation/engine** (5) : tab, open, back, grp, cancel
- **tools** (10) : toolSub, kcKey, gridSave, gridSaveNew, gridNew, gridOpen, gridDel, gridPng, ctool, cclear
- **downloads** (6) : igGo, igNew, igDevice, igDoc, igPick, igTest
- **projects** (47) : goPj, pjStage, tmToggle, tmReset, tmLog, islandBack, rate, islandReasonsToggle, colorOpen, colorSet, inspoFromIdeas, inspoPickDone, inspoPickCancel, inspoDel, newPj, newProjFor, openPj, pjStep, undoPj, pjRows, pjGoal, pjXSet, pjGoalDrop, devAge, devReset, islandOpen, islandClose, islandAck, pjEditEntry, pjEditCancel, pjEditSave, yarnInc, yarnAdd, yarnDel, pjAddNote, pjDelEntry, pjDelEntryNo, pjDelEntryYes, pjCar, pjPhotoDel, pjCoverDel, patPickOpen, patPickSet, pjDel, pjDelNo, pjDelYes, stage
- **library** (16) : ideaBoard, pinSelMode, pinPick, pinPickAll, pinPickNone, pinBulk, pinBoards, boardNew, boardRen, boardDel, lightbox, lbClose, lbPrev, lbNext, ideaAdd, ideaDel
- **indéterminé** (26) : plannedColorAdd, plannedColorDel, coverPick, rgRun, cell, toggleGrp, collapseAll, expandAll, clearWallpaper, setPw, removePw, copySr, undoStage, fileAuthor, dupOk, chip, paste, favAuth, tnSave, favPat, addF, renSave, viewPdf, addOpt, delPhoto, file
- **documentation** (5) : docFind, docSearch, docToggleEditor, docSave, docDel
- **engine** (12) : fStatus, fStage, bkHide, fDiff, resetFilters, toggleEdit, setActiveSize, tv, renF, renCancel, delAsk, delNo
- **patterns** (18) : undoDel, dupBoth, dupNo, dupBack, dupAllBoth, dupAllNew, dupAllOld, dupKeepOld, dupKeepNew, delF, autoAuthor, autoGarment, aiFill, aiRe, aiVisual, delOpt, aiPhoto, delYes
- **service** (1) : resultPhoto
- **pdf-reader** (10) : sub, vclose, vzoomin, vzoomout, vmark, vhl, vsm, pdfNoteClear, pdfNoteSave, aiRead

## Préfixes d'identifiants média réellement utilisés
`docm_`, `f_`, `ideam_`, `t_`, `wp_`

## Préfixes d'identifiants métier (`id: 'x' + uid()`)
`d`, `e`, `i`, `j`, `pc`, `sm`, `y`

## Clés carnet.*
- `carnet.ai` (2 occ.)
- `carnet.boards` (2 occ.)
- `carnet.chart` (8 occ.)
- `carnet.collapsed` (4 occ.)
- `carnet.docs` (3 occ.)
- `carnet.favAuthors` (2 occ.)
- `carnet.folders` (3 occ.)
- `carnet.grids` (3 occ.)
- `carnet.group` (2 occ.)
- `carnet.ideas` (2 occ.)
- `carnet.igApi` (2 occ.)
- `carnet.lastBackup` (2 occ.)
- `carnet.migPj` (2 occ.)
- `carnet.opts` (2 occ.)
- `carnet.patterns` (4 occ.)
- `carnet.pjStage` (3 occ.)
- `carnet.projects` (3 occ.)
- `carnet.pwFail` (1 occ.)
- `carnet.pwHash` (2 occ.)
- `carnet.r3` (2 occ.)
- `carnet.rowStep` (2 occ.)
- `carnet.scratchpad` (4 occ.)
- `carnet.theme` (1 occ.)
- `carnet.ts` (4 occ.)
- `carnet.ui` (5 occ.)
- `carnet.vhl.` (2 occ.)
- `carnet.vmark.` (3 occ.)
- `carnet.vpos.` (3 occ.)
- `carnet.vrcMin` (3 occ.)
- `carnet.vrcPos` (6 occ.)
- `carnet.vsm.` (2 occ.)

## Fonctions les plus volumineuses
- `refreshMeta` l.6028 · 1025 lignes · engine:event-handlers
- `resolveLazyMedia` l.242 · 173 lignes · service:media
- `needZip` l.33 · 145 lignes · core:loader
- `keep` l.423 · 139 lignes · service:storage
- `viewSettings` l.5283 · 139 lignes · patterns:views
- `callSingleProvider` l.1509 · 101 lignes · service:ai
- `handleFiles` l.3038 · 97 lignes · pdf-reader
- `lbClose` l.5123 · 88 lignes · settings
- `viewToolGauge` l.4291 · 83 lignes · downloads
- `vrcAdd` l.3569 · 81 lignes · service:backup
- `applyAppearance` l.716 · 80 lignes · settings:theme
- `viewPjd` l.2430 · 70 lignes · patterns:fiche-ai
- `render` l.5961 · 67 lignes · engine:event-handlers
- `restoreBackup` l.4120 · 63 lignes · tools
- `computeShortRows` l.4183 · 62 lignes · tools

## Fonctions de premier niveau avec le plus d'appels inter-modules
- `refreshMeta` (engine:event-handlers) → completeness, patPickClose, cur, patchFrom, viewFind, patPickFilter, curPj, pjSetPlannedCount
- `viewPjd` (patterns:fiche-ai) → curPj, viewPj, pjStageOf, patternOf, ico, esc, pjCoverId, blobImg
- `handleFiles` (pdf-reader) → toast, dupKey, findDup, persist, safetySnapshot, storageFailure, render, askDup
- `render` (engine:event-handlers) → syncLockScreen, viewLib, viewAdd, viewPj, viewPjd, viewFind, viewFav, viewTools
- `restoreFull` (tools) → patternsReplace, mergeById, foldersReplace, projectsReplace, migratePjV32, saveProjects, gridsReplace, docsReplace
- `vrcAdd` (service:backup) → rowsApply, vrcStat, vrcSubUi, saveProjectsQuiet, dlgOpen, pjSetRowsTotal, openPdfSheet, rowStepX
- `restoreFromMirror` (legacy:bridge) → load, patternsReplace, patKeep, projectsReplace, gridsReplace, foldersReplace, migrateStages, migratePjV32
- `restoreBackup` (tools) → render, needZip, toast, docsReplace, ideasReplace, boardsReplace, toolsSave, patmNewId
- `attachPdf` (pdf-reader) → render, pdfOpen, patEnsureSource, patmIdFor, patmSave, patSetSourcePdf, patSetSourceFileDefault, patSetSourcePages
- `pinBulk` (settings) → toast, askName, boardNameCheck, uid, pinBoardIds, pjStageOf, inspoAddIdeas, saveProjects
- `viewTools` (library) → ico, esc, viewToolGauge, viewToolR3, viewToolRag, viewToolChart, viewToolIg, viewToolShortRows
- `aiRead` (pdf-reader) → toast, render, renderPages, callAI, sig, patSetTranscript, persist, aiMsg
- `viewDet` (engine:event-handlers) → cur, viewLib, completeness, esc, statusChip, projectsBlock, projectsOf, ico
- `igToDoc` (tools) → docmNewId, docmSave, docHost, docsAdd, uid, render, toast
- `viewSettings` (patterns:views) → provReady, esc, provVision, selected, statOn, islandCfg, pjStageOf
