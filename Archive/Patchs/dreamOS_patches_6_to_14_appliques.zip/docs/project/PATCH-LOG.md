# PATCH-LOG

| Id | Date | Contenu | Base | Empreintes |
|---|---|---|---|---|
| **BASE-4.6.4** | 2026-11-20 | Base ZIP complète (code, tests, docs, outils). **Hors `assets/` et pack de thème, absents** (voir PROJECT-STATUS). | — | `docs/project/BASE-MANIFEST.sha256` |

Les livraisons suivantes sont des **patches** : fichiers nouveaux ou modifiés uniquement, avec `PATCH-MANIFEST.md` (modèle : `docs/project/PATCH-MANIFEST.template.md`), README d'intégration, résultats de tests et retour arrière. Avant application : `node tools/manifest.mjs verify docs/project/BASE-MANIFEST.sha256` doit être propre (ou ne différer que par les patches déjà appliqués).
| **PATCH-1** | 2026-11-21 | Documentation seule : `WIP-DATA-MODEL-AUDIT.md`, statut mis à jour. Aucun code. | BASE-4.6.4 | `PATCH-MANIFEST.md` |
| **PATCH-2** | 2026-11-21 | Jalon 4.7a : Patterns possède la liste des patrons et des dossiers (`patterns-store.js`), 4.7.0, cache v32. | BASE-4.6.4 + PATCH-1 | `PATCH-MANIFEST.md` |
| **PATCH-3** | 2026-11-21 | Documentation seule : ordre des travaux décidé (terminer le Jalon 4, puis reprendre le plan d'avant). Aucun code. | PATCH-2 | `PATCH-MANIFEST.md` |
| **PATCH-4** | 2026-11-21 | Jalon 4.7b : Patterns possède les médias de patrons (`patterns-media.js`), 4.7.1, cache v33. | PATCH-3 | `PATCH-MANIFEST.md` |
| **PATCH-5** | 2026-11-21 | Jalon 4.7c : Patterns modifie lui-même les champs d'un patron (`patterns-commands.js`), 4.7.2, cache v34. | PATCH-4 | `PATCH-MANIFEST.md` |
| **PATCH-6** | 2026-11-21 | Jalon 4.7d : Patterns crée patrons / dossiers, enregistre l'analyse par IA et les préférences d'affichage, 4.7.3, cache v35. | PATCH-5 | `PATCH-MANIFEST.md` |
| **PATCH-7** | 2026-11-21 | Jalon 4.8 : PDF Reader possède l'écriture de ses données (`pdf-reader-store.js`, `pdf-reader-commands.js`), 4.8.0, cache v36. | PATCH-6 | `PATCH-MANIFEST.md` |
| **PATCH-8** | 2026-11-21 | Jalon 4.9a : Settings écrit les réglages et le fond d'écran wp_* (`dreamOS/settings/`), 4.9.0, cache v37. | PATCH-7 | `PATCH-MANIFEST.md` |
| **PATCH-9** | 2026-11-21 | Jalon 4.9b : Settings modifie les valeurs de réglages (`settings-commands.js`), 4.9.1, cache v38. | PATCH-8 | `PATCH-MANIFEST.md` |
| **PATCH-10** | 2026-11-21 | Jalon 4.10 : bilan du Jalon 4 (documentation seule, aucun code). | PATCH-9 | `PATCH-MANIFEST.md` |
| **PATCH-11** | 2026-11-22 | Jalon 5.0 : porte de préparation (assets, thème, icônes, polices, page de test interne, décisions), 5.0.0, cache v39. Application non modifiée. | PATCH-10 | `PATCH-MANIFEST.md` |
| **PATCH-12** | 2026-11-22 | Jalon 5.0.1 : DM Sans hébergée, `themes/bliss/` retiré du précache, décisions du 22 nov. consignées, 5.0.1, cache v40. | PATCH-11 | `PATCH-MANIFEST.md` |
| **PATCH-13** | 2026-11-22 | Jalon 5.1 : `index.html` charge `theme/tokens.css` et `theme/fonts.css` (avant l'ancien CSS). Aucun écran modifié. 5.1.0, cache v41. | PATCH-12 | `PATCH-MANIFEST.md` |
| **PATCH-14** | 2026-11-22 | Jalon 5.2 : barre du haut Bliss en aperçu opt-in (`?bliss=1`), barre du bas mobile, 5.2.0, cache v42. Affichage par défaut inchangé. | PATCH-13 | `PATCH-MANIFEST.md` |
