# Bilan du Jalon 4 — « Propriété des données »

État au 21 novembre 2026 · version 4.9.1 · cache `atelier-tricot-v38` · patches 1 à 9 (+ ce bilan, PATCH-10).
Ce bilan décrit ce qui est mesuré ici (suite Node, registre de modules). **Rien n'a été validé dans un vrai navigateur** : les deux tests locaux (`phase2_8_backup_format`, `phase2_8_regression.browser`) et les vérifications manuelles restent à faire de votre côté.

## 1. Ce que chaque module possède (mesuré avec le vrai registre, tous les hôtes engagés)

| Module | Ressources possédées | Reste à app.js (volontairement) |
|---|---|---|
| Patterns | 10 (patrons, horodatage, dossiers, auteurs favoris, groupes repliés, groupement, médias `pdf_` / `th_` / `img_`, moteur) | restauration groupée des blobs ; migrations au chargement |
| Projects | 7 (projets, étapes, migration, médias `pjc_` / `pjp_` / `pji_`, moteur) | migrations au chargement (`pjMigrate`) ; WIP Island inchangée |
| PDF Reader | 7 (reprise, repère, marqueurs, surlignages, compteur : position et état, moteur) | restauration groupée des positions ; lecture à l'ouverture |
| Settings | 8 (apparence, thème, options, IA, verrou, essais ratés, dernière sauvegarde, fond `wp_*`) | calcul / contrôle de l'empreinte ; normalisation IA au chargement |
| Library, Documentation, Downloads, Tools | toutes leurs clés et médias | secours de Tools (`workAt`, chrono, rangs), `askGoal` |

Deux ressources déclarées ne sont pas à un module de données, et c'est voulu : `logic:search` (Search Manager) et `dom:appearance` (Theme Manager).

## 2. Écritures directes restantes dans app.js (inventaire à jour)
- **Écritures physiques** passées en paramètre aux modules : `keep`, `saveBlob`, `IDB.put` / `IDB.del`, `localStorage` (11 + 8 + 21 + 5 occurrences, toutes dans des fonctions « écrivain » ou des portes de repli).
- **Restauration d'une sauvegarde** : écriture des blobs par lots (`saveBlob(names[i], …)`), des positions du lecteur (`keep(k, data.viewer[k])`) et enregistrements globaux (`saveFolders`, `saveDocs`, `saveIdeas`, `persist`). → Jalon 8 (service de sauvegarde).
- **Migrations au chargement** et normalisation des réglages d'IA : lecture-normalisation à l'ouverture. → Jalon 8.
- **Codes de secours** (module absent ou `?<module>=legacy`) : conservés exprès pour le retour arrière. → retirés au Jalon 8.

## 3. Vérification
- 35 fichiers de tests Node, tous verts ; les 16 tests du Jalon 4 totalisent environ 241 000 comparaisons sur le vrai code d'`app.js` (module absent / engagé / relâché puis réengagé).
- Chaque étape a reçu des mutations injectées (de 10 à 20 par test) ; toutes détectées au final. Des mutants échappés au premier passage ont conduit à renforcer les tests (seuils, ordres, jeux de départ trop peu variés).
- Limite connue : les sites situés dans de très grandes fonctions asynchrones (import, analyse IA, mise à niveau de l'empreinte, compteur de rangs) sont vérifiés par garde-fou statique et par commandes seules, pas exécutés isolément.

## 4. Points de vigilance
- Les étapes 4.6c à 4.6e ont été livrées avant la mise en pause décidée par la documentation v8 ; pas de changement de schéma, retour arrière `?projects=legacy`.
- Le choix du modèle de données de la fiche chantier (WIP) reste **ouvert et à vous** : `docs/project/WIP-DATA-MODEL-AUDIT.md` n'est qu'un inventaire.
- Les identifiants créés par les modules viennent du générateur du bootstrap, différent de celui d'app.js (même format `préfixe + numéro`) ; sans effet sur les données existantes.

## 5. Suite : porte de préparation (avant le Jalon 5)
Bloquée tant que je n'ai pas reçu de votre part : (1) le dossier `assets/` avec `assets/island/` (32 icônes PNG + 9 images de l'île) ; (2) le pack de thème (`tokens.css`, `components.css`, icônes SVG / sprite, `CLAUDE.md`, maquettes) ; (3) votre décision sur le modèle de données de la fiche chantier.
Ensuite : Jalons 5.1 à 5.10 (habillage Bliss), 6 (nouvelles fonctions), 7 (autres thèmes), 8 (fin de la propriété des données, retrait des secours, restauration groupée), 9 (validation PC / tablette / téléphone), 10 (synchronisation, Mac, Android).
