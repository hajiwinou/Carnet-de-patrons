# Décisions sur le thème Bliss rose — réponses de l'utilisatrice du 22 novembre 2026

Ces décisions **priment sur `theme/CLAUDE.md`** là où elles le contredisent (le fichier d'origine est conservé tel que reçu). En cas de doute : demander.

## 1. Sources de vérité (ordre)
1. Les maquettes de l'utilisatrice : 8 dossiers livrés le 22 nov. (01 Bibliothèque et patrons, 02 Projets, 03 Lecteur PDF, 04 Outils, 05 Idées, 06 Réglages / IA / états, 07 Tablette, 08 Icônes et états des contrôles : 113 pages HTML + images + aperçus PDF) et le prototype iPhone navigable (19 pages).
2. **Espace Projets sur iPhone** : la version du prototype `dreamos-iphone-navigable` (`projets.html`) **prime** sur la version iPhone du dossier 02. **Espace Projets sur ordinateur : la version du dossier 02 prime** (et non `ordinateur/projets-ordinateur.html` du prototype). *(Lecture de la consigne du 22 nov. ; à corriger si inexacte.)*
3. Les liens d'artefacts de `CLAUDE.md` (spécification de 36 fiches) ne sont pas lisibles ici : seules les maquettes servent de référence. L'ancien code ne vient qu'en dernier.

## 2. Vocabulaire
- **« Journal »** partout : l'onglet, le champ, « Ajouter au journal » dans les outils (le « Notes remplace Journal » de `CLAUDE.md` est abandonné). Les clés de données ne changent pas.
- Statut des projets : **« En cours (WIP) »** (et non « WIP » seul), En attente, Terminé.
- Pastille d'état des données : libellés provisoires tant que la synchronisation n'existe pas (jamais « Synchronisé » dans l'application ; les maquettes l'affichent, la page de test montre les états `local / syncing / offline / conflict / error`).

## 3. Réglages d'apparence : retraits décidés (à exécuter à l'écran Réglages, jalon 5.8 — pas avant)
Retirés de l'interface, car absents des maquettes ou contraires aux règles du thème :
- thème sombre / automatique (`S.ui.theme`) ;
- couleur d'accent (préréglages et sélecteur : `S.ui.accent`) ;
- couleurs de fond et de surface personnalisées (`S.ui.bgColor`, `S.ui.surfaceColor`) ;
- palettes dreamOS personnalisables (`S.ui.dream`) ;
- les 6 polices actuelles (Plus Jakarta Sans, DM Sans, Lora & Playfair, Times New Roman, Inter & Space Grotesk, système), remplacées par les 4 choix de la maquette (Pixelify Sans + DM Sans, DM Sans partout, Lisible, Système).
Conservés (présents dans les maquettes) : choix du thème (Bliss, Doodle, Classique 95, Pixel RPG), polices (nouveaux choix), fond d'écran (choisir / retirer), verrouillage, IA, sauvegarde, et les nouveaux réglages d'accessibilité (taille du texte S/M/L, réduire les animations, contraste renforcé, ombres des fenêtres — fonctions nouvelles, jalon 6).
**Aucune donnée n'est supprimée** : les clés (`carnet.ui` et le fond `wp_*`) restent lues et sauvegardées ; seul l'affichage des réglages retirés disparaît. L'ancien thème Windows XP bleu (`themes/bliss.css`, `styles.css`, `styles-late.css`) disparaît écran par écran, après validation du nouveau.
**Tranché le 22 nov. (« on retire »)** : le voile du fond d'écran (`S.ui.overlayOpacity`) est retiré de l'interface comme le reste ; une ancienne police enregistrée (ex. « Lora ») n'est plus proposée et est remplacée par le choix par défaut (Pixelify Sans + DM Sans). Les anciennes valeurs restent dans les données, simplement ignorées. À exécuter au 5.8.

## 4. Polices
Pixelify Sans **et DM Sans** sont hébergées dans l'application (`fonts/`, licence OFL ; fichiers reçus le 22 nov.) : le thème Bliss n'a plus besoin d'Internet pour ses polices. L'ancien code (`index.html`) continue de charger ses polices depuis Google Fonts tant que l'ancien habillage existe.

## 5. Fonctions nouvelles (jalon 6, une par une)
Favoris / récents / recherche de la boîte à outils ; thèmes Doodle, Classique 95, Pixel RPG ; réglages d'accessibilité ; nouvelles IA (voir ci-dessous) ; carte Reprendre, file d'imports, note vocale, onglets Marqueurs et Matériel, éditeur de patron.

## 6. Questions encore ouvertes
- **Liste des IA** : *pour le moment on ne fait rien* (réponse du 22 nov.) : la liste actuelle (Gemini, Groq, OpenRouter, OpenAI, OmniRoute) reste telle quelle ; Claude / Grok / ChatGPT seraient des fonctions nouvelles, à reprendre plus tard.
- **Anciens fichiers `themes/bliss/`** (fond d'écran et icônes de l'ancien thème bleu) : **plus nécessaires** (22 nov.) ; retirés du précache. L'ancien `themes/bliss.css` les cite encore : il disparaît avec l'ancien habillage.
- Modèle de données de la fiche chantier (WIP) : la question a été reformulée en langage simple le 22 nov. ; toujours en attente.
