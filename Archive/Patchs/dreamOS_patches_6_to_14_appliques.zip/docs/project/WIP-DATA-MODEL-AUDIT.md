# Inventaire du modèle de données actuel d'un projet (fiche WIP) — constat, aucune proposition

Établi le 21 novembre 2026 à partir du code de la base 4.6.4 (`app.js`, `dreamOS/projects/*`). **Rien n'est inventé ni modifié** : ce document sert à arbitrer « Fiche WIP / 4.6c » (v8, section 11). Clé de stockage : `carnet.projects` (liste de projets) ; médias `pjc_*` `pjp_*` `pji_*`.

| Groupe | Champs lus ou écrits dans le code | Remarque |
|---|---|---|
| Identité | `id` (`j…`), `seq`, `name`, `created`, `patternId` | `patternId` vide = pas de patron lié |
| Étape | `stage` (`attente` / `wip` / `termine`), `stagePrev`, `stageAt{étape→date}`, `workAt` | `workAt` = dernière reprise du travail |
| Matériel | `size`, `needles`, `yarns[{id,name,used,planned,…}]`, `plannedSkeins`, `plannedColors[{id,hex,name,yarn,planned}]`, `plannedYarnId` | `plannedSkeins` et `plannedColors[].planned` se remplacent l'un l'autre |
| Avancement | `rows`, `rowsTotal`, `sub` (objectif de sous-étape), `subDone`, `timer{acc,start}`, `rating` | pas de pourcentage |
| Journal | `log[{id,ts,text,photos[],ms?}]`, `notes` | entrées sans distinction automatique / manuelle (« à préciser » v8) |
| Images | `photos[]`, `cover`, `coverPdf`, `inspo[{id,mediaId,mediaType}|{id,ideaId}]` | médias gérés par `projects-media.js` |
| WIP Island | `islandPin`, `leftIsland`, `islandSince`, `islandSeen`, `islandReasons[]`, `devAge` (simulation), `again` | `devAge` n'existe que pour la simulation de pause |

Points d'écriture : un seul module (`projects-commands.js`, via les portes `pj…` d'`app.js`) pour tous les champs ci-dessus **sauf** : migrations au chargement (`pjMigrate`), repli des Tools (chrono, rangs, sous-étape) et création d'objectif (`askGoal`).

## Questions à trancher (pour vous, pas pour moi)
1. Ce modèle est-il la référence, ou la fiche WIP prévue ajoute / retire / renomme des champs (journal automatique / manuel, WIP Island, compteurs multiples) ?
2. Si le modèle change : en une migration versionnée avec anciennes sauvegardes restaurables (règle non négociable), à planifier avec le jalon 8 ?
