# CHANGELOG

## 5.2.0 — 22 nov. 2026
- Aperçu optionnel de la barre du haut et de la barre du bas Bliss (`?bliss=1` pour activer, `?bliss=0` pour revenir). Par défaut : ancien affichage, capture identique au pixel.
## 5.1.0 — 22 nov. 2026
- Le thème Bliss (variables + polices) est chargé par l'application, avant l'ancien CSS qui garde la priorité : aucun changement visuel (captures identiques).
## 5.0.1 — 22 nov. 2026
- DM Sans hébergée (`fonts/`) ; page de test sans Internet ; images de l'ancien thème (`themes/bliss/`) retirées du précache ; décisions du 22 nov. consignées (`DECISIONS-THEME.md`).
## 5.0.0 — 22 nov. 2026
- 5.0 : restauration de `assets/` ; ajout du thème Bliss (`theme/`), des icônes (`icones/`), de Pixelify Sans (`fonts/`) et de la page de test interne `theme-test.html` ; décisions de l'utilisatrice (`docs/project/DECISIONS-THEME.md`). L'application garde son habillage actuel.
## 4.9.1 — 21 nov. 2026 (bilan)
- 4.10 : bilan du Jalon 4 (`docs/project/JALON-4-BILAN.md`) ; aucun changement de code.
## 4.9.1 — 21 nov. 2026
- 4.9b : Settings modifie lui-même les valeurs de réglages (apparence, palette, île, statistiques, fond d'écran, fournisseurs d'IA, préférences, options).
## 4.9.0 — 21 nov. 2026
- 4.9a : nouveau module Settings (`dreamOS/settings/`) : il écrit les réglages (`carnet.ui`, `carnet.theme`, `carnet.opts`, `carnet.ai`, `carnet.pwHash`, `carnet.pwFail`, `carnet.lastBackup`) et le fond d'écran `wp_*`.
## 4.8.0 — 21 nov. 2026
- 4.8 : le lecteur PDF possède l'écriture de ses données (position de reprise, repère de rang, marqueurs de marge, surlignages, position et état réduit du compteur) et leurs modifications.
## 4.7.3 — 21 nov. 2026
- 4.7d : Patterns crée les patrons (nouveau, restauré depuis une sauvegarde) et les dossiers, renomme un dossier, enregistre `analysis` après l'analyse par IA, et possède les préférences `carnet.favAuthors`, `carnet.collapsed`, `carnet.group`.
## 4.7.2
- 4.7c : champs d'un patron modifiés par le module.
## 4.7.1
- 4.7b : médias de patrons `pdf_` / `th_` / `img_`.
## 4.7.0
- 4.7a : liste des patrons et dossiers.

## 4.6.4 — 20 nov. 2026 (base de référence)
- 4.6e : Projects crée les projets, change l'étape, gère les drapeaux de l'île (`islandPin`, `leftIsland`) et les liens avec les patrons.
## 4.6.3
- 4.6d : champs, fils, couleurs prévues, pelotes prévues, rangs au total, raisons de l'île, abandon d'objectif, simulation de pause.
## 4.6.2
- 4.6c : journal, photos, couverture, inspiration, chrono (remise à zéro / temps ajouté), acquittement de l'île.
## 4.6.1
- 4.6b : médias de projets `pjc_` / `pjp_` / `pji_` (passerelle unique).
## 4.6.0
- 4.6a : liste de projets possédée par le module (+ persistance `pjStage`, `migPj`).
## 4.1 à 4.5
- Documentation (articles, médias), Library (idées, tableaux, médias), Tools (grilles, valeurs d'interface), Downloads (réglages Instagram).
## 3.x
- Huit modules métier en place (strangler, hôtes, tests d'équivalence).
- 2026-11-21 — PATCH-1 : inventaire du modèle de données d'un projet (documentation seule).
- 2026-11-21 — PATCH-2 / 4.7.0 : Patterns autorité d'écriture de la liste des patrons et des dossiers et de leur enregistrement.
- 2026-11-21 — PATCH-3 : documentation de l'ordre des travaux (Jalon 4 complet, puis porte de préparation et jalons 5 à 10).
- 2026-11-21 — PATCH-4 / 4.7.1 : Patterns autorité d'écriture et de suppression des médias de patrons.
- 2026-11-21 — PATCH-5 / 4.7.2 : commandes de modification directe d'un patron (titre, texte, statut, dossier, étape, source PDF, miniature, photos, fiche, variantes).
