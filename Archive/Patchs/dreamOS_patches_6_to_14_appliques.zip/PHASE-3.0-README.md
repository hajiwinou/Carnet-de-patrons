# dreamOS — Phase 3 (Jalon 3 « Modules métier ») — démarrage : 3.0 audit + 3.1 socle

Base : laboratoire Phase 2.8 (runtime 2.7.0). Version runtime : **3.1.0** · cache Service Worker **atelier-tricot-v11**.
`app.js`, `app-late.js`, `index.html` et les services de la Phase 2 sont **inchangés** (vérifié par test).

> Lecture retenue : « phase 3 » = Jalon 3 (séparer les huit applications). Le document fondateur appelle « Phase 3 » le moteur de bureau (jalons 4-5) ; ils viennent après.

## Ce qui est livré
1. **Audit traçable** : `node tools/audit-app.mjs` → `docs/phase3/INVENTORY.md` et `inventory.json` (sha256 d'app.js, fonctions par module cible, appels inter-modules, actions de clic, clés `carnet.*`, préfixes média et d'id).
2. **3.1 socle additif**, non branché sur app.js :
   - `dreamOS/core/stable-ids.js` : générateur d'identifiants au format historique (`uid()`), sans collision dans la même milliseconde, accepte les anciens identifiants.
   - `dreamOS/modules/module-registry.js` + `manifest.js` : les 8 modules déclarent leurs clés de stockage et préfixes média ; règle « une seule autorité d'écriture » appliquée (tout est à `legacy` ; un transfert est explicite et refusé si le propriétaire actuel n'est pas le bon).
   - Services `idGenerator` et `moduleRegistry` dans `dreamOS.services`.
3. **Test** `tests/phase3_1.test.mjs` : ids, registre, et cohérence avec le code réel (toute clé `carnet.*` et tout préfixe média d'app.js est revendiqué par un module ; inventaire à jour ; app.js ne dépend pas du socle). Tests 2.1 à 2.5 et précache relancés : OK.

## Constats de l'audit (à arbitrer)
| # | Constat | Impact | Proposition |
|---|---|---|---|
| 1 | app.js : 6 868 lignes, 442 déclarations de fonctions (406 de premier niveau), contre 424 rapportées | Chiffres de la doc à corriger | Mettre à jour la doc |
| 2 | **Un seul gestionnaire de clic de ~590 lignes (l.6117-6706) pilote 168 actions** de tous les modules, plus 5 autres écouteurs globaux (input, change, keydown, drop…) | Aucun module ne peut être extrait proprement tant que ce routeur est commun | **3.2 : routeur d'actions** par module, avant toute extraction |
| 3 | **Préfixes média incohérents** : la doc, `BackupManager` (`MEDIA_PREFIX`) et `refs()` de app.js (l.3706) citent `wall_`, `idea_`, `inspo_` ; le code crée en réalité `wp_`, `ideam_`, `pji_`. Le jeu de test fictif utilise `idea_1`, ce qui masque l'écart | La vérification « fichier référencé manquant » ignore fonds d'écran, médias d'idées et inspirations de projet (les blobs sont tout de même exportés, toutes les clés IDB étant énumérées) | Décision : ajouter `wp_`, `ideam_`, `pji_` à la regex (risque : refuser d'anciennes archives déjà incomplètes). **Non modifié ici.** |
| 4 | **Cobalt existe** (outil Instagram → MP4, `igRequest`, l.4214) ; **WIP Island existe** (≈79 lignes `island*`, dans Projects) | Deux décisions de la doc sont levées | Les préserver |
| 5 | `removeP()` n'a qu'un usage (remplacement d'un PDF, l.2840), `removePSoft()` un seul (suppression avec annulation, l.6698) | Ils ne sont pas interchangeables : l'un supprime les blobs tout de suite | Les garder distincts, les renommer plus tard |
| 6 | Les ids métier ont des préfixes (`j`, `y`, `e`, `i`, `d`, `sm`, `pc`) mais **patrons, articles, idées, tableaux, options n'en ont pas** (`uid()` seul) ; aucun n'a de date de modification | Prérequis de la sync (section 8) | 3.7 : `updatedAt` ajouté sans changer les ids existants |

## Plan proposé pour la suite du jalon 3 (à valider)
- **3.2 Routeur d'actions** : table `action → module` ; le gestionnaire historique délègue, comportement identique (test : les 168 actions sont routées).
- **3.3 Settings / Theme Manager** (le plus isolé : thème, polices, fonds, verrouillage).
- **3.4 Tools** (compteur, chronomètre, notes en services avec contexte projet explicite).
- **3.5 Library + Documentation** (File Manager, Search Manager).
- **3.6 Downloads** (état partagé panneau / application).
- **3.7 Patterns** puis **3.8 Projects** puis **3.9 PDF Reader** (les plus couplés : ~54 + 60 + 38 appels inter-modules), avec transfert d'écriture ressource par ressource.
- Chaque sous-étape : test de non-régression sur le jeu fictif (`phase2_8_regression.browser.mjs`) avant et après.

## À faire de votre côté
- `npm i jszip playwright-core` puis lancer `phase2_8_backup_format.test.mjs` et `phase2_8_regression.browser.mjs` (non exécutables ici : réseau coupé pour les paquets). Je n'ai pas pu les relancer.
- Vérifier sur GitHub Pages que le nouveau cache v11 s'installe et que `dreamOS.services.get('moduleRegistry').report()` répond.
- Trancher le constat 3 et le plan ci-dessus.

## Retour arrière
Remettre `bootstrap.js` et `sw.js` de la 2.8 ; les nouveaux fichiers sont inertes. IndexedDB et localStorage ne sont jamais touchés.
