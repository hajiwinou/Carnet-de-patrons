# dreamOS — Phase 3.6 — Library, Documentation et Search Manager
Runtime **3.6.0** · cache Service Worker **atelier-tricot-v16**.

## Principe (même schéma qu'en 3.4 et 3.5)
La **logique** de recherche et de filtrage passe à des services qui reçoivent leurs collections **explicitement** et ne les modifient jamais. Les **données** (`carnet.ideas`, `carnet.boards`, `carnet.docs`, médias `ideam_*` / `docm_*`) et **tout le rendu HTML** restent à app.js : aucune seconde autorité d'écriture.

## Nouveaux fichiers
- `dreamOS/search/search-manager.js` : `normalize` (sans accents ni casse), `docMatches`, `run(query, collections, {yarnNames})` : patrons, projets, documentation, épingles ; 2 lettres minimum, 20 résultats par groupe. Renvoie les objets d'origine, jamais de HTML.
- `dreamOS/library/pins.js` : `tags`, `boardIds`, `shown` (filtre par tableau et étiquette).
- `dreamOS/library/library-host.js` : `engage()` / `release()` ; transferts enregistrés dans le Module Registry : `logic:search` → `searchManager`, `logic:pin-filter` → `library`, `logic:doc-filter` → `documentation`.

## Modifications d'app.js (code d'origine conservé derrière chaque délégation)
- `libHost()` ; une ligne de délégation dans `ideaTags`, `pinBoardIds`, `pinsShown` et `docHit` (dans `viewDocs`).
- `findHtml` : un appel unique au Search Manager, puis chacune des quatre listes (`pats`, `pjs`, `pins`, `docsR`) prend le résultat du service s'il existe, sinon son filtre d'origine. Le rendu des boutons est inchangé.

## Retour arrière
- À chaud : `window.DreamOSLibraryHost.release()`.
- Par l'adresse : `?library=legacy`.
- Complet : remettre `app.js`, `bootstrap.js`, `sw.js`, `manifest.js` de la 3.5.

## Tests
`tests/phase3_6.test.mjs` extrait le **vrai code d'app.js** (`gkey`, `ideaTags`, `pinBoardIds`, `pinsShown`, `findHtml`, `docHit`) et le compare, hôte absent puis engagé, sur 120 jeux de données aléatoires × 30 requêtes (accents, majuscules, requêtes trop courtes, balises HTML, plus de 20 résultats) : 7 200 comparaisons. `findHtml` est comparé **caractère par caractère** (HTML complet). Les collections ne sont jamais modifiées. Trois mutations volontaires ont été détectées : limite à 19, catégorie ignorée dans la documentation, étiquette par défaut modifiée. Tests 2.1-2.5, précache et 3.1-3.5 relancés : OK.

## Non fait, volontairement
- Ajout / suppression / déplacement d'idées et d'articles, import de médias (`pinBulk`, `docSave`, visionneuse `lb*`) : ils écrivent les données et les blobs ; à migrer avec le File Manager (jalon 6), pour ne pas créer deux autorités.
- `gkey` reste défini dans app.js (utilisé partout) ; le service a sa propre copie, testée identique.

## À faire de votre côté (profil de test)
1. Recharger ; console : `window.DreamOSLibraryHost.enabled` → `true`.
2. Recherche globale : « laine », « ete » (trouve « été »), une seule lettre (message d'aide), un mot absent.
3. Library : filtres par tableau et étiquette, « sans tableau », étiquettes personnalisées.
4. Documentation : recherche dans les articles, compteur de résultats.
5. `release()` puis `engage()` : aucune différence. Toujours en attente : `npm i jszip playwright-core` et tests navigateur 2.8.

## Suite : 3.7 Downloads (Instagram / Cobalt)
