# Jalon 4.7c — Patterns modifie lui-même les champs d'un patron

Version 4.7.2 · cache `atelier-tricot-v34`. Aucun champ, identifiant ni format modifié.

## Ce qui a bougé
- Nouveau `dreamOS/patterns/patterns-commands.js` : 24 commandes appliquées au patron passé en paramètre — titre / statut (`setField`), texte (`setRaw`, `setTranscript`, `markScanned`), dossier, type de photo, ajout de photo, étape (`setStage`), renommage, source PDF (`ensureSource`, `setSourcePdf`, `setSourceFileDefault`, `setSourcePages`), miniature, informations de la fiche (`setFact`, `setChipFact`), variantes (`addOption`, `removeOption`, `setOptionGrid`, `setOptionFact`, `setOptionProp`). Transcriptions fidèles du code d'origine ; ni enregistrement, ni média, ni rendu.
- `patterns-host.js` : expose `commands` (option `now`).
- `app.js` : 24 portes `pat…` (module engagé → commande, sinon code d'origine) ; 28 sites routés : saisies de la fiche, du titre et du texte, statut, dossier, étape, renommage, rangement automatique, import et rattachement de PDF, OCR, miniature, photos, puces, variantes.

## Ce qui reste
L'analyse par IA (`analyze`, `aiVisual`, `aiPhoto`, lecture + analyse) remplit encore elle-même la fiche, les indices, les drapeaux IA, les variantes détectées et `p.analysis` : 4.7d. Aussi : `favAuthors`, `collapsed`, `group`.

## Vérification
`tests/jalon4_7c.test.mjs` : 12 750 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), commandes seules, attentes absolues, garde-fous statiques (aucune écriture directe de ces champs hors des portes, hors zone IA). 29 mutations injectées : toutes détectées (1 d'abord échappée : rangement automatique, assertion ajoutée). Suite complète verte.
Note : les identifiants de variantes créées par le module viennent du générateur du module (même principe qu'en 4.6c) ; ils restent uniques.

## Retour arrière
`?patterns=legacy`.
