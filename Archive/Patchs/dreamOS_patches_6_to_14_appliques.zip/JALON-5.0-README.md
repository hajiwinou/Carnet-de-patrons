# Jalon 5.0 — Porte de préparation

Version 5.0.1 · cache `atelier-tricot-v40` (5.0.1 : DM Sans hébergée, ancien précache `themes/bliss/` retiré, décisions du 22 nov.). **L'application n'est pas modifiée** : `app.js`, `index.html`, `styles*.css` et `themes/` sont inchangés.

## Ce qui est livré
- `assets/` restauré : 32 icônes PNG (`assets/icons/`) et 9 images de l'île en `.webp` (`assets/island/`), soit exactement les 41 fichiers du précache.
- `theme/` : `tokens.css`, `components.css` (reçus, inchangés), `fonts.css` (nouveau : Pixelify Sans en 500 et 600, DM Sans variable 400 à 700, `font-display: swap`), `theme-test.css` (mise en page de la page de test), `CLAUDE.md` (consignes reçues, voir `docs/project/DECISIONS-THEME.md`).
- `icones/` : 59 icônes SVG + `icones-sprite.svg`. `fonts/` : Pixelify Sans Medium et SemiBold, DM Sans variable, licences OFL.
- `theme-test.html` (**page interne**, étape 2 de la méthode) : chaque composant dans ses états (boutons, champs, statut, onglets, barres, pastilles de données, fenêtres, panneaux, pastilles, résultats, notes, jauges, lecteur PDF, volet, idées, sélection, utilitaires, les 59 icônes) et un sélecteur de thème (Bliss, Doodle, Classique 95, Pixel RPG) qui ne change que des variables. À ouvrir via un serveur, pas en double-clic (les icônes viennent du sprite).
- `sw.js` : cache v39 ; précache du thème, des deux polices et du sprite (le thème n'est pas encore chargé par l'application).
- `docs/project/DECISIONS-THEME.md` : vos réponses du 22 nov. et ce qu'elles changent.

## Vérifié (Node, ici)
`tests/jalon5_0.test.mjs` : fichiers livrés, sprite = 59 icônes, 41 assets = précache, aucun `!important` ni couleur en dur hors `tokens.css`, toute variable utilisée est définie, thèmes autres que Bliss limités à des variables, polices présentes, 55 composants montrés, aucun style en ligne sauf la largeur d'une jauge, boutons-icônes nommés, application non touchée. 20 mutations injectées : toutes détectées. Rendu de la page de test relevé en capture à 1280 px et 390 px (Chrome sans tête) : conforme à la maquette dans l'ensemble ; **pas de comparaison pixel à pixel, ni tablette, ni 360 px, ni navigation clavier : à faire écran par écran**.

## Limites
- `themes/bliss/` (images de l'ancien thème) retiré du précache ; l'ancien `themes/bliss.css` les cite encore jusqu'à sa suppression.
- Le thème Bliss n'est pas encore appliqué à l'application : c'est le jalon 5.1.

## Retour arrière
Rien à annuler côté comportement : supprimer les fichiers ajoutés et remettre `sw.js` / `bootstrap.js` du PATCH-10.

## Suite (5.1)
Charger `tokens.css` et `fonts.css` dans l'application sans toucher aux écrans, puis convertir écran par écran dans l'ordre de la spécification : barre du haut, Bibliothèque, Projets, Fiche patron, Lecteur PDF, Outils, Idées, Réglages, formulaires, états vides.
