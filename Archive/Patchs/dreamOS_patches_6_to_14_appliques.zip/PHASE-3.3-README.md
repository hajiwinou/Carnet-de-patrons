# dreamOS — Phase 3.3 — Theme Manager
Runtime **3.3.0** · cache Service Worker **atelier-tricot-v13**. `app.js` toujours inchangé.

## Livré
- `dreamOS/theme/theme-engine.js` : fonctions **pures** qui reproduisent `applyAppearance()` : à partir de `S.ui` elles calculent un plan (attribut `data-theme`, palette dreamOS, variables CSS à poser/retirer, fond d'écran, migration des anciennes palettes). Contient aussi les catalogues `FONTS` et `DREAM_PALETTES` et un calcul de contraste WCAG.
- `dreamOS/theme/theme-manager.js` : service `themeManager` utilisable seul (`palettes()`, `fonts()`, `plan(ui)`, `auditContrast(ui)`, `apply(root, plan)`). **Rien ne l'appelle** : app.js reste l'unique autorité d'écriture sur l'apparence.
- `tests/phase3_3.test.mjs` : exécute le vrai `applyAppearance()` extrait d'app.js et le moteur sur **1 050 configurations** (thèmes, mode sombre, polices, accents, fonds, opacités, anciennes palettes, palettes personnalisées) et compare variables CSS, attributs, classe `no-wallpaper` et migration de `S.ui.dream`. Vérifié : le test échoue si une valeur change. Il vérifie aussi que `FONTS` et `DREAM_PALETTES` n'ont pas dérivé d'app.js.

## Constat utile pour le jalon 8 (Bliss)
Contrastes du texte (cible ≥ 4,5:1) : les 6 palettes dreamOS passent. Le plus faible est le texte discret sur papier (Nuit 4,76 ; Ciel 5,19). Aucune palette ne passe sous 4,5.

## Limites
- Le fond d'écran (`wp_*`, blob) reste géré par app.js : le plan indique seulement `wallpaperId`.
- Les actions `dreamPal`, `setAccent`, `resetColors`, `dreamMin/Max/Close`, `clearWallpaper` sont déjà classées « settings » dans le routeur mais pas encore revendiquées : le transfert d'écriture se fera en une fois (applyAppearance délègue au Theme Manager + actions revendiquées), en 3.4, avec la modification minimale d'app.js nécessaire et un retour arrière documenté.

## À faire de votre côté
Recharger, vérifier thème/palettes/polices comme avant ; console : `dreamOS.services.get('themeManager').auditContrast({})`. Toujours en attente : `npm i jszip playwright-core` puis tests navigateur 2.8.

## Retour arrière
Remettre `bootstrap.js` et `sw.js` de la 3.2 ; le dossier `theme/` est inerte.
