# dreamOS — Bilan du Jalon 3 « Modules métier »

## Résultat en une phrase
Les 8 modules existent dans le registre, chacun avec sa logique pure extraite et testée contre le code d'origine ; les données, l'enregistrement et le rendu restent volontairement dans app.js (une seule autorité d'écriture par ressource).

## État des modules
| Module | Logique portée (ressource du registre) | Étape | Bascule / retour arrière |
|---|---|---|---|
| Settings | apparence + fond d'écran (`theme-engine`, `theme-manager`) | 3.3–3.4 | `?theme=legacy` |
| Tools | chronomètre, compteur de rangs (`stopwatch`, `row-counter`) | 3.5 | `?tools=legacy` |
| Library | filtre des épingles, recherche (`pin-filter`, `search`) | 3.6 | `?library=legacy` |
| Downloads | client Cobalt (`cobalt-client`), clé jamais stockée ni journalisée | 3.7 | `?downloads=legacy` |
| Patterns | moteur de fiche : texte, schéma, IA, grilles (`patterns-engine`, 21 fonctions) | 3.8 | `?patterns=legacy` |
| Projects | étape, fils / pelotes, plan de couleurs, notes, WIP Island (`projects-engine`, 20 fonctions) | 3.9 | `?projects=legacy` |
| PDF Reader | page, durées, zoom, position, surcouches (`pdf-reader-engine`) | 3.10 | `?pdfreader=legacy` |
| Documentation | brouillon, publication, médias, libellés (`documentation-engine`) | 3.11 | `?documentation=legacy` |

Chaque bascule peut aussi se relâcher à chaud : `window.DreamOS<Module>Host.release()`.

## Chiffres
- Version runtime 3.11.0, cache du service worker `atelier-tricot-v21`.
- app.js : 6 964 lignes (≈ +60 par rapport à la phase 2 : points de délégation, code d'origine conservé en repli).
- ~85 points de délégation `…Host()` dans app.js.
- 12 fichiers de tests de phase 3 + les tests de phase 2 : tous OK dans le laboratoire. Comparaisons : 3.3 → 1 050 configs ; 3.4 → 312 ; 3.5 → 9 000 opérations ; 3.6 → 7 200 ; 3.7 → 56 scénarios réseau ; 3.8 → ≈ 44 000 ; 3.9 → ≈ 230 000 ; 3.10 → ≈ 105 000 ; 3.11 → 3 000 scénarios complets. Chaque étape a ses mutations de contrôle (une modification volontaire du code doit faire échouer un test).
- Générateurs d'extraction textuelle : `tools/lib/engine-extractor.mjs` (Patterns, Projects) ; le test vérifie que le module est identique à app.js.

## Ce qui reste volontairement dans app.js
1. **Données** : `S.*`, `carnet.*`, blobs IndexedDB (pdf_, th_, img_, pjc_/pjp_/pji_, ideam_, docm_, wp_).
2. **Rendu HTML** de toutes les vues et le routeur d'actions (179 actions `data-act`, routeur inerte, aucune action revendiquée).
3. **Opérations qui écrivent** : suppression / restauration de patrons et projets, dossiers, doublons, import PDF, appels réseau des fournisseurs d'IA, flux Instagram (`igGo`), notes de journal.
4. **Gestionnaire de fichiers et migration d'état** (prévu au jalon 6).

## Points d'attention
- Les tests `phase2_8_backup_format` (jszip) et `phase2_8_regression.browser` (playwright) ne tournent pas dans le laboratoire : **à lancer chez vous à chaque livraison**.
- La phase 3 n'a changé aucun format de données ni de sauvegarde, sauf : les médias `wp_*`, `ideam_*`, `pji_*` manquants dans une archive donnent un avertissement et ne bloquent plus la restauration.
- Les points de délégation doublent un peu le code (original + module) : ils seront retirés quand la propriété des données aura basculé.

## Proposition pour le Jalon 4 « Propriété des données » (du plus sûr au plus risqué)
1. **Documentation** comme pilote : `carnet.docs` + médias `docm_*` lus / écrits par un `DocumentationStore` via les services de stockage et de médias ; app.js n'y touche plus qu'à travers lui.
2. Library (idées, tableaux), Tools (grilles, notes rapides), Downloads.
3. Projects, puis Patterns (les plus couplés : médias partagés, journal, compteur de rangs piloté par le PDF Reader).
4. Revendiquer les actions du routeur module par module (`claim`), avec bascule + retour arrière à chaque fois.
5. Retirer les replis historiques et alléger app.js une fois chaque module stabilisé en usage réel.

Règle conservée : une étape = une livraison zippée + README + retour arrière + tests d'équivalence + mutations.
