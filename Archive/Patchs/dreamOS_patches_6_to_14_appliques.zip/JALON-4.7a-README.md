# Jalon 4.7a — Patterns possède la liste des patrons et des dossiers

Version 4.7.0 · cache `atelier-tricot-v32`. Aucun champ, identifiant ni format modifié.

## Ce qui a bougé
- Nouveau `dreamOS/patterns/patterns-store.js` : le module adopte les tableaux `S.patterns` et `S.folders` (même référence) et en est la seule autorité d'écriture (ajout en tête / en queue, retrait, annulation, remplacement, mise à jour d'un patron) ; il décide du **déclenchement** des enregistrements (différé `persist`, immédiat `persistNow`, dossiers `saveFolders`) et des écritures de `carnet.patterns` / `carnet.ts` / `carnet.folders` à la restauration depuis le miroir. L'écriture physique reste dans `app.js` (`persistPhys`, `persistNowPhys`, `saveFoldersPhys`).
- `patterns-host.js` : expose `store` ; ressources de stockage `carnet.patterns`, `carnet.ts`, `carnet.folders` transférées au module à l'engagement.
- `app.js` : 17 portes (`patternsAppend/Prepend/RemoveAt/InsertAt/RemoveById/Upsert/Replace`, `foldersAppend/RemoveAt/InsertAt/Replace`, `persist`, `persistNow`, `saveFolders`, `patKeep`) ; 19 sites routés (création, collage, import ZIP, restauration, récupération des patrons perdus, suppression et annulation de patron et de dossier, dossiers automatiques, miroir). Module absent → code d'origine.

## Ce qui reste
Champs d'un patron (titre, texte, grilles, photos : 4.7c) ; médias `pdf_*`, `th_*`, `img_*` (4.7b) ; `favAuthors`, `collapsed`, `group` ; renommage de dossier (champ `name`, 4.7c).

## Vérification
`tests/jalon4_7a.test.mjs` : 7 500 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), magasin seul, propriété des ressources, garde-fous statiques (plus aucune écriture directe de la liste, des dossiers ni de leur stockage hors des portes). 22 mutations injectées : toutes détectées (6 d'abord échappées, tests renforcés). `jalon4_6a` et `jalon4_6e` reçoivent les nouvelles portes. Suite complète verte.

## Retour arrière
`?patterns=legacy`.
