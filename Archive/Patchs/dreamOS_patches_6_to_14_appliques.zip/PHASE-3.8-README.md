# dreamOS — Phase 3.8 — Patterns : moteur pur
Runtime **3.8.0** · cache Service Worker **atelier-tricot-v18**.

## Cartographie préalable (demandée en 3.7)
107 fonctions de Patterns (lignes 1050-1536, 2289-2928, 5156-5701 de la 3.7). Classement automatique :
- **Pures** (ni état `S`, ni DOM, ni stockage) : 45 fonctions, 513 lignes → candidates ;
- **Lisent `S` seulement** (liste, filtres, dossiers, doublons, détail) : 30 fonctions → plus tard, avec les données ;
- le reste écrit dans le DOM, le stockage ou appelle l'IA / les médias.

## Ce qui est migré : le moteur pur (21 fonctions + schéma)
`cleanText`, `isHeading`, `chunkText` (nettoyage et découpage du texte importé) ; `guessAuthor`, `guessGarment`, `normAuthor` ; `filled`, `completeness`, `checks` (cohérence mailles / mesures), `coerce`, `fieldDef` ; `applyAI`, `putGrid`, `applyGrids`, `applyOptGrids`, `mergeOptions`, `findOpt` ; `specText`, `groupSpec`, `rowSpec`, `optList` ; et les catalogues (`SCHEMA`, `ALLF`, `SIZES`, `MEASURES`, `COUNTS`, `CORE_ROWS`, `GROUPDEF`, `ABBR`, `HEAD`, `GARMENT_RE`).

**Le module est extrait mot pour mot d'app.js** (`node tools/gen-patterns-engine.mjs`, analyseur TypeScript) : aucune logique réécrite à la main, donc aucun risque de transcription. Le test vérifie que le fichier versionné est exactement l'extraction du code actuel.

Le patron est toujours passé en paramètre ; seul cet objet est modifié (comme avant). L'identifiant des nouvelles options vient du service `idGenerator` (même format `p…`, sans collision).

## Fichiers
`dreamOS/patterns/patterns-engine.js` (généré), `patterns-host.js` (`engage()` / `release()`, ressource `logic:patterns-engine` : `legacy` ↔ `patterns`), `tools/gen-patterns-engine.mjs`.

## Modifications d'app.js
`patHost()` et une ligne de délégation au début de chacune des 21 fonctions (code d'origine conservé derrière). Aucune autre ligne touchée.

## Retour arrière
- À chaud : `window.DreamOSPatternsHost.release()`.
- Par l'adresse : `?patterns=legacy`.
- Complet : remettre `app.js`, `bootstrap.js`, `sw.js`, `manifest.js` de la 3.7.

## Tests
`tests/phase3_8.test.mjs` : **44 000 comparaisons** entre le code d'app.js (hôte absent) et le moteur (hôte engagé) : 200 textes de patron aléatoires (pages, en-têtes répétés, ligatures, abréviations, mots coupés, numéros de page) × 4 réglages de nettoyage × 4 réglages de découpage, 250 patrons aléatoires (tous les champs du schéma, valeurs valides et invalides, grilles de tailles, options) soumis à toutes les opérations (IA, grilles, options, avec et sans écrasement). **Cas dirigés** pour les seuils que le hasard n'atteint pas : proportion de pages pour un en-tête répété, longueur d'un en-tête (90), cohérence mailles / poitrine (4 %), longueur des noms et descriptions d'options. **Mutations volontaires toutes détectées** (seuils, limites de longueur, conditions d’écrasement, filtres de listes). Le moteur ne contient ni état, ni DOM, ni stockage, ni réseau (vérifié). Inventaire recalé sur la 3.8. Tests 2.1-2.5, précache et 3.1-3.7 : OK.

## Non fait, volontairement (3.9 et suite)
- Dossiers, doublons (`findDup`, `askDup`), liste et filtres, vues, détail, import PDF, enregistrement : lisent ou écrivent `S.patterns` / `carnet.patterns` ; à migrer avec la **donnée**, au jalon 6, quand Patterns deviendra propriétaire d'écriture.
- Appels aux fournisseurs d'IA (`callSingleProvider`, 101 lignes) : service IA, jalon 6.
- `removeP` / `removePSoft` restent distincts, inchangés.
- Les catalogues sont **copiés** dans le module (pas partagés) : tant qu'app.js garde ses propres constantes, une modification du schéma doit être suivie d'un `node tools/gen-patterns-engine.mjs` ; le test échoue sinon.

## À faire de votre côté (profil de test, jamais vos vraies données)
1. Recharger ; console : `window.DreamOSPatternsHost.enabled` → `true`.
2. Importer un patron (PDF ou texte collé) : texte nettoyé, découpé, auteur et type de vêtement devinés comme avant.
3. Lancer l'analyse IA sur une fiche : champs remplis, grilles de tailles, options ; barre de complétude et contrôles de cohérence inchangés.
4. `release()` puis `engage()` : aucune différence. Toujours en attente : `npm i jszip playwright-core` et tests navigateur 2.8.

## Suite : 3.9 Projects (le plus gros : 96 fonctions, ≈ 770 lignes)
