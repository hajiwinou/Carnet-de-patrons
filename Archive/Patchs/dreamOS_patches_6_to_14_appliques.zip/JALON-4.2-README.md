# dreamOS — Jalon 4.2 : Documentation propriétaire de ses médias (docm_*)

## Ce qui change
- `dreamOS/documentation/documentation-media.js` : **seule autorité d'écriture** des médias d'articles — création d'identifiant (`docm_` + id, même format), écriture d'un blob (refuse tout autre préfixe), suppression avec l'article, liste des médias référencés (base d'un futur nettoyage des orphelins). Événements `documentation:media-saved|media-discarded`.
- Le registre transfère `media:docm_*` de `legacy` à `documentation`.
- app.js : `docmNewId()`, `docmSave()`, `docmDiscard()` ; l'ajout de médias à un brouillon, l'enregistrement d'une vidéo téléchargée et la suppression d'un article passent par elles. Code d'origine en repli.
- Version 4.2.0, cache du service worker `atelier-tricot-v23`.

## Pourquoi c'est sûr
L'écriture physique reste celle d'app.js (cache de blobs, URL temporaires, gestion d'échec de stockage) : elle est passée en paramètre à chaque appel. Rien ne change dans les données ni dans les sauvegardes. La lecture (`getBlobUrl`) reste partagée.

## Ne change pas
Format des médias, sauvegarde / restauration ZIP, rendu des articles.

## Retour arrière
`window.DreamOSDocumentationHost.release()` (même à chaud) ou `?documentation=legacy`.

## Tests (tous OK ici)
`tests/jalon4_1.test.mjs` (étendu) : 50 800 comparaisons ; passerelle (préfixe, événements, référencés, abonné défaillant) ; 300 séquences médias hôte absent / engagé ; **garde-fou statique** : plus aucune écriture ni suppression directe de média d'article, et seules deux lignes d'app.js (étiquettes de sauvegarde, détection d'archive) mentionnent encore `docm_`. `tests/phase3_11.test.mjs` : vérifications absolues (un blob par fichier, identifiants `docm_`, médias supprimés avec l'article). 8 mutations toutes détectées.

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : ajouter photos et vidéos à un article, publier, supprimer l'article (puis annuler, puis supprimer pour de bon), exporter un ZIP et réimporter.

## Étape suivante : 4.3 Library (idées, tableaux, médias `ideam_*`) sur le même modèle.
