# dreamOS — Jalon 4.3 : Library propriétaire de ses données (idées, tableaux, médias ideam_*)

## Ce qui change
- `dreamOS/library/library-store.js` : **seule autorité d'écriture** des idées/épingles (`carnet.ideas`) et des tableaux (`carnet.boards`) quand le module est engagé — ajout, ajout multiple, suppression, annulation, suppression par lot, modification (catégorie, tableaux d'une épingle), renommage / suppression d'un tableau, remplacement (import / restauration).
- `dreamOS/library/library-media.js` : seule autorité d'écriture des médias d'idées (`ideam_*`) — identifiant, écriture (refuse tout autre préfixe), suppression.
- Le registre transfère `storage:carnet.ideas`, `storage:carnet.boards` et `media:ideam_*` de `legacy` à `library`.
- app.js : 16 fonctions « porte unique » (`ideasAdd…`, `boardsAppend…`, `ideamSave…`) ; toutes les écritures y passent ; code d'origine en repli.
- Version 4.3.0, cache du service worker `atelier-tricot-v24`.

## Pourquoi c'est sûr
Même principe qu'en 4.1 / 4.2 : le magasin adopte les tableaux d'app.js (même référence) et les modifie sur place ; l'écriture physique reste `keep` / `saveBlob` / `IDB.del` d'app.js. Lecture, recherche, filtres (3.6) et rendu inchangés. Un tableau remplacé « sauvagement » est resynchronisé automatiquement.

## Ne change pas
Formats de données et de sauvegarde ; aucun rendu ; les photos d'inspiration d'un projet qui réutilisent une idée gardent leur média (la suppression reste décidée par l'appelant).

## Retour arrière
`window.DreamOSLibraryHost.release()` (même à chaud) ou `?library=legacy`.

## Tests (tous OK ici)
`tests/jalon4_3.test.mjs` : ≈ 39 000 comparaisons. Le VRAI code d'app.js (actions groupées déplacer / ajouter / catégorie / supprimer, cases à cocher, import de plusieurs photos, média d'une idée, nouveau / renommer / supprimer un tableau, ajouter / supprimer / annuler une épingle) est exécuté hôte absent / engagé sur 500 états aléatoires ; **vérifications absolues** pour chaque scénario (le résultat attendu est calculé à part, pas seulement comparé à l'ancien code) ; 600 séquences de fonctions avec bascule / retour arrière à chaud ; magasin et passerelle ; **garde-fous statiques** (plus aucune écriture directe sur idées, tableaux, médias `ideam_*`). 27 mutations contrôlées, toutes détectées.

## Observation (corrigée en 4.4)
Dans « Plusieurs photos d'un coup », si le **premier** fichier choisi n'est ni une image ni une vidéo, l'import s'arrête sans rien ajouter (la boucle interprète « pas de pause en cours » comme une annulation). À corriger séparément si vous le souhaitez ; le test documente ce comportement.

## Reste hors du module
La restauration de sauvegarde écrit encore les blobs `docm_*` / `ideam_*` en bloc (service de sauvegarde, à traiter avec lui).

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : épingler une idée avec photo, importer plusieurs photos, les ranger dans un tableau (déplacer / ajouter), créer / renommer / supprimer un tableau, supprimer puis annuler une épingle, exporter / réimporter un ZIP, recharger.

## Étape suivante : 4.4 Tools (grilles, notes rapides, bloc-notes) sur le même modèle.
