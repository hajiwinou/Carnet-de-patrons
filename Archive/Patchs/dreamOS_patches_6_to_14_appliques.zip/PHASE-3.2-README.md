# dreamOS — Phase 3.2 — Décisions + routeur d'actions
Runtime **3.2.0** · cache Service Worker **atelier-tricot-v12**. `app.js` toujours inchangé.

## Décisions prises (suite au README 3.0)
1. **Préfixes média** : `BackupManager` reconnaît désormais aussi `wp_`, `ideam_`, `pji_`. Leur absence dans une archive produit un **avertissement** (`warnings` de `inspectArchive`) et **ne bloque jamais** la restauration : une ancienne archive reste restaurable. Les préfixes historiques restent bloquants. Le `refs()` de app.js n'est pas touché (une seule autorité). Test : `tests/phase3_2_backup_prefixes.test.mjs`.
2. **Plan 3.2 → 3.9 validé** dans l'ordre du README 3.0. `removeP()` et `removePSoft()` restent distincts. Cobalt et WIP Island sont préservés (dans Downloads et Projects).
3. **Ids / `updatedAt`** : reportés à 3.7, sans modifier les ids existants.

## 3.2 — Routeur d'actions
- `dreamOS/modules/action-map.js` (généré par `node tools/gen-action-map.mjs`) : les **179 actions** `data-act` rattachées à leur module.
- `dreamOS/modules/action-router.js` : écoute en **capture** avant le gestionnaire historique. Tant qu'aucun module ne revendique une action, il ne fait qu'émettre `action:dispatched` sur l'Event Bus : **comportement identique à la 2.8**. Quand un module revendique une action (`claim(module, action, handler)`), le routeur l'exécute et bloque le gestionnaire historique pour cette action : jamais deux exécutions. `claim` renvoie une fonction de retour arrière ; refus si l'action est inconnue, d'un autre module ou déjà prise.
- Test `tests/phase3_2.test.mjs` : chaque action utilisée par app.js/index.html est dans la carte (et inversement), modules valides, revendication, erreurs isolées, capture, `[data-stop]`, app.js ne référence pas le routeur.
- Limite connue : les actions arrivant par `change`, `input`, `keydown`, `drop` ne passent pas encore par le routeur (seul `click` l'est). À traiter avec le premier module extrait qui en a besoin.

## À faire de votre côté
- Navigateur : recharger, vérifier que l'appli se comporte comme avant, puis `dreamOS.services.get('actionRouter').claimed()` → `[]` et, après un clic, un événement `action:dispatched` (`dreamOS.events.on('action:dispatched', console.log)`).
- Toujours en attente : `npm i jszip playwright-core` puis tests `phase2_8_backup_format` et `phase2_8_regression.browser`.

## Retour arrière
Remettre `bootstrap.js`, `sw.js` et `backup-manager.js` de la 3.1 ; rien d'autre n'en dépend. IndexedDB et localStorage ne sont pas touchés.

## Suite : 3.3 Settings / Theme Manager
