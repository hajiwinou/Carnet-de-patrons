# Jalon 4.9b — Settings modifie les valeurs de réglages

Version 4.9.1 · cache `atelier-tricot-v38`. Aucune clé, aucun champ ni format modifié.

## Ce qui a bougé
- Nouveau `dreamOS/settings/settings-commands.js` : transcriptions fidèles des modifications d'apparence (thème, police, voile, couleurs, accent, réinitialisation, palette), d'île (activation, animal, mois), de statistiques, de fond d'écran (identifiant), d'IA (adresse, clé, modèle, préférences, vision, bascule automatique, fournisseur par défaut) et d'options. Ni enregistrement, ni rendu, ni message.
- `settings-host.js` : expose `commands`. `sw.js` : 1 fichier de plus dans le précache.
- `app.js` : 19 portes `st…` ; routés : tous les champs du panneau Réglages, les actions de couleurs, l'envoi vers l'île, la conversion d'une ancienne palette, la restauration (statistiques, île, fond d'écran si absents) et l'empreinte du verrou (`stPwHash`, 3 sites).

## Ce qui reste
- Normalisation des clés / modèles / adresses d'IA au chargement (lecture-normalisation à l'ouverture, 3 lignes) et chargement initial.
- Restauration groupée des blobs et suppression des codes de secours : Jalon 8.
- Le calcul de l'empreinte et son contrôle restent à app.js.

## Vérification
`tests/jalon4_9b.test.mjs` : 10 500 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), commandes seules, attentes absolues, garde-fous statiques. 20 mutations injectées : toutes détectées (celle de l'empreinte par le test 9a). Tests 6e, phase3_3 et phase3_4 adaptés (nouvelles portes dans leurs extraits). Suite complète verte. La conversion d'ancienne palette et la restauration sont vérifiées par garde-fou statique (fonctions trop grandes pour être exécutées isolément).

## Retour arrière
`?settings=legacy`.
