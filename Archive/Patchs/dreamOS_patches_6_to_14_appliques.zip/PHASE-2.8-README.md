# dreamOS — Phase 2.8 — Validation (laboratoire)
Base : Phase 2.7 inchangée (aucune modification de app.js, ni des services).

## Fait (automatique)
- `tests/phase2_8_precache.test.mjs` : vérifie que le précache du Service Worker couvre index.html, les 14 modules ESM atteints depuis bootstrap.js, les @import CSS des thèmes, et que le repli hors-ligne ignore les `?v=`.
- **Constat corrigé** : `themes/bliss.css` (importé par themes.css) n’était pas dans le précache → un premier lancement suivi d’une coupure réseau aurait perdu le thème. Ajouté avec le fond et les 9 icônes Bliss. Cache `atelier-tricot-v10`.
- Limite : le zip labo ne contient ni `assets/` ni `themes/bliss/` ; leurs fichiers sont signalés en avertissement, pas vérifiés.

- `tests/phase2_8_backup_format.test.mjs` (nécessite `npm i jszip`, sinon SKIP) : avec un vrai JSZip, vérifie que le ZIP écrit par le moteur historique (`buildStoredZip`, extrait de app.js) est lisible avec CRC valides et accepté par `BackupManager.inspectArchive` ; qu'une archive du BackupManager garde les entrées `data.json`, `blobs/`, `types.json` ; qu'une ancienne archive sans `types.json` passe ; que médias manquants, `data.json` absent, version v2 et fichier non-ZIP sont refusés. Dans Node, une petite passerelle convertit les Blob (JSZip les lit nativement dans le navigateur).

- `tests/fixtures/make-fixture.mjs` → `carnet-test-fictif.zip` : sauvegarde v1 **100 % fictive** (4 patrons, 2 dossiers, 3 projets avec journal/photos/fils/rangs/chrono, grille, article, idée, tableau, repères PDF, 11 fichiers). Réutilisable à la main : Réglages > Importer une archive, dans un profil vierge.
- `tests/phase2_8_regression.browser.mjs` (nécessite `playwright-core`, `jszip` et un Chromium, sinon SKIP) : profil vierge, import du ZIP fictif par l'interface, puis contrôle des scénarios §12.2 (1 à 6, 8, 9, 10) juste après l'import **et** après rechargement complet, import en double sans doublon, clé IA préexistante conservée (§12.2 #7), aucune erreur JS. Vérifié : le test échoue bien si une valeur attendue change.
- **Constat (informatif)** : la sauvegarde ZIP ne contient pas `carnet.opts, theme, favAuthors, collapsed, pjStage, r3, chart, ai, igApi, pwHash, group, rowStep, vrcPos…` : thème, favoris d'auteurs, clés IA et mot de passe sont à reconfigurer sur un autre appareil. À arbitrer en Phase 3 (Settings / Backup).

## À faire à la main (sur copie / profil de test, jamais tes vraies données)
1. Première installation en ligne → recharger → couper le réseau → l’appli démarre avec thème et icônes.
2. Mise à jour : ancienne version installée → nouvelle version → rechargements → plus d’ancien cache.
3. Sauvegarde ZIP complète avant 2.7 → restauration dans un profil vierge : patrons, projets (photos, journal, rangs), PDF, repères.
4. Ouvrir un PDF, poser un repère et un compteur, fermer/rouvrir : tout est retrouvé.
5. Ouvrir la console : `await dreamOS.legacy.ready` → statut `ready` ; `dreamOS.legacy.getStateSnapshot()` ne contient ni clé API ni hash de verrouillage.
6. iPhone (Safari, ajouté à l’écran d’accueil) : mêmes tests 1, 3 et 4 ; barre du bas et zones de sécurité sans recouvrement.
7. Quota : vérifier le message d’échec de sauvegarde (storageFailure) sur un profil presque plein.
