#!/usr/bin/env node
// Extrait VERBATIM le moteur pur de Projects depuis app.js (Phase 3.9) → dreamOS/projects/projects-engine.js
// Usage : node tools/gen-projects-engine.mjs
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { collect as collectGeneric, generate as generateGeneric } from './lib/engine-extractor.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const CONFIG = {
  consts: ['YARN_COLORS', 'ISLAND_REASON_GROUPS', 'ISLAND_REASONS'],
  funcs: ['pjStageOf', 'isAutoPjName', 'lastActivity', 'pjLegacyCover', 'pjPlannedTotal', 'pjApplyPlan', 'pjYarns', 'pjSkeins', 'pjYarnNames', 'pjSkeinsTxt', 'yarnCountTxt', 'pjLastTouch', 'pjStartTs', 'ratingAvg', 'colorNameFromHex', 'colorTarget', 'islandReasonLabel', 'islandReasonList', 'fmtEntryDate', 'daysSince'],
  populate: (src) => src.startsWith('ISLAND_REASON_GROUPS.forEach'),
  hookRe: /var pjx = projHost\(\); if \(pjx\) return pjx\.engine\.\w+\([^)]*\);\s*/g,
  factory: 'createProjectsEngine', deps: ['uid'],
  header: `/**
 * dreamOS — Moteur pur de Projects (Phase 3.9)
 * Extrait VERBATIM d'app.js par tools/gen-projects-engine.mjs (analyse TypeScript), sans aucune modification de logique :
 * étape d'un projet, dernière activité, couverture historique, fils et pelotes (prévu / utilisé), plan de couleurs,
 * notes moyennes, nom d'une couleur depuis son code, raisons du WIP Island, dates.
 * Aucune lecture ni écriture de stockage, de DOM ou d'état : les fonctions reçoivent le projet concerné en paramètre
 * (pjYarns et pjApplyPlan le complètent comme le code historique) ; l'enregistrement et le rendu restent à app.js.
 * Seule dépendance externe : le générateur d'identifiants (uid), injecté.
 */`
};
export const collect = (text, strip = true) => collectGeneric(text, CONFIG, strip);
export const generate = (text) => generateGeneric(text, CONFIG);
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { out, count } = generate(fs.readFileSync(path.join(root, 'app.js'), 'utf8'));
  fs.mkdirSync(path.join(root, 'dreamOS/projects'), { recursive: true });
  fs.writeFileSync(path.join(root, 'dreamOS/projects/projects-engine.js'), out);
  console.log('généré :', out.split('\n').length, 'lignes ;', count, 'éléments');
}
