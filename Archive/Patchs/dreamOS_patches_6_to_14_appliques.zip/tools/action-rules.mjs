// Règles par nom d'action (prioritaires sur l'heuristique d'appel) — à valider à la main.
export const ACTION_RULES = [
  [/^(pj|tm|yarn|newPj|newProj|openPj|goPj|stage|devAge|devReset|colorOpen|colorSet|island|rate|pcplan|patPick|inspoDel|inspoPick|inspoFrom|undoPj|setPjStage|needle)/i, 'projects'],
  [/^(v(close|zoom|mark|hl|sm|line|tool)|vrc|pdf|rows?|sub)/i, 'pdf-reader'],
  [/^dlg/, 'dialogs'],
  [/^ig[A-Z]/, 'downloads'],
  [/^(grid|chart|kc|r3|short|rag|gauge|ctool|cclear|toolSub|note|calc)/i, 'tools'],
  [/^(pin|lb|lightbox|idea|board|tag)/i, 'library'],
  [/^(doc|post|art)/i, 'documentation'],
  [/^(dream|setAccent|resetColors|testAi|fullBackup|restore|theme|font|lock|pw|backup|zip|storage)/i, 'settings'],
  [/^(tab|open|back|grp|cancel)$/, 'navigation/engine'],
];

// Attributions manuelles (relues dans le code d'app.js) pour les actions que les règles ci-dessus ne couvrent pas.
export const ACTION_OVERRIDES = {
  patterns: 'addF addOpt aiFill aiPhoto aiRe aiRead aiVisual autoAuthor autoGarment chip collapseAll expandAll toggleGrp delAsk delNo delYes delF delOpt delPhoto dupAllBoth dupAllNew dupAllOld dupBack dupBoth dupKeepNew dupKeepOld dupNo dupOk fDiff fStage fStatus favAuth favPat fileAuthor importStop paste renCancel renF renSave resetFilters setActiveSize toggleEdit tv undoDel',
  settings: 'bkHide clearWallpaper recoverLocal removePw setPw file',
  tools: 'cell copySr resultPhoto rgRun tnSave',
  projects: 'coverPick plannedColorAdd plannedColorDel sendIsland stitchAdd stitchDel undoStage',
  'pdf-reader': 'viewPdf',
};
