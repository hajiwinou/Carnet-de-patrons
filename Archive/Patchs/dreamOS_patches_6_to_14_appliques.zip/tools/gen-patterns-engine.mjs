#!/usr/bin/env node
// Extrait VERBATIM le moteur pur de Patterns depuis app.js (Phase 3.8) → dreamOS/patterns/patterns-engine.js
// Usage : node tools/gen-patterns-engine.mjs
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { collect as collectGeneric, generate as generateGeneric } from './lib/engine-extractor.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const CONFIG = {
  consts: ['SIZES', 'MEASURES', 'COUNTS', 'CORE_ROWS', 'GROUPDEF', 'GROUP_NAMES', 'SCHEMA', 'ALLF', 'ABBR', 'HEAD', 'GARMENT_RE'],
  funcs: ['cleanText', 'isHeading', 'chunkText', 'guessAuthor', 'guessGarment', 'normAuthor', 'filled', 'completeness', 'checks', 'coerce', 'fieldDef', 'applyAI', 'putGrid', 'applyGrids', 'findOpt', 'applyOptGrids', 'mergeOptions', 'specText', 'groupSpec', 'rowSpec', 'optList'],
  populate: (src) => src.startsWith('SCHEMA.forEach'),
  hookRe: /var ph = patHost\(\); if \(ph\) return ph\.engine\.\w+\([^)]*\);\s*/g,
  factory: 'createPatternsEngine', deps: ['uid'],
  header: `/**
 * dreamOS — Moteur pur de Patterns (Phase 3.8)
 * Extrait VERBATIM d'app.js par tools/gen-patterns-engine.mjs (analyse TypeScript), sans aucune modification de logique :
 * nettoyage et découpage du texte importé, devinettes auteur / vêtement, schéma de la fiche, complétude, contrôles
 * de cohérence, application des données de l'IA, fusion des options et des grilles de tailles.
 * Aucune lecture ni écriture de stockage, de DOM ou d'état : les fonctions reçoivent le patron concerné en paramètre
 * (et modifient cet objet, comme le code historique) ; l'enregistrement et le rendu restent à app.js.
 * Seule dépendance externe : le générateur d'identifiants (uid), injecté.
 */`
};
export const collect = (text, strip = true) => collectGeneric(text, CONFIG, strip);
export const generate = (text) => generateGeneric(text, CONFIG);
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { out, count } = generate(fs.readFileSync(path.join(root, 'app.js'), 'utf8'));
  fs.mkdirSync(path.join(root, 'dreamOS/patterns'), { recursive: true });
  fs.writeFileSync(path.join(root, 'dreamOS/patterns/patterns-engine.js'), out);
  console.log('généré :', out.split('\n').length, 'lignes ;', count, 'éléments');
}
