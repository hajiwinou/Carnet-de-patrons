#!/usr/bin/env node
// Génère dreamOS/modules/action-map.js : action data-act → module métier (Phase 3.2). Lecture seule sur app.js.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { ACTION_RULES, ACTION_OVERRIDES } from './action-rules.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = fs.readFileSync(path.join(root, 'app.js'), 'utf8') + fs.readFileSync(path.join(root, 'index.html'), 'utf8');
export function extractActions(text) {
  const tpl = [...text.matchAll(/data-act=\\?"([A-Za-z0-9_]+)/g)].map((m) => m[1]);
  const hdl = [...text.matchAll(/\ba ?(?:===|==) ?'([A-Za-z0-9_]+)'/g)].map((m) => m[1]);
  return [...new Set([...tpl, ...hdl])].sort();
}
const override = {}; for (const [m, list] of Object.entries(ACTION_OVERRIDES)) list.split(/\s+/).forEach((a) => { override[a] = m; });
const norm = (m) => (m === 'navigation/engine' ? 'engine' : m === 'dialogs' ? 'dialogs' : m);
const map = {}; const missing = [];
for (const a of extractActions(src)) {
  const m = override[a] || (ACTION_RULES.find(([re]) => re.test(a)) || [])[1];
  if (m) map[a] = norm(m); else missing.push(a);
}
// actions de sauvegarde manuelle (blocs if(a==='x') sans espaces) : à ranger dans settings/backup
for (const a of missing.slice()) if (/^backup/.test(a)) { map[a] = 'settings'; missing.splice(missing.indexOf(a), 1); }
if (missing.length) { console.error('Actions non classées :', missing.join(' ')); process.exit(1); }
const body = Object.keys(map).sort().map((a) => `  ${/^[A-Za-z_]\w*$/.test(a) ? a : JSON.stringify(a)}: '${map[a]}'`).join(',\n');
fs.writeFileSync(path.join(root, 'dreamOS/modules/action-map.js'), `/**\n * dreamOS — Carte des actions data-act → module (Phase 3.2). GÉNÉRÉ par tools/gen-action-map.mjs, relu à la main.\n * 'engine' = navigation et actions transverses ; 'dialogs' = boutons des dialogues.\n */\nexport const ACTION_MAP = Object.freeze({\n${body}\n});\n`);
console.log(Object.keys(map).length, 'actions');
