# dreamOS — Phase 3.10 : module PDF Reader (calculs purs)

## Ce qui change
- `dreamOS/pdf-reader/pdf-reader-engine.js` : 11 calculs purs du lecteur PDF — page courante, formatage des durées, rythme et temps restant (compteur de rangs), contexte de note, zoom borné, position du compteur flottant, hauteur du panneau, position de reprise, surcouches de surlignage / repères.
- `dreamOS/pdf-reader/pdf-reader-host.js` : `window.DreamOSPdfReaderHost` (`engage()` / `release()`), ressource `logic:pdf-reader-engine` transférée de `legacy` à `pdf-reader`.
- app.js : `pdfHost()` + 12 points de délégation ; les mesures du DOM sont passées en paramètres, le code d'origine reste en repli.
- Version 3.10.0, cache du service worker `atelier-tricot-v20`.

## Ne change pas
DOM, pdf.js, positions enregistrées (`carnet.vpos.*`, `vhl`, `vmark`, `vsm`), compteur de rangs (propriété de Projects), ouverture / fermeture du lecteur, volet d'outils.

## Retour arrière
`window.DreamOSPdfReaderHost.release()` ou `?pdfreader=legacy` dans l'URL.

## Tests (tous OK ici)
`tests/phase3_10.test.mjs` : ~105 000 comparaisons sur DOM simulé (1500 scénarios), hôte absent / engagé, état du DOM comparé après chaque appel ; cas dirigés (seuils de durée, 20 derniers intervalles, zoom, hauteurs) ; 10 mutations toutes détectées ; garde-fou « pas de DOM / stockage ». `phase3_5` adapté (stub `pdfHost`).

## À faire de votre côté
Lancer `phase2_8_backup_format` et `phase2_8_regression.browser` (jszip / playwright absents ici). Puis ouvrir un PDF : défilement (n° de page), zoom, compteur de rangs flottant (rythme), surlignages et repère, ouverture du panneau d'outils.

## Étape suivante : 3.11 Documentation (dernier module « simple »), puis bilan du Jalon 3.
