# Jalon 4.6c — Projects modifie le journal, les photos et la couverture d'un projet

Version 4.6.2 · cache du service worker `atelier-tricot-v29`.

## Ce qui a bougé
- Nouveau `dreamOS/projects/projects-commands.js` : commandes nommées (ajout d'entrée, temps tricoté, chronomètre, photos, couverture, inspiration, acquittement de l'île). Elles s'appliquent au projet passé en paramètre, copient fidèlement le code d'origine (champs, ordre, identifiants `e…` / `i…`) et ne font ni enregistrement, ni suppression de média, ni rendu.
- `projects-host.js` expose `host.commands` (option `now` pour l'horloge).
- `app.js` : 17 petites portes (`pjAddEntry`, `pjAddTimeEntry`, `pjResetTimer`, `pjEnsureTimer`, `pjEnsurePhotos/Inspo`, `pjAddPhoto`, `pjAddCoverPhoto`, `pjAddInspoPhoto/Idea`, `pjClearCover(If)`, `pjPickCover`, `pjRemovePhoto/Entry/Inspo`, `pjAckIsland`) : module engagé → commande ; sinon code d'origine. Les gestionnaires (14 sites + notes d'outils + ajout d'idées) passent par elles.

## Ce qui reste
Fils, plan de couleurs, objectif de sous-étape, compteur de rangs, étape, simulation de développement, drapeaux de l'île (`islandPin`, `leftIsland`), notes (`saveSoonPj`) : prochains sous-jalons. Patterns modifie encore `pr.patternId`.

## Vérification
`tests/jalon4_6c.test.mjs` (13 600 comparaisons) : commandes seules, 11 scénarios sur le vrai code d'app.js (module absent / engagé / relâché puis réengagé), attentes absolues, garde-fous statiques (aucune écriture directe de ces champs hors des portes). 14 mutations injectées, toutes détectées. Suite complète verte (phase2, phase3, jalon4).

## Retour arrière
`?projects=legacy` : le code d'origine reprend la main sans rien perdre.
