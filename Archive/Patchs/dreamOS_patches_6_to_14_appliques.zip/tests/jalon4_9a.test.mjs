// Jalon 4.9a — Settings écrit lui-même les réglages (apparence, options, IA, verrou, dernière sauvegarde) et le fond d'écran wp_* (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installSettingsHost, SETTINGS_RESOURCES } from '../dreamOS/settings/settings-host.js';
import { createSettingsStore, SETTINGS_PERSISTED_KEYS } from '../dreamOS/settings/settings-store.js';
import { createSettingsMedia } from '../dreamOS/settings/settings-media.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const doorBlock = grab(/  function setHost\(\)[\s\S]*?\n  function saveUiSoon[^\n]*\n/, 'portes');
const blk = (cond) => grab(new RegExp('    if \\(' + cond + '\\) \\{[\\s\\S]*?\\n    \\}\\n'), cond);
const act = (head) => 'if (false) {}\n' + grab(new RegExp("    else if \\(a === '" + head + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), head);
const BR = { island: blk('t\\.dataset\\.island'), stat: blk('t\\.dataset\\.stat'), opt: blk('t\\.dataset\\.opt'), wall: blk("t\\.id === 'wallpaperIn' && t\\.files && t\\.files\\[0\\]"), clearWp: act('clearWallpaper'), setPw: act('setPw'), removePw: act('removePw') };
const markDone = grab(/  function backupMarkDone\(\) \{[\s\S]*?\n  \}\n/, 'backupMarkDone');

// 1. garde-fous statiques
const outside = app.replace(doorBlock, '');
for (const [re, what] of [[/keep\('carnet\.(ui|ai|opts|pwHash|pwFail|lastBackup|theme)'/g, 'stockage des réglages'], [/localStorage\.(setItem|removeItem)\(PW_FAIL_KEY/g, 'essais ratés'], [/IDB\.del\(S\.ui\.wallpaperId\)/g, 'suppression du fond'], [/'wp_' \+ uid\(\)/g, 'identifiant du fond'], [/saveBlob\(wid/g, 'écriture du fond']]) assert.deepEqual(outside.match(re) || [], [], 'hors portes : ' + what);
for (const n of ['setHost', 'setKeep', 'setWpNewId', 'setWpPut', 'setWpDiscard', 'pwFailPhys', 'pwFailSet', 'saveAiCfg', 'saveUiCfg', 'saveUiSoon']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);
for (const [re, c] of [[/(?<!function )stPwHash\(/g, 3], [/setKeep\('carnet\.ui', S\.ui\)/g, 4], [/setKeep\('carnet\.opts', S\.opts\)/g, 1], [/setKeep\('carnet\.lastBackup',Date\.now\(\)\)/g, 1], [/setWpDiscard\(S\.ui\.wallpaperId\)/g, 2], [/(?<!function )setWpNewId\(\)/g, 1], [/(?<!function )setWpPut\(wid, wb\)/g, 1]]) assert.equal((app.match(re) || []).length, c, String(re));
assert.equal((app.match(/function pwFailSet\(/g) || []).length, 1);
for (const k of SETTINGS_PERSISTED_KEYS) assert.ok(SETTINGS_RESOURCES.some(([t, n, o]) => t === 'storage' && n === k && o === 'settings'), k);
assert.ok(SETTINGS_RESOURCES.some(([t, n]) => t === 'media' && n === 'wp_*'));

// 2. magasin et médias seuls
{ const ev = []; const st = createSettingsStore({ eventBus: { emit: (t, d) => ev.push([t, d.key]) } }); const w = [];
  for (const k of SETTINGS_PERSISTED_KEYS) st.persist(k, { a: 1 }, (kk, v) => w.push([kk, v])); assert.equal(w.length, 7); assert.deepEqual(ev[0], ['settings:persisted', 'carnet.ui']);
  assert.throws(() => st.persist('carnet.patterns', 1, () => {}), /non gérée/); assert.throws(() => st.persist('carnet.ui', 1), /écriture requise/); assert.ok(Object.isFrozen(st));
  const me = []; const m = createSettingsMedia({ eventBus: { emit: (t, d) => me.push([t, d.id]) } }); assert.equal(m.newId(() => 'x1'), 'wp_x1'); assert.equal(m.isOwn('wp_a'), true); assert.equal(m.isOwn('img_a'), false);
  const blobs = []; (async () => { await m.put('wp_a', 'B', async (i, b) => { blobs.push([i, b]); return 'ok'; }); })(); await new Promise((r) => setTimeout(r, 0)); assert.deepEqual(blobs, [['wp_a', 'B']]);
  await assert.rejects(() => m.put('img_a', 'B', async () => {}), /wp_ requis/); await assert.rejects(() => m.put('wp_a', 'B'), /écriture requise/);
  const del = []; m.discard('ancien', (i) => del.push(i)); m.discard('wp_z', (i) => del.push(i)); assert.deepEqual(del, ['ancien', 'wp_z']); assert.throws(() => m.discard('x'), /suppression requise/); assert.ok(Object.isFrozen(m)); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'S', 'uid', 'keep', 'IDB', 'saveBlob', 'shrink', 'applyAppearance', 'toast', 'render', 'localStorage', 'PW_FAIL_KEY', 'PW_MIN', 'hashPw', 'pwSupported', '$', 'setTimeout', 'clearTimeout', 'uiT', 'backupArtifact', 'ISLAND_ANIMALS', 'a', 't', 'sc', 'Date'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
async function run(mode, st, sc) {
  const win = {}, log = [], S = clone(st.S); let n = 0; const uid = () => 'u' + (++n), timers = [];
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installSettingsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const ctx = { window: win, S, uid, keep: (k, v) => log.push(['keep', k, JSON.stringify(v)]), IDB: { del: (i) => log.push(['del', i]) }, saveBlob: async (i, b) => { log.push(['blob', i, b]); }, shrink: async (f) => 'shrunk:' + f, applyAppearance: () => log.push(['appearance']), toast: (m) => log.push(['toast', m]), render: () => log.push(['render']),
    localStorage: { setItem: (k, v) => log.push(['ls-set', k, v]), removeItem: (k) => log.push(['ls-rm', k]) }, PW_FAIL_KEY: 'carnet.pwFail', PW_MIN: 4, hashPw: async (p) => 'H(' + p + ')', pwSupported: () => true, $: () => ({ value: sc.pw }), setTimeout: (f) => { timers.push(f); return timers.length; }, clearTimeout: () => log.push(['clear']), uiT: null,
    backupArtifact: sc.art ? { idx: sc.art.idx, done: clone(sc.art.done), parts: sc.art.parts } : null, ISLAND_ANIMALS: [{ id: 'chat' }], a: sc.a, t: sc.t || {}, sc, Date: FakeDate };
  const body = `${doorBlock}${markDone}\nreturn (async function(){ ${sc.code}\n })();`;
  await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  timers.forEach((f) => f());
  return JSON.stringify({ S: { ui: S.ui, ai: S.ai, opts: S.opts, pwHash: S.pwHash, unlocked: S.unlocked }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(Math.imul(seed, 2654435761) >>> 0);
  const st = { S: { ui: { accent: '#2A47C9', wallpaperId: pick(r, ['', 'wp_old', 'ancien']), island: pick(r, [undefined, { on: true, months: 4, animal: 'chat' }]), stats: pick(r, [undefined, { a: true }]) }, ai: { prefText: 'groq', models: {} }, opts: { dup: 3, auto: false }, pwHash: pick(r, ['', 'pbkdf2$1$a$b']), unlocked: false } };
  const pw = pick(r, ['', 'abc', 'secret']), chk = r() < .5;
  const scs = [
    { kind: 'ai', code: 'saveAiCfg();' }, { kind: 'uiCfg', code: 'saveUiCfg();' }, { kind: 'uiSoon', code: 'saveUiSoon();' },
    { kind: 'pwFail', code: 'pwFailSet(sc.o);', o: pick(r, [null, { n: 3, until: 5 }]) },
    { kind: 'island', code: BR.island, t: { dataset: { island: pick(r, ['on', 'animal', 'months']) }, checked: chk, value: pick(r, ['chat', '0', '6']) } },
    { kind: 'stat', code: BR.stat, t: { dataset: { stat: 'b' }, checked: chk } },
    { kind: 'opt', code: BR.opt, t: { dataset: { opt: pick(r, ['dup', 'auto']) }, type: pick(r, ['checkbox', 'number']), checked: chk, value: pick(r, ['7', '0', 'x']) } },
    { kind: 'wall', code: BR.wall, t: { id: 'wallpaperIn', files: ['F'], value: 'v' } }, { kind: 'clearWp', code: BR.clearWp, a: 'clearWallpaper' },
    { kind: 'setPw', code: BR.setPw, a: 'setPw', pw }, { kind: 'removePw', code: BR.removePw, a: 'removePw' },
    { kind: 'backup', code: 'backupMarkDone();', art: pick(r, [{ idx: 1, done: { 0: true }, parts: [1, 2] }, { idx: 0, done: {}, parts: [1, 2] }]) }
  ];
  for (const sc of scs) {
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), L = out.log, keeps = L.filter((l) => l[0] === 'keep'), names = L.map((l) => l[0]);
    if (sc.kind === 'ai') assert.deepEqual(L, [['keep', 'carnet.ai', JSON.stringify(st.S.ai)]]);
    if (sc.kind === 'uiCfg') assert.deepEqual(L, [['keep', 'carnet.ui', JSON.stringify(st.S.ui)], ['appearance']]);
    if (sc.kind === 'uiSoon') assert.deepEqual(L, [['appearance'], ['clear'], ['keep', 'carnet.ui', JSON.stringify(st.S.ui)]]);
    if (sc.kind === 'pwFail') assert.deepEqual(L, [sc.o ? ['ls-set', 'carnet.pwFail', JSON.stringify(sc.o)] : ['ls-rm', 'carnet.pwFail']]);
    if (sc.kind === 'island') { const d = sc.t.dataset.island, io = Object.assign({ on: false, months: 3, animal: 'chat' }, st.S.ui.island || {}); if (d === 'on') io.on = chk; else if (d === 'animal') io.animal = sc.t.value; else io.months = Math.max(1, parseInt(sc.t.value, 10) || 3); assert.deepEqual(out.S.ui.island, io); assert.deepEqual(keeps[0].slice(1), ['carnet.ui', JSON.stringify(out.S.ui)]); assert.deepEqual(names, d === 'animal' ? ['keep', 'render'] : ['keep']); }
    if (sc.kind === 'stat') { assert.deepEqual(out.S.ui.stats, Object.assign({}, st.S.ui.stats || {}, { b: chk })); assert.deepEqual(names, ['keep']); assert.equal(keeps[0][1], 'carnet.ui'); }
    if (sc.kind === 'opt') { const k = sc.t.dataset.opt, v = sc.t.type === 'checkbox' ? chk : Math.max(1, parseInt(sc.t.value, 10) || st.S.opts[k]); assert.equal(out.S.opts[k], v); assert.deepEqual(keeps[0].slice(1), ['carnet.opts', JSON.stringify(out.S.opts)]); assert.deepEqual(names, sc.t.type === 'checkbox' ? ['keep', 'render'] : ['keep']); }
    if (sc.kind === 'wall') { const old = st.S.ui.wallpaperId; assert.equal(out.S.ui.wallpaperId, 'wp_u1'); assert.deepEqual(L.filter((l) => l[0] === 'blob'), [['blob', 'wp_u1', 'shrunk:F']]); assert.deepEqual(L.filter((l) => l[0] === 'del'), old ? [['del', old]] : []); assert.deepEqual(names.filter((x) => x !== 'del'), ['render', 'blob', 'keep', 'appearance', 'render', 'toast']); assert.equal(keeps[0][1], 'carnet.ui'); if (old) assert.ok(names.indexOf('del') < names.indexOf('blob')); }
    if (sc.kind === 'clearWp') { const old = st.S.ui.wallpaperId; assert.equal(out.S.ui.wallpaperId, ''); assert.deepEqual(L.filter((l) => l[0] === 'del'), old ? [['del', old]] : []); assert.deepEqual(names.filter((x) => x !== 'del'), ['keep', 'appearance', 'render', 'toast']); }
    if (sc.kind === 'setPw') { if (!pw) assert.deepEqual(L, [['toast', 'Saisissez un mot de passe.']]); else if (pw.length < 4) assert.deepEqual(names, ['toast']); else { assert.equal(out.S.pwHash, 'H(' + pw + ')'); assert.deepEqual(L.filter((l) => l[0] === 'keep'), [['keep', 'carnet.pwHash', JSON.stringify('H(' + pw + ')')]]); assert.deepEqual(L.filter((l) => /^ls-/.test(l[0])), [['ls-rm', 'carnet.pwFail']]); assert.equal(out.S.unlocked, true); } }
    if (sc.kind === 'removePw') { assert.equal(out.S.pwHash, ''); assert.deepEqual(L.filter((l) => l[0] === 'keep'), [['keep', 'carnet.pwHash', '""']]); assert.deepEqual(L.filter((l) => /^ls-/.test(l[0])), [['ls-rm', 'carnet.pwFail']]); assert.equal(out.S.unlocked, true); }
    if (sc.kind === 'backup') { const last = Object.keys(Object.assign({ [sc.art.idx]: true }, sc.art.done)).length >= 2; assert.deepEqual(L, last ? [['keep', 'carnet.lastBackup', String(NOW)]] : []); }
    checks++;
  }
}
console.log('jalon4_9a OK —', checks, 'comparaisons');
