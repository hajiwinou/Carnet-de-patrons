// Jalon 4.5 — Downloads propriétaire de carnet.igApi (adresse + clé Cobalt) : une seule autorité d'écriture, clé jamais divulguée
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installDownloadsHost } from '../dreamOS/downloads/downloads-host.js';
import { createDownloadsStore, DOWNLOADS_CONFIG_FIELDS } from '../dreamOS/downloads/downloads-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const helperSrc = grab(/  function igCfgSet\(field, value\)[^\n]*\n/, 'igCfgSet'), handlerSrc = grab(/    if \(t\.dataset\.ig\) \{[^\n]*\n/, 'saisie igCfg');

// 1. garde-fous statiques
const outside = app.replace(helperSrc, '');
assert.deepEqual(outside.match(/keep\(\s*'carnet\.igApi'|S\.igCfg(\.\w+|\[[^\]]+\])\s*=[^=]|S\.igCfg\s*=[^=]/g) || [], [], 'écriture directe de la configuration Cobalt');
assert.deepEqual([...new Set(app.match(/data-ig="[a-zA-Z]+"/g).map((x) => x.slice(9, -1)))].sort(), [...DOWNLOADS_CONFIG_FIELDS].sort(), 'champs de saisie = champs gérés');

// 2. propriété
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {}; assert.equal(reg.ownerOf('storage', 'carnet.igApi'), 'legacy');
  const h = installDownloadsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.igApi'), 'downloads'); assert.equal(reg.ownerOf('logic', 'cobalt-client'), 'downloads');
  assert.throws(() => reg.transferOwnership('storage', 'carnet.igApi', 'legacy', 'tools'), /transfert refusé/); h.release(); assert.equal(reg.ownerOf('storage', 'carnet.igApi'), 'legacy'); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.igApi'), 'downloads'); }

// 3. magasin : champs, écriture, confidentialité de la clé
{ const bus = new EventBus(), seen = []; bus.on('downloads:config-saved', (p) => seen.push(p)); const st = createDownloadsStore({ eventBus: bus }); const cfg = { endpoint: '', key: '' }, w = [];
  const SECRET = 'cle-secrete-12345'; assert.equal(st.setConfig(cfg, 'key', SECRET, (k, v) => w.push([k, JSON.stringify(v)])), true); assert.equal(cfg.key, SECRET); assert.deepEqual(w, [['carnet.igApi', JSON.stringify({ endpoint: '', key: SECRET })]]);
  st.setConfig(cfg, 'endpoint', 'http://127.0.0.1:9000', () => {}); assert.deepEqual(seen, [{ field: 'key' }, { field: 'endpoint' }]); assert.ok(!JSON.stringify(seen).includes(SECRET) && !JSON.stringify(seen).includes('127.0.0.1'), 'valeurs jamais publiées');
  assert.throws(() => st.setConfig(cfg, 'autre', 1, () => {}), /non géré/); assert.throws(() => st.setConfig(null, 'key', 1, () => {}), /configuration requise/); assert.throws(() => st.setConfig(cfg, 'key', 1), /écriture requise/);
  const bad = createDownloadsStore({ eventBus: { emit() { throw new Error('x'); } } }); assert.equal(bad.setConfig({}, 'key', 'v', () => {}), true);
  const code = fs.readFileSync(path.join(root, 'dreamOS/downloads/downloads-store.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, ''); for (const bad2 of [/console\./, /localStorage/, /fetch\(/, /document\b/, /window\b/]) assert.ok(!bad2.test(code), 'accès interdit : ' + bad2); }

// 4. équivalence sur le VRAI code d'app.js : saisie de l'adresse / de la clé, hôte absent / engagé / relâché à chaud
const ARGS = ['window', 'S', 'keep', 't'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; }; const pick = (r, a) => a[Math.floor(r() * a.length)];
function run(mode, init, edits) {
  const win = {}, log = [], S = { igCfg: JSON.parse(JSON.stringify(init)) };
  let host = null; if (mode !== 'legacy') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); host = installDownloadsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); host.engage(); }
  const f = new Function(...ARGS, `${helperSrc}\nreturn function(t){ ${handlerSrc.replace(/return;/g, '')} };`)(win, S, (k, v) => log.push([k, JSON.stringify(v)]), null);
  edits.forEach((e, i) => { if (mode === 'hot' && i === 2) host.release(); if (mode === 'hot' && i === 4) host.engage(); f({ dataset: { ig: e.field }, value: e.value }); });
  return JSON.stringify({ S: S.igCfg, log });
}
let checks = 0;
for (let seed = 1; seed <= 800; seed++) {
  const r = rng(seed), init = pick(r, [{ endpoint: '', key: '' }, { endpoint: 'http://a', key: 'k' }]);
  const edits = Array.from({ length: Math.floor(r() * 7) + 1 }, () => ({ field: pick(r, ['endpoint', 'key']), value: pick(r, ['', ' http://127.0.0.1:9000/ ', 'abc', 'x'.repeat(40)]) }));
  const A = run('legacy', init, edits), B = run('host', init, edits), C = run('hot', init, edits); assert.equal(B, A, 'hôte engagé ' + seed); assert.equal(C, A, 'bascule à chaud ' + seed);
  const out = JSON.parse(A); const last = {}; edits.forEach((e) => (last[e.field] = e.value)); for (const k of Object.keys(last)) assert.equal(out.S[k], last[k], 'dernière valeur saisie'); assert.equal(out.log.length, edits.length, 'une écriture par saisie'); assert.ok(out.log.every((l) => l[0] === 'carnet.igApi')); checks += 4;
}
console.log('jalon4_5 OK —', checks, 'comparaisons');
