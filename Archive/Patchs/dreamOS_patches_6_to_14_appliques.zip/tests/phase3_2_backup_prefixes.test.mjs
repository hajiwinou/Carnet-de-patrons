// Décision 3.1 : wp_, ideam_, pji_ sont détectés (avertissement) sans bloquer d'anciennes archives
import assert from 'node:assert/strict';
import { BackupManager } from '../dreamOS/backup-manager.js';

const archives = new WeakMap();
class FakeZip {
  constructor() { this.entries = new Map(); }
  file(name, value) {
    if (arguments.length === 1) {
      const stored = this.entries.get(name);
      return stored === undefined ? null : { async: async (kind) => kind === 'blob' ? (stored instanceof Blob ? stored : new Blob([stored])) : (stored instanceof Blob ? stored.text() : String(stored)) };
    }
    this.entries.set(name, value);
    return this;
  }
  folder(prefix) {
    const base = `${prefix}/`;
    return { forEach: (callback) => {
      for (const name of this.entries.keys()) {
        if (name.startsWith(base)) callback(name.slice(base.length), { dir: false });
      }
    }};
  }
  async generateAsync() {
    const blob = new Blob(['fake-zip']);
    archives.set(blob, new Map(this.entries));
    return blob;
  }
  static async loadAsync(blob) {
    const entries = archives.get(blob);
    if (!entries) throw new Error('Archive de test inconnue');
    const zip = new FakeZip();
    zip.entries = new Map(entries);
    return zip;
  }
}


const storage = { keys: async () => [], get: async () => null, put: async () => {}, delete: async () => {} };
const bm = new BackupManager({ storage, zipProvider: async () => FakeZip });
const make = async (data, blobs = []) => { const z = new FakeZip(); z.file('data.json', JSON.stringify(data)); blobs.forEach((b) => z.file('blobs/' + b, new Blob(['x']))); return z.generateAsync(); };

// ancienne archive : médias d'idées / inspirations absents → restaurable, avec avertissements
const info = await bm.inspectArchive(await make({ v: 1, patterns: [], projects: [{ id: 'j1', cover: 'pjc_1', inspo: [{ mediaId: 'pji_1' }] }], ideas: [{ mediaId: 'ideam_1' }] }, ['pjc_1']));
assert.equal(info.valid, true);
assert.equal(info.warnings.length, 2);
assert.ok(info.warnings.some((w) => w.includes('pji_1')) && info.warnings.some((w) => w.includes('ideam_1')));
// archive complète : aucun avertissement
const ok = await bm.inspectArchive(await make({ v: 1, patterns: [], ideas: [{ mediaId: 'ideam_1' }] }, ['ideam_1']));
assert.deepEqual([...ok.warnings], []);
// les préfixes historiques restent bloquants
const bad = await make({ v: 1, patterns: [], projects: [{ cover: 'pjc_9' }] });
await assert.rejects(() => bm.inspectArchive(bad), /incomplète/);
console.log('phase3_2_backup_prefixes : OK');
