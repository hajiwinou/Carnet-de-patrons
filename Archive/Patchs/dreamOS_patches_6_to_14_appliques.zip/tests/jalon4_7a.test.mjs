// Jalon 4.7a — Patterns est l'autorité d'écriture de la LISTE des patrons et des dossiers (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPatternsHost, PATTERNS_RESOURCES } from '../dreamOS/patterns/patterns-host.js';
import { createPatternsStore, PATTERNS_PERSISTED_KEYS } from '../dreamOS/patterns/patterns-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const fn = (n) => grab(new RegExp('  (?:async )?function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const doorsSrc = grab(/  function patHost\(\)[^\n]*\n/, 'patHost') + grab(/  function patStore\(\)[\s\S]*?\n  function patSetGroup[^\n]*\n/, 'portes patrons');
const SRC = [fn('removeP'), fn('removePSoft'), fn('removeFolderSoft'), fn('folderFor'), fn('restoreFromMirror'), fn('recoverLocalPatterns')].join('');
const act = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), n);
const BR = { paste: 'if (false) {}\n' + act('paste'), addF: 'if (false) {}\n' + act('addF') };

// 1. garde-fous statiques : plus aucune écriture directe de la liste / des dossiers hors des portes
const outsideAll = app.replace(grab(/  function patHost\(\)[\s\S]*?\n  function patSetGroup[^\n]*\n/, 'bloc des portes'), '');
const forbid = [[/S\.patterns\.(push|unshift|splice)\(/g, 'liste des patrons'], [/S\.patterns\s*=[^=]/g, 'affectation des patrons'], [/S\.patterns\[\w+\]\s*=[^=]/g, 'remplacement de patron'], [/S\.folders\.(push|unshift|splice)\(/g, 'liste des dossiers'], [/S\.folders\s*=[^=]/g, 'affectation des dossiers'],
  [/keep\('carnet\.(patterns|folders|ts)'/g, 'écriture directe du stockage'], [/IDB\.put\('meta_(patterns|folders)'/g, 'miroir']];
// (la fonction physique saveFoldersPhys et persistNowPhys sont les seules écritures physiques autorisées ; l'état initial `patterns: load(…)` n'est pas une écriture)
let outside = outsideAll.replace(/  function saveFoldersPhys\(\)[^\n]*\n/, '').replace(/  function persistNowPhys\(\) \{[\s\S]*?\n  \}\n/, '').replace(/  function mirrorFlush\(\) \{[\s\S]*?\n  \}\n/, '');
for (const [re, what] of forbid) assert.deepEqual(outside.match(re) || [], [], 'écriture directe hors portes : ' + what);
for (const n of ['patStore', 'fldStore', 'persist', 'persistNow', 'saveFolders', 'patKeep', 'patternsAppend', 'patternsPrepend', 'patternsRemoveAt', 'patternsInsertAt', 'patternsRemoveById', 'patternsUpsert', 'patternsReplace', 'foldersAppend', 'foldersRemoveAt', 'foldersInsertAt', 'foldersReplace']) assert.ok(new RegExp('function ' + n + '\\(').test(app), n);
assert.equal((app.match(/function persistPhys\(/g) || []).length, 1); assert.equal((app.match(/persistNowPhys\(\)/g) || []).length >= 3, true);

// 2. magasin seul
{ const ev = []; const bus = { emit: (t, d) => ev.push(t) }; const st = createPatternsStore({ eventBus: bus }); const saves = [];
  assert.throws(() => st.patterns.append({}), /aucun tableau/); const a = [{ id: 'a' }], f = [{ id: 'f' }];
  st.patterns.adopt(a, { save: (x, light) => saves.push(['save', x === a, light]), saveNow: (x) => { saves.push(['now', x === a]); return Promise.resolve(7); } }); st.folders.adopt(f, { save: () => saves.push(['fsave']) });
  assert.throws(() => st.patterns.adopt('x'), /tableau requis/); assert.equal(st.patterns.list(), a); assert.equal(st.patterns.count(), 1);
  st.patterns.prepend({ id: 'b' }); st.patterns.append({ id: 'c' }); assert.deepEqual(a.map((x) => x.id), ['b', 'a', 'c']); assert.equal(st.patterns.removeAt(1).id, 'a'); st.patterns.insertAt(9, { id: 'z' }); assert.deepEqual(a.map((x) => x.id), ['b', 'c', 'z']); st.patterns.insertAt(0, { id: 'y' }); assert.equal(a[0].id, 'y');
  const u1 = { id: 'c', t: 1 }; st.patterns.upsert(u1); assert.equal(a[2], u1); st.patterns.upsert({ id: 'new' }); assert.equal(a[0].id, 'new'); a.push({ id: 'b' }); assert.equal(st.patterns.removeById('b'), 2); assert.ok(!a.some((x) => x.id === 'b')); assert.equal(st.patterns.removeById('zz'), 0);
  const keep = st.patterns.list(); st.patterns.replaceAll([{ id: 'r1' }, { id: 'r2' }]); assert.equal(st.patterns.list(), keep); assert.deepEqual(a.map((x) => x.id), ['r1', 'r2']); st.patterns.replaceAll(a); assert.equal(a.length, 2); st.patterns.replaceAll(null); assert.equal(a.length, 0);
  st.patterns.save(true); st.patterns.save(); assert.deepEqual(saves.slice(0, 2), [['save', true, true], ['save', true, undefined]]); return_check(st.patterns.saveNow()); function return_check(p) { assert.ok(p instanceof Promise); }
  st.folders.append({ id: 'g' }); st.folders.removeAt(0); st.folders.save(); assert.ok(saves.some((x) => x[0] === 'fsave')); assert.deepEqual(f.map((x) => x.id), ['g']);
  const w = []; assert.equal(st.persist('carnet.patterns', [1], (k, v) => w.push([k, v])), true); assert.deepEqual(w, [['carnet.patterns', [1]]]); assert.throws(() => st.persist('carnet.other', 1, () => {}), /non gérée/); assert.throws(() => st.persist('carnet.ts', 1), /écriture requise/);
  assert.deepEqual([...PATTERNS_PERSISTED_KEYS], ['carnet.patterns', 'carnet.ts', 'carnet.folders', 'carnet.favAuthors', 'carnet.collapsed', 'carnet.group']); assert.ok(ev.includes('patterns:patterns:added') || ev.some((t) => t.includes('added'))); assert.ok(Object.isFrozen(st)); }

// 3. propriété des ressources
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {}; const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win });
  const owners = () => PATTERNS_RESOURCES.map(([k, n]) => reg.ownerOf(k, n)); assert.deepEqual(owners(), PATTERNS_RESOURCES.map(() => 'legacy')); h.engage(); assert.deepEqual(owners(), PATTERNS_RESOURCES.map(() => 'patterns')); h.release(); assert.deepEqual(owners(), PATTERNS_RESOURCES.map(() => 'legacy'));
  for (const k of ['carnet.patterns', 'carnet.ts', 'carnet.folders']) assert.ok(PATTERNS_RESOURCES.some(([t, n]) => t === 'storage' && n === k), k); assert.ok(h.store && h.store.patterns && h.store.folders); }

// 4. équivalence sur le vrai code : hôte absent / engagé / relâché puis réengagé
const ARGS = ['window', 'S', 'uid', 'keep', 'IDB', 'toast', 'render', 'askConfirm', 'deferDelete', 'load', 'sc', 'pjLinkProjects', 'pjUnlinkPattern', 'saveProjects', 'patJson', 'gkey', 'newPattern', 'openP', '$', 'a', 'restoreAuxiliary', 'projectsReplace', 'gridsReplace', 'storageFailure', 'newProject', 'autoFile', 'Date'];
const FakeDate = class extends Date { static now() { return 1_800_000_000_000; } };
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
function state(r) {
  const patterns = Array.from({ length: Math.floor(r() * 4) + 1 }, (_, i) => ({ id: 'p' + i, title: 'T' + i, folder: pick(r, [undefined, 'd0', 'd1']), source: { pdf: 'pdf_' + i }, thumb: 'th_' + i, photos: [{ id: 'img_' + i }, {}] }));
  const folders = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ id: 'd' + i, name: 'Dossier' + i, created: i }));
  return { patterns, folders, projects: [], favAuthors: [], delF: 'x', renameId: 'y', busy: '', importRunning: false, log: [], ui: {} };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => 1_800_000_000_000, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const idb = { meta_patterns: sc.mirror, meta_folders: sc.fmirror, meta_snapshot_1: sc.snap, pdf_orphan: sc.orphan };
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), IDB: { put: (k) => { log.push(['idbput', k]); return Promise.resolve(); }, del: (id) => log.push(['idbdel', id]), keys: async () => Object.keys(idb).filter((k) => idb[k] !== undefined), get: async (k) => idb[k] },
    toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), askConfirm: async () => true, deferDelete: (m, undo, done) => { log.push(['defer', m]); if (sc.undo) undo(); else done(); log.push([sc.undo ? 'undone' : 'done']); }, load: (k, d) => (k === 'carnet.ts' ? sc.ts || 0 : d), sc,
    pjLinkProjects: () => {}, pjUnlinkPattern: () => {}, saveProjects: () => {}, patJson: {}, gkey: (s) => String(s).toLowerCase(), newPattern: (t, tx, src) => ({ id: 'n' + uid(), title: t, text: tx, source: src }), openP: (id) => log.push(['open', id]),
    $: (s) => ({ value: s === '#pasteTitle' ? sc.title : s === '#pasteText' ? sc.text : s === '#newFolder' ? sc.fname : '' }), a: sc.a, restoreAuxiliary: async () => {}, projectsReplace: () => {}, gridsReplace: () => {}, storageFailure: (e) => log.push(['fail', String(e)]), newProject: () => {}, autoFile: () => {}, Date: FakeDate };
  const phys = `function persistPhys(light) { log.push(['persistPhys', !!light]); }\nasync function persistNowPhys() { log.push(['persistNowPhys']); return 'phys-ok'; }\nfunction saveFoldersPhys() { log.push(['foldersPhys', JSON.stringify(S.folders)]); }\nasync function safetySnapshot() { await persistNow(); log.push(['snap']); }\n`;
  const body = `${phys}${doorsSrc}${SRC}\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function('log', ...ARGS, body)(log, ...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { patterns: S.patterns, folders: S.folders, ret: S.ret }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(seed), st = state(r), p0 = st.patterns[0];
  const mirror = JSON.stringify({ ts: pick(r, [5, 5e12]), list: [{ id: 'm1' }, { id: 'm2' }] }), snapP = JSON.stringify({ patterns: [{ id: 'p0' }, { id: 'sn1' }] });
  const scs = [
    { kind: 'removeP', code: 'removeP(S.patterns[0]);' }, { kind: 'soft', code: 'removePSoft(S.patterns[sc.idx % S.patterns.length]);', undo: r() < .5, idx: Math.floor(r() * 9) }, { kind: 'light', code: 'persist(true); persist(); S.ret = await persistNow();' }, { kind: 'folder', code: 'removeFolderSoft(sc.fid);', fid: pick(r, ['d0', 'd1', 'd2', 'zz']), undo: r() < .5 },
    { kind: 'folderFor', code: 'S.ret = folderFor(sc.fname);', fname: pick(r, ['Dossier0', 'dossier1', 'Nouveau']) }, { kind: 'paste', code: BR.paste, a: 'paste', title: pick(r, ['', 'Mon titre']), text: pick(r, ['', '  ', 'maille 1'] ) },
    { kind: 'addF', code: BR.addF, a: 'addF', fname: pick(r, ['', 'Neuf']) }, { kind: 'mirrorF', noFolders: true, code: 'await restoreFromMirror();', mirror, fmirror: JSON.stringify([{ id: 'fm' }]), ts: 0 }, { kind: 'mirror', code: 'await restoreFromMirror();', mirror, fmirror: JSON.stringify([{ id: 'fm' }]), ts: pick(r, [0, 9]) }, { kind: 'recover', code: 'await recoverLocalPatterns();', snap: snapP, orphan: pick(r, [undefined, { arrayBuffer: 1, name: 'Vieux.pdf' }]) }
  ];
  if (st.folders.length) { /* états valides */ }
  for (const sc of scs) {
    const st0 = sc.noFolders ? { ...st, folders: [] } : st; const A = await run('absent', st0, sc), B = await run('engaged', st0, sc), C = await run('hot', st0, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), ids = out.S.patterns.map((x) => x.id), fids = out.S.folders.map((x) => x.id), L = out.log.map((l) => l[0]);
    if (sc.kind === 'removeP') { assert.deepEqual(ids, st.patterns.slice(1).map((x) => x.id)); assert.deepEqual(out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]), ['pdf_0', 'th_0', 'img_0']); assert.deepEqual(L.filter((x) => x.startsWith('persist')), ['persistPhys']); }
    if (sc.kind === 'soft') { const di = sc.idx % st.patterns.length; assert.deepEqual(ids, sc.undo ? st.patterns.map((x) => x.id) : st.patterns.filter((_, i) => i !== di).map((x) => x.id)); assert.equal(L.filter((x) => x === 'persistPhys').length, sc.undo ? 2 : 1); assert.equal(L.includes(sc.undo ? 'undone' : 'done'), true); }
    if (sc.kind === 'folder') { const has = st.folders.some((f) => f.id === sc.fid); if (!has) { assert.deepEqual(fids, st.folders.map((x) => x.id)); assert.deepEqual(L, []); } else { assert.deepEqual(fids, sc.undo ? st.folders.map((x) => x.id) : st.folders.filter((f) => f.id !== sc.fid).map((x) => x.id)); assert.equal(out.log.filter((l) => l[0] === 'foldersPhys').length, sc.undo ? 2 : 1); out.S.patterns.forEach((x, i) => assert.equal(x.folder, sc.undo || st.patterns[i].folder !== sc.fid ? (st.patterns[i].folder) : undefined)); } }
    if (sc.kind === 'folderFor') { const ex = st.folders.find((f) => f.name.toLowerCase() === sc.fname.toLowerCase()); if (ex) assert.deepEqual([fids, L], [st.folders.map((x) => x.id), []]); else { assert.deepEqual(fids, [...st.folders.map((x) => x.id), fids.at(-1)]); assert.match(fids.at(-1), /^du\d+$/); assert.equal(out.log.filter((l) => l[0] === 'foldersPhys').length, 1); } }
    if (sc.kind === 'paste') { if (!sc.text.trim()) { assert.deepEqual(ids, st.patterns.map((x) => x.id)); assert.deepEqual(L, ['toast']); } else { assert.equal(out.S.patterns[0].title, sc.title.trim() || 'Patron collé'); assert.equal(out.S.patterns.length, st.patterns.length + 1); assert.deepEqual(L.filter((x) => x.startsWith('persist') || x === 'open'), ['persistPhys', 'open']); } }
    if (sc.kind === 'addF') { if (!sc.fname) assert.deepEqual(fids, st.folders.map((x) => x.id)); else { assert.equal(out.S.folders.at(-1).name, 'Neuf'); assert.equal(out.log.filter((l) => l[0] === 'foldersPhys').length, 1); } }
    if (sc.kind === 'light') { assert.deepEqual(out.log.filter((l) => l[0].startsWith('persist')), [['persistPhys', true], ['persistPhys', false], ['persistNowPhys']]); assert.equal(out.S.ret, 'phys-ok'); }
    if (sc.kind === 'mirrorF') { assert.deepEqual(fids, ['fm']); assert.equal(out.log.filter((l) => l[0] === 'keep' && l[1] === 'carnet.folders').length, 1); assert.equal(out.log.find((l) => l[1] === 'carnet.folders')[2], JSON.stringify([{ id: 'fm' }])); }
    if (sc.kind === 'mirror') { const m = JSON.parse(mirror), ts = sc.ts || 0; const replaced = (!st.patterns.length || (m.ts || 0) > ts); assert.deepEqual(ids, replaced ? ['m1', 'm2'] : st.patterns.map((x) => x.id)); assert.equal(out.log.filter((l) => l[0] === 'keep' && l[1] === 'carnet.patterns').length, replaced ? 1 : 0); assert.equal(out.log.filter((l) => l[0] === 'keep' && l[1] === 'carnet.ts').length, replaced ? 1 : 0); if (replaced) assert.equal(out.log.find((l) => l[1] === 'carnet.ts')[2], JSON.stringify(m.ts)); assert.equal(out.log.filter((l) => l[0] === 'keep' && l[1] === 'carnet.folders').length, st.folders.length ? 0 : 1); }
    if (sc.kind === 'recover') { assert.equal(ids.length, st.patterns.length + 1 + (sc.orphan ? 1 : 0)); assert.deepEqual(ids.slice(st.patterns.length).length, 1 + (sc.orphan ? 1 : 0)); assert.equal(ids[st.patterns.length], 'sn1'); assert.ok(L.includes('snap')); assert.equal(L.filter((x) => x === 'persistNowPhys').length, 1); assert.equal(out.log.find((l) => l[0] === 'toast')[1], (1 + (sc.orphan ? 1 : 0)) + ' patron(s) récupéré(s).'); }
    checks++;
  }
}
console.log('jalon4_7a OK —', checks, 'comparaisons');
