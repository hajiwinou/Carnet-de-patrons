// Jalon 4.6c — Projects modifie lui-même le journal, les photos et la couverture d'un projet (commandes), sur le VRAI code d'app.js
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsCommands } from '../dreamOS/projects/projects-commands.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const helperSrc = grab(/  function projStore\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'projStore..pjRelinkPattern'), projHostSrc = one('projHost'), curSrc = one('curPj');
const door = grab(/  function pjCmd\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'portes');
const multi = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), n);
const single = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[^\\n]*\\n"), n);
const BR = { coverPick: multi('coverPick'), tmReset: single('tmReset'), tmLog: multi('tmLog'), pjAddNote: multi('pjAddNote'), pjCoverDel: single('pjCoverDel'), islandAck: single('islandAck'), islandBack: multi('islandBack'), islandOpen: multi('islandOpen'),
  inspoDel: multi('inspoDel'), pjDelEntryYes: multi('pjDelEntryYes'), pjPhotoDel: multi('pjPhotoDel') };
const photoBlocks = grab(/    if \(t\.id === 'pjCover' && t\.files && t\.files\[0\]\) \{[\s\S]*?(?=\n    if \(t\.id === 'rgPhoto')/, 'pjCover..pjPhotos');

// 1. garde-fous statiques : plus aucune écriture directe de ces champs hors des portes
const outside = app.replace(door, '');
const forbid = [[/(?<!S)\.log\.unshift\(/g, 'journal'], [/\.timer\s*=\s*\{/g, 'chronomètre'], [/\.coverPdf\s*=/g, 'couverture PDF'], [/\.cover\s*=[^=]/g, 'couverture'], [/\.photos\.push\(/g, 'photos'], [/\.photos\s*=\s*\(pr\w*\.photos/g, 'photos'], [/\.inspo\.push\(/g, 'inspiration'], [/\.inspo\s*=\s*(\[|\w+\.inspo\.filter)/g, 'inspiration'], [/isIsland\(x\)\) x\.islandSeen\s*=/g, 'île (acquittement groupé)'], [/\.log\s*=\s*\w+\.log\.filter/g, 'journal']];
for (const [re, what] of forbid) assert.deepEqual(outside.match(re) || [], [], 'écriture directe hors portes : ' + what);
for (const n of ['pjAddEntry', 'pjAddTimeEntry', 'pjResetTimer', 'pjEnsureTimer', 'pjEnsurePhotos', 'pjEnsureInspo', 'pjAddPhoto', 'pjAddCoverPhoto', 'pjAddInspoPhoto', 'pjAddInspoIdea', 'pjClearCover', 'pjClearCoverIf', 'pjPickCover', 'pjRemovePhoto', 'pjRemoveEntry', 'pjRemoveInspo', 'pjAckIsland']) assert.ok(new RegExp('function ' + n + '\\(').test(door), n);

// 2. commandes seules
{ let n = 0, t = 1000; const c = createProjectsCommands({ uid: () => 'u' + (++n), now: () => t });
  assert.throws(() => createProjectsCommands({}), /uid requis/);
  const p = { log: [], cover: 'c1', photos: ['c1', 'c2'], inspo: [], timer: { acc: 5, start: 9 } };
  assert.deepEqual(c.addLogEntry(p, 'x', ['a']), { id: 'eu1', ts: 1000, text: 'x', photos: ['a'] }); assert.equal(p.log[0].id, 'eu1');
  t = 2000; c.addTimeEntry(p, 3000, 'L'); assert.deepEqual(p.log[0], { id: 'eu2', ts: 2000, text: 'L', ms: 3000, photos: [] }); assert.equal(p.workAt, 2000); assert.deepEqual(p.timer, { acc: 0, start: 0 });
  p.timer = { acc: 1, start: 1 }; c.resetTimer(p); assert.deepEqual(p.timer, { acc: 0, start: 0 }); const nt = {}; c.ensureTimer(nt); assert.deepEqual(nt.timer, { acc: 0, start: 0 }); c.ensureTimer(p); assert.equal(p.timer.acc, 0);
  const q = {}; c.ensurePhotos(q); c.ensureInspo(q); assert.deepEqual(q, { photos: [], inspo: [] }); c.ensurePhotos(q); assert.deepEqual(q.photos, []);
  c.addCoverPhoto(q, 'n'); assert.deepEqual([q.photos, q.cover, q.coverPdf], [['n'], 'n', false]); c.addPhoto(q, 'm'); assert.deepEqual(q.photos, ['n', 'm']);
  assert.deepEqual(c.addInspoPhoto(q, 'pji_1'), { id: 'iu3', mediaId: 'pji_1', mediaType: 'image' });
  assert.deepEqual(c.addInspoIdea(q, 'idea1'), { id: 'iu4', ideaId: 'idea1' });
  c.pickCover(q, '__pdf'); assert.deepEqual([q.cover, q.coverPdf], ['n', true]); c.pickCover(q, '__auto'); assert.deepEqual([q.cover, q.coverPdf], ['', false]); c.pickCover(q, 'm'); assert.deepEqual([q.cover, q.coverPdf], ['m', false]);
  c.clearCoverIf(q, 'zz'); assert.equal(q.cover, 'm'); c.clearCoverIf(q, 'm'); assert.equal(q.cover, ''); q.cover = 'm'; c.clearCover(q); assert.equal(q.cover, '');
  q.cover = 'n'; c.removePhoto(q, 'n'); assert.deepEqual([q.photos, q.cover], [['m'], '']); const r = {}; c.removePhoto(r, 'x'); assert.deepEqual(r.photos, []);
  const l = { cover: 'a', log: [{ id: 'e1', photos: ['a', 'b'] }, { id: 'e2' }] }; assert.deepEqual(c.removeLogEntry(l, 'e1'), ['a', 'b']); assert.equal(l.cover, ''); assert.deepEqual(l.log, [{ id: 'e2' }]); assert.deepEqual(c.removeLogEntry(l, 'zz'), []); assert.equal(l.log.length, 1);
  const i = { inspo: [{ id: 'a' }, { id: 'b' }] }; c.removeInspo(i, 'a'); assert.deepEqual(i.inspo, [{ id: 'b' }]);
  const ps = [{ k: 1 }, { k: 2 }]; c.ackIsland(ps, (x) => x.k === 2); assert.deepEqual(ps, [{ k: 1 }, { k: 2, islandSeen: true }]);
  assert.ok(Object.isFrozen(c)); }

// 3. équivalence sur le vrai code : hôte absent / engagé / relâché puis réengagé
const ARGS = ['window', 'S', 'uid', 'keep', 'saveBlob', 'IDB', 'toast', 'render', 'askConfirm', 'confirm', 'deferDelete', 'Date', 'a', 'b', 'isIsland', 'tmMs', 'tmFmt', 'shrink', 't'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const projects = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ id: 'j' + i, name: 'P' + i, stage: 'wip', cover: pick(r, ['', 'pjc_a' + i, 'pjp_L' + i, 'pji_1' + i]), coverPdf: r() < .5, photos: ['pjc_a' + i, 'pjc_b' + i], inspo: [{ id: 'i1', mediaId: 'pji_1' + i, mediaType: 'image' }, { id: 'i2', ideaId: 'x', mediaId: 'ideam_z' }], log: [{ id: 'e1', ts: 1, text: 't', photos: ['pjp_L' + i, 'pjp_M' + i] }, { id: 'e2', ts: 2, text: '' }], timer: { acc: Math.floor(r() * 5000), start: 0 }, isl: r() < .5, created: i }));
  return { projects, curProj: projects[0].id, pjDraft: pick(r, ['', '  ', ' note ']), pjDel: false, pjDelEntry: null, pjIsland: false };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), saveBlob: async (id, bl) => { log.push(['blob', id, JSON.stringify(bl)]); }, IDB: { put: () => Promise.resolve(), del: (id) => log.push(['idbdel', id]) },
    toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), askConfirm: async () => sc.confirm, confirm: () => sc.confirm, deferDelete: (m, u, d) => { log.push(['defer', m]); d(); }, Date: FakeDate, a: sc.a, b: { dataset: { id: sc.id } },
    isIsland: (x) => !!x.isl, tmMs: (p) => p.timer.acc, tmFmt: (ms) => ms + 'ms', shrink: async (f) => 'shrunk:' + f.name, t: sc.t || {} };
  const body = `${projHostSrc}${curSrc}${helperSrc}\nreturn (async function(){ if (false) {}\n${sc.code} }).call(this);`;
  await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { projects: S.projects, pjDraft: S.pjDraft, pjDelEntry: S.pjDelEntry, pjIsland: S.pjIsland }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 400; seed++) {
  const r = rng(seed), st = state(r), pj = st.projects[0];
  const scs = [
    { kind: 'coverPick', a: 'coverPick', id: pick(r, ['__auto', '__pdf', 'pjc_b0', 'pjc_zz']) }, { kind: 'tmReset', a: 'tmReset' }, { kind: 'tmLog', a: 'tmLog' }, { kind: 'pjAddNote', a: 'pjAddNote' }, { kind: 'pjCoverDel', a: 'pjCoverDel' },
    { kind: 'islandAck', a: 'islandAck' }, { kind: 'islandBack', a: 'islandBack' }, { kind: 'islandOpen', a: 'islandOpen' }, { kind: 'inspoDel', a: 'inspoDel', id: pick(r, ['i1', 'i2', 'zz']), confirm: r() < .7 }, { kind: 'pjDelEntryYes', a: 'pjDelEntryYes', id: pick(r, ['e1', 'e2', 'zz']) },
    { kind: 'pjPhotoDel', a: 'pjPhotoDel', id: pick(r, ['pjc_a0', 'pjc_b0', 'pjc_zz']), confirm: r() < .7 }
  ];
  for (const sc of scs) {
    sc.code = BR[sc.kind];
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché/réengagé seed ${seed}`); checks += 2;
    const out = JSON.parse(A), P = out.S.projects[0], keeps = out.log.filter((l) => l[0] === 'keep').length, dels = out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]);
    // attentes absolues
    if (sc.kind === 'coverPick') { if (sc.id === '__auto') assert.deepEqual([P.cover, P.coverPdf], ['', false]); else if (sc.id === '__pdf') assert.deepEqual([P.cover, P.coverPdf], [pj.cover, true]); else assert.deepEqual([P.cover, P.coverPdf], [sc.id, false]); assert.equal(keeps, 1); }
    if (sc.kind === 'tmReset') { assert.deepEqual(P.timer, { acc: 0, start: 0 }); assert.equal(keeps, 1); }
    if (sc.kind === 'tmLog') { if (pj.timer.acc < 1000) { assert.equal(keeps, 0); assert.deepEqual(P.log, pj.log); } else { assert.equal(P.log.length, 3); assert.deepEqual([P.log[0].text, P.log[0].ms, P.log[0].ts, P.workAt], ['Temps tricoté : ' + pj.timer.acc + 'ms', pj.timer.acc, NOW, NOW]); assert.match(P.log[0].id, /^eu\d+$/); assert.deepEqual(P.timer, { acc: 0, start: 0 }); assert.equal(keeps, 1); } }
    if (sc.kind === 'pjAddNote') { if (!st.pjDraft.trim()) { assert.equal(P.log.length, 2); assert.equal(keeps, 0); } else { assert.equal(P.log.length, 3); assert.deepEqual([P.log[0].text, P.log[0].photos, P.log[0].ts], ['note', [], NOW]); assert.equal(out.S.pjDraft, ''); assert.equal(keeps, 1); } }
    if (sc.kind === 'pjCoverDel') { assert.equal(P.cover, ''); assert.equal(keeps, pj.cover ? 1 : 0); }
    if (sc.kind === 'islandAck') { out.S.projects.forEach((x, i) => assert.equal(x.islandSeen, st.projects[i].isl ? true : undefined)); assert.equal(keeps, 1); }
    if (sc.kind === 'islandOpen') { out.S.projects.forEach((x, i) => assert.equal(x.islandSeen, st.projects[i].isl ? true : undefined)); assert.equal(out.S.pjIsland, true); assert.equal(keeps, 1); }
    if (sc.kind === 'inspoDel') { const e = pj.inspo.find((x) => x.id === sc.id); if (e && sc.confirm) assert.ok(!P.inspo.some((x) => x.id === sc.id)); if (e && e.mediaId && !e.ideaId && sc.confirm && pj.cover === e.mediaId) assert.equal(P.cover, ''); }
    if (sc.kind === 'pjDelEntryYes') { const e = pj.log.find((x) => x.id === sc.id); assert.deepEqual(dels, e ? e.photos || [] : []); assert.ok(!P.log.some((x) => x.id === sc.id)); if (e && (e.photos || []).includes(pj.cover)) assert.equal(P.cover, ''); else assert.equal(P.cover, pj.cover); }
    if (sc.kind === 'pjPhotoDel') { if (sc.confirm) { assert.ok(!P.photos.includes(sc.id)); assert.deepEqual(dels, [sc.id]); if (pj.cover === sc.id) assert.equal(P.cover, ''); } else assert.deepEqual(dels, []); }
    checks++;
  }
}
// 4. bloc des photos (cover / pjAddPh / inspoAddPh / pjPhotos) avec hôte engagé : mêmes résultats qu'absent, ids de média inchangés
for (let seed = 1; seed <= 100; seed++) {
  const r = rng(seed + 9000), st = state(r);
  for (const id of ['pjCover', 'pjAddPh', 'inspoAddPh', 'pjPhotos']) {
    const fl = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ name: 'f' + i })), sc = { kind: id, code: photoBlocks, t: { id, files: fl, value: 'x' } };
    const A = await run('absent', st, sc), B = await run('engaged', st, sc); assert.equal(B, A, id + ' seed ' + seed); checks++; }
}
console.log('jalon4_6c OK —', checks, 'comparaisons');
