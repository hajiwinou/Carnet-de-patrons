// Jalon 4.7b — Patterns est l'autorité d'écriture et de suppression des médias de patrons (pdf_ / th_ / img_) (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPatternsHost, PATTERNS_RESOURCES } from '../dreamOS/patterns/patterns-host.js';
import { createPatternsMedia, PATTERN_MEDIA_PREFIXES } from '../dreamOS/patterns/patterns-media.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const fn = (n) => grab(new RegExp('  (?:async )?function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const doorBlock = grab(/  function patHost\(\)[\s\S]*?\n  function patSetGroup[^\n]*\n/, 'portes'), doorsSrc = doorBlock.replace(/\n  function persist\(light\)[^\n]*\n  function persistNow\(\)[^\n]*\n  function saveFolders\(\)[^\n]*\n/, '\n');
assert.ok(doorsSrc.length < doorBlock.length, 'extraction des portes sans persist');
const SRC = [fn('removeP'), fn('removePSoft'), fn('storeThumb'), fn('addPhotos')].join('');
const delPhoto = 'if (false) {}\n' + grab(/    else if \(a === 'delPhoto' && p\) \{[\s\S]*?\n    \}\n/, 'delPhoto').replace("else if (a === 'delPhoto' && p)", "else if (a === 'delPhoto' && p)");

// 1. garde-fous statiques
const outside = app.replace(doorBlock, '').replace(/  async function saveBlob\(id, blob\) \{[\s\S]*?\n  \}\n/, '').replace(/  function (docmSave|ideamSave|pjmSave)\([^\n]*\n/g, '');
assert.deepEqual((outside.match(/saveBlob\([^)]*\)/g) || []).map((x) => x.replace(/\s/g, '')), ['saveBlob(id,blob)', 'saveBlob(names[i],newBlob([raw],{type:ty})'], 'seules écritures directes restantes : restauration groupée et porte du fond d\'écran (Settings, 4.9a)');
for (const [re, what] of [[/IDB\.del\((p|pp)\.source\.pdf\)/g, 'PDF'], [/IDB\.del\(\w+\.thumb\)/g, 'miniature'], [/IDB\.del\(ph\.id\)/g, 'photo'], [/IDB\.del\(rem\.id\)/g, 'photo retirée'], [/'(pdf|th|img)_'\s*\+/g, 'identifiant construit à la main']]) assert.deepEqual(outside.match(re) || [], [], 'écriture ou suppression directe hors portes : ' + what);
assert.equal((app.match(/patmIdFor\('pdf_', p\.id\)/g) || []).length, 2); assert.equal((app.match(/patmSave\(pdfId, f\)/g) || []).length, 2); assert.equal((app.match(/patmRestore\(phId,/g) || []).length, 1);
assert.equal((app.match(/var phId = ph\.id \|\| patmNewId\('img_'\);/g) || []).length, 1, 'import : un identifiant existant est conservé, sinon un nouveau img_');
for (const n of ['patmHost', 'patmNewId', 'patmIdFor', 'patmSave', 'patmRestore', 'patmDiscard', 'patmDiscardAll']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);

// 2. passerelle seule
{ const ev = []; const m = createPatternsMedia({ eventBus: { emit: (t, d) => ev.push([t, d]) } }); const w = [], d = [];
  assert.deepEqual([...PATTERN_MEDIA_PREFIXES], ['pdf_', 'th_', 'img_']); assert.equal(m.newId('img_', () => 'x1'), 'img_x1'); assert.throws(() => m.newId('pjc_', () => 'x'), /préfixe non géré/);
  assert.equal(m.idFor('pdf_', 'pat1'), 'pdf_pat1'); assert.equal(m.idFor('th_', 'p'), 'th_p'); assert.throws(() => m.idFor('img_', ''), /patron requis/); assert.throws(() => m.idFor('zz_', 'p'), /préfixe/);
  await m.put('th_a', 'B', async (id, b) => { w.push([id, b]); return 7; }); assert.deepEqual(w, [['th_a', 'B']]); await assert.rejects(() => m.put('pjc_a', 'B', () => {}), /pdf_ \/ th_ \/ img_ requis/); await assert.rejects(() => m.put('img_a', 'B'), /écriture requise/);
  await m.restore('legacyId', 'Z', async (id, b) => w.push([id, b])); assert.deepEqual(w.at(-1), ['legacyId', 'Z']); await assert.rejects(() => m.restore('', 1, () => {}), /identifiant requis/); await assert.rejects(() => m.restore('a', 1), /écriture requise/);
  assert.equal(m.discard('whatever', (x) => d.push(x)), true); assert.deepEqual(d, ['whatever']); assert.throws(() => m.discard('x'), /suppression requise/);
  assert.deepEqual([...m.referenced([{ source: { pdf: 'pdf_a' }, thumb: 'th_a', photos: [{ id: 'img_1' }, { id: 'old' }, {}] }, null, { source: {}, photos: [] }, { thumb: 'zz' }])].sort(), ['img_1', 'pdf_a', 'th_a']);
  assert.ok(ev.some(([t]) => t === 'patterns:media-saved') && ev.some(([t]) => t === 'patterns:media-restored') && ev.some(([t]) => t === 'patterns:media-discarded')); assert.ok(Object.isFrozen(m)); }

// 3. propriété des ressources
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((x) => reg.declare(x)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win: {} });
  const media = PATTERNS_RESOURCES.filter(([t]) => t === 'media'); assert.deepEqual(media.map(([, n]) => n), ['pdf_*', 'th_*', 'img_*']);
  assert.deepEqual(media.map(([k, n]) => reg.ownerOf(k, n)), ['legacy', 'legacy', 'legacy']); h.engage(); assert.deepEqual(media.map(([k, n]) => reg.ownerOf(k, n)), ['patterns', 'patterns', 'patterns']); assert.equal(reg.moduleOf('media', 'pdf_abc'), 'patterns'); h.release(); assert.deepEqual(media.map(([k, n]) => reg.ownerOf(k, n)), ['legacy', 'legacy', 'legacy']); assert.ok(h.media); }

// 4. équivalence sur le vrai code
const ARGS = ['window', 'document', 'S', 'uid', 'keep', 'IDB', 'toast', 'render', 'deferDelete', 'pjLinkProjects', 'pjUnlinkPattern', 'saveProjects', 'patJson', 'a', 'b', 'p', 'sc', 'shrink', 'persist', 'saveBlob'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
function state(r) {
  const patterns = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ id: 'p' + i, title: 'T' + i, source: pick(r, [{}, { pdf: 'pdf_p' + i }]), thumb: pick(r, ['', 'th_p' + i]), photos: pick(r, [[], [{ id: 'img_a' + i, kind: 'modele' }, { id: 'oldid' + i }, {}]]) }));
  return { patterns, folders: [], projects: [], tab: pick(r, ['lib', 'pat']), busy: '', ui: {} };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const fakeCanvas = { width: 0, height: 0, getContext: () => ({ fillRect() {}, set fillStyle(v) {} }), toBlob: (cb, type, q) => cb('thumb:' + type + ':' + q + ':' + fakeCanvas.width + 'x' + fakeCanvas.height) };
  const document = { createElement: () => fakeCanvas };
  const pdf = { getPage: async () => ({ getViewport: ({ scale }) => ({ width: 100 * scale, height: 140 * scale }), render: () => ({ promise: Promise.resolve() }) }) };
  const ctx = { window: win, document, S, uid, keep: () => {}, IDB: { put: () => Promise.resolve(), del: (id) => log.push(['idbdel', id]) }, toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), deferDelete: (m, undo, done) => { if (sc.undo) undo(); else done(); log.push([sc.undo ? 'undone' : 'done']); },
    pjLinkProjects: () => {}, pjUnlinkPattern: () => {}, saveProjects: () => {}, patJson: {}, a: sc.a, b: { dataset: { i: String(sc.i) } }, p: S.patterns[0], sc, shrink: async (f) => { if (f.bad) throw new Error('x'); return 'shrunk:' + f.name; }, persist: () => log.push(['persist']), saveBlob: async (id, blob) => { log.push(['blob', id, blob]); } };
  const body = `${doorsSrc}${SRC}\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function('log', 'pdf', ...ARGS, body)(log, pdf, ...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { patterns: S.patterns, busy: S.busy }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(seed), st = state(r), p0 = st.patterns[0];
  const files = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ name: 'f' + i, bad: r() < .25 }));
  const scs = [
    { kind: 'removeP', code: 'removeP(S.patterns[0]);' }, { kind: 'soft', code: 'removePSoft(S.patterns[0]);', undo: r() < .5 }, { kind: 'thumb', code: 'await storeThumb(S.patterns[0], pdf);' },
    { kind: 'photos', code: 'await addPhotos(S.patterns[0], sc.files, sc.pk);', files, pk: pick(r, ['modele', 'detail']) }, { kind: 'delPhoto', code: delPhoto, a: 'delPhoto', i: Math.floor(r() * 3) }
  ];
  for (const sc of scs) {
    if (sc.kind === 'delPhoto' && !p0.photos.length) continue;
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), P = out.S.patterns[0], dels = out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]), blobs = out.log.filter((l) => l[0] === 'blob');
    const exp = [...(p0.source && p0.source.pdf ? [p0.source.pdf] : []), ...(p0.thumb ? [p0.thumb] : []), ...p0.photos.filter((x) => x.id).map((x) => x.id)];
    if (sc.kind === 'removeP') { assert.deepEqual(dels, exp); assert.equal(out.S.patterns.some((x) => x.id === 'p0'), false); }
    if (sc.kind === 'soft') { assert.deepEqual(dels, sc.undo ? [] : exp); }
    if (sc.kind === 'thumb') { assert.deepEqual(blobs, [['blob', 'th_p0', 'thumb:image/jpeg:0.8:360x504']]); assert.equal(P.thumb, 'th_p0'); assert.equal(out.log.filter((l) => l[0] === 'render').length, st.tab === 'lib' ? 1 : 0); }
    if (sc.kind === 'photos') { const ok = files.filter((f) => !f.bad); assert.deepEqual(blobs.map((b) => b[2]), ok.map((f) => 'shrunk:' + f.name)); blobs.forEach((b) => assert.match(b[1], /^img_u\d+$/)); assert.deepEqual(P.photos.slice(p0.photos.length).map((x) => x.kind), ok.map(() => sc.pk)); assert.deepEqual(P.photos.slice(p0.photos.length).map((x) => x.id), blobs.map((b) => b[1])); assert.deepEqual(out.log.filter((l) => l[0] === 'toast').map((l) => l[1]), [...files.filter((f) => f.bad).map(() => 'Photo ignorée'), ...(ok.length ? [ok.length + ' photo(s) ajoutée(s).'] : [])]); assert.equal(out.S.busy, ''); }
    if (sc.kind === 'delPhoto') { const rem = p0.photos[sc.i]; assert.equal(P.photos.length, p0.photos.length - (rem ? 1 : 0)); assert.deepEqual(dels, rem && rem.id ? [rem.id] : []); }
    checks++;
  }
}
console.log('jalon4_7b OK —', checks, 'comparaisons');
