// Jalon 4.6e — Projects crée les projets, change leur étape, gère les drapeaux de l'île et les liens avec les patrons (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsCommands } from '../dreamOS/projects/projects-commands.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const fn = (n) => grab(new RegExp('  function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const helperSrc = grab(/  function projStore\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'projStore..pjRelinkPattern'), projHostSrc = one('projHost'), curSrc = one('curPj');
const door = grab(/  function pjCmd\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'portes');
const patDoorsSrc = grab(/  function patHost\(\)[^\n]*\n/, 'patHost') + grab(/  function patStore\(\)[\s\S]*?\n  function persist\(light\)/, 'patStore').replace(/\n  function persist\(light\)$/, '\n') + grab(/  function patternsAppend[\s\S]*?\n  function patmDiscardAll[^\n]*\n/, 'portes patrons');
const SRC = [one('pjStageOf'), one('isAutoPjName'), one('nextPjSeq'), fn('pjYarns'), fn('pjApplyPlan'), fn('newProject'), fn('setPjStage'), fn('islandExit'), fn('pjSetPattern'), fn('removePSoft'), fn('removeP'), fn('migrateStages')].join('');
const sendIsland = grab(/    if\(a==='sendIsland'\)[^\n]*\n/, 'sendIsland');
const act = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), n);
const islandBack = 'if (false) {}\n' + act('islandBack'), noteSave = 'if (false) {}\n' + act('pdfNoteSave');

// 1. garde-fous statiques
const outside = app.replace(door, '');
const forbid = [[/\bpr\.stage\s*=[^=]/g, 'étape'], [/\bpr\.stageAt\[[^\]]+\]\s*=[^=]/g, 'date d\'étape'], [/(?<!\bp)\.stagePrev\s*=/g, 'étape précédente'], [/\.islandPin\s*=[^=]/g, 'épingle île'], [/delete \w+\.islandPin/g, 'épingle île'], [/\.leftIsland\s*=[^=]/g, 'sortie île'], [/delete \w+\.leftIsland/g, 'sortie île'],
  [/\.patternId\s*=[^=]/g, 'lien patron'], [/\bnpr\.workAt\s*=/g, 'reprise du travail'], [/stageAt: \{\} \}/g, 'création de projet'], [/\bnpr\.log = \[\]/g, 'journal vide']];
for (const [re, what] of forbid) assert.deepEqual(outside.match(re) || [], [], 'écriture directe hors portes : ' + what);
for (const n of ['pjCreate', 'pjChangeStage', 'pjSetStageDate', 'pjPinToIsland', 'pjExitIsland', 'pjTouch', 'pjEnsureLog', 'pjSetPatternId', 'pjLinkProjects', 'pjUnlinkPattern', 'pjRelinkPattern']) assert.ok(new RegExp('function ' + n + '\\(').test(door), n);

assert.equal((app.match(/pjRelinkPattern\(pendingReplace\.id, p\.id\);/g) || []).length, 1, 'remplacement de patron : les projets suivent le nouveau patron (porte unique)');

// 2. commandes seules
{ let n = 0, t = 1000; const c = createProjectsCommands({ uid: () => 'u' + (++n), now: () => t });
  const p1 = c.createProject({}, 4); assert.deepEqual(p1, { id: 'ju1', seq: 4, name: 'Projet 4', stage: 'attente', patternId: '', cover: '', size: '', yarns: [], needles: '', rows: 0, log: [], timer: { acc: 0, start: 0 }, created: 1000, stageAt: { attente: 1000 } });
  t = 2000; const p2 = c.createProject({ name: 'N', stage: 'wip', patternId: 'p' }, 1); assert.deepEqual([p2.name, p2.stage, p2.patternId, p2.workAt, p2.stageAt], ['N', 'wip', 'p', 2000, { wip: 2000 }]);
  t = 3000; p2.timer = { acc: 10, start: 500 }; p2.islandPin = true; p2.islandSince = 1; p2.leftIsland = 2; c.changeStage(p2, 'wip', 'termine'); assert.deepEqual([p2.stage, p2.stagePrev, p2.stageAt.termine, p2.timer, 'islandPin' in p2, 'islandSince' in p2, 'leftIsland' in p2, p2.workAt], ['termine', 'wip', 3000, { acc: 2510, start: 0 }, false, false, false, 2000]);
  t = 4000; c.changeStage(p2, 'termine', 'wip'); assert.deepEqual([p2.stage, p2.workAt], ['wip', 4000]); t = 5000; c.changeStage(p2, 'wip', 'attente'); assert.equal(p2.workAt, 4000); assert.equal(p2.stagePrev, 'wip');
  const w = { stageAt: {}, workAt: 1 }; t = 9000; c.changeStage(w, 'wip', 'wip'); assert.equal(w.workAt, 1, 'pas de reprise si déjà WIP'); c.changeStage(w, 'attente', 'wip'); assert.equal(w.workAt, 9000);
  c.setStageDate(p2, 'wip', 77); assert.equal(p2.stageAt.wip, 77);
  const q = { leftIsland: 1 }; c.pinToIsland(q); assert.deepEqual(q, { islandPin: true, islandSeen: true }); t = 6000; c.exitIsland(q, false); assert.deepEqual(q, { islandSeen: true }); q.islandPin = true; c.exitIsland(q, true); assert.deepEqual(q, { islandSeen: true, leftIsland: 6000 });
  c.touch(q); assert.equal(q.workAt, 6000); const l = {}; c.ensureLog(l); assert.deepEqual(l.log, []); l.log.push(1); c.ensureLog(l); assert.deepEqual(l.log, [1]);
  const a = { patternId: 'x' }, b = { patternId: 'y' }, d = { patternId: 'x' }; c.setPatternId(a, ''); assert.equal(a.patternId, ''); c.setPatternId(a, null); assert.equal(a.patternId, ''); c.linkProjects([a, b], 'z'); assert.deepEqual([a.patternId, b.patternId], ['z', 'z']);
  c.relinkPattern([a, b, d], 'z', 'k'); assert.deepEqual([a.patternId, b.patternId, d.patternId], ['k', 'k', 'x']); c.unlinkPattern([a, b, d], 'k'); assert.deepEqual([a.patternId, b.patternId, d.patternId], ['', '', 'x']); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'S', 'uid', 'keep', 'IDB', 'toast', 'toastAct', 'render', 'Date', 'a', 'b', 'islandCfg', 'isIsland', 'saveUiCfg', '$', 'persist', 'saveFolders', 'deferDelete', 'patJson', 'load', 'noteCtx', 'stEnableIsland', 'returnToPdf', 'VRC', 'sc', 'saveBlob'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const patterns = Array.from({ length: 3 }, (_, i) => ({ id: 'p' + i, title: 'Patron' + i, stage: pick(r, ['wip', 'termine', 'attente']), stageAt: pick(r, [undefined, { wip: 5, termine: 6 }]), source: { pdf: 'pdf' + i }, thumb: 'th' + i, photos: [{ id: 'ph' + i }, {}] }));
  const projects = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ id: 'j' + i, seq: i + 1, name: pick(r, ['Nouveau projet', 'Mon pull', 'Projet ' + (i + 1)]), stage: pick(r, ['attente', 'wip', 'termine']), patternId: pick(r, ['', 'p0', 'p1']), yarns: [], plannedSkeins: pick(r, [0, 2]), plannedColors: pick(r, [[], [{ id: 'pc1', planned: 3, hex: '#fff', name: 'Rouge' }]]),
    log: [], timer: { acc: Math.floor(r() * 100), start: pick(r, [0, 1000]) }, created: i, stageAt: { attente: 1 }, isl: r() < .5, islandPin: pick(r, [undefined, true]), islandSince: pick(r, [undefined, 3]), leftIsland: pick(r, [undefined, 9]), workAt: pick(r, [undefined, 4]) }));
  return { projects, patterns, curProj: projects[0].id, pdfNote: pick(r, ['', ' idée ']), folders: [], ui: {}, open: {} };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), IDB: { put: () => Promise.resolve(), del: (id) => log.push(['idbdel', id]) }, toast: (m) => log.push(['toast', m]), toastAct: (m, l, act, id) => log.push(['toastAct', m, l, act, id]), render: () => log.push(['render']),
    Date: FakeDate, a: sc.a, b: { dataset: { id: sc.id } }, islandCfg: () => ({ on: sc.islandOn !== false }), isIsland: (x) => !!x.isl, saveUiCfg: () => log.push(['uicfg']), stEnableIsland: () => { S.ui.island = Object.assign({}, S.ui.island || {}, { on: true }); }, $: () => ({ style: {} }), persist: () => log.push(['persist']), saveFolders: () => {},
    deferDelete: (m, undo, done) => { log.push(['defer', m]); if (sc.undo) undo(); else done(); log.push([sc.undo ? 'undone' : 'done']); }, patJson: {}, load: () => 0, noteCtx: () => sc.ctx || '', returnToPdf: () => log.push(['returnToPdf']), VRC: { pr: sc.noPr ? null : S.projects[0] }, sc, saveBlob: async () => {} };
  const body = `${patDoorsSrc}${projHostSrc}${curSrc}${helperSrc}${SRC}\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { projects: S.projects, patterns: S.patterns, ui: S.ui, pdfNote: S.pdfNote, ret: S.ret }, log: log.filter((l) => l[0] !== 'keep'), n });
}
let checks = 0;
for (let seed = 1; seed <= 300; seed++) {
  const r = rng(seed), st = state(r), pj = st.projects[0], pat = st.patterns[0];
  const scs = [
    { kind: 'new', code: 'S.ret = newProject(sc.o);', o: pick(r, [{}, { name: 'Pull', stage: 'wip', patternId: 'p1' }, { stage: 'termine' }]) },
    { kind: 'stage', code: 'setPjStage(S.projects[0], sc.to, sc.quiet);', to: pick(r, ['attente', 'wip', 'termine']), quiet: r() < .5 },
    { kind: 'exit', code: 'islandExit(S.projects[0]);' }, { kind: 'send', code: 'var b0 = b; ' + sendIsland.replace(/b\.dataset\.id/g, "'j0'") },
    { kind: 'back', code: islandBack.replace(/b\.dataset\.id/g, "'j0'"), islandOn: r() < .8 }, { kind: 'setpat', code: 'pjSetPattern(S.projects[0], sc.pid);', pid: pick(r, ['', 'p1', 'p2']) },
    { kind: 'softdel', code: 'removePSoft(S.patterns[0]);', undo: r() < .5 }, { kind: 'hard', code: 'removeP(S.patterns[0]);' }, { kind: 'mig', code: 'migrateStages();' },
    { kind: 'note', code: noteSave, ctx: pick(r, ['', 'Rang 4']), noPr: r() < .2 }
  ];
  for (const sc of scs) {
    sc.a = sc.kind === 'send' ? 'sendIsland' : sc.kind === 'back' ? 'islandBack' : sc.kind === 'note' ? 'pdfNoteSave' : undefined;
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), P = out.S.projects.find((x) => x.id === 'j0') || out.S.projects[0], logs = out.log.map((l) => l[0]);
    if (sc.kind === 'new') { const R = out.S.ret, o = sc.o; assert.match(R.id, /^ju\d+$/); assert.equal(R.stage, o.stage || 'attente'); assert.equal(R.created, NOW); assert.equal(R.stageAt[R.stage], NOW); assert.equal(R.workAt, R.stage === 'wip' ? NOW : undefined); assert.equal(R.patternId, o.patternId || ''); assert.equal(R.seq, Math.max(...st.projects.map((x) => x.seq || 0)) + 1); assert.equal(out.S.projects[0].id, R.id); assert.equal(out.S.projects.length, st.projects.length + 1); }
    if (sc.kind === 'stage') {
      const from = ['wip', 'termine'].includes(pj.stage) ? pj.stage : 'attente';
      if (from === sc.to) { assert.deepEqual(P, clone(st.projects[0])); assert.deepEqual(logs, []); }
      else { assert.equal(P.stagePrev, from); assert.equal(P.stage, sc.to); assert.equal(P.stageAt[sc.to], NOW); assert.equal(logs.includes('render'), true);
        if (sc.to === 'termine') { assert.equal(P.timer.start, 0); assert.equal(P.timer.acc, pj.timer.acc + (pj.timer.start ? NOW - pj.timer.start : 0)); for (const k of ['islandSince', 'islandPin', 'leftIsland']) assert.equal(k in P, false); } else { assert.equal(P.timer.start, pj.timer.start); assert.equal(P.islandPin, pj.islandPin); }
        assert.equal(P.workAt, sc.to === 'wip' && from !== 'wip' ? NOW : pj.workAt); assert.equal(logs.includes('toastAct'), !sc.quiet); } }
    if (sc.kind === 'exit') { assert.equal('islandPin' in P, false); if (pj.isl) { assert.equal(P.leftIsland, NOW); assert.deepEqual(out.log.find((l) => l[0] === 'toastAct').slice(2), ['Remettre sur l’île', 'islandBack', 'j0']); } else { assert.equal(P.leftIsland, pj.leftIsland); assert.equal(logs.includes('toastAct'), false); } }
    if (sc.kind === 'send') { assert.deepEqual([P.islandPin, 'leftIsland' in P, P.islandSeen], [true, false, true]); assert.equal(out.S.ui.island.on, true); }
    if (sc.kind === 'back') { if (!sc.islandOn) { assert.deepEqual(P, clone(st.projects[0])); assert.deepEqual(out.log.map((l) => l[0]), ['toast']); } else { assert.deepEqual([P.islandPin, 'leftIsland' in P, P.islandSeen], [true, false, true]); } }
    if (sc.kind === 'setpat') { assert.equal(P.patternId, sc.pid); const auto = !pj.name || pj.name === 'Nouveau projet' || /^Projet \d+$/.test(pj.name); const lp = st.patterns.find((x) => x.id === sc.pid); assert.equal(P.name, sc.pid && auto && lp ? lp.title : pj.name); }
    if (sc.kind === 'softdel') { assert.equal(out.S.patterns.some((x) => x.id === 'p0'), sc.undo); out.S.projects.forEach((x, i) => assert.equal(x.patternId, sc.undo ? st.projects[i].patternId : st.projects[i].patternId === 'p0' ? '' : st.projects[i].patternId)); assert.equal(out.log.filter((l) => l[0] === 'idbdel').length, sc.undo ? 0 : 3); }
    if (sc.kind === 'hard') { assert.equal(out.S.patterns.some((x) => x.id === 'p0'), false); out.S.projects.forEach((x, i) => assert.equal(x.patternId, st.projects[i].patternId === 'p0' ? '' : st.projects[i].patternId)); }
    if (sc.kind === 'mig') { st.patterns.forEach((p) => { if (p.stage === 'wip' || p.stage === 'termine') { const np = out.S.projects.find((x) => x.patternId === p.id && x.created === NOW && x.stage === p.stage); assert.ok(np, 'projet migré'); assert.equal(np.stageAt[p.stage], p.stageAt && p.stageAt[p.stage] ? p.stageAt[p.stage] : NOW); } }); }
    if (sc.kind === 'note') { const txt = (st.pdfNote || '').trim(); if (sc.noPr || !txt) { assert.deepEqual(P.log, st.projects[0].log); assert.equal(P.workAt, st.projects[0].workAt); } else { assert.equal(P.log[0].text, (sc.ctx ? sc.ctx + ' — ' : '') + txt); assert.equal(P.workAt, NOW); assert.equal(out.S.pdfNote, ''); assert.equal(logs.includes('returnToPdf'), true); } }
    checks++;
  }
}
console.log('jalon4_6e OK —', checks, 'comparaisons');
