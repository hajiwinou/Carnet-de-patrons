// Phase 2.8 — non-régression (spec §12.2) dans un VRAI navigateur, sur un jeu de données fictif et un profil vierge.
// Prérequis : playwright-core + un Chromium (SKIP sinon). Aucune donnée réelle n'est touchée.
import fs from 'node:fs'; import path from 'node:path'; import http from 'node:http'; import { createRequire } from 'node:module'; import { fileURLToPath } from 'node:url';
const req = createRequire(import.meta.url), here = path.dirname(fileURLToPath(import.meta.url)), root = path.resolve(here, '..');
let chromium, JSZIPMIN; try { ({ chromium } = req('playwright-core')); JSZIPMIN = fs.readFileSync(req.resolve('jszip/dist/jszip.min.js')); } catch { console.log('SKIP : playwright-core / jszip introuvables.'); process.exit(0); }
const find = (d) => { try { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { const r = find(p); if (r) return r; } else if (/^(chrome|chrome-headless-shell)$/.test(e.name)) return p; } } catch {} };
const exe = process.env.CHROME_PATH || find(process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers');
if (!exe) { console.log('SKIP : aucun Chromium trouvé (variable CHROME_PATH).'); process.exit(0); }
if (!fs.existsSync(path.join(here, 'fixtures/carnet-test-fictif.zip'))) { console.log('Jeu fictif absent : node tests/fixtures/make-fixture.mjs'); process.exit(1); }
const exp = JSON.parse(fs.readFileSync(path.join(here, 'fixtures/carnet-test-fictif.expected.json'), 'utf8')), D = exp.data;

const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0]).replace(/\/$/, '/index.html')); fs.readFile(f, (e, b) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(f)] || 'application/octet-stream' }); r.end(b); } }); });
await new Promise((ok) => server.listen(0, '127.0.0.1', ok)); const url = `http://127.0.0.1:${server.address().port}/`;

const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
const ctx = await browser.newContext({ serviceWorkers: 'block' });
await ctx.route(/^https?:\/\/(?!127\.0\.0\.1)/, (r) => /jszip/.test(r.request().url()) ? r.fulfill({ status: 200, contentType: 'text/javascript', body: JSZIPMIN }) : r.abort());
const page = await ctx.newPage(), errors = []; page.on('pageerror', (e) => errors.push(e.message));
const ready = async () => { await page.goto(url); await page.evaluate(() => window.DreamOSLegacy.ready); };
const snap = () => page.evaluate(() => JSON.parse(JSON.stringify(window.DreamOSLegacy.getStateSnapshot())));
const ls = (k) => page.evaluate((k) => localStorage.getItem(k), k);
const idb = () => page.evaluate(() => new Promise((ok, ko) => { const o = indexedDB.open('carnet_patrons_db', 1); o.onerror = () => ko(o.error);
  o.onsuccess = () => { const s = o.result.transaction('blobs').objectStore('blobs'), out = {}, rq = s.openCursor();
    rq.onsuccess = () => { const c = rq.result; if (c) { out[c.key] = c.value instanceof Blob ? { size: c.value.size, type: c.value.type } : typeof c.value; c.continue(); } else ok(out); }; }; }));
const results = []; const check = (n, label, cond, detail = '') => { results.push([n, label, !!cond, detail]); };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const importFile = async () => { await page.evaluate(() => { const b = document.querySelector('[data-act="tab"][data-v="set"]'); if (b) b.click(); });
  await page.waitForSelector('#restoreIn', { state: 'attached' }); await page.setInputFiles('#restoreIn', path.join(here, 'fixtures/carnet-test-fictif.zip'));
  await page.waitForFunction(() => /Sauvegarde complète restaurée|invalide/.test(document.querySelector('#toast')?.textContent || ''), null, { timeout: 30000 });
  return page.evaluate(() => document.querySelector('#toast').textContent); };

await ready();
await page.evaluate(() => localStorage.setItem('carnet.ai', JSON.stringify({ provider: 'gemini', keys: { gemini: 'CLE-FICTIVE-123' } })));   // scénario 7
const toast = await importFile();
check(10, 'Une sauvegarde créée avant la migration est restaurée (message de succès)', /complète restaurée/.test(toast), toast);
await page.waitForTimeout(800);
for (const phase of ['juste après la restauration', 'après rechargement complet']) {
  if (phase.startsWith('après')) await ready();
  const s = await snap(), blobs = await idb(), P = (id) => s.patterns.find((x) => x.id === id), J = (id) => s.projects.find((x) => x.id === id), tag = ` — ${phase}`;
  check(1, 'Les 4 patrons existent, avec titre, dossier et statut' + tag, D.patterns.every((p) => P(p.id) && P(p.id).title === p.title && (P(p.id).folder || '') === (p.folder || '') && P(p.id).status === p.status));
  check(1, 'Les PDF des patrons sont lisibles (type PDF, taille exacte)' + tag, D.patterns.every((p) => same(blobs[p.source.pdf], exp.blobs[p.source.pdf])));
  const j = J('j_lune');
  check(2, 'Projet : fils, aiguilles, taille, journal (2 entrées) et photos conservés' + tag, j && same(j.yarns, D.projects[0].yarns) && j.needles === '4 mm' && j.size === 'M' && j.log.length === 2 && same(j.photos, D.projects[0].photos));
  check(2, 'Projet : entrée de journal avec sa photo' + tag, j && j.log[0].photos[0] === 'pjp_lune2' && blobs.pjp_lune2);
  check(3, 'Compteur de rangs (128) et temps tricoté (1 h 30) non remis à zéro' + tag, j && j.rows === 128 && j.timer.acc === 5400000);
  check(3, 'Étapes des 3 projets (WIP / en attente / terminé) conservées' + tag, J('j_lune')?.stage === 'wip' && J('j_brume')?.stage === 'attente' && J('j_top')?.stage === 'termine' && J('j_top')?.rows === 240);
  const keys = Object.keys(D.viewer ? exp.data.viewer : {}); const vals = await Promise.all(keys.map(ls));
  check(4, 'Repère, position, surlignage et marqueurs du PDF liés au bon patron' + tag, keys.every((k, i) => same(JSON.parse(vals[i]), exp.data.viewer[k])) && P('p_lune'));
  check(5, 'Dossiers (2) identiques et patrons rangés dedans' + tag, same(s.folders.map((f) => f.name).sort(), ['Classiques', 'Été']) && P('p_lune').folder === 'd_classiques' && P('p_ete').folder === 'd_ete');
  check(6, 'Statistiques (interface) restaurées' + tag, same(s.ui.stats, D.ui.stats));
  check(8, 'Tableaux d\'inspiration, idées liées et notes rapides intacts' + tag, same(s.boards, D.boards) && same(s.ideas[0].boards, ['b_1']) && s.scratchpad === D.scratchpad && same(s.docs[0].media, D.docs[0].media));
  check(9, 'Les 11 fichiers (PDF, photos, miniatures, médias) sont dans IndexedDB, taille et type exacts' + tag, Object.keys(exp.blobs).every((k) => same(blobs[k], exp.blobs[k])), JSON.stringify(Object.keys(exp.blobs).filter((k) => !same(blobs[k], exp.blobs[k]))));
  check(7, 'La configuration IA déjà présente n\'est pas effacée par la restauration' + tag, (await ls('carnet.ai') || '').includes('CLE-FICTIVE-123'));
}
// Seconde restauration du même fichier : pas de doublons
await importFile(); await page.waitForTimeout(800);
const s2 = await snap(), uniq = (a) => new Set(a.map((x) => x.id)).size === a.length;
check(10, 'Restaurer deux fois le même ZIP ne crée aucun doublon', s2.patterns.length === 4 && s2.projects.length === 3 && s2.folders.length === 2 && uniq(s2.patterns) && uniq(s2.projects) && s2.ideas.length === 1 && s2.docs.length === 1);
check(0, 'Aucune erreur JavaScript non interceptée pendant tout le parcours', errors.length === 0, errors.join(' | '));

// Informatif : clés carnet.* lues par l'appli mais absentes de la sauvegarde ZIP
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8'), used = [...new Set([...app.matchAll(/load\('(carnet\.[A-Za-z0-9_]+)'/g)].map((m) => m[1]))];
const covered = ['carnet.patterns', 'carnet.folders', 'carnet.projects', 'carnet.grids', 'carnet.docs', 'carnet.ideas', 'carnet.boards', 'carnet.scratchpad'];
await browser.close(); server.close();
for (const [n, l, ok, d] of results) console.log(`${ok ? '✓' : '✗'} [§12.2 #${n}] ${l}${!ok && d ? ' — ' + d : ''}`);
console.log('\nℹ Réglages lus par l\'appli mais NON inclus dans la sauvegarde ZIP (à reconfigurer sur un autre appareil) :\n  ' + used.filter((k) => !covered.includes(k) && !/\.(vhl|vmark|vsm|vpos)/.test(k)).join(', '));
const bad = results.filter((r) => !r[2]); console.log(bad.length ? `\nÉCHEC : ${bad.length} contrôle(s)` : `\nTous les contrôles passent (${results.length}).`); process.exit(bad.length ? 1 : 0);
