// Jalon 4.3 — Library propriétaire de carnet.ideas, carnet.boards et des médias ideam_* : une seule autorité d'écriture, équivalence avec le code d'origine
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installLibraryHost } from '../dreamOS/library/library-host.js';
import { createLibraryStore } from '../dreamOS/library/library-store.js';
import { createLibraryMedia } from '../dreamOS/library/library-media.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const helperSrc = grab(/  function libStore\(kind\)[\s\S]*?\n  function ideamDiscard[^\n]*\n/, 'libStore..ideamDiscard');
const libHostSrc = grab(/  function libHost\(\)[^\n]*\n/, 'libHost'), boardIdsSrc = grab(/  function pinBoardIds\(item\)[^\n]*\n/, 'pinBoardIds');
const pinBulkSrc = grab(/  async function pinBulk\(kind\) \{[\s\S]*?\n  \}\n/, 'pinBulk');
const changeTagSrc = grab(/    if \(t\.dataset\.pintag !== undefined\)[\s\S]*?\n      return;\n    \}\n/, 'pintag/pinboard');
const multiSrc = grab(/    \/\* Plusieurs photos d'un coup \*\/[\s\S]*?\n      return;\n    \}\n/, 'ideaMultiIn');
const mediaSrc = grab(/    \/\* Média Idée \(Pinterest\) \*\/[\s\S]*?\n      return;\n    \}\n/, 'ideaMediaIn');
const boardsSrc = grab(/    else if \(a === 'boardNew'\) \{[\s\S]*?(?=\n    else if \(a === 'newPj'\))/, 'boardNew/Ren/Del');
const ideaSrc = grab(/    else if \(a === 'ideaAdd'\) \{[\s\S]*?(?=\n    else if \(a === 'fStatus'\))/, 'ideaAdd/ideaDel');

// 1. garde-fous statiques : aucune écriture directe hors de la porte unique
const outside = app.replace(helperSrc, '');
assert.deepEqual(outside.match(/S\.(ideas|boards)\s*=[^=]|S\.(ideas|boards)\.(unshift|splice|push|pop|shift|sort|reverse|fill)\b|keep\(\s*'carnet\.(ideas|boards)'/g) || [], [], 'écriture directe sur les idées / tableaux');
assert.deepEqual(outside.match(/(?<!ideaDraft)\.tag\s*=[^=]|(?<!S)\.boards\s*=[^=]/g) || [], [], "modification directe d'une idée");
assert.deepEqual(outside.match(/saveBlob\(\s*(mid2|imid)\b|IDB\.del\(\s*(it\.mediaId|S\.ideaDraft\.mediaId|remIdea\.mediaId)\s*\)/g) || [], [], "écriture / suppression directe de média d'idée");
assert.equal(outside.split('\n').filter((l) => l.includes('ideam_') && !/^\s*\/?\*|^\s*\/\*/.test(l)).length, 0, 'références ideam_ hors de la porte unique');

// 2. propriété dans le registre
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {};
  for (const [k, n] of [['storage', 'carnet.ideas'], ['storage', 'carnet.boards'], ['media', 'ideam_*']]) assert.equal(reg.ownerOf(k, n), 'legacy');
  const h = installLibraryHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage();
  for (const [k, n] of [['storage', 'carnet.ideas'], ['storage', 'carnet.boards'], ['media', 'ideam_*']]) assert.equal(reg.ownerOf(k, n), 'library');
  assert.throws(() => reg.transferOwnership('media', 'ideam_*', 'legacy', 'tools'), /transfert refusé/);
  h.release(); assert.equal(reg.ownerOf('media', 'ideam_*'), 'legacy'); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.boards'), 'library'); }

// 3. magasin et passerelle
{ const w = []; const st = createLibraryStore({ eventBus: new EventBus() }); assert.throws(() => st.ideas.addFirst({}), /aucun tableau/); assert.throws(() => st.boards.append({}), /aucun tableau/);
  const I = [{ id: 'a', tag: 'x', boards: ['b1'] }, { id: 'b' }, { id: 'c' }], B = [{ id: 'b1', name: 'N' }]; st.ideas.adopt(I, (x) => w.push(['i', x.length])); st.boards.adopt(B, (x) => w.push(['b', x.length]));
  assert.equal(st.ideas.list(), I); st.ideas.addFirst({ id: 'n' }); assert.deepEqual(I.map((x) => x.id), ['n', 'a', 'b', 'c']);
  st.ideas.addMany([{ id: 'm1' }, { id: 'm2' }]); assert.deepEqual(I.map((x) => x.id), ['m1', 'm2', 'n', 'a', 'b', 'c']);
  st.ideas.removeByIds(['m1', 'c', 'zz']); assert.deepEqual(I.map((x) => x.id), ['m2', 'n', 'a', 'b']); assert.equal(st.ideas.list(), I);
  assert.equal(st.ideas.patch([I[2]], { tag: 'T' }), 1); assert.equal(I[2].tag, 'T'); st.ideas.patch(I, (i) => (i.id === 'a' ? { boards: [] } : null)); assert.deepEqual(I[2].boards, []); assert.equal(I[0].boards, undefined);
  const n0 = w.length; st.ideas.patch(I, { tag: 'Z' }); assert.equal(w.length, n0 + 1, 'une seule écriture par patch');
  assert.equal(st.ideas.removeAt(0).id, 'm2'); st.ideas.insertAt(99, { id: 'q' }); assert.equal(I.at(-1).id, 'q'); st.ideas.replaceAll(null); assert.equal(I.length, 0);
  st.boards.append({ id: 'b2', name: 'M' }); assert.deepEqual(B.map((x) => x.id), ['b1', 'b2']); st.boards.rename(B[0], 'Renommé'); assert.equal(B[0].name, 'Renommé'); st.boards.removeById('b1'); assert.deepEqual(B.map((x) => x.id), ['b2']); assert.equal(st.boards.list(), B);
  assert.throws(() => st.ideas.adopt('x'), /tableau requis/);
  const bad = createLibraryStore({ eventBus: { emit() { throw new Error('x'); } } }); const a2 = []; bad.ideas.adopt(a2, () => {}); bad.ideas.addFirst({ id: 1 }); assert.equal(a2.length, 1);
  const m = createLibraryMedia({ eventBus: new EventBus() }); assert.equal(m.newId(() => 'z'), 'ideam_z'); assert.equal(m.isOwn('ideam_1'), true); assert.equal(m.isOwn('docm_1'), false);
  await assert.rejects(m.put('docm_1', 1, async () => {}), /ideam_/); await assert.rejects(m.put('ideam_1', 1), /écriture requise/); assert.equal(await m.put('ideam_1', 1, async (id) => id), 'ideam_1'); assert.throws(() => m.discard('ideam_1'), /suppression requise/); assert.equal(m.discard('ideam_1', () => {}), true);
  assert.deepEqual([...m.referenced([{ mediaId: 'ideam_1' }, { mediaId: 'img_2' }, {}, null, { mediaId: 'ideam_1' }])], ['ideam_1']); }

// 4. équivalence sur le VRAI code d'app.js : états aléatoires × scénarios, hôte absent / engagé
const ARGS = ['window', 'S', 'uid', 'keep', 'saveBlob', 'IDB', 'shrink', 'toast', 'render', '$', 'askName', 'askConfirm', 'boardNameCheck', 'deferDelete', 'inspoAddIdeas', 'saveProjects', 'pjStageOf', 'a', 'b', 'v', 't', 'Date', 'mergeById'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, a) => a[Math.floor(r() * a.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const nb = Math.floor(r() * 4), boards = Array.from({ length: nb }, (_, i) => ({ id: 'b' + i, name: 'Tab' + i }));
  const ideas = Array.from({ length: Math.floor(r() * 6) }, (_, i) => ({ id: 'i' + i, title: 'T' + i, tag: pick(r, ['Inspiration', 'Couleurs', '']), note: '', mediaId: pick(r, ['', 'ideam_k' + i, 'img_z']), mediaType: 'image', boards: r() < .8 ? boards.filter(() => r() < .5).map((x) => x.id) : undefined, created: i }));
  return { ideas, boards, ideaBoard: pick(r, ['all', 'none', ...boards.map((b) => b.id)]), ideaTag: pick(r, ['all', 'Couleurs']), ideaDraft: { title: pick(r, ['', ' T ']), note: pick(r, ['', 'n']), tag: 'Inspiration', mediaId: pick(r, ['', 'ideam_d']), mediaType: pick(r, ['', 'video']) },
    pinSel: r() < .15 ? null : Object.fromEntries(ideas.filter(() => r() < .5).map((i) => [i.id, 1])), bulkBoard: '', busy: '', projects: [] };
}
async function run(withHost, st, sc) {
  const win = {}, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); installLibraryHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }).engage(); }
  const dom = { '#bulkBoard': { value: sc.bulkBoard }, '#bulkTag': { value: sc.bulkTag }, '#bulkProj': { value: '' } };
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), saveBlob: async (id, bl) => log.push(['blob', id, JSON.stringify(bl)]), IDB: { del: (id) => log.push(['idbdel', id]) }, shrink: async (f) => 'shrunk:' + f.name,
    toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), $: (s) => dom[s] || null, askName: async () => sc.name, askConfirm: async () => sc.confirm, boardNameCheck: () => () => '',
    deferDelete: (msg, undo, done) => { log.push(['defer', msg]); if (sc.undo) { undo(); log.push(['undone', JSON.stringify(S.ideas)]); } else done(); }, inspoAddIdeas: () => 0, saveProjects: () => {}, pjStageOf: () => 'attente',
    a: sc.a, b: { dataset: { i: String(sc.i ?? 0), id: 'x' } }, v: sc.v, t: sc.t ? clone(sc.t) : {}, Date: FakeDate, mergeById: (x, y) => x.concat(y || []) };
  const body = `${libHostSrc}${boardIdsSrc}${helperSrc}\n${pinBulkSrc}\nreturn (async function(){ ${sc.code} }).call(this);`;
  const f = new Function(...ARGS, body); const res = await f(...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { ideas: S.ideas, boards: S.boards, ideaBoard: S.ideaBoard, ideaDraft: S.ideaDraft, pinSel: S.pinSel, bulkBoard: S.bulkBoard, busy: S.busy }, log, res: res ?? null, n });
}
let checks = 0;
for (let seed = 1; seed <= 500; seed++) {
  const r = rng(seed), st = state(r); const first = st.ideas[0], nI = st.ideas.length;
  const files = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ name: 'f' + i, type: pick(r, ['image/png', 'video/mp4', 'application/pdf']) }));
  const scs = [
    ...['move', 'add', 'tag', 'del'].map((k) => ({ code: `return pinBulk(${JSON.stringify(k)});`, bulkBoard: pick(r, ['b0', 'b1', 'none', '__new__', '']), bulkTag: pick(r, ['Couleurs', '']), name: pick(r, ['Neuf', '']), confirm: r() < .7, kind: 'bulk-' + k })),
    { code: `${changeTagSrc}`, t: { dataset: { pintag: String(Math.floor(r() * 7)) }, value: 'Nouveau' }, kind: 'pintag' },
    { code: `${changeTagSrc}`, t: { dataset: { pinboard: String(Math.floor(r() * 7)), bid: pick(r, ['b0', 'b1', 'b9']) }, checked: r() < .5 }, kind: 'pinboard' },
    { code: `${multiSrc}`, t: { id: 'ideaMultiIn', value: 'x', files }, kind: 'multi' },
    { code: `${mediaSrc}`, t: { id: 'ideaMediaIn', value: 'x', files: [files[0]] }, kind: 'media' },
    ...['boardNew', 'boardRen', 'boardDel', 'ideaAdd', 'ideaDel'].map((k) => ({ code: `if (false) {}\n${k.startsWith('board') ? boardsSrc : ideaSrc}`, a: k, name: pick(r, ['Neuf', 'Renommé', '']), confirm: r() < .7, i: Math.floor(r() * 8), undo: r() < .5, kind: k }))
  ];
  for (const sc of scs) {
    sc.code = sc.code.replace(/\bt\.files\b/g, 't.files');
    const A = await run(false, st, sc), B = await run(true, st, sc); assert.equal(B, A, `${sc.kind} seed ${seed}`); checks++;
    const out = JSON.parse(A);
    if (sc.kind === 'ideaDel' && st.ideas[sc.i]) { const dels = out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]); assert.deepEqual(dels, !sc.undo && st.ideas[sc.i].mediaId ? [st.ideas[sc.i].mediaId] : [], 'suppression du média avec l\'épingle'); checks++; }
    if (sc.kind === 'multi') { const L = out.log.filter((l) => l[0] === 'blob'); assert.ok(L.every((l) => /^ideam_u\d+$/.test(l[1]))); const exp = files.filter((f) => /^(image|video)\//.test(f.type)).length; assert.equal(L.length, exp, 'import multiple : tous les fichiers image / vidéo sont importés, même si le premier choisi n\'en est pas un'); checks++; }
    if (sc.kind === 'media') { const L = out.log.filter((l) => l[0] === 'blob'); assert.equal(L.length, 1); assert.match(L[0][1], /^ideam_u\d+$/); assert.equal(out.S.ideaDraft.mediaId, L[0][1]); checks++; }
    if (sc.kind === 'bulk-del' && out.log.some((l) => l[0] === 'toast' && /supprimée/.test(l[1]))) { assert.equal(out.S.ideas.length, nI - Object.keys(st.pinSel || {}).filter((id) => st.ideas.some((x) => x.id === id)).length); checks++; }
    const sel = st.ideas.filter((x) => Object.keys(st.pinSel || {}).includes(x.id)), after = (id) => out.S.ideas.find((x) => x.id === id);
    if (sc.kind === 'bulk-tag' && sc.bulkTag && sel.length) { assert.ok(sel.every((x) => after(x.id).tag === sc.bulkTag), 'catégorie appliquée'); assert.ok(st.ideas.filter((x) => !sel.includes(x)).every((x) => after(x.id).tag === x.tag), 'autres idées inchangées'); checks++; }
    if ((sc.kind === 'bulk-move' || sc.kind === 'bulk-add') && sel.length && (['none', ...st.boards.map((b) => b.id)]).includes(sc.bulkBoard) && !(sc.kind === 'bulk-add' && sc.bulkBoard === 'none')) {
      for (const x of sel) { const nb = after(x.id).boards; if (sc.bulkBoard === 'none') assert.deepEqual(nb, []); else if (sc.kind === 'bulk-move') assert.deepEqual(nb, [sc.bulkBoard]); else { assert.ok(nb.includes(sc.bulkBoard)); assert.equal(nb.filter((y) => y === sc.bulkBoard).length, 1); } }
      assert.ok(st.ideas.filter((x) => !sel.includes(x)).every((x) => JSON.stringify(after(x.id).boards) === JSON.stringify(x.boards)), 'autres idées inchangées'); checks++; }
    if (sc.kind === 'bulk-move' && sel.length && sc.bulkBoard === '__new__' && sc.name) { assert.equal(out.S.boards.length, st.boards.length + 1); assert.equal(out.S.boards.at(-1).name, sc.name); checks++; }
    if (sc.kind === 'ideaDel' && st.ideas[sc.i]) { const ids = st.ideas.map((x) => x.id); const exp = sc.undo ? ids : ids.filter((_, k) => k !== sc.i); assert.deepEqual(out.S.ideas.map((x) => x.id), exp, 'suppression / annulation de l\'épingle'); checks++; }
    if (sc.kind === 'pinboard') { const k = +sc.t.dataset.pinboard, o = st.ideas[k]; if (o) { const exp = (o.boards || []).filter((x) => x !== sc.t.dataset.bid).concat(sc.t.checked ? [sc.t.dataset.bid] : []); assert.deepEqual(out.S.ideas[k].boards, exp, 'case à cocher d\'un tableau'); checks++; } else assert.deepEqual(out.S.ideas, clone(st.ideas)); }
    if (sc.kind === 'pintag') { const k = +sc.t.dataset.pintag; if (st.ideas[k]) { assert.equal(out.S.ideas[k].tag, 'Nouveau'); checks++; } }
    if (sc.kind === 'bulk-del' && out.log.some((l) => l[0] === 'toast' && /supprimée/.test(l[1]))) { assert.deepEqual(out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]), sel.filter((x) => x.mediaId).map((x) => x.mediaId), 'médias supprimés avec les épingles'); checks++; }
    if (sc.kind === 'boardDel') { const db = st.boards.find((x) => x.id === st.ideaBoard); if (db && sc.confirm) { assert.ok(!out.S.boards.some((b) => b.id === db.id), 'tableau supprimé'); assert.equal(out.S.ideaBoard, 'all'); checks++; } else assert.deepEqual(out.S.boards, st.boards); }
    if (sc.kind === 'boardRen') { const rb = st.boards.find((x) => x.id === st.ideaBoard); if (rb && sc.name) { assert.equal(out.S.boards.find((b) => b.id === rb.id).name, sc.name); checks++; } }
    if (sc.kind === 'boardNew' && sc.name) { assert.equal(out.S.boards.at(-1).name, sc.name); assert.equal(out.S.ideaBoard, out.S.boards.at(-1).id); checks++; }
    if (sc.kind === 'multi') { const L = out.log.filter((l) => l[0] === 'blob').map((l) => l[1]); assert.deepEqual(out.S.ideas.slice(0, L.length).map((x) => x.mediaId), L, 'nouvelles épingles en tête, dans l\'ordre'); assert.equal(out.S.ideas.length, st.ideas.length + L.length); checks++; }
    if (sc.kind === 'media' && st.ideaDraft.mediaId) { assert.ok(out.log.some((l) => l[0] === 'idbdel' && l[1] === st.ideaDraft.mediaId), 'ancien média de brouillon supprimé'); checks++; }
    if (sc.kind === 'boardDel' && out.log.some((l) => l[0] === 'keep' && l[1] === 'carnet.boards')) { const db = st.boards.find((x) => x.id === st.ideaBoard); assert.ok(db); assert.ok(out.S.ideas.every((i) => !(i.boards || []).includes(db.id)), 'références au tableau supprimé retirées'); assert.ok(!out.S.boards.some((b) => b.id === db.id)); checks++; }
  }
}
// 5. séquences au niveau des fonctions : bascule / retour arrière à chaud, données ET écritures identiques
const build = new Function('window', 'S', 'keep', 'uid', 'saveBlob', 'IDB', `${helperSrc}\nreturn { libStore, saveIdeas, saveBoards, ideasAdd, ideasAddMany, ideasRemoveAt, ideasInsertAt, ideasRemoveByIds, ideasPatch, ideasReplace, boardsAppend, boardsRename, boardsRemove, boardsReplace, ideamNewId, ideamSave, ideamDiscard };`);
function world(mode, init) {
  const win = {}, S = { ideas: clone(init.ideas), boards: clone(init.boards) }, log = []; let un = 0;
  const f = build(win, S, (k, v) => log.push([k, JSON.stringify(v)]), () => 'u' + (++un), async (id, b) => { log.push(['blob', id, b]); return id; }, { del: (id) => log.push(['idbdel', id]) });
  let host = null; if (mode === 'host') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); host = installLibraryHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); host.engage(); }
  return { f, S, log, host };
}
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed + 5000), init = state(r), A = world('legacy', init), B = world('host', init);
  for (let step = 0; step < 16; step++) {
    const op = Math.floor(r() * 14), i = Math.floor(r() * 7), it = { id: 'n' + step, tag: 'T', boards: ['b0'], mediaId: 'ideam_' + step };
    const bd = { id: 'nb' + step, name: 'B' + step }, sv = r() < .5, many = [{ id: 'm' + step }, { id: 'mm' + step }], rep = [{ id: 'r' + step, boards: [] }];
    for (const w of [A, B]) {
      if (op === 0) w.f.ideasAdd(clone(it)); else if (op === 1) w.f.ideasAddMany(clone(many)); else if (op === 2) w.f.ideasRemoveAt(i); else if (op === 3) w.f.ideasInsertAt(i, clone(it));
      else if (op === 4) w.f.ideasRemoveByIds(['i0', 'i2', 'n1']); else if (op === 5) w.f.ideasPatch(w.S.ideas.slice(0, 3), (x) => (x.id.length % 2 ? { tag: 'P' + step } : null)); else if (op === 6) w.f.ideasReplace(clone(rep), sv);
      else if (op === 7) w.f.boardsAppend(clone(bd)); else if (op === 8 && w.S.boards[0]) w.f.boardsRename(w.S.boards[0], 'R' + step); else if (op === 9) w.f.boardsRemove('b1'); else if (op === 10) w.f.boardsReplace(clone([bd]), sv);
      else if (op === 11 && w.host) { w.host.release(); w.host.engage(); } else if (op === 12 && w.host) { w.host.release(); } else if (op === 13) { w.f.saveIdeas(); w.f.saveBoards(); }
    }
    if (op === 12) B.host.engage();
    assert.deepEqual(B.S.ideas, A.S.ideas, `idées ${seed}/${step}/${op}`); assert.deepEqual(B.S.boards, A.S.boards, `tableaux ${seed}/${step}/${op}`); assert.deepEqual(B.log, A.log, `écritures ${seed}/${step}/${op}`); checks += 3;
  }
}
// réassignation sauvage : le magasin se resynchronise ; restauration au démarrage sans écriture ; hôte relâché ⇒ code historique
{ const w = world('host', { ideas: [{ id: 'a' }], boards: [] }); w.f.ideasAdd({ id: 'b' }); w.S.ideas = [{ id: 'zz' }]; w.f.ideasAdd({ id: 'c' }); assert.deepEqual(w.S.ideas.map((x) => x.id), ['c', 'zz']); assert.equal(w.f.libStore('ideas').list(), w.S.ideas);
  const n = w.log.length; w.f.boardsReplace([{ id: 'r' }]); assert.equal(w.log.length, n); w.host.release(); assert.equal(w.f.libStore('ideas'), null); w.f.ideasAdd({ id: 'n' }); assert.equal(w.S.ideas[0].id, 'n'); }
console.log('jalon4_3 OK —', checks, 'comparaisons');
