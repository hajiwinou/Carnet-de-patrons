// Jalon 4.6b — Projects propriétaire des médias de projets (pjc_ / pjp_ / pji_) : une seule autorité d'écriture et de suppression
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsMedia, PROJECT_MEDIA_PREFIXES } from '../dreamOS/projects/projects-media.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const helperSrc = grab(/  function projStore\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'projStore..pjRelinkPattern'), projHostSrc = one('projHost'), curSrc = one('curPj');
const photoBlocks = grab(/    if \(t\.id === 'pjCover' && t\.files && t\.files\[0\]\) \{[\s\S]*?(?=\n    if \(t\.id === 'rgPhoto')/, 'pjCover..pjPhotos');
const branch = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), n);
const inspoDelSrc = branch('inspoDel'), entryDelSrc = branch('pjDelEntryYes'), photoDelSrc = branch('pjPhotoDel');
const delYesSrc = grab(/    else if \(a === 'pjDelYes'\) \{[\s\S]*?\n    \}\n/, 'pjDelYes');

// 1. garde-fous statiques
const outside = app.replace(helperSrc, '');
assert.deepEqual(outside.match(/saveBlob\(\s*(cid2|inspoI|i4|pid)\b/g) || [], [], 'écriture directe de média de projet');
assert.deepEqual(outside.match(/IDB\.del\(\s*(pid9|ide\.mediaId|pr5\.cover|e\.mediaId)\s*\)/g) || [], [], 'suppression directe de média de projet');
assert.equal((outside.match(/IDB\.del\(id\)/g) || []).length, 4, 'seules les portes uniques de Documentation, de Library, de Patterns et du fond d\'écran (Settings) suppriment encore par IDB.del(id)');
assert.deepEqual(outside.match(/'(pjc_|pjp_|pji_)'\s*\+\s*uid\(\)/g) || [], [], 'identifiant de média de projet fabriqué hors de la porte unique');

// 2. propriété
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {}; const names = ['pjc_*', 'pjp_*', 'pji_*'];
  names.forEach((n) => assert.equal(reg.ownerOf('media', n), 'legacy'));
  const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win }); h.engage(); names.forEach((n) => assert.equal(reg.ownerOf('media', n), 'projects')); assert.equal(reg.ownerOf('media', 'ideam_*'), 'legacy', 'médias d\'idées : Library, pas Projects');
  assert.throws(() => reg.transferOwnership('media', 'pjc_*', 'legacy', 'tools'), /transfert refusé/); h.release(); names.forEach((n) => assert.equal(reg.ownerOf('media', n), 'legacy')); h.engage(); assert.equal(reg.ownerOf('media', 'pji_*'), 'projects'); }

// 3. passerelle
{ const bus = new EventBus(), seen = []; ['saved', 'discarded'].forEach((t) => bus.on('projects:media-' + t, () => seen.push(t))); const m = createProjectsMedia({ eventBus: bus }); const uid = () => 'abc';
  assert.deepEqual([...PROJECT_MEDIA_PREFIXES], ['pjc_', 'pjp_', 'pji_']); assert.equal(m.newId('pjc_', uid), 'pjc_abc'); assert.equal(m.newId('pjp_', uid), 'pjp_abc'); assert.equal(m.newId('pji_', uid), 'pji_abc'); assert.throws(() => m.newId('img_', uid), /préfixe non géré/);
  for (const ok of ['pjc_1', 'pjp_1', 'pji_1']) assert.equal(m.isOwn(ok), true); for (const no of ['ideam_1', 'docm_1', 'img_1', 5, null]) assert.equal(m.isOwn(no), false);
  await assert.rejects(m.put('ideam_1', 1, async () => {}), /pjc_/); await assert.rejects(m.put('pjc_1', 1), /écriture requise/); assert.equal(await m.put('pjp_1', 'b', async (id, b) => id + b), 'pjp_1b');
  assert.equal(m.discard('img_ancien', () => {}), true, 'suppression sans contrainte de préfixe (anciens projets)'); assert.throws(() => m.discard('pjc_1'), /suppression requise/); assert.deepEqual(seen, ['saved', 'discarded']);
  const refs = m.referenced([{ cover: 'pjc_a', photos: ['pjc_a', 'pjc_b', 'img_x'], inspo: [{ mediaId: 'pji_1' }, { mediaId: 'ideam_z', ideaId: 'i' }, { mediaId: 'pji_2', ideaId: 'i' }], log: [{ photos: ['pjp_1', 'pjp_1'] }, {}] }, null, { cover: '' }]);
  assert.deepEqual([...refs].sort(), ['pjc_a', 'pjc_b', 'pji_1', 'pjp_1']); assert.deepEqual([...m.referenced(null)], []);
  const bad = createProjectsMedia({ eventBus: { emit() { throw new Error('x'); } } }); assert.equal(await bad.put('pjc_9', 1, async () => 'ok'), 'ok'); }

// 4. équivalence sur le VRAI code d'app.js
const ARGS = ['window', 'S', 'uid', 'keep', 'saveBlob', 'shrink', 'IDB', 'toast', 'render', 'askConfirm', 'confirm', 'deferDelete', 'Date', 'a', 'b', 't'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, a) => a[Math.floor(r() * a.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const projects = Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ id: 'j' + i, seq: i + 1, name: 'P' + i, stage: 'wip', patternId: '', cover: pick(r, ['', 'pjc_a' + i, 'pjp_L' + i]), photos: ['pjc_a' + i, 'pjc_b' + i], inspo: [{ id: 'i1', mediaId: 'pji_1' + i, mediaType: 'image' }, { id: 'i2', ideaId: 'x', mediaId: 'ideam_z' }], log: [{ id: 'e1', ts: 1, text: 't', photos: ['pjp_L' + i, 'pjp_M' + i] }, { id: 'e2', ts: 2, text: '' }], created: i, stageAt: {} }));
  return { projects, curProj: projects[0].id, pjDraft: pick(r, ['', ' note ']), busy: '', pjDel: false, pjDelEntry: null, tab: 'pjd' };
}
async function run(withHost, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }).engage(); }
  let k = 0; const ctx = { window: win, S, uid, keep: (kk, x) => log.push(['keep', kk, JSON.stringify(x)]), saveBlob: async (id, bl) => { log.push(['blob', id, JSON.stringify(bl)]); }, shrink: async (f) => { if (f.bad) throw new Error('x'); return 'shrunk:' + f.name; },
    IDB: { put: (kk, x) => { log.push(['idbput', kk, x]); return Promise.resolve(); }, del: (id) => log.push(['idbdel', id]) }, toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), askConfirm: async () => sc.confirm, confirm: () => sc.confirm,
    deferDelete: (msg, undo, done) => { log.push(['defer', msg]); if (sc.undo) { undo(); } else done(); }, Date: FakeDate, a: sc.a, b: { dataset: { id: sc.id } }, t: sc.t ? { ...sc.t, files: sc.t.files, value: 'x' } : {} };
  const body = `${projHostSrc}${curSrc}${helperSrc}\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function(...ARGS, body)(...ARGS.map((kk) => ctx[kk]));
  return JSON.stringify({ S: { projects: S.projects, busy: S.busy, pjDraft: S.pjDraft, pjDel: S.pjDel, pjDelEntry: S.pjDelEntry, curProj: S.curProj }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 500; seed++) {
  const r = rng(seed), st = state(r), pj = st.projects[0];
  const files = (m) => Array.from({ length: Math.floor(r() * 3) + 1 }, (_, i) => ({ name: 'f' + i, bad: r() < .2 })).slice(0, m);
  const scs = [
    { kind: 'cover', code: photoBlocks, t: { id: 'pjCover' }, files: null }, { kind: 'inspoAdd', code: photoBlocks, t: { id: 'inspoAddPh' } }, { kind: 'pjAdd', code: photoBlocks, t: { id: 'pjAddPh' } }, { kind: 'logPh', code: photoBlocks, t: { id: 'pjPhotos' } },
    { kind: 'inspoDel', code: `if (false) {}\n${inspoDelSrc}`, a: 'inspoDel', id: pick(r, ['i1', 'i2', 'zz']), confirm: r() < .7 }, { kind: 'entryDel', code: `if (false) {}\n${entryDelSrc}`, a: 'pjDelEntryYes', id: pick(r, ['e1', 'e2', 'zz']) },
    { kind: 'photoDel', code: `if (false) {}\n${photoDelSrc}`, a: 'pjPhotoDel', id: pick(r, ['pjc_a0', 'pjc_b0', 'pjc_zz']), confirm: r() < .7 }, { kind: 'projDel', code: `if (false) {}\n${delYesSrc}`, a: 'pjDelYes', undo: r() < .5 }
  ];
  for (const sc of scs) {
    if (sc.t) { const fl = files(3); sc.t = { ...sc.t, files: fl }; sc.files = fl; }
    const A = await run(false, st, sc), B = await run(true, st, sc); assert.equal(B, A, `${sc.kind} seed ${seed}`); checks++;
    const out = JSON.parse(A), blobs = out.log.filter((l) => l[0] === 'blob').map((l) => l[1]), dels = out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]), P = out.S.projects[0];
    const okFiles = sc.files ? sc.files.filter((f) => !f.bad) : [];
    if (sc.kind === 'cover') { const f0 = sc.files[0]; if (f0.bad) assert.equal(blobs.length, 0); else { assert.equal(blobs.length, 1); assert.match(blobs[0], /^pjc_u\d+$/); assert.equal(P.cover, blobs[0]); assert.equal(P.photos.at(-1), blobs[0]); } checks++; }
    if (sc.kind === 'inspoAdd') { assert.equal(blobs.length, okFiles.length); assert.ok(blobs.every((b) => /^pji_u\d+$/.test(b))); assert.deepEqual(P.inspo.slice(2).map((e) => e.mediaId), blobs); checks++; }
    if (sc.kind === 'pjAdd') { assert.equal(blobs.length, okFiles.length); assert.ok(blobs.every((b) => /^pjc_u\d+$/.test(b))); assert.deepEqual(P.photos.slice(2), blobs); checks++; }
    if (sc.kind === 'logPh') { assert.equal(blobs.length, okFiles.length); assert.ok(blobs.every((b) => /^pjp_u\d+$/.test(b))); if (okFiles.length) assert.deepEqual(P.log[0].photos, blobs); else assert.equal(P.log.length, 2); checks++; }
    if (sc.kind === 'inspoDel') { const e = pj.inspo.find((x) => x.id === sc.id); if (e && e.mediaId && !e.ideaId && sc.confirm) assert.deepEqual(dels, [e.mediaId]); else assert.deepEqual(dels, []); checks++; }
    if (sc.kind === 'entryDel') { const e = pj.log.find((x) => x.id === sc.id); assert.deepEqual(dels, e ? e.photos || [] : []); assert.ok(!P.log.some((x) => x.id === sc.id)); checks++; }
    if (sc.kind === 'photoDel') { if (sc.confirm) { assert.deepEqual(dels, [sc.id]); assert.ok(!P.photos.includes(sc.id)); } else assert.deepEqual(dels, []); checks++; }
    if (sc.kind === 'projDel') { if (sc.undo) assert.deepEqual(dels, []); else { const exp = [...(pj.cover.startsWith('pjc_') ? [pj.cover] : []), ...pj.photos, 'pji_1' + 0, ...pj.log.flatMap((e) => e.photos || [])]; assert.deepEqual(dels.slice().sort(), exp.map((x) => (x === 'pji_10' ? 'pji_1' + pj.id.slice(1) : x)).sort(), 'tous les médias du projet supprimés, idée partagée conservée'); assert.ok(!dels.includes('ideam_z')); } checks++; }
  }
}
// 5. bascule à chaud : une écriture après relâchement suit le code d'origine, sans perte
{ const win = {}, log = []; const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win }); h.engage();
  const f = new Function('window', 'S', 'uid', 'keep', 'saveBlob', 'IDB', `${projHostSrc}${helperSrc}\nreturn { pjmNewId, pjmSave, pjmDiscard };`)(win, { projects: [] }, () => 'u1', () => {}, async (id) => log.push(['blob', id]), { del: (id) => log.push(['del', id]), put: () => Promise.resolve() });
  assert.equal(f.pjmNewId('pjc_'), 'pjc_u1'); await f.pjmSave('pjc_u1', 1); f.pjmDiscard('pjc_u1'); h.release(); assert.equal(f.pjmNewId('pji_'), 'pji_u1'); await f.pjmSave('whatever', 1); f.pjmDiscard('x'); assert.deepEqual(log, [['blob', 'pjc_u1'], ['del', 'pjc_u1'], ['blob', 'whatever'], ['del', 'x']]); }
console.log('jalon4_6b OK —', checks, 'comparaisons');
