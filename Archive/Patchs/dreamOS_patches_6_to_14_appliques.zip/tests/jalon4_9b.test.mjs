// Jalon 4.9b — Settings modifie lui-même les valeurs de réglages (apparence, palette, IA, options, île, fond) (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installSettingsHost } from '../dreamOS/settings/settings-host.js';
import { createSettingsCommands, DEFAULT_ACCENT } from '../dreamOS/settings/settings-commands.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const doorBlock = grab(/  function setHost\(\)[\s\S]*?\n  function saveUiSoon[^\n]*\n/, 'portes');
const pal = grab(/  var DREAM_PALETTES = \[[\s\S]*?\n  \];\n/, 'palettes');
const blk = (cond) => grab(new RegExp('    if \\(' + cond + '\\) \\{[\\s\\S]*?\\n    \\}\\n'), cond);
const line = (cond) => grab(new RegExp('    if \\(' + cond + '[^\\n]*\\n'), cond);
const actLine = (head) => 'if (false) {}\n' + grab(new RegExp("    else if \\(a === '" + head + "'\\)[^\\n]*\\n"), head);
const BR = { ui: blk('t\\.dataset\\.ui'), dream: blk('t\\.dataset\\.dream'), aikey: blk('t\\.dataset\\.aikey \\|\\| t\\.dataset\\.aiurl'), omni: line('t\\.dataset\\.aiomnivision'), model: line('t\\.dataset\\.aimodel'), pref: line('t\\.dataset\\.aipref'), fail: line('t\\.dataset\\.aifailover'), opt: blk('t\\.dataset\\.opt'), island: blk('t\\.dataset\\.island'), stat: blk('t\\.dataset\\.stat'),
  dreamPal: actLine('dreamPal'), accent: actLine('setAccent'), reset: actLine('resetColors') };

// 1. garde-fous statiques
const outside = app.replace(doorBlock, '');
for (const [re, what] of [[/\bS\.ui\.[A-Za-z]+\s*=[^=]/g, 'apparence'], [/\bS\.ui\[[^\]]+\]\s*=[^=]/g, 'apparence'], [/\bS\.ui\.dream\[[^\]]+\]\s*=[^=]/g, 'palette'], [/\bS\.ai\.(urls|keys|models)\[[^\]]+\]\s*=[^=]/g, 'fournisseurs'], [/\bS\.ai\.(prefText|prefVision|omniVision|autoFailover)\s*=[^=]/g, 'préférences d\'IA'], [/\bS\.ai\[[^\]]+\]\s*=[^=]/g, 'préférence d\'IA'], [/\bS\.opts\[[^\]]+\]\s*=[^=]/g, 'options'], [/\bS\.pwHash\s*=[^=]/g, 'empreinte']]) {
  const hits = (outside.match(re) || []).filter((h) => !/^S\.ai\.(urls|keys|models)\s*=/.test(h)); assert.deepEqual(hits, [], 'hors portes : ' + what);
}
for (const n of ['stCmd', 'stUiField', 'stDreamColor', 'stDreamPalette', 'stAccent', 'stResetColors', 'stStat', 'stIsland', 'stEnableIsland', 'stUiValue', 'stAiUrl', 'stAiKey', 'stAiDefaults', 'stAiOmni', 'stAiModel', 'stAiPref', 'stAiFailover', 'stOpt', 'stPwHash']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);
// chargement initial (normalisation des clés / modèles / adresses à l'ouverture) : lecture-normalisation, une seule forme attendue
assert.equal((outside.match(/S\.ai\.(keys|models|urls) = Object\.assign\(\{\}, defaultAiConfig/g) || []).length, 3);
for (const [re, c] of [[/(?<!function )stDreamPalette\(/g, 2], [/(?<!function )stUiValue\(/g, 5], [/(?<!function )stEnableIsland\(/g, 1], [/(?<!function )stResetColors\(/g, 1], [/(?<!function )stAccent\(/g, 1]]) assert.equal((app.match(re) || []).length, c, String(re));

// 2. commandes seules
{ const c = createSettingsCommands(); assert.ok(Object.isFrozen(c)); assert.equal(DEFAULT_ACCENT, '#2A47C9');
  const ui = {}; c.setUiField(ui, 'theme', 'dark'); c.setUiField(ui, 'overlayOpacity', '0.5'); assert.deepEqual(ui, { theme: 'dark', overlayOpacity: 0.5 }); c.setUiField(ui, 'font', '0.5'); assert.equal(ui.font, '0.5');
  c.setDreamColor(ui, { a: 1, b: 2 }, 'b', 9); assert.deepEqual(ui.dream, { a: 1, b: 9 }); c.setDreamColor(ui, { a: 7, b: 2 }, 'c', 5); assert.deepEqual(ui.dream, { a: 1, b: 9, c: 5 });
  const P = { x: 1 }; c.setDreamPalette(ui, P); assert.deepEqual(ui.dream, { x: 1 }); assert.notEqual(ui.dream, P); c.setAccent(ui, '#fff'); assert.equal(ui.accent, '#fff'); c.resetColors(ui); assert.deepEqual([ui.bgColor, ui.surfaceColor, ui.accent], ['', '', '#2A47C9']);
  const old = { a: true }; ui.stats = old; c.setStat(ui, 'b', false); assert.deepEqual(ui.stats, { a: true, b: false }); assert.notEqual(ui.stats, old); assert.deepEqual(old, { a: true });
  const u2 = {}; let io = c.setIslandOption(u2, 'on', 'x', true, 'chat'); assert.deepEqual(io, { on: true, months: 3, animal: 'chat' }); assert.equal(u2.island, io); c.setIslandOption(u2, 'animal', 'ours', false, 'chat'); assert.equal(u2.island.animal, 'ours'); assert.equal(u2.island.on, true);
  c.setIslandOption(u2, 'months', '0', false, 'chat'); assert.equal(u2.island.months, 3); c.setIslandOption(u2, 'months', '9', false, 'chat'); assert.equal(u2.island.months, 9); c.setIslandOption(u2, 'months', '-4', false, 'chat'); assert.equal(u2.island.months, 1);
  const u3 = { island: { months: 5 } }; c.enableIsland(u3); assert.deepEqual(u3.island, { months: 5, on: true }); const u4 = {}; c.enableIsland(u4); assert.deepEqual(u4.island, { on: true }); c.setUiValue(u4, 'wallpaperId', 'wp_1'); assert.equal(u4.wallpaperId, 'wp_1');
  const ai = { urls: {}, keys: {}, models: {} }; c.setProviderUrl(ai, 'o', '  http://x  '); c.setProviderKey(ai, 'g', ' k '); c.setModel(ai, 'g', 'm'); c.setPreference(ai, 'prefText', 'g'); c.setOmniVision(ai, true); c.setAutoFailover(ai, false);
  assert.deepEqual(ai, { urls: { o: 'http://x' }, keys: { g: ' k ' }, models: { g: 'm' }, prefText: 'g', omniVision: true, autoFailover: false });
  const ready = (id) => id === 'ok'; const a2 = {}; c.adoptDefaultProviders(a2, 'n', true, ready); assert.deepEqual([a2.prefText, a2.prefVision], ['n', 'n']); const a3 = { prefText: 'ok', prefVision: 'ok' }; c.adoptDefaultProviders(a3, 'n', true, ready); assert.deepEqual([a3.prefText, a3.prefVision], ['ok', 'ok']); const a4 = { prefText: 'zz', prefVision: 'zz' }; c.adoptDefaultProviders(a4, 'n', false, ready); assert.deepEqual([a4.prefText, a4.prefVision], ['n', 'zz']);
  const o = { dup: 3, auto: false }; c.setOption(o, 'dup', false, true, '7'); c.setOption(o, 'auto', true, true, 'x'); assert.deepEqual(o, { dup: 7, auto: true }); c.setOption(o, 'dup', false, false, 'abc'); assert.equal(o.dup, 7); c.setOption(o, 'dup', false, false, '0'); assert.equal(o.dup, 7); c.setOption(o, 'dup', false, false, '-2'); assert.equal(o.dup, 1); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'S', 'uid', 'keep', 'IDB', 'saveBlob', 'applyAppearance', 'toast', 'render', 'localStorage', 'PW_FAIL_KEY', 'setTimeout', 'clearTimeout', 'uiT', 'ISLAND_ANIMALS', 'DREAM_PALETTES', 'provReady', 'provVision', 'a', 'v', 't', 'sc'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
async function run(mode, st, sc) {
  const win = {}, log = [], S = clone(st.S), timers = [];
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installSettingsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const ctx = { window: win, S, uid: () => 'u', keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), IDB: { del() {} }, saveBlob: async () => {}, applyAppearance: () => log.push(['appearance']), toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), localStorage: {}, PW_FAIL_KEY: 'k', setTimeout: (f) => { timers.push(f); return 1; }, clearTimeout() {}, uiT: null,
    ISLAND_ANIMALS: [{ id: 'chat' }], provReady: (id) => st.ready.includes(id), provVision: (id) => st.vision.includes(id), a: sc.a, v: sc.v, t: sc.t || {}, sc };
  const body = `${pal}${doorBlock}\nreturn (async function(){ ${sc.code}\n })();`;
  await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  timers.forEach((f) => f());
  return JSON.stringify({ S: { ui: S.ui, ai: S.ai, opts: S.opts, aiTestStatus: S.aiTestStatus }, log });
}
const PAL0 = (() => { const m = pal.match(/DREAM_PALETTES = \[\s*\[[^\]]*?,\s*(\{[^}]*\})\]/); return m ? Function('return ' + m[1].replace(/(\w+):/g, '"$1":').replace(/'/g, '"'))() : null; })();
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(Math.imul(seed, 2654435761) >>> 0);
  const st = { ready: pick(r, [[], ['groq'], ['groq', 'gem']]), vision: pick(r, [[], ['gem'], ['groq', 'gem']]), S: { aiTestStatus: { groq: 1, gem: 1 }, ui: { accent: '#111', bgColor: 'x', surfaceColor: 'y', dream: pick(r, [undefined, { main: '#000' }]), island: pick(r, [undefined, { on: false, months: 2, animal: 'ours' }]), stats: pick(r, [undefined, { a: true }]), wallpaperId: '' },
    ai: { prefText: pick(r, ['', 'groq', 'old']), prefVision: pick(r, ['', 'gem', 'old']), urls: { omniroute: 'u' }, keys: { groq: '' }, models: { groq: 'm' } }, opts: { dup: 3, auto: false } } };
  const pid = pick(r, ['groq', 'gem']), val = pick(r, ['', ' abc ', '0.4', '#abcdef', '7']), chk = r() < .5;
  const scs = [
    { kind: 'ui', code: BR.ui, t: { dataset: { ui: pick(r, ['theme', 'font', 'overlayOpacity', 'bgColor']) }, value: val } },
    { kind: 'dream', code: BR.dream, t: { dataset: { dream: pick(r, ['main', 'desk']) }, value: val } },
    { kind: 'aiurl', code: BR.aikey, t: { dataset: { aiurl: pid }, value: val } }, { kind: 'aikey', code: BR.aikey, t: { dataset: { aikey: pid }, value: val } },
    { kind: 'omni', code: BR.omni, t: { dataset: { aiomnivision: '1' }, checked: chk } }, { kind: 'model', code: BR.model, t: { dataset: { aimodel: pid }, value: val } }, { kind: 'pref', code: BR.pref, t: { dataset: { aipref: pick(r, ['prefText', 'prefVision']) }, value: val } }, { kind: 'fail', code: BR.fail, t: { dataset: { aifailover: '1' }, checked: chk } },
    { kind: 'opt', code: BR.opt, t: { dataset: { opt: 'dup' }, type: pick(r, ['checkbox', 'number']), checked: chk, value: pick(r, ['7', '0', 'x', '-3']) } },
    { kind: 'island', code: BR.island, t: { dataset: { island: pick(r, ['on', 'animal', 'months']) }, checked: chk, value: pick(r, ['ours', '0', '6']) } }, { kind: 'stat', code: BR.stat, t: { dataset: { stat: 'b' }, checked: chk } },
    { kind: 'dreamPal', code: BR.dreamPal, a: 'dreamPal', v: pick(r, ['0', '1', '99']) }, { kind: 'accent', code: BR.accent, a: 'setAccent', v: '#abc123' }, { kind: 'reset', code: BR.reset, a: 'resetColors' }
  ];
  for (const sc of scs) {
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), L = out.log, names = L.map((l) => l[0]), ui = out.S.ui, ai = out.S.ai, d = sc.t && sc.t.dataset;
    if (sc.kind === 'ui') { const k = d.ui; assert.equal(ui[k], k === 'overlayOpacity' ? JSON.parse(JSON.stringify(parseFloat(val))) : val); if (k === 'overlayOpacity' && Number.isNaN(parseFloat(val))) assert.equal(ui[k], null); assert.deepEqual(names, k === 'theme' || k === 'font' ? ['keep', 'appearance', 'render'] : ['appearance', 'keep']); }
    if (sc.kind === 'dream') { assert.deepEqual(ui.dream, Object.assign({}, PAL0, st.S.ui.dream || {}, { [d.dream]: val })); assert.deepEqual(names, ['appearance', 'keep']); }
    if (sc.kind === 'aiurl') { assert.equal(ai.urls[pid], val.trim()); assert.equal(ai.keys[pid], st.S.ai.keys[pid]); }
    if (sc.kind === 'aikey') { assert.equal(ai.keys[pid], val); assert.equal(ai.urls[pid], st.S.ai.urls[pid]); }
    if (sc.kind === 'aikey' || sc.kind === 'aiurl') { const rd = (id) => st.ready.includes(id); let pt = st.S.ai.prefText, pv = st.S.ai.prefVision; if (rd(pid)) { if (!pt || !rd(pt)) pt = pid; if (st.vision.includes(pid) && (!pv || !rd(pv))) pv = pid; } assert.deepEqual([ai.prefText, ai.prefVision], [pt, pv]); assert.equal(out.S.aiTestStatus && out.S.aiTestStatus[pid], undefined); assert.deepEqual(names, ['keep']); }
    if (sc.kind === 'omni') { assert.equal(ai.omniVision, chk); assert.deepEqual(names, ['keep', 'render']); }
    if (sc.kind === 'model') { assert.equal(ai.models[pid], val); assert.deepEqual(names, ['keep']); }
    if (sc.kind === 'pref') { assert.equal(ai[d.aipref], val); assert.deepEqual(names, ['keep']); }
    if (sc.kind === 'fail') { assert.equal(ai.autoFailover, chk); assert.deepEqual(names, ['keep']); }
    if (sc.kind === 'opt') { const cb = sc.t.type === 'checkbox'; assert.equal(out.S.opts.dup, cb ? chk : Math.max(1, parseInt(sc.t.value, 10) || 3)); assert.deepEqual(names, cb ? ['keep', 'render'] : ['keep']); }
    if (sc.kind === 'island') { const w = d.island, io = Object.assign({ on: false, months: 3, animal: 'chat' }, st.S.ui.island || {}); if (w === 'on') io.on = chk; else if (w === 'animal') io.animal = sc.t.value; else io.months = Math.max(1, parseInt(sc.t.value, 10) || 3); assert.deepEqual(ui.island, io); assert.deepEqual(names, w === 'animal' ? ['keep', 'render'] : ['keep']); }
    if (sc.kind === 'stat') { assert.deepEqual(ui.stats, Object.assign({}, st.S.ui.stats || {}, { b: chk })); }
    if (sc.kind === 'dreamPal') { const i = +sc.v; if (i <= 1) { assert.notDeepEqual(ui.dream, undefined); assert.deepEqual(names, ['keep', 'appearance', 'render']); } else { assert.deepEqual(ui.dream, st.S.ui.dream); assert.deepEqual(names, []); } }
    if (sc.kind === 'accent') { assert.equal(ui.accent, '#abc123'); assert.deepEqual(names, ['keep', 'appearance', 'render']); }
    if (sc.kind === 'reset') { assert.deepEqual([ui.bgColor, ui.surfaceColor, ui.accent], ['', '', '#2A47C9']); assert.deepEqual(L.map((l) => l[0]), ['keep', 'appearance', 'render', 'toast']); assert.equal(L[3][1], 'Couleurs réinitialisées.'); }
    checks++;
  }
}
console.log('jalon4_9b OK —', checks, 'comparaisons');
