// Phase 2.8 — complétude du précache du Service Worker (spec §10.2)
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rd = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const norm = (u) => path.posix.normalize(u.replace(/^\.\//, '').split('?')[0]);
const sw = rd('sw.js');
const LOCAL = new Set(eval(sw.match(/var LOCAL = (\[[\s\S]*?\]);/)[1]).filter((u) => u !== './').map(norm));
const fails = [], warns = [];
const need = (f, why) => { if (!LOCAL.has(f)) fails.push(`${f} absent du précache (${why})`); };
const exists = (f) => fs.existsSync(path.join(root, f));

// 1. chaque entrée du précache existe (les assets/ non livrés dans le zip labo sont signalés à part)
for (const f of LOCAL) if (!exists(f)) ((f.startsWith('assets/') || f.startsWith('themes/bliss/')) ? warns : fails).push(`${f} listé dans le précache mais absent du zip`);
// 2. fichiers locaux référencés par index.html
for (const m of rd('index.html').matchAll(/(?:href|src)="([^"#:]+?)"/g)) if (!/^(https?:|data:)/.test(m[1])) need(norm(m[1]), 'index.html');
// 3. graphe des modules ESM depuis bootstrap.js
const seen = new Set(); const walk = (f) => {
  if (seen.has(f)) return; seen.add(f); need(f, 'module ESM');
  for (const m of rd(f).matchAll(/(?:import|export)[^'"]*?from\s*'(\.[^']+)'/g)) walk(path.posix.join(path.posix.dirname(f), m[1]));
};
walk('dreamOS/bootstrap.js');
// 4. @import CSS et url() relatifs des thèmes
for (const css of ['themes/themes.css', 'themes/bliss.css']) {
  const t = rd(css);
  for (const m of t.matchAll(/@import url\("([^"]+)"\)/g)) need(norm(path.posix.join('themes', m[1])), `@import dans ${css}`);
}
const bl = rd('themes/bliss.css'), bAssets = new Set();
for (const m of bl.matchAll(/url\("(\.[^")]+)"\)/g)) bAssets.add(norm(path.posix.join('themes', m[1])));
// Ancien thème bleu : ses images (themes/bliss/) sont retirées du précache (décision du 22 nov. 2026) ; elles disparaissent avec l'ancien CSS, écran par écran.
void bAssets;
// 5. le SW sert bien tous les modules en cas de coupure : stratégie réseau d'abord + repli cache
if (!/caches\.match\(r, \{ ignoreSearch: true \}\)/.test(sw)) fails.push('repli cache sans ignoreSearch : les ?v= casseraient hors-ligne');

console.log(`Précache : ${LOCAL.size} entrées · modules ESM atteints : ${seen.size}`);
warns.forEach((w) => console.log('  ⚠', w)); fails.forEach((w) => console.log('  ✗', w));
if (fails.length) { console.log(`ÉCHEC (${fails.length})`); process.exit(1); }
console.log('Précache complet pour le code (JS/CSS/HTML).');
