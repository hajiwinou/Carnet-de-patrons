// Jalon 4.7c — Patterns modifie lui-même les champs d'un patron (titre, texte, statut, dossier, étape, source PDF, photos, fiche, variantes) (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPatternsHost } from '../dreamOS/patterns/patterns-host.js';
import { createPatternsCommands } from '../dreamOS/patterns/patterns-commands.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const fn = (n) => grab(new RegExp('  (?:async )?function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const doorBlock = grab(/  function patHost\(\)[\s\S]*?\n  function patSetGroup[^\n]*\n/, 'portes');
const doorsSrc = doorBlock.replace(/\n  function persist\(light\)[^\n]*\n  function persistNow\(\)[^\n]*\n  function saveFolders\(\)[^\n]*\n/, '\n');
assert.ok(doorsSrc.length < doorBlock.length);
const SRC = [one('stageOf'), one('hasResultPhoto'), fn('setStage'), fn('renameP'), fn('autoFile'), fn('folderFor'), one('normAuthor'), one('fieldDef'), fn('addPhotos'), fn('storeThumb')].join('');
const line = (cond) => grab(new RegExp('    if \\(' + cond + '[^\\n]*\\n'), cond);
const blk = (cond) => grab(new RegExp('    if \\(' + cond + '\\) \\{[\\s\\S]*?\\n    \\}\\n'), cond);
const act = (head) => 'if (false) {}\n' + grab(new RegExp('    else if \\(' + head + '\\) \\{[\\s\\S]*?\\n    \\}\\n'), head);
const actLine = (head) => 'if (false) {}\n' + grab(new RegExp('    else if \\(' + head + '\\) \\{[^\\n]*\\n'), head);
const BR = { title: line("t\\.id === 'title'"), raw: line("t\\.id === 'rawText'"), status: line('t\\.dataset\\.status'), folder: line('t\\.dataset\\.folder'), pk: line('t\\.dataset\\.pk !== undefined'), opt: blk('t\\.dataset\\.oi !== undefined'), fact: blk('t\\.dataset\\.k'),
  chip: act("a === 'chip' && p"), addOpt: act("a === 'addOpt' && p"), delOpt: actLine("a === 'delOpt' && p") };

// 1. garde-fous statiques : plus aucune écriture directe de ces champs hors des portes
const outside = app.replace(doorBlock, '');
const forbid = [[/\bp\.title\s*=[^=]/g, 'titre'], [/\bp\.raw\s*=[^=]/g, 'texte'], [/\bp\.status\s*=[^=]/g, 'statut'], [/\bp\.folder\s*=[^=]/g, 'dossier'], [/delete p\.folder/g, 'dossier'], [/\bp\.stage\s*=[^=]/g, 'étape'], [/\bp\.stagePrev\s*=/g, 'étape précédente'], [/\bp\.stageAt\[[^\]]+\]\s*=/g, 'date d\'étape'],
  [/\bp\.source\.(pdf|file|pages)\s*=[^=]/g, 'source'], [/\bp\.source\s*=\s*p\.source/g, 'source'], [/\bp\.thumb\s*=[^=]/g, 'miniature'], [/delete p\.thumb/g, 'miniature'], [/\bp\.scanned\s*=[^=]/g, 'scanné'], [/\bp\._v\s*=[^=]/g, 'version du texte'], [/\bp\.photos\s*=\s*\(p\.photos/g, 'photos'], [/\bp\.photos\[[^\]]+\]\.kind\s*=/g, 'type de photo'],
  [/\bp\.opts\.(push|splice)\(/g, 'variantes'], [/\bp\.opts\s*=\s*p\.opts\s*\|\|/g, 'variantes'], [/\bp\.f\[[^\]]+\]\s*=[^=]/g, 'fiche'], [/delete p\.f\[/g, 'fiche'], [/delete p\.ai\[/g, 'drapeau IA'], [/delete o\.f\[/g, 'fiche de variante'], [/\bo\.f\[[^\]]+\]\s*=[^=]/g, 'fiche de variante'], [/\bo\.ai\s*=[^=]/g, 'variante IA']];
// (l'analyse par IA — analyze, aiVisual, aiPhoto — écrit encore p.f / p.ai / p.opts : 4.7d)
const analyzeZone = outside.slice(outside.indexOf('  function aiPhoto'), outside.indexOf('  function aiPhoto') + 0);
for (const [re, what] of forbid) { const hits = (outside.match(re) || []); assert.deepEqual(hits.filter((h) => !/p\.f\[|delete p\.ai|p\.opts|o\.ai|o\.f\[/.test(h)), [], 'écriture directe hors portes : ' + what); }
for (const n of ['patCmd', 'patSetField', 'patSetRaw', 'patSetTranscript', 'patMarkScanned', 'patSetFolderField', 'patSetFolder', 'patSetPhotoKind', 'patAddPhoto', 'patSetStage', 'patRename', 'patEnsureSource', 'patSetSourcePdf', 'patSetSourceFileDefault', 'patSetSourcePages', 'patClearThumb', 'patSetThumb', 'patSetFact', 'patSetChipFact', 'patAddOption', 'patRemoveOption', 'patSetOptionGrid', 'patSetOptionFact', 'patSetOptionProp']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);
// sites d'import non exécutables ici : une seule forme attendue
for (const [re, c] of [[/patSetSourcePdf\(p, pdfId\)/g, 2], [/(?<!function )patMarkScanned\(p\)/g, 1], [/patSetTranscript\(p, out\.join\('\\n\\f\\n'\)\)/g, 1], [/patSetFolder\(p, pendingReplace\.folder\)/g, 1], [/(?<!function )patClearThumb\(p\)/g, 1], [/patSetSourcePages\(p, pdf\.numPages\)/g, 1], [/patSetSourceFileDefault\(p, f\.name\)/g, 1], [/(?<!function )patEnsureSource\(p\)/g, 1]]) assert.equal((app.match(re) || []).length, c, String(re));

// 2. commandes seules
{ let n = 0, t = 1000; const c = createPatternsCommands({ uid: () => 'u' + (++n), now: () => t }); assert.throws(() => createPatternsCommands({}), /uid requis/);
  const p = { photos: [{ id: 'a', kind: 'modele' }], f: { designer: 'X' }, ai: { designer: 1, garment: 1 }, source: {} };
  c.setField(p, 'title', 'T'); c.setField(p, 'status', 's'); assert.deepEqual([p.title, p.status], ['T', 's']); c.setRaw(p, 'x'.repeat(90005)); assert.equal(p.raw.length, 90000); assert.equal(p._v, 1); c.setTranscript(p, 'tr'); assert.deepEqual([p.raw, p.scanned, p._v], ['tr', false, 2]); c.markScanned(p); assert.equal(p.scanned, true);
  c.setFolderField(p, 'd1'); assert.equal(p.folder, 'd1'); c.setFolderField(p, ''); assert.equal('folder' in p, false); c.setFolder(p, 'd2'); assert.equal(p.folder, 'd2'); c.setPhotoKind(p, '0', 'fini'); assert.equal(p.photos[0].kind, 'fini'); c.addPhoto(p, 'b', 'detail'); assert.deepEqual(p.photos[1], { id: 'b', kind: 'detail' }); const q = {}; c.addPhoto(q, 'z', 'k'); assert.deepEqual(q.photos, [{ id: 'z', kind: 'k' }]);
  t = 5000; c.setStage(p, 'attente', 'wip'); assert.deepEqual([p.stage, p.stagePrev, p.stageAt], ['wip', 'attente', { wip: 5000 }]);
  const r = {}; c.rename(r, 'Nom'); assert.deepEqual(r, { title: 'Nom', source: { file: 'Nom.pdf' } }); const s = {}; c.ensureSource(s); c.setSourcePdf(s, 'pdf_1'); c.setSourceFileDefault(s, 'a.pdf'); c.setSourceFileDefault(s, 'b.pdf'); c.setSourcePages(s, 9); assert.deepEqual(s, { source: { pdf: 'pdf_1', file: 'a.pdf', pages: 9 } }); s.thumb = 'th'; c.clearThumb(s); assert.equal('thumb' in s, false); c.setThumb(s, 'th_2'); assert.equal(s.thumb, 'th_2');
  c.setFact(p, 'designer', ''); assert.deepEqual([p.f, p.ai], [{}, { garment: 1 }]); c.setFact(p, 'garment', 'Pull'); assert.deepEqual([p.f, p.ai], [{ garment: 'Pull' }, {}]); c.setFact(p, 'x', undefined); assert.deepEqual(p.f, { garment: 'Pull' }); c.setChipFact(p, 'sizes', ['S', 'M']); assert.deepEqual(p.f.sizes, ['S', 'M']); c.setChipFact(p, 'sizes', []); assert.equal('sizes' in p.f, false);
  c.addOption(p); assert.deepEqual(p.opts, [{ id: 'u1', group: 'Manches', name: '', desc: '', f: {}, measures: {}, counts: {}, ai: 0 }]); c.addOption(p); c.removeOption(p, '0'); assert.deepEqual(p.opts.map((o) => o.id), ['u2']);
  const o = { f: { a: 1 }, ai: 1 }; c.setOptionGrid(o, 'measures', 'r1', 'S', '12.5'); c.setOptionGrid(o, 'measures', 'r1', 'M', 'abc'); assert.deepEqual(o.measures, { r1: { S: 12.5, M: NaN } }); c.setOptionGrid(o, 'measures', 'r1', 'S', ''); assert.equal('S' in o.measures.r1, false); assert.equal(o.ai, 1);
  c.setOptionFact(o, 'a', ''); assert.deepEqual([o.f, o.ai], [{}, 0]); o.ai = 1; c.setOptionFact(o, 'b', 3); assert.deepEqual([o.f, o.ai], [{ b: 3 }, 0]); o.ai = 1; c.setOptionProp(o, 'name', 'N'); assert.deepEqual([o.name, o.ai], ['N', 0]); assert.ok(Object.isFrozen(c)); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'document', 'S', 'uid', 'keep', 'IDB', 'toast', 'toastAct', 'render', 'persist', 'saveSoon', 'refreshMeta', 'ALLF', 'SIZES', 'a', 'b', 't', 'p', 'sc', 'shrink', 'saveBlob', 'Date', 'pdf', 'nameTaken', 'gkey'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const jn = (v) => JSON.parse(JSON.stringify(v === undefined ? null : v)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const patterns = Array.from({ length: 2 }, (_, i) => ({ id: 'p' + i, title: 'T' + i, raw: 'abc', _v: pick(r, [undefined, 3]), status: 'a', stage: pick(r, [undefined, 'attente', 'wip', 'termine']), stageAt: pick(r, [undefined, { attente: 1 }]), folder: pick(r, [undefined, 'd0']), source: pick(r, [{}, { pdf: 'pdf_p' + i, file: 'F.pdf' }]), thumb: pick(r, ['', 'th_p' + i]),
    photos: [{ id: 'img_a', kind: 'modele' }, { id: 'img_b', kind: 'fini' }], f: { designer: 'Anna Dupont', garment: 'Pull', sizes: ['S', 'M'], ease_cm: 4 }, ai: { designer: 1, garment: 1, sizes: 1 }, ev: {},
    opts: [{ id: 'o1', group: 'Manches', name: 'Longues', f: { sleeves: 'longues', ease_cm: 3 }, measures: { r1: { S: 10 } }, counts: {}, ai: 1 }, { id: 'o2', group: 'Col', name: '', f: {}, measures: {}, counts: {}, ai: 1 }] }));
  return { patterns, folders: [{ id: 'd0', name: 'Dossier0', created: 1 }], open: {}, tab: pick(r, ['lib', 'pat']), busy: '', ui: {} };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const fakeCanvas = { width: 0, height: 0, getContext: () => ({ fillRect() {} }), toBlob: (cb) => cb('thumb') }; const document = { createElement: () => fakeCanvas };
  const pdf = { getPage: async () => ({ getViewport: ({ scale }) => ({ width: 100 * scale, height: 140 * scale }), render: () => ({ promise: Promise.resolve() }) }) };
  const ALLF = [{ k: 'designer', t: 'text' }, { k: 'ease_cm', t: 'number' }, { k: 'sizes', t: 'multi' }, { k: 'garment', t: 'select' }, { k: 'tags', t: 'multi' }];
  const classes = []; const b = { dataset: sc.bd || {}, classList: { toggle: (c) => log.push(['toggle', c]) } };
  const ctx = { window: win, document, S, uid, keep: () => {}, IDB: { put: () => Promise.resolve(), del: () => {} }, toast: (m) => log.push(['toast', m]), toastAct: (m) => log.push(['toastAct', m]), render: () => log.push(['render']), persist: () => log.push(['persist']), saveSoon: () => log.push(['soon']), refreshMeta: () => log.push(['meta']),
    ALLF, SIZES: ['XS', 'S', 'M', 'L'], a: sc.a, b, t: sc.t || {}, p: S.patterns[0], sc, shrink: async (f) => 'shrunk:' + f, saveBlob: async (id) => { log.push(['blob', id]); }, Date: FakeDate, pdf, nameTaken: () => false, gkey: (x) => String(x).toLowerCase() };
  const body = `${doorsSrc}${SRC}\nfunction saveFolders() { log.push(['foldersave']); }\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function('log', ...ARGS, body)(log, ...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { patterns: S.patterns, folders: S.folders, open: S.open, ret: S.ret }, log, n });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(seed), st = state(r), p0 = st.patterns[0], val = pick(r, ['', '12', 'abc', 'Nouveau', ' x ']);
  const scs = [
    { kind: 'title', code: BR.title, t: { id: 'title', value: val } }, { kind: 'raw', code: BR.raw, t: { id: 'rawText', value: pick(r, ['', 'y'.repeat(90010)]) } }, { kind: 'status', code: BR.status, t: { dataset: { status: '1' }, value: val } }, { kind: 'folder', code: BR.folder, t: { dataset: { folder: '1' }, value: pick(r, ['', 'd0', 'd9']) } }, { kind: 'pk', code: BR.pk, t: { dataset: { pk: String(Math.floor(r() * 2)) }, value: pick(r, ['fini', 'detail']) } },
    { kind: 'fact', code: BR.fact, t: { dataset: { k: pick(r, ['designer', 'ease_cm', 'garment', 'zz']) }, value: val } },
    { kind: 'optGrid', code: BR.opt, t: { dataset: { oi: pick(r, ['0', '1', '5']), og: pick(r, ['measures', 'counts']), r: 'r1', s: pick(r, ['S', 'M']) }, value: pick(r, ['', '10', '7.5']) } },
    { kind: 'optFact', code: BR.opt, t: { dataset: { oi: pick(r, ['0', '1']), of: pick(r, ['f:ease_cm', 'f:sleeves', 'f:zz']) }, value: val } }, { kind: 'optProp', code: BR.opt, t: { dataset: { oi: pick(r, ['0', '1']), of: pick(r, ['name', 'group', 'desc']) }, value: val } },
    { kind: 'chip', code: BR.chip, a: 'chip', bd: { k: pick(r, ['sizes', 'tags']), v: 'L' }, v: 'L' }, { kind: 'addOpt', code: BR.addOpt, a: 'addOpt' }, { kind: 'delOpt', code: BR.delOpt, a: 'delOpt', bd: { i: pick(r, ['0', '1']) } },
    { kind: 'stage', code: 'setStage(S.patterns[0], sc.to, sc.quiet);', to: pick(r, ['attente', 'wip', 'termine']), quiet: r() < .5 }, { kind: 'rename', code: 'renameP(S.patterns[0], sc.nm);', nm: val }, { kind: 'autoFile', code: 'S.ret = autoFile(S.patterns[0], sc.mode);', mode: pick(r, ['author', 'garment']) },
    { kind: 'thumb', code: 'await storeThumb(S.patterns[0], pdf);' }, { kind: 'photos', code: 'await addPhotos(S.patterns[0], [\'f0\', \'f1\'], sc.k);', k: pick(r, ['modele', 'fini']) }
  ];
  for (const sc of scs) {
    if (sc.kind === 'chip') { sc.code = BR.chip.replace(/\bv\b(?!\w)/g, 'v'); }
    const code = sc.code; sc.code = (sc.kind === 'chip' ? 'var v = sc.v; ' : '') + code;
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), P = out.S.patterns[0], L = out.log.map((l) => l[0]);
    if (sc.kind === 'title') { assert.equal(P.title, sc.t.value); assert.deepEqual(L, ['soon']); }
    if (sc.kind === 'raw') { assert.equal(P.raw, sc.t.value.slice(0, 90000)); assert.equal(P._v, (p0._v || 0) + 1); assert.deepEqual(L, ['soon']); }
    if (sc.kind === 'status') { assert.equal(P.status, sc.t.value); assert.deepEqual(L, ['persist', 'render']); }
    if (sc.kind === 'folder') { if (sc.t.value) assert.equal(P.folder, sc.t.value); else assert.equal('folder' in P, false); assert.deepEqual(L, ['persist']); }
    if (sc.kind === 'pk') { assert.equal(P.photos[+sc.t.dataset.pk].kind, sc.t.value); assert.deepEqual(L, ['persist']); }
    if (sc.kind === 'fact') { const k = sc.t.dataset.k, num = k === 'ease_cm'; if (val === '') assert.equal(k in P.f, false); else assert.equal(P.f[k], num ? jn(parseFloat(val)) : val); assert.equal(k in P.ai, false); assert.deepEqual(L, ['soon', 'meta']); }
    if (sc.kind === 'optGrid') { const i = +sc.t.dataset.oi, d = sc.t.dataset; if (!p0.opts[i]) { assert.deepEqual(P.opts, p0.opts.map((o) => clone(o))); assert.deepEqual(L, []); } else { const g = P.opts[i][d.og][d.r]; if (sc.t.value === '') assert.equal(d.s in g, false); else assert.equal(g[d.s], jn(parseFloat(sc.t.value))); assert.equal(P.opts[i].ai, p0.opts[i].ai); assert.deepEqual(L, ['soon']); } }
    if (sc.kind === 'optFact') { const i = +sc.t.dataset.oi, k = sc.t.dataset.of.slice(2); const num = k === 'ease_cm'; if (val === '') assert.equal(k in P.opts[i].f, false); else assert.equal(P.opts[i].f[k], num ? jn(parseFloat(val)) : val); assert.equal(P.opts[i].ai, 0); assert.deepEqual(L, ['soon']); }
    if (sc.kind === 'optProp') { const i = +sc.t.dataset.oi, k = sc.t.dataset.of; assert.equal(P.opts[i][k], val); assert.equal(P.opts[i].ai, 0); assert.deepEqual(L, k === 'group' ? ['persist', 'render'] : ['soon']); }
    if (sc.kind === 'chip') { const k = sc.bd.k; if (k === 'sizes') { const base = p0.f.sizes.slice(), arr = base.includes('L') ? base.filter((x) => x !== 'L') : [...base, 'L']; arr.sort((x, y) => ['XS', 'S', 'M', 'L'].indexOf(x) - ['XS', 'S', 'M', 'L'].indexOf(y)); assert.deepEqual(P.f.sizes, arr); assert.deepEqual(L, ['persist', 'render']); } else { assert.deepEqual(P.f.tags, ['L']); assert.deepEqual(L, ['persist', 'toggle', 'meta']); } }
    if (sc.kind === 'addOpt') { assert.equal(P.opts.length, 3); assert.deepEqual(P.opts[2], { id: 'u1', group: 'Manches', name: '', desc: '', f: {}, measures: {}, counts: {}, ai: 0 }); assert.equal(out.S.open.opts, 1); assert.deepEqual(L, ['persist', 'render']); }
    if (sc.kind === 'delOpt') { assert.deepEqual(P.opts.map((o) => o.id), p0.opts.map((o) => o.id).filter((_, i) => i !== +sc.bd.i)); assert.deepEqual(L, ['persist', 'render']); }
    if (sc.kind === 'stage') { const from = ['wip', 'termine'].includes(p0.stage) ? p0.stage : 'attente'; if (from === sc.to) { assert.deepEqual(P, clone(p0)); assert.deepEqual(L, []); } else { assert.deepEqual([P.stage, P.stagePrev, P.stageAt[sc.to]], [sc.to, from, NOW]); assert.equal(L[0], 'persist'); assert.equal(L.includes('toastAct'), !sc.quiet); assert.equal(out.S.open.result, sc.to === 'termine' ? 1 : undefined); } }
    if (sc.kind === 'rename') { assert.equal(P.title, val); assert.equal(P.source.file, val + '.pdf'); assert.equal(P.source.pdf, p0.source.pdf); assert.deepEqual(L, ['persist']); }
    if (sc.kind === 'autoFile') { assert.deepEqual(L.filter((x) => x === 'persist').length, p0.folder ? 0 : 1); if (p0.folder) { assert.equal(P.folder, p0.folder); assert.equal(out.S.folders.length, 1); } else { assert.match(P.folder, /^du\d+$/); assert.equal(out.S.folders.length, 2); assert.equal(out.S.folders[1].id, P.folder); assert.equal(out.S.folders[1].name, sc.mode === 'garment' ? 'Pull' : 'Anna Dupont'); assert.equal(out.S.ret, true); } }
    if (sc.kind === 'thumb') { assert.equal(P.thumb, 'th_p0'); assert.ok(out.log.some((l) => l[0] === 'blob' && l[1] === 'th_p0')); }
    if (sc.kind === 'photos') { assert.deepEqual(P.photos.slice(2).map((x) => x.kind), [sc.k, sc.k]); assert.deepEqual(P.photos.slice(2).map((x) => x.id), ['img_u1', 'img_u2']); }
    checks++;
  }
}
console.log('jalon4_7c OK —', checks, 'comparaisons');
