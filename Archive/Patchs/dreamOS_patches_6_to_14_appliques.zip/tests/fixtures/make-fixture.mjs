// Génère tests/fixtures/carnet-test-fictif.zip : sauvegarde « v1 » 100 % fictive (aucune donnée réelle).
// Même format que fullBackup() : data.json + blobs/ + types.json, écrit avec le vrai buildStoredZip de app.js.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const app = fs.readFileSync(path.join(here, '../../app.js'), 'utf8');
const { buildStoredZip } = new Function(app.slice(app.indexOf('var ZIP_CRC_TABLE'), app.indexOf('var BACKUP_PART_BYTES')) + '; return { buildStoredZip };')();

const T0 = Date.UTC(2026, 9, 1, 9, 0, 0), DAY = 86400000;
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==', 'base64');
const pdf = (t) => Buffer.from(`%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\n% ${t}\ntrailer<</Root 1 0 R>>\n%%EOF`);
export const BLOBS = {
  pdf_lune: [pdf('Patron fictif Lune'), 'application/pdf'], pdf_brume: [pdf('Patron fictif Brume'), 'application/pdf'],
  pdf_ete: [pdf('Patron fictif Top Été'), 'application/pdf'], pdf_pieds: [pdf('Patron fictif Chaussettes'), 'application/pdf'],
  img_lune: [png, 'image/png'], th_lune: [png, 'image/png'], pjp_lune1: [png, 'image/png'], pjp_lune2: [png, 'image/png'],
  pjc_top1: [png, 'image/png'], docm_1: [png, 'image/png'], idea_1: [png, 'image/png'],
};
const pat = (id, title, folder, pdfKey, f, extra = {}) => ({ id, title, created: T0 + Object.keys(BLOBS).length, status: 'validé', folder, source: { pdf: pdfKey, name: title + '.pdf' },
  raw: `Patron fictif « ${title} ». Monter 120 mailles. Tricoter 10 cm en côtes 2/2.`, f, g: { measures: { bust: 96 }, counts: { caston: 120 } }, photos: [], ai: {}, ev: {}, gai: {}, opts: [], ...extra });
const data = {
  v: 1, at: T0 + 20 * DAY,
  folders: [{ id: 'd_classiques', name: 'Classiques', created: T0 }, { id: 'd_ete', name: 'Été', created: T0 }],
  patterns: [
    pat('p_lune', 'Cardigan Lune', 'd_classiques', 'pdf_lune', { garment: 'Cardigan', designer: 'Studio Fictif', gauge_sts: 22, gauge_rows: 30, sizes: ['S', 'M', 'L'] }, { photos: [{ id: 'img_lune', kind: 'modele' }] }),
    pat('p_brume', 'Bonnet Brume', 'd_classiques', 'pdf_brume', { garment: 'Bonnet', designer: 'Studio Fictif' }),
    pat('p_ete', 'Top Été', 'd_ete', 'pdf_ete', { garment: 'Top', designer: 'Atelier Imaginaire' }),
    pat('p_pieds', 'Chaussettes Pieds-Nus', '', 'pdf_pieds', { garment: 'Chaussettes', designer: 'Atelier Imaginaire' }, { status: 'brouillon' }),
  ],
  projects: [
    { id: 'j_lune', seq: 1, name: 'Cardigan Lune (laine fictive)', stage: 'wip', patternId: 'p_lune', cover: 'pjp_lune1', size: 'M', yarns: [{ id: 'y1', name: 'Laine fictive grise', used: 3 }], needles: '4 mm', rows: 128,
      photos: ['pjp_lune1', 'pjp_lune2'], timer: { acc: 5400000, start: 0 }, created: T0 + DAY, stageAt: { wip: T0 + 2 * DAY }, workAt: T0 + 2 * DAY,
      log: [{ id: 'e2', ts: T0 + 9 * DAY, text: 'Devant droit terminé.', photos: ['pjp_lune2'] }, { id: 'e1', ts: T0 + 3 * DAY, text: 'Montage et côtes.', photos: [] }] },
    { id: 'j_brume', seq: 2, name: 'Bonnet Brume', stage: 'attente', patternId: 'p_brume', cover: '', size: '', yarns: [], needles: '', rows: 0, log: [], timer: { acc: 0, start: 0 }, created: T0 + 4 * DAY, stageAt: { attente: T0 + 4 * DAY } },
    { id: 'j_top', seq: 3, name: 'Top Été fini', stage: 'termine', patternId: 'p_ete', cover: 'pjc_top1', photos: ['pjc_top1'], size: 'S', yarns: [{ id: 'y2', name: 'Coton imaginaire', used: 5 }], needles: '3,5 mm', rows: 240,
      rating: { result: 5, fit: 4 }, timer: { acc: 36000000, start: 0 }, created: T0, stageAt: { termine: T0 + 15 * DAY }, log: [{ id: 'e3', ts: T0 + 15 * DAY, text: 'Terminé !', photos: [] }] },
  ],
  grids: [{ id: 'g_test', name: 'Grille test', mode: 'stitch', w: 3, h: 3, cells: [[0, 1, 0], [1, 0, 1], [0, 1, 0]], ts: T0 }],
  docs: [{ id: 'doc_1', title: 'Article fictif : monter les mailles', category: 'Tutoriel', content: 'Contenu de test.', media: [{ id: 'docm_1', type: 'image' }], created: T0 }],
  ideas: [{ id: 'i_1', title: 'Idée de test', tag: 'été', note: '', mediaId: 'idea_1', mediaType: 'image', boards: ['b_1'], created: T0 }],
  boards: [{ id: 'b_1', name: 'Inspirations été' }],
  scratchpad: 'Note rapide fictive',
  ui: { wallpaperId: '', stats: { totalRows: 368 }, island: null },
  viewer: {
    'carnet.vmark.p_lune': { i: 2, y: 0.4 }, 'carnet.vpos.p_lune': { i: 3, f: 0.25 },
    'carnet.vhl.p_lune': { '1': [{ y: 0.3 }] }, 'carnet.vsm.p_lune': { '2': [{ x: 0.5, y: 0.5 }] },
  },
};
const J = (o) => new Blob([JSON.stringify(o)], { type: 'application/json' });
const entries = [{ name: 'data.json', blob: J(data) }, ...Object.entries(BLOBS).map(([k, [b, t]]) => ({ name: 'blobs/' + k, blob: new Blob([b], { type: t }) })),
  { name: 'types.json', blob: J(Object.fromEntries(Object.entries(BLOBS).map(([k, [, t]]) => [k, t]))) }];
const zip = await buildStoredZip(entries);
fs.writeFileSync(path.join(here, 'carnet-test-fictif.zip'), Buffer.from(await zip.arrayBuffer()));
fs.writeFileSync(path.join(here, 'carnet-test-fictif.expected.json'), JSON.stringify({ data, blobs: Object.fromEntries(Object.entries(BLOBS).map(([k, [b, t]]) => [k, { size: b.length, type: t }])) }, null, 1));
console.log('Jeu fictif :', data.patterns.length, 'patrons,', data.projects.length, 'projets,', Object.keys(BLOBS).length, 'fichiers.');
