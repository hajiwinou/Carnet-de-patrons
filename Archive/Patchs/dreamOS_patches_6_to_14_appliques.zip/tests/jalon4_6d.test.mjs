// Jalon 4.6d — Projects modifie lui-même champs, fils, plan de couleurs, raisons de l'île, objectif, rangs et simulation (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsCommands } from '../dreamOS/projects/projects-commands.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const helperSrc = grab(/  function projStore\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'projStore..pjRelinkPattern'), projHostSrc = one('projHost'), curSrc = one('curPj');
const door = grab(/  function pjCmd\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'portes');
const yarnsSrc = grab(/  function pjYarns\(pr\) \{[\s\S]*?\n  \}\n/, 'pjYarns');
const blk = (cond) => grab(new RegExp('    if \\(' + cond + '\\) \\{[\\s\\S]*?\\n    \\}\\n'), cond);
const lineIf = (cond) => grab(new RegExp('    if \\(' + cond + '[^\\n]*\\n'), cond);
const act = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), n);
const actLine = (n) => grab(new RegExp("    else if \\(a === '" + n + "'\\) \\{[^\\n]*\\n"), n);
const BR = {
  pcplan: blk('t\\.dataset\\.pcplan'), pjplan: lineIf('t\\.dataset\\.pjplan'), yf: blk('t\\.dataset\\.yf'), yn: blk('t\\.dataset\\.yn'), again: lineIf('t\\.dataset\\.again'), reason: blk('t\\.dataset\\.islandReason'),
  field: lineIf("t\\.dataset\\.pj && t\\.tagName !== 'SELECT'"), select: blk("t\\.dataset\\.pj && t\\.tagName === 'SELECT'"),
  yarnAdd: 'if (false) {}\n' + act('yarnAdd'), yarnDel: 'if (false) {}\n' + act('yarnDel'), pcAdd: 'if (false) {}\n' + act('plannedColorAdd'), pcDel: 'if (false) {}\n' + act('plannedColorDel'), dev: 'if (false) {}\n' + grab(/    else if \(a === 'devAge' \|\| a === 'devReset'\) \{[\s\S]*?\n    \}\n/, 'dev'), goalDrop: 'if (false) {}\n' + actLine('pjGoalDrop')
};

// 1. garde-fous statiques
const outside = app.replace(door, '');
const forbid = [[/\.plannedSkeins\s*=[^=]/g, 'pelotes prévues'], [/\.plannedColors\s*=\s*\(/g, 'couleurs prévues'], [/\.plannedColors\.push\(/g, 'couleurs prévues'], [/(?<!y)\.planned\s*=[^=]/g, 'compteur prévu'], [/(?<!V)\.again\s*=[^=]/g, 'again'], [/\.rowsTotal\s*=[^=]/g, 'rangs au total'],
  [/\.islandReasons\.push\(/g, 'raisons île'], [/\.islandReasons\s*=\s*\w+\.islandReasons\.filter/g, 'raisons île'], [/\.devAge\s*=[^=]/g, 'simulation'], [/delete \w+\.devAge/g, 'simulation'], [/\.yarns\s*=\s*pjYarns/g, 'fils'], [/pjYarns\(\w+\)\.push\(/g, 'fils'], [/VRC\.pr\.sub\s*=/g, 'objectif'], [/\bpg3\.sub\s*=/g, 'objectif'], [/\[t\.dataset\.pj\]\s*=/g, 'champ'], [/\[t\.dataset\.yf\]\s*=/g, 'champ fil']];
for (const [re, what] of forbid) assert.deepEqual(outside.match(re) || [], [], 'écriture directe hors portes : ' + what);
for (const n of ['pjSetField', 'pjSetAgain', 'pjSetRowsTotal', 'pjDropGoal', 'pjSetPlannedSkeins', 'pjSetPlannedCount', 'pjSetYarnField', 'pjSetYarnName', 'pjAddYarn', 'pjRemoveYarn', 'pjAddPlannedColor', 'pjRemovePlannedColor', 'pjToggleIslandReason', 'pjDevReset', 'pjDevPause']) assert.ok(new RegExp('function ' + n + '\\(').test(door), n);

// 2. commandes seules
{ let n = 0, t = 5_000_000_000; const c = createProjectsCommands({ uid: () => 'u' + (++n), now: () => t });
  const p = { name: 'a', plannedSkeins: 3 }; c.setField(p, 'needles', '4 mm'); c.setField(p, 'name', 'b'); assert.deepEqual([p.needles, p.name], ['4 mm', 'b']);
  c.setAgain(p, true); assert.equal(p.again, true); c.setRowsTotal(p, '180'); assert.equal(p.rowsTotal, 180); c.setRowsTotal(p, 'x'); assert.equal(p.rowsTotal, 0); p.sub = { target: 1 }; c.dropGoal(p); assert.equal(p.sub, null);
  c.setPlannedSkeins(p, '-4'); assert.equal(p.plannedSkeins, 0); c.setPlannedSkeins(p, '7'); assert.equal(p.plannedSkeins, 7);
  const col = {}; c.setPlannedCount(col, '5x'); assert.equal(col.planned, 5); c.setPlannedCount(col, ''); assert.equal(col.planned, 0);
  const y = {}; c.setYarnField(y, 'planned', '-2'); assert.equal(y.planned, 0); c.setYarnField(y, 'planned', '3'); assert.equal(y.planned, 3); c.setYarnField(y, 'brand', '12'); assert.equal(y.brand, '12'); c.setYarnName(y, 'N'); assert.equal(y.name, 'N');
  const ys = []; assert.deepEqual(c.addYarn(ys), { id: 'yu1', name: '', used: 0 }); assert.equal(ys.length, 1); const pr = { yarns: ys }; c.removeYarn(pr, ys, 'yu1'); assert.deepEqual(pr.yarns, []); c.removeYarn(pr, [{ id: 'k' }], 'zz'); assert.deepEqual(pr.yarns, [{ id: 'k' }]);
  const q = { plannedSkeins: 4 }; const c1 = c.addPlannedColor(q); assert.deepEqual(c1, { id: 'pcu2', hex: '', name: '', yarn: 'À définir', planned: 4 }); assert.equal(q.plannedSkeins, 0); const c2 = c.addPlannedColor(q); assert.equal('planned' in c2, false);
  c1.planned = 9; c.removePlannedColor(q, c2.id); assert.equal(q.plannedColors.length, 1); assert.equal(q.plannedSkeins, 0); c.removePlannedColor(q, c1.id); assert.equal(q.plannedSkeins, 9); c.removePlannedColor(q, 'zz'); assert.equal(q.plannedSkeins, 9);
  const r = {}; c.toggleIslandReason(r, 'a', true); c.toggleIslandReason(r, 'a', true); c.toggleIslandReason(r, 'b', true); assert.deepEqual(r.islandReasons, ['a', 'b']); c.toggleIslandReason(r, 'a', false); assert.deepEqual(r.islandReasons, ['b']); c.toggleIslandReason(r, 'zz', false); assert.deepEqual(r.islandReasons, ['b']);
  const d = { devAge: 1, islandSince: 2, islandSeen: true }; c.devReset(d); assert.deepEqual(d, { islandSeen: true }); c.devPause(d, 2); assert.equal(d.devAge, t - 2 * 30.44 * 86400000 - 86400000); assert.equal('islandSeen' in d, false); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'document', 'S', 'uid', 'keep', 'IDB', 'toast', 'render', 'askConfirm', 'Date', 'a', 'b', 't', 'islandCfg', 'yarnRowHtml', 'pjPlannedTotal', 'yarnCountTxt', 'pjSkeinsTxt', 'islandChosenHtml', 'isAutoPjName', 'VRC', 'pjSubRefresh', 'saveSoonPj', 'saveProjectsQuiet', 'saveBlob'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const projects = Array.from({ length: Math.floor(r() * 2) + 1 }, (_, i) => ({ id: 'j' + i, name: pick(r, ['Nouveau projet', 'Mon pull', 'Projet 3']), stage: 'wip', patternId: '', needles: '', plannedSkeins: pick(r, [0, 3]), plannedColors: pick(r, [[], [{ id: 'pc1', planned: 4, hex: '#fff' }], [{ id: 'pc1', planned: 0 }, { id: 'pc2', planned: 2 }]]),
    yarns: [{ id: 'y1', name: 'L', used: 1, planned: 2, brand: 'B' }, { id: 'y2', name: '', used: 0 }], islandReasons: pick(r, [undefined, [], ['a'], ['a', 'b']]), again: false, rowsTotal: 10, sub: pick(r, [null, { target: 5, n: 1, at: 1 }]), devAge: pick(r, [undefined, 5]), islandSince: pick(r, [undefined, 7]), islandSeen: pick(r, [undefined, true]), created: i }));
  return { projects, curProj: projects[0].id, colorOpen: '', ui: {}, patterns: [{ id: 'p1', title: 'Titre' }] };
}
async function run(mode, st, sc) {
  const win = { scrollTo() {} }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const el = (o) => ({ ...o, closest: () => null, classList: { toggle() {} }, remove() {} });
  const document = { querySelector: (s) => (s === '[data-dev="pj"]' ? { value: sc.devPj } : s === '[data-dev="months"]' ? { value: sc.months } : null), querySelectorAll: () => [], getElementById: () => null };
  const ctx = { window: win, document, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), IDB: { put: () => Promise.resolve(), del: () => {} }, toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), askConfirm: async () => sc.confirm, Date: FakeDate, a: sc.a, b: { dataset: { id: sc.id } },
    t: sc.t ? el({ tagName: 'INPUT', ...sc.t }) : {}, islandCfg: () => ({ on: true }), yarnRowHtml: () => '', pjPlannedTotal: () => 0, yarnCountTxt: () => '', pjSkeinsTxt: () => '', islandChosenHtml: () => '', isAutoPjName: (x) => !x || x === 'Nouveau projet' || /^Projet \d+$/.test(x),
    VRC: { pr: S.projects[0] }, pjSubRefresh: () => {}, saveSoonPj: () => log.push(['soon']), saveProjectsQuiet: () => log.push(['quiet']), saveBlob: async () => {} };
  const body = `${projHostSrc}${curSrc}${helperSrc}${yarnsSrc}\nreturn (async function(){ ${sc.code} }).call(this);`;
  await new Function('log', ...ARGS, body)(log, ...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { projects: S.projects, colorOpen: S.colorOpen }, log: log.filter((l) => l[0] !== 'idbput').map((l) => (l[0] === 'keep' ? ['save', l[1]] : l)), n });
}
let checks = 0;
for (let seed = 1; seed <= 300; seed++) {
  const r = rng(seed), st = state(r), pj = st.projects[0], rawNum = pick(r, ['3', '-2', 'x', '', '12abc', '0']);
  const scs = [
    { kind: 'pcplan', t: { dataset: { pcplan: pick(r, ['pc1', 'pc2', 'zz']) }, value: rawNum } }, { kind: 'pjplan', t: { dataset: { pjplan: '1' }, value: rawNum } }, { kind: 'yf', t: { dataset: { yf: pick(r, ['planned', 'brand', 'color']), id: pick(r, ['y1', 'y2', 'zz']) }, value: rawNum } },
    { kind: 'yn', t: { dataset: { yn: pick(r, ['y1', 'y2', 'zz']) }, value: ' Nom ' } }, { kind: 'again', t: { dataset: { again: '1' }, checked: r() < .5 } }, { kind: 'reason', t: { dataset: { islandReason: pick(r, ['a', 'c']) }, checked: r() < .5 } },
    { kind: 'field', t: { dataset: { pj: pick(r, ['name', 'needles', 'size']) }, value: 'val' } }, { kind: 'select', t: { dataset: { pj: pick(r, ['patternId', 'needles']) }, tagName: 'SELECT', value: pick(r, ['p1', '4 mm']) } },
    { kind: 'yarnAdd' }, { kind: 'yarnDel', id: pick(r, ['y1', 'y2', 'zz']), confirm: r() < .6 }, { kind: 'pcAdd' }, { kind: 'pcDel', id: pick(r, ['pc1', 'pc2', 'zz']) },
    { kind: 'dev', a: pick(r, ['devAge', 'devReset']), devPj: pick(r, ['j0', 'zz']), months: pick(r, ['3', '0', 'x']) }, { kind: 'goalDrop' }
  ];
  for (const sc of scs) {
    sc.code = BR[sc.kind] || BR[{ pcAdd: 'pcAdd' }[sc.kind]]; sc.a = sc.a || ({ yarnAdd: 'yarnAdd', yarnDel: 'yarnDel', pcAdd: 'plannedColorAdd', pcDel: 'plannedColorDel', goalDrop: 'pjGoalDrop' }[sc.kind]);
    if (sc.kind === 'goalDrop') sc.confirm = true;
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), P = out.S.projects[0], saves = out.log.filter((l) => l[0] === 'save' || l[0] === 'soon').length, num = Math.max(0, parseInt(rawNum, 10) || 0);
    if (sc.kind === 'pcplan') { const c0 = pj.plannedColors.find((x) => x.id === sc.t.dataset.pcplan); if (c0) { assert.equal(P.plannedColors.find((x) => x.id === c0.id).planned, num); assert.equal(saves, 1); } else { assert.deepEqual(P.plannedColors, pj.plannedColors); assert.equal(saves, 0); } }
    if (sc.kind === 'pjplan') { assert.equal(P.plannedSkeins, num); assert.equal(saves, 1); }
    if (sc.kind === 'yf') { const y0 = pj.yarns.find((x) => x.id === sc.t.dataset.id), f = sc.t.dataset.yf; if (y0) assert.equal(P.yarns.find((x) => x.id === y0.id)[f], f === 'planned' ? num : rawNum); else assert.deepEqual(P.yarns, pj.yarns); }
    if (sc.kind === 'yn') { const i = pj.yarns.findIndex((x) => x.id === sc.t.dataset.yn); if (i >= 0) assert.equal(P.yarns[i].name, ' Nom '); else assert.deepEqual(P.yarns, pj.yarns); }
    if (sc.kind === 'again') assert.equal(P.again, sc.t.checked);
    if (sc.kind === 'reason') { const base = pj.islandReasons || [], rs = sc.t.dataset.islandReason; const exp = sc.t.checked ? (base.includes(rs) ? base : [...base, rs]) : base.filter((x) => x !== rs); assert.deepEqual(P.islandReasons || [], exp); }
    if (sc.kind === 'field') assert.equal(P[sc.t.dataset.pj], 'val');
    if (sc.kind === 'select') { assert.equal(P[sc.t.dataset.pj], sc.t.value); if (sc.t.dataset.pj === 'patternId' && sc.t.value === 'p1' && ['Nouveau projet', 'Projet 3'].includes(pj.name)) assert.equal(P.name, 'Titre'); else assert.equal(P.name, pj.name); assert.deepEqual(out.log.map((l) => l[0]), ['save', 'render']); }
    if (sc.kind === 'yarnAdd') { assert.equal(P.yarns.length, 3); assert.match(P.yarns[2].id, /^yu\d+$/); assert.deepEqual([P.yarns[2].name, P.yarns[2].used], ['', 0]); assert.equal(saves, 1); }
    if (sc.kind === 'yarnDel') { const has = pj.yarns.some((x) => x.id === sc.id); const gone = has && (sc.id === 'y2' || sc.confirm); assert.equal(P.yarns.some((x) => x.id === sc.id), has && !gone); }
    if (sc.kind === 'pcAdd') { const c = P.plannedColors.at(-1); assert.match(c.id, /^pcu\d+$/); assert.equal(c.yarn, 'À définir'); assert.equal(out.S.colorOpen, 'p:' + c.id); if (!pj.plannedColors.length && pj.plannedSkeins > 0) { assert.equal(c.planned, pj.plannedSkeins); assert.equal(P.plannedSkeins, 0); } else { assert.equal('planned' in c, false); assert.equal(P.plannedSkeins, pj.plannedSkeins); } }
    if (sc.kind === 'pcDel') { assert.equal(saves, 1); const old = pj.plannedColors.find((x) => x.id === sc.id); assert.ok(!P.plannedColors.some((x) => x.id === sc.id)); assert.equal(P.plannedSkeins, !P.plannedColors.length && old && old.planned > 0 ? old.planned : pj.plannedSkeins); }
    if (sc.kind === 'dev') { if (sc.devPj !== 'j0') assert.equal(saves, 0); else if (sc.a === 'devReset') { assert.equal(saves, 1); assert.equal('devAge' in P, false); assert.equal('islandSince' in P, false); assert.equal(P.islandSeen, pj.islandSeen); } else { const m = Math.max(1, parseInt(sc.months, 10) || 1); assert.equal(P.devAge, NOW - m * 30.44 * 86400000 - 86400000); assert.equal('islandSince' in P, false); assert.equal('islandSeen' in P, false); } }
    if (sc.kind === 'goalDrop') { assert.equal(P.sub, null); }
    checks++;
  }
}
console.log('jalon4_6d OK —', checks, 'comparaisons');
