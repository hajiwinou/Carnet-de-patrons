// Jalon 4.7d — Patterns crée patrons / dossiers, enregistre l'analyse par IA et les préférences d'affichage (auteurs favoris, groupes repliés, groupement) (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPatternsHost, PATTERNS_RESOURCES } from '../dreamOS/patterns/patterns-host.js';
import { createPatternsCommands } from '../dreamOS/patterns/patterns-commands.js';
import { PATTERNS_PERSISTED_KEYS } from '../dreamOS/patterns/patterns-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const fn = (n) => grab(new RegExp('  (?:async )?function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const doorBlock = grab(/  function patHost\(\)[\s\S]*?\n  function patSetGroup[^\n]*\n/, 'portes');
const doorsSrc = doorBlock.replace(/\n  function persist\(light\)[^\n]*\n  function persistNow\(\)[^\n]*\n  function saveFolders\(\)[^\n]*\n/, '\n');
assert.ok(doorsSrc.length < doorBlock.length);
const act = (head) => 'if (false) {}\n' + grab(new RegExp("    else if \\(a === '" + head + "'\\) \\{[\\s\\S]*?\\n    \\}\\n"), head);
const BR = { toggle: act('toggleGrp'), collapse: act('collapseAll'), expand: act('expandAll'), fav: act('favAuth'), addF: act('addF'), renSave: act('renSave'), grp: "if (false) {}\n" + grab(/    else if \(a === 'grp'\)[^\n]*\n/, 'grp') };
const SRC = [fn('newPattern'), fn('folderFor')].join('');

// 1. garde-fous statiques
const outside = app.replace(doorBlock, '');
for (const [re, what] of [[/keep\('carnet\.(favAuthors|collapsed|group)'/g, 'stockage des préférences'], [/\bS\.favAuthors\.(push|splice)\(/g, 'auteurs favoris'], [/\bS\.collapsedGroups\[[^\]]+\]\s*=[^=]/g, 'groupes repliés'], [/delete S\.collapsedGroups\[/g, 'groupes repliés'], [/\bS\.group\s*=[^=]/g, 'groupement'], [/\bp\.analysis\s*=[^=]/g, 'analyse'], [/\brf\.name\s*=[^=]/g, 'nom de dossier'], [/saveCollapsed\(/g, 'ancienne fonction'], [/\bid: 'd' \+ uid\(\)/g, 'création de dossier'], [/status: 'brouillon'/g, 'création de patron'], [/\bp\.(f|ai|ev)\.(designer|garment)\s*=[^=]/g, 'devinette']])
  assert.deepEqual(outside.match(re) || [], [], 'hors portes : ' + what);
for (const n of ['patCreate', 'patMarkGuess', 'patRestore', 'patSetAnalysis', 'patNewFolder', 'patRenameFolder', 'patToggleFavAuthor', 'patToggleGroup', 'patCollapseGroups', 'patExpandGroups', 'patSetGroup']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);
for (const [re, c] of [[/patSetAnalysis\(p, n, usedProvider\)/g, 1], [/var pat = patRestore\(rec, photos\);/g, 1], [/patNewFolder\(nm\)/g, 1], [/patRenameFolder\(rf, rn\)/g, 1], [/patToggleFavAuthor\(b\.dataset\.a\)/g, 1], [/patToggleGroup\(gid\)/g, 1], [/(?<!function )patCollapseGroups\(/g, 1], [/(?<!function )patExpandGroups\(/g, 1], [/(?<!function )patSetGroup\(v\)/g, 1]]) assert.equal((app.match(re) || []).length, c, String(re));
assert.deepEqual([...PATTERNS_PERSISTED_KEYS].slice(3), ['carnet.favAuthors', 'carnet.collapsed', 'carnet.group']);
for (const k of ['carnet.favAuthors', 'carnet.collapsed', 'carnet.group']) assert.ok(PATTERNS_RESOURCES.some(([t, n, o]) => t === 'storage' && n === k && o === 'patterns'), k);

// 2. commandes seules
{ let n = 0, t = 1000; const c = createPatternsCommands({ uid: () => 'u' + (++n), now: () => t });
  assert.deepEqual(c.createPattern('', '', null), { id: 'u1', title: 'Patron sans titre', created: 1000, status: 'brouillon', source: {}, raw: '', f: {}, g: { measures: {}, counts: {} }, photos: [], ai: {}, ev: {}, gai: {}, opts: [] });
  const p = c.createPattern('Pull', 'txt', { file: 'a.pdf' }); assert.deepEqual([p.title, p.raw, p.source], ['Pull', 'txt', { file: 'a.pdf' }]); c.markGuess(p, 'designer', 'Anna', 'Repéré'); assert.deepEqual([p.f, p.ai, p.ev], [{ designer: 'Anna' }, { designer: 1 }, { designer: 'Repéré' }]);
  assert.deepEqual(Object.keys(c.restorePattern({ id: 'r' }, [])), ['id', 'title', 'created', 'status', 'stage', 'folder', 'source', 'raw', 'f', 'g', 'photos', 'ai', 'ev', 'gai', 'opts']);
  assert.deepEqual(c.restorePattern({ id: 'r' }, [1]), { id: 'r', title: 'Patron restauré', created: 1000, status: 'brouillon', stage: undefined, folder: undefined, source: {}, raw: '', f: {}, g: { measures: {}, counts: {} }, photos: [1], ai: {}, ev: {}, gai: {}, opts: [] });
  const full = c.restorePattern({ id: 'r', title: 'T', created: 5, status: 's', stage: 'wip', folder: 'd', source: { pdf: 'x' }, text: 'tx', fields: { a: 1 }, measures: { m: 1 }, counts: { k: 2 }, options: [{ id: 'o' }] }, []); assert.deepEqual([full.title, full.created, full.status, full.stage, full.folder, full.raw, full.f, full.g, full.opts], ['T', 5, 's', 'wip', 'd', 'tx', { a: 1 }, { measures: { m: 1 }, counts: { k: 2 } }, [{ id: 'o' }]]);
  assert.equal(c.restorePattern({ id: 'r', raw: 'R', text: 'tx' }, []).raw, 'R');
  const q = { opts: [1, 2] }; t = 7000; c.setAnalysis(q, 4, 'groq'); assert.deepEqual(q.analysis, { at: 7000, n: 4, opts: 2, provider: 'groq' }); const q2 = {}; c.setAnalysis(q2, 0, 'x'); assert.equal(q2.analysis.opts, 0);
  assert.deepEqual(c.createFolder('Pulls'), { id: 'du3', name: 'Pulls', created: 7000 }); const f = { name: 'a' }; c.renameFolder(f, 'b'); assert.equal(f.name, 'b');
  const fav = ['a']; c.toggleFavAuthor(fav, 'b'); c.toggleFavAuthor(fav, 'a'); assert.deepEqual(fav, ['b']);
  const m = {}; c.toggleGroup(m, 'g'); assert.deepEqual(m, { g: 0 }); c.toggleGroup(m, 'g'); assert.deepEqual(m, { g: 1 }); c.toggleGroup(m, 'g'); assert.equal(m.g, 0); c.collapseGroups(m, ['x', 'y']); assert.deepEqual(m, { g: 0, x: 1, y: 1 }); c.expandGroups(m, ['x', 'zz']); assert.deepEqual(m, { g: 0, y: 1 }); assert.ok(Object.isFrozen(c)); }

// 3. équivalence sur le vrai code
const ARGS = ['window', 'S', 'uid', 'keep', 'toast', 'render', 'persist', 'saveSoon', 'a', 'b', '$', 'v', 'sc', 'Date', 'gkey', 'groupsOf', 'filteredPatterns', 'groupCollapseId', 'p'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
async function run(mode, st, sc) {
  const win = {}, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  const ctx = { window: win, S, uid, keep: (k, v) => log.push(['keep', k, JSON.stringify(v)]), toast: (m) => log.push(['toast', m]), render: () => log.push(['render']), persist: () => log.push(['persist']), saveSoon: () => log.push(['soon']), a: sc.a, b: { dataset: sc.bd || {} }, $: (s) => ({ value: s === '#renameIn' ? sc.rn : sc.nm }), v: sc.v, sc, Date: FakeDate, gkey: (x) => String(x).toLowerCase(), groupsOf: () => sc.groups.map((g) => ({ g })), filteredPatterns: () => [], groupCollapseId: (g) => g.g, p: null };
  const body = `${doorsSrc}${SRC}\nfunction saveFolders() { log.push(['foldersave']); }\nfunction guessAuthor(t) { return /par (\\w+)/.test(t || '') ? RegExp.$1 : ''; }\nfunction guessGarment(t) { return /pull/i.test(t || '') ? 'Pull' : ''; }\nfunction normAuthor(s) { return String(s || ''); }\nreturn (async function(){ ${sc.code} }).call(this);`;
  const ret = await new Function('log', ...ARGS, body)(log, ...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { folders: S.folders, fav: S.favAuthors, col: S.collapsedGroups, group: S.group }, log, ret: ret === undefined ? null : ret, n });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(Math.imul(seed, 2654435761) >>> 0);
  const st = { patterns: [], folders: [{ id: 'd0', name: 'Dossier0', created: 1 }], favAuthors: pick(r, [[], ['anna'], ['anna', 'bob']]), collapsedGroups: pick(r, [{}, { g1: 0 }, { g1: 1, g2: 0 }, { g2: 1 }]), group: 'garment', renameId: 'd0' };
  const groups = pick(r, [[], ['g1'], ['g1', 'g2', 'g3']]);
  const fk = pick(r, ['anna', 'carl']), gid = pick(r, ['g1', 'g2', 'g9']), nm = pick(r, ['', 'Pulls', ' x ']), gv = pick(r, ['garment', 'author', 'folder', 'all']);
  const title = pick(r, ['', 'Pull rouge', 'Bonnet']), raw = pick(r, ['', 'modèle par Anna', 'pull']);
  const scs = [
    { kind: 'toggle', code: BR.toggle, a: 'toggleGrp', bd: { gid: pick(r, [gid, '']) }, groups }, { kind: 'collapse', code: BR.collapse, a: 'collapseAll', groups }, { kind: 'expand', code: BR.expand, a: 'expandAll', groups },
    { kind: 'fav', code: BR.fav, a: 'favAuth', bd: { a: 'anna' }, groups, fk: 'anna' }, { kind: 'fav', code: BR.fav, a: 'favAuth', bd: { a: 'carl' }, groups, fk: 'carl' }, { kind: 'grp', code: BR.grp, a: 'grp', v: gv, groups },
    { kind: 'addF', code: BR.addF, a: 'addF', nm: nm === ' x ' ? ' x ' : nm, groups }, { kind: 'renSave', code: BR.renSave, a: 'renSave', bd: { id: pick(r, ['d0', 'zz']) }, rn: nm, groups },
    { kind: 'newPattern', code: 'return newPattern(sc.title, sc.raw, sc.src);', title, raw, src: pick(r, [undefined, { file: 'a.pdf' }]), groups }, { kind: 'folderFor', code: "return folderFor(sc.fname);", fname: pick(r, ['Dossier0', 'dossier0', 'Nouveau']), groups }
  ];
  for (const sc of scs) {
    const A = await run('absent', st, sc), B = await run('engaged', st, sc), C = await run('hot', st, sc); assert.equal(B, A, `${sc.kind} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), L = out.log.map((l) => l[0]), keeps = out.log.filter((l) => l[0] === 'keep');
    if (sc.kind === 'toggle') { const id = sc.bd.gid; const col = clone(st.collapsedGroups); if (id) col[id] = (st.collapsedGroups[id] !== undefined ? !!st.collapsedGroups[id] : true) ? 0 : 1; assert.deepEqual(out.S.col, col); assert.deepEqual(L, id ? ['keep', 'render'] : []); if (id) assert.deepEqual(keeps[0].slice(1), ['carnet.collapsed', JSON.stringify(col)]); }
    if (sc.kind === 'collapse') { const col = clone(st.collapsedGroups); groups.forEach((g) => { col[g] = 1; }); assert.deepEqual(out.S.col, col); assert.deepEqual(L, ['keep', 'render']); assert.equal(keeps[0][1], 'carnet.collapsed'); }
    if (sc.kind === 'expand') { const col = clone(st.collapsedGroups); groups.forEach((g) => { delete col[g]; }); assert.deepEqual(out.S.col, col); assert.deepEqual(L, ['keep', 'render']); assert.equal(keeps[0][1], 'carnet.collapsed'); }
    if (sc.kind === 'fav') { const fk = sc.fk; const fav = st.favAuthors.includes(fk) ? st.favAuthors.filter((x) => x !== fk) : [...st.favAuthors, fk]; assert.deepEqual(out.S.fav, fav); assert.deepEqual(keeps[0].slice(1), ['carnet.favAuthors', JSON.stringify(fav)]); assert.deepEqual(L, ['keep', 'render']); }
    if (sc.kind === 'grp') { assert.equal(out.S.group, gv); assert.deepEqual(keeps[0].slice(1), ['carnet.group', JSON.stringify(gv)]); assert.deepEqual(L, ['keep', 'render']); }
    if (sc.kind === 'addF') { const t = nm.trim(); if (!t) { assert.deepEqual(out.S.folders, st.folders); assert.deepEqual(L, []); } else { assert.deepEqual(out.S.folders[1], { id: 'du1', name: t, created: NOW }); assert.equal(out.S.folders.length, 2); assert.deepEqual(L, ['foldersave', 'render']); } }
    if (sc.kind === 'renSave') { const t = nm.trim(), ok = t && sc.bd.id === 'd0'; assert.equal(out.S.folders[0].name, ok ? t : 'Dossier0'); assert.deepEqual(L, ok ? ['foldersave', 'render'] : ['render']); }
    if (sc.kind === 'newPattern') { const P = out.ret; assert.equal(P.id, 'u1'); assert.equal(P.title, title || 'Patron sans titre'); assert.equal(P.created, NOW); assert.equal(P.status, 'brouillon'); assert.deepEqual(P.source, sc.src || {}); const f = {}, ai = {}, ev = {}; if (/par (\w+)/.test(raw)) { f.designer = /par (\w+)/.exec(raw)[1]; ai.designer = 1; ev.designer = 'Repéré dans le texte'; } if (/pull/i.test(title + ' ' + raw)) { f.garment = 'Pull'; ai.garment = 1; ev.garment = 'Déduit du titre'; } assert.deepEqual([P.f, P.ai, P.ev], [f, ai, ev]); assert.deepEqual([P.photos, P.opts, P.gai, P.g], [[], [], {}, { measures: {}, counts: {} }]); }
    if (sc.kind === 'folderFor') { const R = out.ret; if (sc.fname.toLowerCase() === 'dossier0') { assert.equal(R.id, 'd0'); assert.equal(out.S.folders.length, 1); } else { assert.deepEqual(R, { id: 'du1', name: 'Nouveau', created: NOW }); assert.deepEqual(out.S.folders[1], R); assert.deepEqual(L, ['foldersave']); } }
    checks++;
  }
}
console.log('jalon4_7d OK —', checks, 'comparaisons');
