// Phase 3.9 — module Projects : moteur pur équivalent au code d'app.js (fuzzing) et fidèle à l'extraction
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { collect, generate } from '../tools/gen-projects-engine.mjs';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsEngine } from '../dreamOS/projects/projects-engine.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

// 1. module versionné == extraction d'app.js
if (!process.env.SKIP_EXTRACTION_CHECK) assert.equal(generate(app).out, fs.readFileSync(path.join(root, 'dreamOS/projects/projects-engine.js'), 'utf8'), 'projects-engine.js ne correspond plus à app.js : relancer node tools/gen-projects-engine.mjs');

// 2. code historique (avec ses hooks) exécuté hôte absent / hôte engagé
const { ordered, FUNCS } = collect(app, false);
const hostSrc = app.match(/  function projHost\(\)[^\n]*\n/)[0];
const NAMES = [...FUNCS, 'YARN_COLORS', 'ISLAND_REASON_GROUPS', 'ISLAND_REASONS'];
const build = new Function('uid', 'window', `${hostSrc}\n${ordered.join('\n')}\nreturn { ${NAMES.join(', ')} };`);
const seqUid = () => { let n = 0; return () => 'u' + (++n); };
function world(withHost) {
  const win = {}; const fns = build(seqUid(), win);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: seqUid(), win }); h.engage(); assert.equal(reg.ownerOf('logic', 'projects-engine'), 'projects'); h.release(); assert.equal(reg.ownerOf('logic', 'projects-engine'), 'legacy'); h.engage(); assert.equal(win.DreamOSProjectsHost.enabled, true); }
  return { fns, win };
}
const A = world(false).fns, WB = world(true), B = WB.fns;
assert.equal(WB.win.DreamOSProjectsHost.enabled, true);
const eng = createProjectsEngine({ uid: seqUid() });
for (const k of ['YARN_COLORS', 'ISLAND_REASON_GROUPS', 'ISLAND_REASONS']) assert.deepEqual(eng[k], A[k], k);

const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o));
const norm = (o) => JSON.parse(JSON.stringify(o).replace(/"y?u\d+"/g, '"UID"').replace(/"yu\d+"/g, '"UID"'));
const NOW = 1_800_000_000_000; Date.now = () => NOW;
let checks = 0;
const eq = (a, b, m) => { assert.deepEqual(b, a, m); checks++; };
const hex = (r) => '#' + Math.floor(r() * 0xffffff).toString(16).padStart(6, '0');
const IDS = ['demotivated', 'pattern', 'gauge', 'gift', 'inconnu', 'time', 'sleeve'];
function project(r) {
  const pick = (a) => a[Math.floor(r() * a.length)], maybe = (p, f) => (r() < p ? f() : undefined);
  const pr = { created: NOW - Math.floor(r() * 4e10), stage: pick(['wip', 'termine', 'attente', 'x', undefined]), stageAt: r() < .9 ? { wip: maybe(.6, () => NOW - Math.floor(r() * 3e10)), termine: maybe(.3, () => NOW - 1000) } : {} };
  maybe(.5, () => pr.log = Array.from({ length: Math.floor(r() * 4) }, () => ({ ts: maybe(.8, () => NOW - Math.floor(r() * 1e9)), photos: r() < .5 ? ['pjp_a', 'pjc_z'] : undefined })));
  maybe(.5, () => pr.cover = pick(['pjc_a', 'pjc_z', 'pji_q', '', null]));
  maybe(.5, () => pr.photos = pick([['pjc_a'], [], ['pjp_1', 'pjc_z']]));
  maybe(.4, () => pr.timer = { start: pick([0, NOW - 5, undefined]) });
  maybe(.3, () => pr.devAge = NOW - Math.floor(r() * 9e9));
  maybe(.5, () => pr.workAt = NOW - Math.floor(r() * 9e9));
  maybe(.5, () => pr.rts = Array.from({ length: Math.floor(r() * 4) }, () => NOW - Math.floor(r() * 9e9)));
  maybe(.5, () => pr.rating = { pattern: pick([0, 1, 3, 4, 5, undefined]), yarn: pick([2, 5, 0]), result: pick([4, 4, 5]), fit: pick([3, undefined]), comfort: pick([1, 5, 0]) });
  maybe(.5, () => pr.islandReasons = r() < .9 ? Array.from({ length: Math.floor(r() * 4) }, () => pick(IDS)) : 'nope');
  const k = r();
  if (k < .3) pr.yarn = pick(['  Mérinos ', '', ' ', 'Coton']);
  else if (k < .8) pr.yarns = Array.from({ length: Math.floor(r() * 4) }, (_, i) => ({ id: 'y' + i, name: pick(['A', 'B', '']), brand: pick(['', 'Drops']), color: pick(['', 'rouge']), used: pick([0, 1, 2.5, undefined]), planned: pick([0, 3, undefined, -1]) }));
  maybe(.5, () => pr.plannedColors = Array.from({ length: Math.floor(r() * 4) }, (_, i) => ({ id: 'c' + i, name: pick(['', 'Bleu']), hex: pick(['', hex(r)]), planned: pick([0, 2, 5, -2, undefined]), yarnId: pick([undefined, 'y0', 'y9']) })));
  maybe(.4, () => { pr.plannedSkeins = pick([0, 4, -1, undefined]); pr.plannedYarnId = pick([undefined, 'y0']); });
  return pr;
}
const PURE = ['pjStageOf', 'lastActivity', 'pjLegacyCover', 'pjPlannedTotal', 'pjSkeins', 'pjYarnNames', 'pjSkeinsTxt', 'pjLastTouch', 'pjStartTs', 'ratingAvg', 'islandReasonList'];
for (let seed = 1; seed <= 3000; seed++) {
  const r = rng(seed), pr = project(r);
  const pa = clone(pr), pb = clone(pr), pe = clone(pr);
  for (const f of PURE) {
    let ra, rb, re, ea, eb, ee;
    const run = (fn, p) => { try { return [fn(p), null]; } catch (e) { return [null, e.constructor.name]; } };
    [ra, ea] = run(A[f], pa); [rb, eb] = run(B[f], pb); [re, ee] = run(eng[f], pe);
    eq(norm(ra), norm(rb), f + ' ' + seed); eq(ea, eb, f + ' err ' + seed); eq(norm(ra), norm(re), f + ' eng ' + seed); eq(ea, ee, f + ' eng err ' + seed);
    eq(norm(pa), norm(pb), 'mutation projet ' + f + ' ' + seed); eq(norm(pa), norm(pe), 'mutation projet eng ' + f + ' ' + seed);
  }
  // pjApplyPlan (mutateur) : mêmes ids dans le même ordre
  const qa = clone(pr), qb = clone(pr); if (qa.stageAt) { try { A.pjApplyPlan(qa); } catch (e) { var xa = 1; } try { B.pjApplyPlan(qb); } catch (e) { var xb = 1; } eq(norm(qa), norm(qb), 'pjApplyPlan ' + seed); }
  const ys = A.pjYarns(clone(pr)); for (const y of ys.slice(0, 2)) { eq(A.yarnCountTxt(y), B.yarnCountTxt(y), 'yarnCountTxt'); }
  for (const key of ['y:y0', 'c:c1', 'y:zz', 'c:c0', 'q']) { const a = clone(pr), b = clone(pr); eq(A.colorTarget(a, key), B.colorTarget(b, key), 'colorTarget ' + key); }
  const h = r() < .1 ? 'zz' : hex(r); eq(A.colorNameFromHex(h), B.colorNameFromHex(h), 'colorName'); eq(A.colorNameFromHex(h.slice(1)), B.colorNameFromHex(h.slice(1)), 'colorName2');
  const ts = NOW - Math.floor(r() * 1e11) + (r() < .1 ? 1e11 : 0); eq(A.daysSince(ts), B.daysSince(ts), 'daysSince'); eq(A.fmtEntryDate(ts), B.fmtEntryDate(ts), 'fmtEntryDate');
}
for (const n of ['', null, undefined, 'Nouveau projet', 'Projet 12', 'Projet', 'Projet x', 'Pull']) eq(A.isAutoPjName(n), B.isAutoPjName(n), 'isAutoPjName');
for (const id of ['gift', 'nope', undefined]) eq(A.islandReasonLabel(id), B.islandReasonLabel(id), 'islandReasonLabel');

for (let k = 0; k <= 6; k++) for (const d of [-1, 0, 1]) { const ts = NOW - k * 86400000 + d; eq(A.daysSince(ts), B.daysSince(ts), 'daysSince frontière'); assert.equal(B.daysSince(NOW - k * 86400000), k); }
// 3. cas dirigés : seuils
const e2 = createProjectsEngine({ uid: seqUid() });
assert.equal(e2.pjStageOf({ stage: 'wip' }), 'wip'); assert.equal(e2.pjStageOf({ stage: 'autre' }), 'attente');
assert.equal(e2.isAutoPjName('Projet 3'), true); assert.equal(e2.isAutoPjName('Projet'), false);
assert.equal(e2.ratingAvg({ rating: { pattern: 4, yarn: 5 } }), '4,5'); assert.equal(e2.ratingAvg({}), '');
assert.equal(e2.ratingAvg({ rating: { pattern: 1, yarn: 1, result: 1, fit: 1, comfort: 2 } }), '1,2');
assert.equal(e2.pjSkeinsTxt({ yarns: [{ id: 'a', used: 1, planned: 3 }, { id: 'b', used: 2 }] }), '3 / 3');
assert.equal(e2.yarnCountTxt({ used: 2, planned: 5 }), '2 / 5'); assert.equal(e2.yarnCountTxt({ planned: 0 }), '0');
assert.equal(e2.pjPlannedTotal({ plannedColors: [{ planned: 2 }, { planned: -3 }, { planned: 4 }] }), 6); assert.equal(e2.pjPlannedTotal({ plannedSkeins: 5 }), 5);
assert.equal(e2.colorNameFromHex('#ffffff'), 'Blanc'); assert.equal(e2.colorNameFromHex('#1a1a1a'), 'Noir'); assert.equal(e2.colorNameFromHex('xyz'), '');
assert.equal(e2.daysSince(NOW - 86400000 * 3 - 5), 3); assert.equal(e2.daysSince(NOW + 5e9), 0);
assert.equal(e2.pjLastTouch({ timer: { start: 1 } }), NOW); assert.equal(e2.pjLastTouch({ devAge: 42 }), 42);
assert.equal(e2.pjLegacyCover({ cover: 'pjc_a', photos: ['pjc_a'] }), false); assert.equal(e2.pjLegacyCover({ cover: 'pjc_a' }), true); assert.equal(e2.pjLegacyCover({ cover: 'pji_a' }), false);
const mk = e2.pjYarns({ yarn: ' Laine ' }); assert.equal(mk[0].name, 'Laine'); assert.ok(/^yu\d+$/.test(mk[0].id));

// 4. hôte relâché → code d'origine, même résultat
{ const w = world(true); w.win.DreamOSProjectsHost.release(); assert.equal(w.win.DreamOSProjectsHost.enabled, false); eq(A.ratingAvg({ rating: { pattern: 3, yarn: 4 } }), w.fns.ratingAvg({ rating: { pattern: 3, yarn: 4 } }), 'relâché'); }

// 5. garde-fou : le moteur n'accède ni au stockage, ni au DOM, ni à l'état
const src = fs.readFileSync(path.join(root, 'dreamOS/projects/projects-engine.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, '');
for (const bad of [/localStorage/, /indexedDB/, /\bdocument\./, /\bwindow\./, /(^|[^\w.'])S\.\w/, /\bfetch\(/]) assert.ok(!bad.test(src), 'accès interdit : ' + bad);
console.log('phase3_9 OK —', checks, 'comparaisons');
