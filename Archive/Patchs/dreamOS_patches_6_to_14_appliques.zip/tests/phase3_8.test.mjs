// Phase 3.8 — module Patterns : moteur pur équivalent au code d'app.js (fuzzing) et fidèle à l'extraction
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { collect, generate } from '../tools/gen-patterns-engine.mjs';
import { installPatternsHost } from '../dreamOS/patterns/patterns-host.js';
import { createPatternsEngine } from '../dreamOS/patterns/patterns-engine.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

// 1. le module versionné est exactement l'extraction d'app.js (aucune retouche manuelle, aucune dérive)
if (!process.env.SKIP_EXTRACTION_CHECK) assert.equal(generate(app).out, fs.readFileSync(path.join(root, 'dreamOS/patterns/patterns-engine.js'), 'utf8'), 'patterns-engine.js ne correspond plus à app.js : relancer node tools/gen-patterns-engine.mjs');

// 2. code historique d'app.js (avec ses points de délégation) exécuté hôte absent / hôte engagé
const { ordered, FUNCS } = collect(app, false);
const patHostSrc = app.match(/  function patHost\(\)[^\n]*\n/)[0];
const NAMES = [...FUNCS, 'SIZES', 'MEASURES', 'COUNTS', 'CORE_ROWS', 'GROUPDEF', 'GROUP_NAMES', 'SCHEMA', 'ALLF', 'ABBR', 'HEAD', 'GARMENT_RE'];
const build = new Function('uid', 'window', `${patHostSrc}\n${ordered.join('\n')}\nreturn { ${NAMES.join(', ')} };`);
const seqUid = () => { let n = 0; return () => 'u' + (++n); };
function world(withHost) {
  const win = {}; const uid = seqUid(); const fns = build(uid, win);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: seqUid(), win }); h.engage(); assert.equal(reg.ownerOf('logic', 'patterns-engine'), 'patterns'); }
  return fns;
}
const A = world(false), B = world(true);
const engine = createPatternsEngine({ uid: seqUid() });

// catalogues identiques (schéma, abréviations, groupes…)
for (const k of ['SIZES', 'MEASURES', 'COUNTS', 'CORE_ROWS', 'GROUPDEF', 'GROUP_NAMES', 'SCHEMA', 'ALLF', 'ABBR', 'HEAD', 'GARMENT_RE'])
  assert.deepEqual(engine[k], A[k], `catalogue ${k}`);

const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const same = (x, y, msg) => assert.deepEqual(y, x, msg);
const clone = (o) => JSON.parse(JSON.stringify(o));
let checks = 0;

// --- texte : nettoyage, découpage, titres
const LINES = ['Rang 1 : 2 m ens. à l’endroit (k2tog), p2tog, ssk', 'Taille : S M L', 'DOS', 'Devant :', 'Manches', 'page 3 sur 12', '12', 'Tricoter 10,5 cm en jersey, 3 millimètres', 'ﬁnitions ﬂeur “guillemets” – tiret — long…', '• puce ▪ autre ●', 'mot-\ncoupé', 'Rnd 5: k1, p1 ; sl1 ; yo ; k3tog ; psso', 'En-tête du patron', 'Copyright 2024', 'Les mailles sont montées. Ensuite tricoter. Puis continuer : 2 m, 4 m !', 'Row 7 (RS): kfb, m1l, m1r, sl1-k2tog-psso', '', 'Montage', 'Encolure :', 'Tour de poitrine 90 cm / 95 cm / 100 cm', 'une très longue phrase sans ponctuation ' + 'mot '.repeat(70)];
for (let seed = 1; seed <= 200; seed++) {
  const r = rng(seed); const pick = (a) => a[Math.floor(r() * a.length)];
  const raw = Array.from({ length: 1 + Math.floor(r() * 6) }, () => Array.from({ length: 2 + Math.floor(r() * 14) }, () => pick(LINES)).join('\n')).join('\f');
  for (const o of [{ headers: true, expand: true }, { headers: false, expand: false }, { headers: true, expand: false }, { headers: false, expand: true }]) {
    const ca = A.cleanText(raw, o), cb = B.cleanText(raw, o); same(ca, cb, `cleanText ${seed}`);
    for (const c of [{}, { min: 5, max: 8 }, { min: 20, max: 30 }, { min: '12', max: '40' }]) same(A.chunkText(ca, c), B.chunkText(ca, c), `chunkText ${seed}`);
    checks += 2;
  }
  for (const l of raw.split('\n').slice(0, 12)) { assert.equal(B.isHeading(l), A.isHeading(l)); checks++; }
  for (const t of [raw, raw.slice(0, 400), 'Par Marie Dupont\n' + raw, 'Design by Jane Roe', 'Modèle : pull Torsades — création Léa', 'bonnet', 'Écharpe snood chaussettes', '', undefined]) {
    same(A.guessAuthor(t), B.guessAuthor(t), `guessAuthor ${seed}`); same(A.guessGarment(t), B.guessGarment(t), `guessGarment ${seed}`); checks += 2;
  }
}
for (const s of ['  Jane  Roe. ', 'x;;', '', undefined, null, 12]) assert.equal(B.normAuthor(s), A.normAuthor(s));
for (const v of [[], [1], '', 0, null, undefined, 'a', false]) assert.equal(B.filled(v), A.filled(v));

// --- schéma : valeurs aléatoires pour chaque champ
const valueFor = (f, r) => {
  const bad = [undefined, null, '', {}, 'zzz', [], NaN];
  if (r() < 0.15) return bad[Math.floor(r() * bad.length)];
  if (f.t === 'select') return r() < 0.85 ? f.o[Math.floor(r() * f.o.length)] : 'inconnu';
  if (f.t === 'multi') return r() < 0.85 ? f.o.filter(() => r() < 0.5) : 'pas un tableau';
  if (f.t === 'number') return r() < 0.8 ? [12, '3,5', '7.25', 'abc', 0, -4][Math.floor(r() * 6)] : null;
  return r() < 0.9 ? 'Texte ' + Math.floor(r() * 99) + ' '.repeat(r() < 0.1 ? 700 : 0) : 12;
};
const grid = (rows, r, sizes) => Object.fromEntries(rows.filter(() => r() < 0.8).map((row) => [row[0] || row, Object.fromEntries(sizes.filter(() => r() < 0.7).map((s) => [s, [10, '55,5', '60.5', 'x', null, 0, 99.9][Math.floor(r() * 7)]]))]));
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(1000 + seed); const sz = engine.SIZES.filter(() => r() < 0.5);
  const mk = () => ({ id: 'p1', title: 'T', raw: r() < 0.8 ? 'texte' : '  ', f: Object.fromEntries(engine.ALLF.filter(() => r() < 0.4).map((f) => [f.k, valueFor(f, r)]).filter(([, v]) => v !== undefined)), g: { measures: grid(engine.MEASURES, r, engine.SIZES), counts: grid(engine.COUNTS, r, engine.SIZES) }, photos: r() < 0.7 ? [{ kind: 'fini' }, { kind: 'patron' }].filter(() => r() < 0.6) : undefined, ai: {}, ev: {}, gai: {}, opts: r() < 0.5 ? [{ id: 'o1', group: 'Manches', name: 'Manche courte', ai: 1, measures: {}, counts: {} }, { id: 'o2', group: 'Poches', name: 'Poche', measures: {}, counts: {} }] : [] });
  const p0 = mk(); p0.f.sizes = r() < 0.7 ? sz : undefined; if (r() < 0.2) p0.f.gauge_sts = '22'; if (r() < 0.2) p0.f.gauge_rows = 30;
  const pa = clone(p0), pb = clone(p0);
  same(A.completeness(pa), B.completeness(pb), `completeness ${seed}`); same(A.checks(pa), B.checks(pb), `checks ${seed}`);
  const res = { fields: Object.fromEntries(engine.ALLF.filter(() => r() < 0.6).map((f) => [f.k, r() < 0.25 ? { v: valueFor(f, r), q: 'preuve ' + 'x'.repeat(Math.floor(r() * 200)) } : valueFor(f, r)])), size_map: r() < 0.5 ? { S: 90, M: '95', XXXL: 1, L: null } : undefined, measures: grid(engine.MEASURES, r, engine.SIZES), counts: grid(engine.COUNTS, r, engine.SIZES) };
  const keys = [undefined, undefined, engine.ALLF.filter(() => r() < 0.4).map((f) => f.k)][Math.floor(r() * 3)]; const over = r() < 0.5;
  const opts = [{ group: 'Manches', name: 'Manche courte', fields: { sleeves: 'x', cuffs: { v: 'y' }, hem: 'z' }, desc: 'd'.repeat(600), q: 'q' }, { group: 'Poches', name: 'Poche plaquée', fields: {} }, { group: 'Inconnu', name: 'x' }, { name: 'sans groupe' }, null, { group: 'Encolure', name: 'Col V', fields: { neckline: engine.ALLF.find((f) => f.k === 'neckline')?.o?.[0] } }];
  const ogr = [{ group: 'Manches', name: 'manche COURTE', measures: grid(engine.MEASURES, r, engine.SIZES), counts: grid(engine.COUNTS, r, engine.SIZES) }, { group: 'Poches', name: 'poche', measures: { length: { S: 12 } } }, null, { group: 'x', name: 'y' }];
  const calls = [['applyAI', [res, keys, over]], ['applyGrids', [res, over]], ['mergeOptions', [opts, over]], ['applyOptGrids', [ogr, over]], ['applyAI', [res, undefined, true]], ['mergeOptions', [opts, true]], ['applyOptGrids', [ogr, true]]];
  for (const [fn, args] of calls) { const ra = A[fn](pa, ...clone(args)), rb = B[fn](pb, ...clone(args)); same(ra, rb, `${fn} ${seed}`); same(pa, pb, `${fn} p ${seed}`); checks += 2; }
  same(A.completeness(pa), B.completeness(pb)); same(A.checks(pa), B.checks(pb)); same(A.optList(pa), B.optList(pb));
  for (const f of engine.ALLF) { same(A.fieldDef(f.k), B.fieldDef(f.k)); for (let i = 0; i < 2; i++) { const v = valueFor(f, r); same(A.coerce(f, v), B.coerce(f, v), `coerce ${f.k}`); checks++; } }
  same(A.findOpt(pa, 'Manches', 'MANCHE courte'), B.findOpt(pb, 'Manches', 'MANCHE courte'));
  const ks = engine.ALLF.filter(() => r() < 0.3).map((f) => f.k); assert.equal(B.specText(ks), A.specText(ks));
}
// --- cas dirigés : seuils que le hasard n'atteint pas
{ // en-têtes / pieds de page répétés : seuil du nombre de pages concernées
  for (let pages = 3; pages <= 9; pages++) for (let withHeader = 0; withHeader <= pages; withHeader++) {
    const raw = Array.from({ length: pages }, (_, i) => [i < withHeader ? 'Mon Patron Gratuit 2024' : 'Autre ligne ' + i, 'Rang 1 : k2tog', 'Contenu ' + i, 'Rang 2 : p2tog', i < withHeader ? 'Mon Patron Gratuit 2024' : 'Pied ' + i].join('\n')).join('\f');
    for (const o of [{ headers: true, expand: true }, { headers: true, expand: false }]) { same(A.cleanText(raw, o), B.cleanText(raw, o), `en-têtes ${pages}/${withHeader}`); checks++; }
  }
  // longueur maximale d'une ligne considérée comme en-tête répété (90 caractères)
  for (const len of [30, 79, 80, 81, 89, 90, 91, 120]) {
    const head = 'H'.repeat(len);
    const raw = Array.from({ length: 5 }, (_, i) => [head, 'Rang 1', 'Contenu ' + i, head].join('\n')).join('\f');
    same(A.cleanText(raw, { headers: true, expand: false }), B.cleanText(raw, { headers: true, expand: false }), `longueur en-tête ${len}`); checks++;
  }
  // cohérence mailles / tour de poitrine : autour du seuil de 4 %
  for (let gs = 10; gs <= 30; gs += 4) for (let bust = 60; bust <= 130; bust += 10) for (const delta of [-0.2, -0.06, -0.05, -0.045, -0.041, -0.04, -0.039, -0.03, 0, 0.03, 0.039, 0.04, 0.041, 0.045, 0.05, 0.06, 0.2]) {
    const chest = Math.round(bust * gs / 10 * (1 + delta));
    const p = { raw: 'x', f: { sizes: ['S'], gauge_sts: String(gs), gauge_rows: 30 }, g: { measures: { bust: { S: bust } }, counts: { chest: { S: chest } } }, photos: [] };
    same(A.checks(clone(p)), B.checks(clone(p)), `checks ${gs}/${bust}/${delta}`); checks++;
  }
  // noms et descriptions d'options longs ; champs d'option au-delà de la limite
  for (const len of [79, 80, 81, 200]) for (const dlen of [499, 500, 501]) {
    const list = [{ group: 'Manches', name: 'N'.repeat(len), desc: 'd'.repeat(dlen), q: 'q'.repeat(len + 90), fields: { sleeves: 'a'.repeat(700) } }];
    const pa = { opts: [], g: {} }, pb = { opts: [], g: {} };
    same(A.mergeOptions(pa, clone(list), false), B.mergeOptions(pb, clone(list), false)); same(pa, pb, `options ${len}/${dlen}`); checks++;
  }
}
assert.equal(B.groupSpec(), A.groupSpec()); assert.equal(B.rowSpec(), A.rowSpec()); assert.equal(B.specText([]), A.specText([]));
assert.equal(B.fieldDef('inexistant'), A.fieldDef('inexistant'));

// --- propriété, retour arrière, garde-fous
const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m));
const host = installPatternsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: seqUid(), win: {} });
assert.equal(host.enabled, false); assert.equal(reg.ownerOf('logic', 'patterns-engine'), 'legacy');
host.engage(); host.release(); assert.equal(reg.ownerOf('logic', 'patterns-engine'), 'legacy');
assert.throws(() => createPatternsEngine({}), /uid requis/);
assert.equal((app.match(/DreamOSPatternsHost/g) || []).length, 1);
assert.ok(!/patterns-host|patterns-engine/.test(app), 'app.js n’importe aucun module ES');
const engineCode = fs.readFileSync(path.join(root, 'dreamOS/patterns/patterns-engine.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
assert.ok(!/\bS\.|document\.|window\.|localStorage|IDB|saveBlob|render\(|toast\(|fetch\(/.test(engineCode), 'le moteur ne touche ni état, ni DOM, ni stockage, ni réseau');
console.log(`phase3_8 : OK (${checks} comparaisons sur 200 textes et 250 patrons aléatoires, hôte absent vs engagé)`);
