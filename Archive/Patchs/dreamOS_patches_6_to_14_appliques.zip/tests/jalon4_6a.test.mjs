// Jalon 4.6a — Projects propriétaire de la LISTE des projets et de son enregistrement (carnet.projects, pjStage, migPj)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installProjectsHost } from '../dreamOS/projects/projects-host.js';
import { createProjectsStore, PROJECTS_PERSISTED_KEYS } from '../dreamOS/projects/projects-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const helperSrc = grab(/  function projStore\(\)[\s\S]*?\n  function pjRelinkPattern[^\n]*\n/, 'projStore..pjRelinkPattern');
const one = (n) => grab(new RegExp('  function ' + n + '\\([^\\n]*\\n'), n);
const fn = (n) => grab(new RegExp('  function ' + n + '\\([^)]*\\) \\{[\\s\\S]*?\\n  \\}\\n'), n);
const patDoorsSrc = grab(/  function patHost\(\)[^\n]*\n/, 'patHost') + grab(/  function patStore\(\)[\s\S]*?\n  function persist\(light\)/, 'patStore').replace(/\n  function persist\(light\)$/, '\n') + grab(/  function patternsAppend[\s\S]*?\n  function patmDiscardAll[^\n]*\n/, 'portes patrons');
const projHostSrc = one('projHost'), seqSrc = one('nextPjSeq'), curSrc = one('curPj'), saveSoonSrc = one('saveSoonPj'), newSrc = fn('newProject'), migSrc = fn('migrateStages'), removePSrc = fn('removeP'), removePSoftSrc = fn('removePSoft');
const delBr = grab(/    else if \(a === 'pjDel'\)[\s\S]*?(?=\n    else if \(a === 'lightbox'\))/, 'pjDel*'), coverBr = grab(/    else if \(a === 'coverPick'\) \{[\s\S]*?\n    \}\n/, 'coverPick'), stageBr = grab(/    else if \(a === 'goPj'\)[^\n]*\n    else if \(a === 'pjStage'\)[^\n]*\n/, 'goPj/pjStage');

// 1. garde-fous statiques
const outside = app.replace(helperSrc, '');
assert.deepEqual(outside.match(/keep\(\s*'carnet\.(projects|pjStage|migPj)'|S\.projects\s*=[^=]|S\.projects\.(unshift|splice|push|pop|shift|sort|reverse|fill)\b|meta_projects'\s*,/g) || [], [], 'écriture directe de la liste des projets');
assert.deepEqual([...new Set((app.match(/pjSettingSave\('(carnet\.[A-Za-z0-9]+)'/g) || []).map((x) => x.slice(15, -1)))].sort(), [...PROJECTS_PERSISTED_KEYS].sort(), 'clés réglages = liste blanche');

assert.ok(app.includes('projectsReplace(mergeById(S.projects, data.projects));'), 'fusion de sauvegarde : enregistrement par le saveProjects() qui suit l\'import');
assert.ok(app.includes('if (Array.isArray(l)) { projectsReplace(l, true); }'), 'restauration depuis le miroir IndexedDB : enregistrement demandé');
// 2. propriété
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {}; const names = ['carnet.projects', 'carnet.pjStage', 'carnet.migPj']; names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'legacy'));
  const h = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win }); h.engage(); names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'projects')); assert.equal(reg.ownerOf('logic', 'projects-engine'), 'projects'); assert.equal(reg.ownerOf('media', 'pjc_*'), 'projects', 'médias : transférés en 4.6b');
  assert.throws(() => reg.transferOwnership('storage', 'carnet.projects', 'legacy', 'tools'), /transfert refusé/); h.release(); names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'legacy')); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.migPj'), 'projects'); }

// 3. magasin
{ const bus = new EventBus(), seen = []; ['added', 'removed', 'restored', 'replaced', 'persisted'].forEach((t) => bus.on('projects:' + t, () => seen.push(t))); const st = createProjectsStore({ eventBus: bus });
  assert.throws(() => st.addFirst({}), /aucun tableau/); assert.equal(st.adopted, false); const P = [{ id: 'a' }], w = []; st.adopt(P, (x) => w.push(x.length)); assert.equal(st.adopted, true); assert.equal(st.list(), P);
  st.addFirst({ id: 'b' }); assert.deepEqual(P.map((x) => x.id), ['b', 'a']); assert.equal(st.removeAt(0).id, 'b'); assert.equal(st.removeAt(9), undefined); st.insertAt(99, { id: 'q' }); assert.equal(P.at(-1).id, 'q'); assert.equal(w.length, 4);
  st.replaceAll([{ id: 'r' }]); assert.equal(w.length, 4); assert.equal(st.list(), P); st.replaceAll(null, true); assert.equal(P.length, 0); assert.equal(w.length, 5); st.save(); assert.equal(w.length, 6);
  const log = []; st.persist('carnet.pjStage', 'wip', (k, v) => log.push([k, v])); assert.deepEqual(log, [['carnet.pjStage', 'wip']]); assert.throws(() => st.persist('carnet.projects', 1, () => {}), /non gérée/); assert.throws(() => st.persist('carnet.migPj', 1), /écriture requise/);
  assert.deepEqual(seen, ['added', 'removed', 'removed', 'restored', 'replaced', 'replaced', 'persisted']); assert.throws(() => st.adopt('x'), /tableau requis/);
  const bad = createProjectsStore({ eventBus: { emit() { throw new Error('x'); } } }); const a2 = []; bad.adopt(a2, () => {}); bad.addFirst({ id: 1 }); assert.equal(a2.length, 1); }

// 4. équivalence sur le VRAI code d'app.js
const ARGS = ['window', 'S', 'uid', 'keep', 'saveBlob', 'IDB', 'render', 'toast', 'deferDelete', 'persist', 'patJson', 'load', 'Date', 'a', 'b', 'v'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, a) => a[Math.floor(r() * a.length)];
const NOW = 1_800_000_000_000; const FakeDate = class extends Date { static now() { return NOW; } };
function state(r) {
  const patterns = Array.from({ length: Math.floor(r() * 4) }, (_, i) => ({ id: 'p' + i, title: 'Patron' + i, stage: pick(r, ['wip', 'termine', 'attente']), stageAt: r() < .5 ? { wip: NOW - 5, termine: NOW - 9 } : undefined, thumb: pick(r, ['', 'th_' + i]), photos: r() < .5 ? [{ id: 'img_' + i }] : [] }));
  const projects = Array.from({ length: Math.floor(r() * 5) }, (_, i) => ({ id: 'j' + i, seq: i + 1, name: 'Projet ' + (i + 1), stage: pick(r, ['wip', 'attente', 'termine']), patternId: pick(r, ['', ...patterns.map((p) => p.id)]), cover: pick(r, ['', 'pjc_a']), photos: ['pjp_' + i], inspo: [{ id: 'i1', mediaId: 'pji_1' }, { id: 'i2', ideaId: 'x', mediaId: 'ideam_z' }], log: [{ photos: ['pjp_L' + i] }], created: i, stageAt: {} }));
  return { patterns, projects, curProj: pick(r, [null, ...projects.map((p) => p.id)]), pjDel: false, tab: 'pj', pjStage: 'wip', pjIsland: true, migDone: r() < .5 };
}
async function run(withHost, st, sc) {
  const win = {}, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid, now: () => NOW, win }).engage(); }
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), saveBlob: async () => {}, IDB: { put: (k, x) => { log.push(['idbput', k, x]); return Promise.resolve(); }, del: (id) => log.push(['idbdel', id]) }, render: () => log.push(['render']), toast: (m) => log.push(['toast', m]),
    deferDelete: (msg, undo, done) => { log.push(['defer', msg]); if (sc.undo) { undo(); log.push(['undone', JSON.stringify(S.projects)]); } else done(); }, persist: () => log.push(['persist']), patJson: { p0: 1 }, load: (k, d) => (k === 'carnet.migPj' ? (S.migDone ? 1 : 0) : d), Date: FakeDate,
    a: sc.a, b: { dataset: { id: sc.id } }, v: sc.v };
  const body = `${patDoorsSrc}${projHostSrc}${seqSrc}${curSrc}${helperSrc}${newSrc}${migSrc}${removePSrc}${removePSoftSrc}\nwindow.scrollTo = function(){};\nreturn (async function(){ ${sc.code} }).call(this);`;
  const res = await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { projects: S.projects, patterns: S.patterns, curProj: S.curProj, pjDel: S.pjDel, tab: S.tab, pjStage: S.pjStage, pjIsland: S.pjIsland }, log, res: res === undefined ? null : (res && res.id) || res, n });
}
let checks = 0;
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed), st = state(r), pid = pick(r, [...st.patterns.map((p) => p.id), 'none']);
  const scs = [
    { kind: 'new', code: `return newProject({ name: ${JSON.stringify(pick(r, ['', 'Mon pull']))}, stage: ${JSON.stringify(pick(r, ['wip', 'attente', undefined]))}, patternId: ${JSON.stringify(pick(r, ['', pid]))} }).id;` },
    { kind: 'migrate', code: `return migrateStages();` },
    { kind: 'delYes', code: `if (false) {}\n${delBr}`, a: 'pjDelYes', undo: r() < .5 }, { kind: 'delNo', code: `if (false) {}\n${delBr}`, a: 'pjDelNo' },
    { kind: 'cover', code: `if (false) {}\n${coverBr}`, a: 'coverPick', id: pick(r, ['__auto', '__pdf', 'pjc_x']) },
    { kind: 'stage', code: `if (false) {}\n${stageBr}`, a: pick(r, ['goPj', 'pjStage']), v: pick(r, ['wip', 'termine', 'attente']) },
    { kind: 'removeP', code: `return removeP(S.patterns[0] || { id: 'zz' });` }, { kind: 'removePSoft', code: `return S.patterns[0] ? removePSoft(S.patterns[0]) : null;`, undo: r() < .5 }
  ];
  for (const sc of scs) {
    const A = await run(false, st, sc), B = await run(true, st, sc); assert.equal(B, A, `${sc.kind} seed ${seed}`); checks++;
    const out = JSON.parse(A), keeps = out.log.filter((l) => l[0] === 'keep').map((l) => l[1]);
    if (sc.kind === 'new') { assert.equal(out.S.projects.length, st.projects.length + 1); assert.equal(out.S.projects[0].id, out.res); assert.ok(keeps.includes('carnet.projects')); assert.ok(out.log.some((l) => l[0] === 'idbput' && l[1] === 'meta_projects'), 'miroir IndexedDB'); checks++; }
    if (sc.kind === 'migrate') { if (st.migDone) assert.deepEqual(out.log, []); else { const n = st.patterns.filter((p) => p.stage === 'wip' || p.stage === 'termine').length; assert.equal(out.S.projects.length, st.projects.length + n); assert.ok(keeps.includes('carnet.migPj')); assert.ok(keeps.includes('carnet.projects')); } checks++; }
    if (sc.kind === 'delYes' && st.curProj) { const ids = st.projects.map((p) => p.id); assert.deepEqual(out.S.projects.map((p) => p.id), sc.undo ? ids : ids.filter((x) => x !== st.curProj)); assert.equal(out.S.curProj, null); assert.equal(out.S.tab, 'pj'); if (!sc.undo) { const pr = st.projects.find((p) => p.id === st.curProj), dels = out.log.filter((l) => l[0] === 'idbdel').map((l) => l[1]); assert.ok(pr.photos.every((x) => dels.includes(x)) && dels.includes('pji_1') && !dels.includes('ideam_z'), 'médias du projet supprimés, idée partagée conservée'); } checks++; }
    if (sc.kind === 'cover' && st.curProj) { assert.ok(keeps.includes('carnet.projects'), 'enregistrement après modification d\'un champ'); checks++; }
    if (sc.kind === 'stage') { assert.equal(out.S.pjStage, sc.v); assert.ok(keeps.includes('carnet.pjStage')); assert.equal(out.S.pjIsland, false); checks++; }
    if (sc.kind === 'removeP') { assert.ok(keeps.includes('carnet.projects')); checks++; }
  }
}
// 5. séquences : bascule / retour arrière à chaud, données ET écritures identiques
const build = new Function('window', 'S', 'keep', 'IDB', `${projHostSrc}${helperSrc}\nreturn { projStore, pjSettingSave, saveProjects, saveProjectsQuiet, projectsAdd, projectsRemoveAt, projectsInsertAt, projectsReplace };`);
function world(mode, init) {
  const win = {}, S = { projects: clone(init.projects) }, log = [];
  const f = build(win, S, (k, v) => log.push([k, JSON.stringify(v)]), { put: (k, x) => { log.push(['idbput', k, x]); return Promise.resolve(); } });
  let host = null; if (mode === 'host') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); host = installProjectsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), uid: () => 'x', win }); host.engage(); }
  return { f, S, log, host };
}
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed + 7000), init = state(r), A = world('legacy', init), B = world('host', init);
  for (let step = 0; step < 14; step++) {
    const op = Math.floor(r() * 10), i = Math.floor(r() * 6), pr = { id: 'n' + step, name: 'N' + step }, sv = r() < .5;
    for (const w of [A, B]) {
      if (op === 0) w.f.projectsAdd(clone(pr)); else if (op === 1) w.f.projectsRemoveAt(i); else if (op === 2) w.f.projectsInsertAt(i, clone(pr)); else if (op === 3) w.f.projectsReplace(clone([pr]), sv);
      else if (op === 4) { if (w.S.projects[0]) w.S.projects[0].name = 'M' + step; w.f.saveProjects(); } else if (op === 5) w.f.saveProjectsQuiet(); else if (op === 6) w.f.pjSettingSave('carnet.pjStage', 'wip');
      else if (op === 7 && w.host) { w.host.release(); w.host.engage(); } else if (op === 8 && w.host) w.host.release(); else if (op === 9 && w.host && !w.host.enabled) w.host.engage();
    }
    if (op === 8) B.host.engage();
    assert.deepEqual(B.S.projects, A.S.projects, `projets ${seed}/${step}/${op}`); assert.deepEqual(B.log, A.log, `écritures ${seed}/${step}/${op}`); checks += 2;
  }
}
{ const w0 = world('host', { projects: [{ id: 'a' }] }); w0.f.saveProjectsQuiet(); assert.deepEqual(w0.log.map((l) => l[0]), ['carnet.projects', 'idbput'], 'saveProjectsQuiet enregistre'); const w1 = world('legacy', { projects: [{ id: 'a' }] }); w1.f.saveProjectsQuiet(); assert.deepEqual(w1.log, w0.log); }
{ const w = world('host', { projects: [{ id: 'a' }] }); w.f.projectsAdd({ id: 'b' }); w.S.projects = [{ id: 'zz' }]; w.f.projectsAdd({ id: 'c' }); assert.deepEqual(w.S.projects.map((x) => x.id), ['c', 'zz']); assert.equal(w.f.projStore().list(), w.S.projects); const n = w.log.length; w.f.projectsReplace([{ id: 'r' }]); assert.equal(w.log.length, n); w.host.release(); assert.equal(w.f.projStore(), null); w.f.projectsAdd({ id: 'n' }); assert.equal(w.S.projects[0].id, 'n'); }
console.log('jalon4_6a OK —', checks, 'comparaisons');
