// Jalon 4.4 — Tools propriétaire de carnet.grids / chart / r3 / rowStep / scratchpad : une seule autorité d'écriture, équivalence avec le code d'origine
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installToolsHost } from '../dreamOS/tools/tools-host.js';
import { createToolsStore, TOOLS_PERSISTED_KEYS } from '../dreamOS/tools/tools-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const helperSrc = grab(/  function toolsStore\(\)[\s\S]*?\n  function gridsReplace[^\n]*\n/, 'toolsStore..gridsReplace');
const hostSrc = grab(/  function toolsHost\(\)[^\n]*\n/, 'toolsHost');
const removeSrc = grab(/  function removeGridSoft\(id\) \{[\s\S]*?\n  \}\n/, 'removeGridSoft'), gridSaveSrc = grab(/  function gridSave\(asNew\) \{[\s\S]*?\n  \}\n/, 'gridSave');
const chartConst = grab(/  var CHART_TOOLS = \{[\s\S]*?\n  \};\n/, 'CHART_TOOLS');
const chartToolsSrc = chartConst + grab(/  function chartTools\(mode\) \{[\s\S]*?\n  \}\n/, 'chartTools'), askStepSrc = grab(/  function askStepX\(\) \{[\s\S]*?\n  \}\n/, 'askStepX');
const gridBr = grab(/    else if \(a === 'gridNew'\)[\s\S]*?(?=\n    else if \(a === 'gridDel'\))/, 'gridNew/gridOpen');
const chartBr = grab(/    else if \(a === 'ctool'\)[\s\S]*?(?=\n    else if \(a === 'toggleGrp'\))/, 'ctool/cell/cclear');
const scratchLine = grab(/    if \(t\.id === 'scratchpad'\)[^\n]*\n/, 'scratchpad'), r3Blk = grab(/    if \(t\.dataset\.r3 !== undefined\) \{\n[\s\S]*?\n    \}\n/, 'r3');

// 1. garde-fous statiques
const outside = app.replace(helperSrc, '');
assert.deepEqual(outside.match(/keep\(\s*'carnet\.(grids|chart|r3|rowStep|scratchpad)'|S\.grids\s*=[^=]|S\.grids\.(unshift|splice|push|pop|shift|sort|reverse|fill)\b|meta_grids'\s*,/g) || [], [], 'écriture directe hors de la porte unique');
assert.deepEqual([...new Set((app.match(/toolsSave\('(carnet\.[A-Za-z0-9]+)'/g) || []).map((x) => x.slice(11, -1)))].sort(), [...TOOLS_PERSISTED_KEYS].sort(), 'clés enregistrées = liste blanche');

// 2. propriété
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {}; const names = ['carnet.grids', 'carnet.chart', 'carnet.r3', 'carnet.rowStep', 'carnet.scratchpad'];
  names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'legacy'));
  const h = installToolsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'tools')); assert.equal(reg.ownerOf('logic', 'stopwatch'), 'tools');
  assert.throws(() => reg.transferOwnership('storage', 'carnet.grids', 'legacy', 'library'), /transfert refusé/); h.release(); names.forEach((n) => assert.equal(reg.ownerOf('storage', n), 'legacy')); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.r3'), 'tools'); }

// 3. magasin
{ const bus = new EventBus(), seen = []; ['grid-added', 'grid-updated', 'grid-removed', 'grid-restored', 'persisted'].forEach((t) => bus.on('tools:' + t, () => seen.push(t)));
  const st = createToolsStore({ eventBus: bus }); assert.throws(() => st.grids.addFirst({}), /aucun tableau/); const G = [{ id: 'a', name: 'A' }], w = []; st.grids.adopt(G, (x) => w.push(x.length)); assert.equal(st.grids.list(), G);
  st.grids.addFirst({ id: 'b' }); assert.deepEqual(G.map((x) => x.id), ['b', 'a']); st.grids.patch(G[1], { name: 'Z' }); assert.equal(G[1].name, 'Z'); assert.equal(st.grids.removeAt(0).id, 'b'); st.grids.insertAt(9, { id: 'q' }); assert.equal(G.at(-1).id, 'q');
  assert.equal(w.length, 4); st.grids.replaceAll([{ id: 'r' }]); assert.equal(w.length, 4); assert.equal(st.grids.list(), G); st.grids.replaceAll(null, true); assert.equal(G.length, 0); assert.equal(w.length, 5);
  const log = []; assert.equal(st.persist('carnet.chart', { x: 1 }, (k, v) => log.push([k, v])), true); assert.deepEqual(log, [['carnet.chart', { x: 1 }]]); assert.throws(() => st.persist('carnet.grids', 1, () => {}), /non gérée/); assert.throws(() => st.persist('carnet.r3', 1), /écriture requise/);
  assert.deepEqual(seen, ['grid-added', 'grid-updated', 'grid-removed', 'grid-restored', 'persisted']); assert.throws(() => st.grids.adopt('x'), /tableau requis/);
  const bad = createToolsStore({ eventBus: { emit() { throw new Error('x'); } } }); const a2 = []; bad.grids.adopt(a2, () => {}); bad.grids.addFirst({ id: 1 }); assert.equal(a2.length, 1); }

// 4. équivalence sur le VRAI code d'app.js
const ARGS = ['window', 'S', 'uid', 'keep', 'IDB', 'toast', 'render', 'deferDelete', 'gridThumb', 'dlgOpen', 'rowStepX', 'patchFrom', 'viewToolR3', 'a', 'b', 'v', 't', 'Date'];
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, a) => a[Math.floor(r() * a.length)];
const FakeDate = class extends Date { static now() { return NOW; } }; const NOW = 1_800_000_000_000;
function state(r) {
  const mk = (i) => ({ id: 'g' + i, name: 'Grille' + i, mode: pick(r, ['color', 'lace']), w: 2, h: 2, cells: [['#fff', '#000'], ['#000', '#fff']], ts: i, thumb: 'th' + i });
  const grids = Array.from({ length: Math.floor(r() * 5) }, (_, i) => mk(i));
  const mode = pick(r, ['color', 'lace', 'cables']);
  return { grids, curGrid: pick(r, [null, ...grids.map((g) => g.id)]), gridName: pick(r, ['', ' Nom ', 'Neuf']), scratchpad: pick(r, ['', 'texte']), r3: { sts: '', rows: '', per: '10', cm: '', nSts: '', nRows: '' },
    chart: { mode, w: 2, h: 2, tool: Math.floor(r() * 3), palette: ['#fff', '#b45309', '#1c1917', '#d97706'], cells: { color: [['#fff', '#000'], ['#000', '#fff']], lace: [['o', 'x'], ['x', 'o']], cables: [['|', '-'], ['-', '|']] } } };
}
async function run(withHost, st, sc) {
  const win = { scrollTo: () => log.push(['scroll']) }, log = [], S = clone(st); let n = 0; const uid = () => 'u' + (++n);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); installToolsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }).engage(); }
  const ctx = { window: win, S, uid, keep: (k, x) => log.push(['keep', k, JSON.stringify(x)]), IDB: { put: (k, x) => { log.push(['idbput', k, x]); return Promise.resolve(); } }, toast: (m) => log.push(['toast', m]), render: () => log.push(['render']),
    deferDelete: (msg, undo, done) => { log.push(['defer', msg]); if (sc.undo) { undo(); log.push(['undone', JSON.stringify(S.grids), S.curGrid]); } else done(); }, gridThumb: (c, m) => 'thumb:' + m + c.length, dlgOpen: () => Promise.resolve(sc.dlg), rowStepX: () => 5,
    patchFrom: () => log.push(['patch']), viewToolR3: () => 'v', a: sc.a, b: { dataset: { id: sc.id, r: '0', c: '1' }, style: {}, textContent: '' }, v: sc.v, t: clone(sc.t || {}), Date: FakeDate };
  const body = `${hostSrc}${helperSrc}\n${chartToolsSrc}${removeSrc}${gridSaveSrc}${askStepSrc}\nreturn (async function(){ ${sc.code} }).call(this);`;
  const res = await new Function(...ARGS, body)(...ARGS.map((k) => ctx[k]));
  return JSON.stringify({ S: { grids: S.grids, curGrid: S.curGrid, gridName: S.gridName, scratchpad: S.scratchpad, r3: S.r3, chart: S.chart }, log, res: res ?? null, n });
}
let checks = 0;
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed), st = state(r), gid = pick(r, [...st.grids.map((g) => g.id), 'inconnu']), gi = st.grids.findIndex((g) => g.id === gid);
  const scs = [
    { kind: 'remove', code: `return removeGridSoft(b.dataset.id);`, id: gid, undo: r() < .5 },
    { kind: 'saveNew', code: `return gridSave(true);`, undo: false }, { kind: 'saveUpd', code: `return gridSave(false);` },
    { kind: 'gridBr', code: `if (false) {}\n${gridBr}`, a: pick(r, ['gridNew', 'gridOpen']), id: gid },
    { kind: 'chartBr', code: `if (false) {}\n${chartBr}`, a: pick(r, ['ctool', 'cell', 'cclear']), v: pick(r, ['0', '1', '2', 'x']) },
    { kind: 'scratch', code: `${scratchLine}`, t: { id: 'scratchpad', value: pick(r, ['', 'nouvelle note']) } },
    { kind: 'r3', code: `${r3Blk}`, t: { dataset: { r3: pick(r, ['sts', 'rows', 'per']) }, value: pick(r, ['', '22', '10.5']) } },
    { kind: 'rowstep', code: `return askStepX();`, dlg: pick(r, [null, undefined, '7', '12']) }
  ];
  for (const sc of scs) {
    const A = await run(false, st, sc), B = await run(true, st, sc); assert.equal(B, A, `${sc.kind} seed ${seed}`); checks++;
    const out = JSON.parse(A), keeps = out.log.filter((l) => l[0] === 'keep').map((l) => l[1]);
    if (sc.kind === 'remove' && gi >= 0) { const ids = st.grids.map((g) => g.id); assert.deepEqual(out.S.grids.map((g) => g.id), sc.undo ? ids : ids.filter((x) => x !== gid), 'suppression / annulation'); assert.ok(keeps.includes('carnet.grids')); assert.ok(out.log.some((l) => l[0] === 'idbput' && l[1] === 'meta_grids'), 'miroir IndexedDB'); if (!sc.undo && st.curGrid === gid) assert.equal(out.S.curGrid, null); checks++; }
    if (sc.kind === 'remove' && gi < 0) { assert.deepEqual(out.log, []); checks++; }
    if (sc.kind === 'saveNew') { const empty = false; const cells = st.chart.cells[st.chart.mode]; if (cells && cells.length && st.gridName.trim()) { assert.equal(out.S.grids.length, st.grids.length + 1); assert.equal(out.S.grids[0].name, st.gridName.trim()); assert.equal(out.S.curGrid, out.S.grids[0].id); assert.match(out.S.grids[0].id, /^gu\d+$/); checks++; } else assert.deepEqual(out.S.grids, clone(st.grids)); }
    if (sc.kind === 'saveUpd') { const cells = st.chart.cells[st.chart.mode], ex = st.grids.find((g) => g.id === st.curGrid); if (cells && cells.length && st.gridName.trim()) { if (ex) { assert.equal(out.S.grids.length, st.grids.length); assert.equal(out.S.grids.find((g) => g.id === ex.id).name, st.gridName.trim()); } else assert.equal(out.S.grids.length, st.grids.length + 1); assert.ok(keeps.includes('carnet.grids')); checks++; } }
    if (sc.kind === 'gridBr' && sc.a === 'gridNew') { assert.deepEqual(out.S.chart.cells[st.chart.mode], []); assert.equal(out.S.curGrid, null); assert.ok(keeps.includes('carnet.chart')); checks++; }
    if (sc.kind === 'gridBr' && sc.a === 'gridOpen' && gi >= 0) { assert.equal(out.S.curGrid, gid); assert.equal(out.S.gridName, st.grids[gi].name); assert.ok(keeps.includes('carnet.chart')); checks++; }
    if (sc.kind === 'chartBr') { assert.ok(keeps.includes('carnet.chart'), 'graphique enregistré'); checks++; if (sc.a === 'cclear') assert.deepEqual(out.S.chart.cells[st.chart.mode], []); }
    if (sc.kind === 'scratch') { assert.equal(out.S.scratchpad, sc.t.value); assert.deepEqual(out.log.filter((l) => l[0] === 'keep'), [['keep', 'carnet.scratchpad', JSON.stringify(sc.t.value)]]); checks++; }
    if (sc.kind === 'r3') { assert.equal(out.S.r3[sc.t.dataset.r3], sc.t.value); assert.deepEqual(keeps, ['carnet.r3']); checks++; }
    if (sc.kind === 'rowstep') { const ok = sc.dlg != null; assert.deepEqual(out.log.filter((l) => l[0] === 'keep'), ok ? [['keep', 'carnet.rowStep', String(parseInt(sc.dlg, 10))]] : []); assert.equal(out.res, ok); checks++; }
  }
}
// 5. séquences : bascule / retour arrière à chaud, données ET écritures identiques
const build = new Function('window', 'S', 'keep', 'IDB', `${hostSrc}${helperSrc}\nreturn { toolsStore, toolsSave, saveGrids, gridsAdd, gridsPatch, gridsRemoveAt, gridsInsertAt, gridsReplace };`);
function world(mode, init) {
  const win = {}, S = { grids: clone(init.grids) }, log = [];
  const f = build(win, S, (k, v) => log.push([k, JSON.stringify(v)]), { put: (k, x) => { log.push(['idbput', k, x]); return Promise.resolve(); } });
  let host = null; if (mode === 'host') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); host = installToolsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); host.engage(); }
  return { f, S, log, host };
}
for (let seed = 1; seed <= 600; seed++) {
  const r = rng(seed + 9000), init = state(r), A = world('legacy', init), B = world('host', init);
  for (let step = 0; step < 14; step++) {
    const op = Math.floor(r() * 10), i = Math.floor(r() * 6), g = { id: 'n' + step, name: 'N' + step }, sv = r() < .5, key = pick(r, TOOLS_PERSISTED_KEYS);
    for (const w of [A, B]) {
      if (op === 0) w.f.gridsAdd(clone(g)); else if (op === 1 && w.S.grids[0]) w.f.gridsPatch(w.S.grids[0], { name: 'P' + step }); else if (op === 2) w.f.gridsRemoveAt(i); else if (op === 3) w.f.gridsInsertAt(i, clone(g));
      else if (op === 4) w.f.gridsReplace(clone([g]), sv); else if (op === 5) w.f.saveGrids(); else if (op === 6) w.f.toolsSave(key, { s: step });
      else if (op === 7 && w.host) { w.host.release(); w.host.engage(); } else if (op === 8 && w.host) w.host.release(); else if (op === 9 && w.host && !w.host.enabled) w.host.engage();
    }
    if (op === 8) B.host.engage();
    assert.deepEqual(B.S.grids, A.S.grids, `grilles ${seed}/${step}/${op}`); assert.deepEqual(B.log, A.log, `écritures ${seed}/${step}/${op}`); checks += 2;
  }
}
{ const w = world('host', { grids: [{ id: 'a' }] }); w.f.gridsAdd({ id: 'b' }); w.S.grids = [{ id: 'zz' }]; w.f.gridsAdd({ id: 'c' }); assert.deepEqual(w.S.grids.map((x) => x.id), ['c', 'zz']); assert.equal(w.f.toolsStore().grids.list(), w.S.grids); const n = w.log.length; w.f.gridsReplace([{ id: 'r' }]); assert.equal(w.log.length, n); w.host.release(); assert.equal(w.f.toolsStore(), null); w.f.gridsAdd({ id: 'n' }); assert.equal(w.S.grids[0].id, 'n'); }
console.log('jalon4_4 OK —', checks, 'comparaisons');
