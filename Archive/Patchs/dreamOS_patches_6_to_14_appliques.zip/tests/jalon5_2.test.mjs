// Jalon 5.2 : barre du haut Bliss (aperçu opt-in). Extrait le vrai code d'app.js.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const app=fs.readFileSync('app.js','utf8'), idx=fs.readFileSync('index.html','utf8'), css=fs.readFileSync('theme/components.css','utf8');
const a=app.indexOf('function blissIco'), b=app.indexOf('function tabbar()');
assert.ok(a>0&&b>a);
const src=app.slice(a,b);
const make=(tab)=>new Function('S',src+';return {top:blissTopbar(),nav:blissBottomNav()};')({tab});
const dest=h=>[...h.matchAll(/data-v="([a-z]+)"/g)].map(m=>m[1]);
const tabs=['lib','det','add','fav','find','pj','pjd','calc','doc','idea','set'];
const cur=h=>[...h.matchAll(/<button[^>]*data-v="([a-z]+)"[^>]*aria-current="page"/g)].map(m=>m[1]);
const known=new Set(['lib','pj','calc','doc','idea','set','find','add','fav']);
for(const t of tabs){
  const {top,nav}=make(t);
  for(const d of [...dest(top),...dest(nav)]) assert.ok(known.has(d),'destination inconnue '+d);
  // toutes les destinations de l'ancienne barre restent atteignables
  const all=new Set([...dest(top),...dest(nav)]);
  for(const d of ['lib','pj','calc','doc','idea','set','find','add','fav']) assert.ok(all.has(d),'inaccessible: '+d+' sur '+t);
  // chaque bouton sans texte visible a un aria-label
  for(const m of (top+nav).matchAll(/<button\b[^>]*>(.*?)<\/button>/g)){ const txt=m[1].replace(/<svg.*?<\/svg>/g,'').trim(); if(!txt) assert.match(m[0],/aria-label="[^"]+"/,'icône sans nom: '+m[0].slice(0,80)); }
  assert.ok(!/style=|#[0-9a-f]{3,6}\b|Synchronisé/i.test(top+nav));
  assert.match(top,/Données locales/);
}
// page courante
const exp={lib:'lib',det:'lib',add:'lib',fav:'lib',pj:'pj',pjd:'pj',idea:'idea',calc:'calc',set:'set'};
for(const [t,e] of Object.entries(exp)){ const {nav}=make(t); assert.deepEqual(cur(nav),[e],'nav courante '+t); }
assert.deepEqual(cur(make('doc').nav),[]);
// aperçu opt-in : rien en mode normal
assert.match(app,/function tabbar\(\) \{\n    if \(BLISS\) return blissBottomNav\(\);/);
assert.match(app,/if \(BLISS\) \{ var tpb/);
assert.match(app,/BLISS = \(function\(\)[\s\S]*?localStorage\.getItem\('wp_bliss_preview'\) === '1'/);
assert.match(idx,/<header id="topbar" hidden><\/header>/);
assert.equal(idx.includes('components.css'),false,'components.css chargé seulement en aperçu');
assert.match(app,/blissCss\.href = 'theme\/components\.css'/);
// CSS : pas de hex/!important, cibles ≥ 44 px
assert.equal(/!important|#[0-9a-fA-F]{3,6}\b/.test(css),false);
assert.match(css,/\.dos-topbar \.dos-topbar__wide \{ display: none; \}/);
console.log('jalon5_2 OK');
