// Phase 2.8 — format de sauvegarde v1 avec une VRAIE bibliothèque ZIP (jszip : npm i jszip)
// Vérifie : (1) le ZIP écrit par le moteur historique (buildStoredZip) est lisible par JSZip et le BackupManager,
// (2) une archive du BackupManager reste conforme au format historique, (3) les cas d'archives invalides.
import fs from 'node:fs'; import assert from 'node:assert/strict'; import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url'; import path from 'node:path';
import { BackupManager } from '../dreamOS/backup-manager.js';
let JSZip; try { JSZip = createRequire(import.meta.url)('jszip'); } catch { console.log('SKIP : jszip introuvable (npm i jszip).'); process.exit(0); }

// Extraction du vrai code d'écriture ZIP de app.js (aucune copie à maintenir)
const app = fs.readFileSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../app.js'), 'utf8');
const chunk = app.slice(app.indexOf('var ZIP_CRC_TABLE'), app.indexOf('var BACKUP_PART_BYTES'));
const { buildStoredZip } = new Function(chunk + '; return { buildStoredZip };')();

// Dans Node, JSZip ne lit pas les Blob/File (il le fait dans le navigateur) : petite passerelle de test qui les convertit en ArrayBuffer.
class Z {
  constructor() { this.z = new JSZip(); this.pend = []; }
  file(n, v) { if (arguments.length === 1) return this.z.file(n); if (v instanceof Blob) this.pend.push(v.arrayBuffer().then((b) => this.z.file(n, b))); else this.z.file(n, v); return this; }
  folder(p) { return this.z.folder(p); }
  async generateAsync() { await Promise.all(this.pend); return new Blob([await this.z.generateAsync({ type: 'arraybuffer' })]); }
  static async loadAsync(f) { return JSZip.loadAsync(await f.arrayBuffer()); }
}

const data = { v: 1, at: 1, patterns: [{ id: 'p1', source: { pdf: 'pdf_a' }, photos: [{ id: 'img_b' }] }],
  folders: [], projects: [{ id: 'j1', photos: ['pjp_c'], cover: 'pjp_c' }], grids: [], docs: [], ideas: [], boards: [] };
const blobs = { pdf_a: new Blob(['%PDF-1.4 test'], { type: 'application/pdf' }), img_b: new Blob(['jpegdata'], { type: 'image/jpeg' }), pjp_c: new Blob(['photo'], { type: 'image/jpeg' }) };
const types = Object.fromEntries(Object.entries(blobs).map(([k, b]) => [k, b.type]));
const J = (o) => new Blob([JSON.stringify(o)], { type: 'application/json' });
const mgr = () => new BackupManager({ storage: { keys: async () => Object.keys(blobs), get: async (k) => blobs[k] }, zipProvider: () => Z });

// 1. archive écrite par le moteur historique (format de fullBackup)
const legacy = await buildStoredZip([{ name: 'data.json', blob: J(data) }, ...Object.entries(blobs).map(([k, b]) => ({ name: 'blobs/' + k, blob: b })), { name: 'types.json', blob: J(types) }]);
const z = await JSZip.loadAsync(await legacy.arrayBuffer(), { checkCRC32: true });   // CRC vérifiés
assert.equal(await z.file('blobs/pdf_a').async('string'), '%PDF-1.4 test');
const rep = await mgr().inspectArchive(new File([legacy], 'carnet-sauvegarde.zip'));
assert.equal(rep.valid, true); assert.equal(rep.mediaCount, 3); assert.equal(rep.types.pdf_a, 'application/pdf');

// 2. archive créée par le BackupManager : mêmes noms d'entrées que le format historique, relisible
const made = await mgr().createArchive(data);
const z2 = await JSZip.loadAsync(await made.arrayBuffer());
assert.deepEqual(Object.keys(z2.files).sort(), ['blobs/', 'blobs/img_b', 'blobs/pdf_a', 'blobs/pjp_c', 'data.json', 'types.json']);
assert.equal(JSON.parse(await z2.file('data.json').async('string')).v, 1);

// 3. ancienne archive sans types.json : toujours acceptée
const old = await buildStoredZip([{ name: 'data.json', blob: J(data) }, ...Object.entries(blobs).map(([k, b]) => ({ name: 'blobs/' + k, blob: b }))]);
assert.equal((await mgr().inspectArchive(new File([old], 'ancienne.zip'))).mediaCount, 3);

// 4. archives invalides : refusées avant toute restauration
const noMedia = await buildStoredZip([{ name: 'data.json', blob: J(data) }, { name: 'blobs/pdf_a', blob: blobs.pdf_a }]);
await assert.rejects(() => mgr().inspectArchive(new File([noMedia], 'x.zip')), /Archive incomplète : 2 média/);
const noData = await buildStoredZip([{ name: 'blobs/pdf_a', blob: blobs.pdf_a }]);
await assert.rejects(() => mgr().inspectArchive(new File([noData], 'partie-2.zip')), /data\.json est absent/);
const v2 = await buildStoredZip([{ name: 'data.json', blob: J({ ...data, v: 2 }) }]);
await assert.rejects(() => mgr().inspectArchive(new File([v2], 'v2.zip')), /non pris en charge/);
await assert.rejects(() => mgr().inspectArchive(new File([new Blob(['pas un zip'])], 'x.zip')));
console.log('Phase 2.8 : format de sauvegarde v1 validé avec JSZip réel.');
