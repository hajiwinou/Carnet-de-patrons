// Phase 3.10 — module PDF Reader : calculs purs équivalents au code d'app.js (DOM simulé), hôte absent / engagé
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPdfReaderHost } from '../dreamOS/pdf-reader/pdf-reader-host.js';
import { createPdfReaderEngine } from '../dreamOS/pdf-reader/pdf-reader-engine.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (n) => { const m = app.match(new RegExp('\\n  function ' + n + '\\([^\\n]*\\n[\\s\\S]*?\\n  \\}\\n')); assert.ok(m, 'fonction introuvable : ' + n); return m[0]; };
const NAMES = ['pageLabel', 'vCurPage', 'noteCtx', 'vrcFmt', 'vrcStat', 'vrcPlace', 'setZoom', 'sheetVsh', 'sheetSize', 'vOvPage', 'vRestore', 'vposNow'];
const src = app.match(/  function pdfHost\(\)[^\n]*\n/)[0] + NAMES.map(grab).join('\n');
const build = new Function('window', '$', 'V', 'VRC', 'SHEET', 'load', 'keep', 'document', 'vRerender', `${src}\nreturn { ${NAMES.join(', ')} };`);

// DOM simulé (enregistre ce que le code écrit)
function el(o = {}) { const e = { hidden: false, textContent: '', innerHTML: '', style: { props: {}, setProperty(k, v) { this.props[k] = v; } }, classList: { s: new Set(), add(c) { this.s.add(c); }, remove(c) { this.s.delete(c); } }, offsetWidth: 0, offsetHeight: 0, clientWidth: 0, clientHeight: 0, scrollTop: 0, scrollLeft: 0, scrollWidth: 1, scrollHeight: 1, getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 100 }), querySelector() { return e.ov; }, ...o }; return e; }
function world(withHost, st) {
  const win = { innerHeight: 800 }; const dom = { '#vscroll': el(st.scroll), '#vpage': el(), '#vrcSt': el(), '#vrc': el(st.vrc), '#viewer': el(st.viewer) };
  const V = { pages: st.pages.map((p) => ({ el: el({ offsetTop: p.top, offsetHeight: p.h, ov: el() }) })), pdf: st.pdf, zoom: st.zoom, id: 'd1', hl: st.hl, mark: st.mark, sm: st.sm };
  const VRC = { pr: st.pr }, SHEET = { page: st.page, snap: 'half' }; const kept = {}; const timers = [];
  const doc = { getElementById: () => (st.sheetBottom == null ? null : { style: { bottom: st.sheetBottom } }) };
  const fns = build(win, (s) => dom[s], V, VRC, SHEET, (k, d) => st.stored ?? d, (k, v) => { kept[k] = v; }, doc, () => {});
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPdfReaderHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); assert.equal(reg.ownerOf('logic', 'pdf-reader-engine'), 'pdf-reader'); }
  return { fns, dom, V, VRC, SHEET, kept };
}
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o));
let checks = 0;
const snap = (w) => JSON.stringify({ dom: Object.fromEntries(Object.entries(w.dom).map(([k, e]) => [k, { h: e.hidden, t: e.textContent, i: e.innerHTML, st: e.style, c: [...e.classList.s], sl: e.scrollTop }])), pages: w.V.pages.map((p) => p.el.ov.innerHTML), zoom: w.V.zoom, snapv: w.SHEET.snap, kept: w.kept });
const origRun = (w, f, args) => { try { return JSON.stringify(w.fns[f](...args)); } catch (e) { return 'ERR ' + e.constructor.name; } };
function scenario(seed) {
  const r = rng(seed), n = (a, b) => a + Math.floor(r() * (b - a + 1)), pick = (a) => a[Math.floor(r() * a.length)];
  const np = r() < .1 ? 0 : n(1, 8); let top = 0; const pages = Array.from({ length: np }, () => { const t = top; const h = pick([0, 300, 800, 1000]); top += h + 10; return { top: t, h }; });
  const rects = () => Array.from({ length: n(0, 3) }, () => ({ x0: r(), y0: r(), x1: r(), y1: r() }));
  const hl = {}; for (let i = 0; i < np; i++) if (r() < .6) hl[i] = rects();
  const sm = r() < .7 ? {} : undefined; if (sm) for (let i = 0; i < np; i++) if (r() < .5) sm[i] = [{ x: r(), y: r() }, { x: r(), y: r() }];
  const rts = r() < .2 ? undefined : Array.from({ length: n(0, 30) }, (_, i) => 1e9 + i * pick([200, 3000, 60000, 5e5, 9e5, 1e6, 5e6]) + n(0, 999));
  return { pages, hl, sm, mark: r() < .5 && np ? { i: n(0, np - 1), y: r() } : null, stored: r() < .5 && np ? { i: n(0, np - 1), f: r() } : undefined, pdf: r() < .9 ? {} : null, zoom: pick([1, 1.5, 3.99]), page: pick([undefined, 0, 2, 7]),
    scroll: { scrollTop: n(0, 6000), clientHeight: pick([0, 400, 700]), scrollWidth: pick([0, 500]), scrollHeight: pick([0, 3000]) },
    vrc: { offsetWidth: pick([0, 60, 120]), offsetHeight: pick([0, 60]) }, viewer: { clientWidth: pick([0, 320, 800]), clientHeight: pick([0, 500, 900]), offsetHeight: 0 }, sheetBottom: pick([null, '0px', '12.5px', 'x']),
    pr: r() < .15 ? null : { rts, rows: pick([0, 5, 40, undefined]), rowsTotal: pick([0, 10, 40, 100, undefined]) } };
}
for (let seed = 1; seed <= 1500; seed++) {
  const st = scenario(seed), r = rng(seed + 99);
  const A = world(false, clone(st)), B = world(true, clone(st));
  const S2 = (w) => w;
  for (const [f, args] of [['pageLabel', []], ['vCurPage', []], ['vrcFmt', [Math.floor(r() * 1e7)]], ['vrcFmt', [59499]], ['vrcFmt', [59500]], ['vrcFmt', [60000 * 9 + 30000]], ['vrcFmt', [3600000]], ['noteCtx', [{ rows: 3 }]], ['noteCtx', [null]], ['noteCtx', [{ rows: 0 }]], ['vrcStat', []],
    ['vrcPlace', [{ x: r(), y: r() }]], ['vrcPlace', [{ x: 'a' }]], ['vrcPlace', [null]], ['setZoom', [r() * 6]], ['setZoom', [1]], ['setZoom', [0.1]], ['setZoom', [9]],
    ['sheetSize', [{ style: {}, offsetHeight: 200 }, 'compact']], ['sheetSize', [{ style: {}, offsetHeight: 200 }, 'full']], ['sheetSize', [{ style: {}, offsetHeight: 200 }, 'half']]]) {
    // arguments clonés par monde ; window.innerHeight simulé
    A.fns && (globalThis.window = { innerHeight: 800 });
    const aa = clone(args), ab = clone(args);
    const ra = origRun(A, f, aa), rb = origRun(B, f, ab); assert.equal(rb, ra, `${f} seed ${seed}`);
    assert.deepEqual(clone(ab), clone(aa), `${f} arg muté ${seed}`);
    assert.equal(snap(B), snap(A), `état ${f} seed ${seed}`); checks += 3;
  }
  for (const i of [0, 1, 2, 5, 9]) { for (const w of [A, B]) { try { w.fns.vOvPage(i); } catch (e) {} } assert.equal(snap(B), snap(A), `vOvPage ${i} seed ${seed}`); checks++; }
  for (const f of ['vRestore', 'vposNow']) { let ea = '', eb = ''; try { A.fns[f](); } catch (e) { ea = e.constructor.name; } try { B.fns[f](); } catch (e) { eb = e.constructor.name; } assert.equal(eb, ea, f + ' err'); assert.equal(snap(B), snap(A), `${f} seed ${seed}`); checks++; }
}
// moteur seul == code d'origine (hôte absent) sur les entrées d'origine
const eng = createPdfReaderEngine(); const W0 = world(false, scenario(7));
for (const ms of [0, 999, 1000, 59499, 59500, 60000, 61000, 599999, 3599999, 3600000, 7322000, 1e8]) assert.equal(eng.vrcFmt(ms), W0.fns.vrcFmt(ms), 'vrcFmt ' + ms);
assert.equal(eng.vrcFmt(61000), '1 min 01'); assert.equal(eng.vrcFmt(600000), '10 min'); assert.equal(eng.vrcFmt(3600000), '1 h 00'); assert.equal(eng.vrcFmt(59000), '59 s');
const many = [0]; for (let i = 1; i <= 25; i++) many.push(many[i - 1] + i * 1000);
assert.equal(eng.vrcStatText({ rts: many, rows: 1, rowsTotal: 2 }), (() => { const iv = many.slice(1).map((v, i) => v - many[i]).slice(-20); const avg = iv.reduce((a, b) => a + b, 0) / 20; return '⏱ ' + eng.vrcFmt(avg) + ' / rang · reste ≈ ' + eng.vrcFmt(avg); })());
assert.equal(W0.fns.vrcStat && 1, 1); { const w = world(false, { ...scenario(5), pr: { rts: many, rows: 1, rowsTotal: 2 } }); const w2 = world(true, { ...scenario(5), pr: { rts: many, rows: 1, rowsTotal: 2 } }); w.fns.vrcStat(); w2.fns.vrcStat(); assert.equal(w2.dom['#vrcSt'].textContent, w.dom['#vrcSt'].textContent); assert.ok(w.dom['#vrcSt'].textContent.includes('16 s')); }
// seuils dirigés
assert.equal(eng.vrcStatText({ rows: 3, rowsTotal: 10 }), '3 / 10 rangs'); assert.equal(eng.vrcStatText({}), '');
assert.equal(eng.vrcStatText({ rts: [0, 60000, 120000], rows: 10, rowsTotal: 10 }), '⏱ 1 min / rang · terminé 🎉');
assert.equal(eng.vrcStatText({ rts: [0, 60000, 120000], rows: 8, rowsTotal: 10 }), '⏱ 1 min / rang · reste ≈ 2 min');
assert.equal(eng.vrcStatText({ rts: [0, 899999] }), '⏱ 15 min / rang');
assert.equal(eng.vrcStatText({ rts: [0, 900000] }), ''); // intervalle ≥ 15 min ignoré
assert.equal(eng.clampZoom(0.5), 0.6); assert.equal(eng.clampZoom(5), 4); assert.equal(eng.clampZoom(2), 2);
assert.deepEqual(eng.sheetHeights(1000, 'compact'), { height: '', maxHeight: '600px' }); assert.deepEqual(eng.sheetHeights(1000, 'full'), { height: '900px', maxHeight: '' }); assert.deepEqual(eng.sheetHeights(1000, 'half'), { height: '520px', maxHeight: '' });
assert.equal(eng.noteCtxText(true, 0, 5), 'p. 1 · rang 5'); assert.equal(eng.noteCtxText(false, 3, 0), '');
assert.equal(eng.pageIndexAt([0, 100, 200], 150, 0), 1); assert.equal(eng.pageIndexAt([50], 10, 0), 0); assert.equal(eng.pageLabelText(2, 0), '');
// relâché → code d'origine ; garde-fou
{ const w = world(true, scenario(3)); globalThis.window = { innerHeight: 800 }; }
const code = fs.readFileSync(path.join(root, 'dreamOS/pdf-reader/pdf-reader-engine.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g, '');
for (const bad of [/localStorage/, /indexedDB/, /\bdocument\b/, /\bwindow\b/, /\bfetch\(/, /\$\(/]) assert.ok(!bad.test(code), 'accès interdit : ' + bad);
console.log('phase3_10 OK —', checks, 'comparaisons');
