// Phase 3.2 — carte des actions et routeur
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { ACTION_MAP } from '../dreamOS/modules/action-map.js';
import { createActionRouter } from '../dreamOS/modules/action-router.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const text = fs.readFileSync(path.join(root, 'app.js'), 'utf8') + fs.readFileSync(path.join(root, 'index.html'), 'utf8');

// 1. toute action utilisée dans les gabarits ou testée par le gestionnaire est dans la carte (et inversement)
const tpl = [...text.matchAll(/data-act=\\?"([A-Za-z0-9_]+)/g)].map((m) => m[1]);
const hdl = [...text.matchAll(/\ba ?(?:===|==) ?'([A-Za-z0-9_]+)'/g)].map((m) => m[1]);
const used = new Set([...tpl, ...hdl]);
assert.deepEqual([...used].filter((a) => !(a in ACTION_MAP)), [], 'actions sans module');
assert.deepEqual(Object.keys(ACTION_MAP).filter((a) => !used.has(a)), [], 'actions de la carte absentes du code');
// 2. modules valides
const valid = new Set([...MODULE_MANIFEST.map((m) => m.name), 'engine', 'dialogs']);
for (const [a, m] of Object.entries(ACTION_MAP)) assert.ok(valid.has(m), `${a} → module inconnu ${m}`);
// 3. routeur
const bus = new EventBus(); const seen = []; bus.on('action:dispatched', (e) => seen.push(e));
const r = createActionRouter({ eventBus: bus });
assert.equal(r.moduleFor('tmToggle'), 'projects'); assert.equal(r.moduleFor('nope'), null);
assert.equal(r.dispatch('tmToggle', {}), false, 'inerte par défaut : laisse passer à app.js');
assert.deepEqual(seen.at(-1), { action: 'tmToggle', module: 'projects', handled: false });
assert.throws(() => r.claim('tools', 'tmToggle', () => {}), /appartient au module/);
assert.throws(() => r.claim('projects', 'inconnue', () => {}), /inconnue/);
let n = 0; const off = r.claim('projects', 'tmToggle', () => { n++; });
assert.throws(() => r.claim('projects', 'tmToggle', () => {}), /déjà revendiquée/);
assert.equal(r.dispatch('tmToggle', {}), true); assert.equal(n, 1);
off(); assert.equal(r.dispatch('tmToggle', {}), false, 'retour arrière possible');
r.claim('projects', 'tmReset', () => { throw new Error('boum'); });
const errs = []; bus.on('action:error', (e) => errs.push(e)); assert.equal(r.dispatch('tmReset', {}), true); assert.equal(errs[0].message, 'boum');
// 4. branchement DOM simulé : capture, [data-stop], arrêt de la propagation seulement si traité
const listeners = {}; const target = { addEventListener: (t, f, c) => { listeners[t] = [f, c]; }, removeEventListener: (t) => { delete listeners[t]; } };
const r2 = createActionRouter({ target, eventBus: bus }).start();
assert.equal(listeners.click[1], true, 'phase de capture');
const mk = (act, stop) => { const el = { dataset: { act, id: 'x' }, closest: (s) => (s === '[data-act]' ? el : null) }; let stopped = 0, prevented = 0;
  return { ev: { target: { closest: (s) => (s === '[data-stop]' ? (stop ? {} : null) : el) }, stopImmediatePropagation: () => stopped++, preventDefault: () => prevented++ }, get stopped() { return stopped; } }; };
let hit = 0; r2.claim('library', 'lbNext', (c) => { hit += c.id === 'x' ? 1 : 0; });
let c1 = mk('lbPrev'); listeners.click[0](c1.ev); assert.equal(c1.stopped, 0, 'non revendiquée : app.js garde la main');
let c2 = mk('lbNext'); listeners.click[0](c2.ev); assert.equal(c2.stopped, 1); assert.equal(hit, 1);
let c3 = mk('lbNext', true); listeners.click[0](c3.ev); assert.equal(c3.stopped, 0); assert.equal(hit, 1, 'data-stop respecté');
r2.dispose(); assert.ok(!listeners.click);
// 5. app.js n'utilise pas le routeur
assert.ok(!/actionRouter|ACTION_MAP/.test(fs.readFileSync(path.join(root, 'app.js'), 'utf8')));
console.log('phase3_2 : OK');
