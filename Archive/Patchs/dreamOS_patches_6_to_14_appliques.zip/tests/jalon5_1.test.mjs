// Jalon 5.1 : thème chargé dans l'app sans changement visuel.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=f=>fs.readFileSync(f,'utf8');
const idx=read('index.html'), sw=read('sw.js');
const pos=s=>idx.indexOf(s);
assert.ok(pos('theme/tokens.css')>0 && pos('theme/fonts.css')>0, 'thème chargé');
assert.ok(pos('theme/tokens.css')<pos('href="styles.css"'), 'tokens AVANT styles.css (l\'ancien CSS garde la priorité)');
assert.ok(pos('theme/fonts.css')<pos('href="styles.css"'));
assert.equal(idx.includes('theme/components.css'), false, 'components.css pas encore chargé (1er écran converti)');
assert.ok(pos('styles-late.css')>pos('styles.css') && pos('themes.css')>pos('styles-late.css'), 'ordre ancien CSS inchangé');
assert.equal((idx.match(/theme\/tokens\.css/g)||[]).length,1);
assert.match(sw,/atelier-tricot-v42/);
for(const f of ['theme/tokens.css','theme/fonts.css']) assert.ok(new RegExp("'"+f.replace('.','\\.')+"'").test(sw), f+' en précache');
// l'app ne pose jamais data-theme="bliss" (sinon la spécificité inverserait la priorité)
assert.equal(/setAttribute\('data-theme',\s*'bliss'/.test(read('app.js')),false);
// noms communs : l'ancien CSS les redéfinit bien sur :root
const tk=new Set([...read('theme/tokens.css').matchAll(/^\s*(--[a-z0-9-]+)\s*:/gm)].map(m=>m[1]));
const old=read('styles.css'); const common=[...tk].filter(n=>new RegExp('^\\s*'+n+'\\s*:','m').test(old));
assert.ok(common.length>=7);
console.log('jalon5_1 OK ('+common.length+' noms communs, priorité ancienne)');
