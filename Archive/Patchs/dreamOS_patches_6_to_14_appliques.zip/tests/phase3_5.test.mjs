// Phase 3.5 — module Tools : chronomètre et compteur de rangs équivalents au code historique (fuzzing)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installToolsHost } from '../dreamOS/tools/tools-host.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const A = grab(/function toolsHost\(\)[\s\S]*?saveProjects\(\); render\(\);\n  \}\n/, 'toolsHost..tmToggle');
const B = grab(/function subAdvance[\s\S]*?(?=\n  function askGoal)/, 'subAdvance/rowsApply');
const PDFH = 'function pdfHost() { return null; }\nfunction pjEnsureTimer(pr) { if (!pr.timer) pr.timer = { acc: 0, start: 0 }; }\n';
const C = PDFH + grab(/function vrcFmt[\s\S]*?(?=\n  function vrcPlace)/, 'vrcFmt/vrcStat');
const build = new Function('S', 'pjStageOf', 'setPjStage', 'saveProjects', 'render', 'toast', 'Date', 'window', '$', 'VRC',
  `${A}\n${B}\n${C}\nreturn { tmMs, tmTotal, tmFmt, tmShort, tmLogMs, tmToggle, subAdvance, rowsApply, vrcFmt, vrcStat };`);

// PRNG déterministe
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
function world(seed, withHost) {
  const r = rng(seed); let clock = 1_700_000_000_000; const log = [];
  const fakeDate = { now: () => clock };
  const projects = Array.from({ length: 4 }, (_, i) => ({ id: 'j' + i, stage: ['attente', 'wip', 'termine'][Math.floor(r() * 3)], rows: Math.floor(r() * 30), rowsTotal: r() < 0.5 ? 0 : 50 + Math.floor(r() * 100),
    timer: r() < 0.6 ? { acc: Math.floor(r() * 1e6), start: r() < 0.3 ? clock - Math.floor(r() * 5e5) : 0 } : undefined,
    sub: r() < 0.5 ? { target: 5 + Math.floor(r() * 20), n: Math.floor(r() * 5), at: 1 } : null,
    log: r() < 0.5 ? [{ id: 'e1', ms: 60000 }, { id: 'e2', text: 'Temps tricoté : 1:02:03 ...' }, { id: 'e3', text: 'autre' }] : [], rts: r() < 0.5 ? [clock - 90000, clock - 60000, clock - 30000] : undefined }));
  const S = { projects };
  const pjStageOf = (pr) => (pr.stage === 'wip' || pr.stage === 'termine' ? pr.stage : 'attente');
  const setPjStage = (pr, st) => { log.push('stage:' + pr.id + ':' + st); pr.stage = st; };
  const win = {}; const vrcEls = {}; const $ = (sel) => (vrcEls[sel] ||= { hidden: false, textContent: '' }); const VRC = { pr: null };
  const fns = build(S, pjStageOf, setPjStage, () => log.push('save'), () => log.push('render'), (m) => log.push('toast:' + m), fakeDate, win, $, VRC);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installToolsHost({ moduleRegistry: reg, legacy: null, eventBus: new EventBus(), win, now: fakeDate.now }); h.engage(); assert.equal(reg.ownerOf('logic', 'row-counter'), 'tools'); }
  return { r, projects, fns, log, tick: (ms) => { clock += ms; }, VRC, $ };
}
let ops = 0;
for (let seed = 1; seed <= 150; seed++) {
  const a = world(seed, false); const b = world(seed, true);
  for (let step = 0; step < 60; step++) {
    const dt = Math.floor(a.r() * 120000); b.r(); a.tick(dt); b.tick(dt);
    const i = Math.floor(a.r() * 4); b.r(); const kind = a.r(); b.r(); const arg = [1, 1, 1, -1, 5, -3, 0, 12][Math.floor(a.r() * 8)]; b.r();
    const res = [a, b].map((w) => {
      const pr = w.projects[i];
      if (kind < 0.3) return w.fns.tmToggle(pr);
      if (kind < 0.7) return w.fns.rowsApply(pr, arg);
      if (kind < 0.8) return w.fns.subAdvance(pr, arg);
      if (kind < 0.9) { pr.sub = { target: 3 + Math.abs(arg), n: 0, at: 1 }; return null; }
      return [w.fns.tmMs(pr), w.fns.tmTotal(pr), w.fns.tmFmt(w.fns.tmTotal(pr)), w.fns.tmShort(w.fns.tmTotal(pr)), w.fns.tmShort(dt), w.fns.tmFmt(dt * 97)];
    });
    const where = `seed ${seed} pas ${step} op ${kind.toFixed(2)} arg ${arg} projet ${i}`;
    assert.deepEqual(res[1], res[0], `résultat : ${where}`);
    assert.deepEqual(b.projects, a.projects, `projets : ${where}`);
    assert.deepEqual(b.log, a.log, `effets de bord (étape, toast, save, render) : ${where}`);
    ops++;
  }
  // estimation du rythme : le service reproduit vrcStat
  for (const w of [a, b]) { w.VRC.pr = w.projects[0]; w.fns.vrcStat(); }
  assert.deepEqual(b.$('#vrcSt'), a.$('#vrcSt'));
  const pace = b.fns && (await import('../dreamOS/tools/row-counter.js')).createRowCounter().pace(a.projects[0]);
  const f = a.fns.vrcFmt; const pr = a.projects[0];
  const expected = pace.avgMs ? '⏱ ' + f(pace.avgMs) + ' / rang' + (pace.total > pace.rows ? ' · reste ≈ ' + f(pace.remainingMs) : pace.total ? ' · terminé 🎉' : '') : (pace.total ? pace.rows + ' / ' + pace.total + ' rangs' : '');
  assert.equal(a.$('#vrcSt').textContent, expected, `pace() vs vrcStat, seed ${seed}`);
}
// cas dirigé : plus de 40 rangs d'affilée (le fuzzing n'atteint pas la limite des 40 horodatages) + annulations
for (const seed of [7, 8]) {
  const a = world(seed, false); const b = world(seed, true);
  for (const w of [a, b]) { w.projects[0].rts = undefined; w.projects[0].rows = 0; w.projects[0].sub = null; }
  for (let k = 0; k < 55; k++) { a.tick(1000); b.tick(1000); a.fns.rowsApply(a.projects[0], 1); b.fns.rowsApply(b.projects[0], 1); }
  assert.equal(a.projects[0].rts.length, 40); assert.deepEqual(b.projects[0], a.projects[0]);
  for (let k = 0; k < 45; k++) { a.fns.rowsApply(a.projects[0], -1); b.fns.rowsApply(b.projects[0], -1); }
  assert.deepEqual(b.projects[0], a.projects[0]); assert.equal(a.projects[0].rows, 10);
  a.fns.rowsApply(a.projects[0], 0); b.fns.rowsApply(b.projects[0], 0); assert.deepEqual(b.projects[0], a.projects[0]);
}
// formats : valeurs limites identiques
const w = world(1, false); const w2 = world(1, true);
for (const ms of [0, 1, 999, 59999, 60000, 61000, 3599999, 3600000, 36000000, 86399999, 360000000]) {
  assert.equal(w2.fns.tmFmt(ms), w.fns.tmFmt(ms)); assert.equal(w2.fns.tmShort(ms), w.fns.tmShort(ms));
}
// propriété et retour arrière
const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {};
const host = installToolsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win });
assert.equal(host.enabled, false); assert.equal(reg.ownerOf('logic', 'stopwatch'), 'legacy');
host.engage(); assert.equal(reg.ownerOf('logic', 'stopwatch'), 'tools'); host.release(); assert.equal(reg.ownerOf('logic', 'stopwatch'), 'legacy');
// garde-fous sur app.js
assert.equal((app.match(/DreamOSToolsHost/g) || []).length, 1);
assert.ok(!/tools-host|stopwatch\.js|row-counter/.test(app), 'app.js n’importe aucun module ES');
console.log(`phase3_5 : OK (${ops} opérations aléatoires comparées, hôte absent vs engagé)`);
