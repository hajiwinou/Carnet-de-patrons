// Jalon 4.1 — Documentation devient propriétaire de carnet.docs : une seule autorité d'écriture, équivalence avec le code d'origine
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installDocumentationHost } from '../dreamOS/documentation/documentation-host.js';
import { createDocumentationStore } from '../dreamOS/documentation/documentation-store.js';
import { createDocumentationMedia } from '../dreamOS/documentation/documentation-media.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const helperSrc = app.match(/  function docsStore\(\)[\s\S]*?\n  function docmDiscard[^\n]*\n/)[0];

// 1. garde-fou statique : aucune écriture sur S.docs ni sur carnet.docs hors des fonctions de la porte unique
const outside = app.replace(helperSrc, '');
const writes = outside.match(/S\.docs\s*=[^=]|S\.docs\.(unshift|splice|push|pop|shift|sort|reverse|fill|copyWithin)\b|keep\(\s*'carnet\.docs'/g) || [];
assert.deepEqual(writes, [], 'écriture directe sur les articles hors de docsStore/saveDocs/docsAdd/docsRemoveAt/docsInsertAt/docsReplace');
assert.ok(!/S\.docs\s*=[^=]/.test(app.replace(helperSrc, '').replace(/docs: load\('carnet\.docs'/, '')), 'réassignation directe');

// 1b. points d'entrée de données : l'import ZIP enregistre aussitôt, la fusion de sauvegarde enregistre via saveDocs() final, le démarrage n'écrit pas
assert.ok(app.includes("docsReplace(JSON.parse(await docEntry.async('string')), true)"), 'restauration ZIP : enregistrement attendu');
assert.ok(app.includes('docsReplace(mergeById(S.docs, data.docs));') && /saveFolders\(\); saveDocs\(\); saveIdeas\(\); persist\(\);/.test(app), 'fusion de sauvegarde');
assert.ok(app.includes("if(k==='docs') docsReplace(JSON.parse(raw));"), 'restauration miroir IndexedDB');
// 1c. médias d'articles : plus aucune écriture ni identifiant docm_ hors de la porte unique
assert.deepEqual(outside.match(/saveBlob\(\s*mid\b|IDB\.del\(\s*m\.id\s*\)/g) || [], [], 'écriture / suppression directe de média d\'article');
assert.equal(outside.split('\n').filter((l) => l.includes('docm_')).length, 2, "références docm_ hors de la porte unique : seules les étiquettes de sauvegarde et la détection d'archive sont admises");
// 2. propriété dans le registre
{ const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const win = {};
  assert.equal(reg.ownerOf('storage', 'carnet.docs'), 'legacy');
  const h = installDocumentationHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win });
  h.engage(); assert.equal(reg.ownerOf('media', 'docm_*'), 'documentation'); assert.equal(reg.ownerOf('storage', 'carnet.docs'), 'documentation'); assert.equal(reg.ownerOf('logic', 'documentation-engine'), 'documentation');
  assert.throws(() => reg.transferOwnership('storage', 'carnet.docs', 'legacy', 'tools'), /transfert refusé/);
  h.release(); assert.equal(reg.ownerOf('media', 'docm_*'), 'legacy'); assert.equal(reg.ownerOf('storage', 'carnet.docs'), 'legacy'); h.engage(); assert.equal(reg.ownerOf('storage', 'carnet.docs'), 'documentation'); }

// 3. magasin : référence partagée, écriture unique par opération, événements
{ const arr = [{ id: 'a' }]; const writes2 = []; const bus = new EventBus(); const ev = []; ['added', 'removed', 'restored', 'replaced', 'saved'].forEach((t) => bus.on?.('documentation:' + t, (p) => ev.push([t, p])));
  const st = createDocumentationStore({ eventBus: bus }); assert.throws(() => st.add({}), /aucun tableau/); assert.equal(st.adopted, false);
  st.adopt(arr, (x) => writes2.push(JSON.stringify(x))); assert.equal(st.list(), arr);
  const bus2 = new EventBus(); const seen = []; ['added', 'removed', 'restored', 'replaced', 'saved'].forEach((t) => bus2.on('documentation:' + t, (p) => seen.push(t + ':' + p.count)));
  const st2 = createDocumentationStore({ eventBus: bus2 }); st2.adopt([], () => {}); st2.add({ id: 'e' }); st2.removeAt(0); assert.deepEqual(seen, ['saved:1', 'added:1', 'saved:0', 'removed:0']);
  st.add({ id: 'b' }); assert.deepEqual(arr.map((x) => x.id), ['b', 'a']); assert.equal(writes2.length, 1);
  assert.equal(st.removeAt(0).id, 'b'); assert.equal(writes2.length, 2); assert.equal(st.removeAt(9), undefined); assert.equal(writes2.length, 3);
  st.insertAt(99, { id: 'z' }); assert.deepEqual(arr.map((x) => x.id), ['a', 'z']); st.insertAt(0, { id: 'y' }); assert.deepEqual(arr.map((x) => x.id), ['y', 'a', 'z']);
  const w = writes2.length; st.replaceAll([{ id: 'q' }]); assert.equal(writes2.length, w); assert.equal(st.list(), arr); assert.deepEqual(arr.map((x) => x.id), ['q']);
  st.replaceAll([{ id: 'r' }], true); assert.equal(writes2.length, w + 1); st.replaceAll(null); assert.equal(arr.length, 0);
  const bad = createDocumentationStore({ eventBus: { emit() { throw new Error('abonné défaillant'); } } }); const a2 = []; let n = 0; bad.adopt(a2, () => n++); bad.add({ id: 1 }); assert.equal(a2.length, 1); assert.equal(n, 1);
  assert.throws(() => st.adopt('x'), /tableau requis/); }

// 4. équivalence : séquences aléatoires d'opérations, hôte absent / engagé / bascule en cours de route
const build = new Function('window', 'S', 'keep', 'uid', 'saveBlob', 'IDB', `${helperSrc}\nreturn { docsStore, saveDocs, docsAdd, docsRemoveAt, docsInsertAt, docsReplace, docmNewId, docmSave, docmDiscard };`);
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o));
function world(mode, init) {
  const win = {}, S = { docs: clone(init) }, log = [];
  let un = 0; const f = build(win, S, (k, v) => log.push([k, JSON.stringify(v)]), () => 'u' + (++un), async (id, b) => { log.push(['blob', id, b]); return id; }, { del: (id) => log.push(['idbdel', id]) });
  let host = null;
  if (mode !== 'legacy') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); host = installDocumentationHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); host.engage(); }
  return { f, S, log, host, win };
}
const doc = (r, i) => ({ id: 'd' + i + Math.floor(r() * 99), title: 'T' + i, category: 'Technique', content: '', media: [], created: i });
let checks = 0;
for (let seed = 1; seed <= 800; seed++) {
  const r = rng(seed), init = Array.from({ length: Math.floor(r() * 5) }, (_, i) => doc(r, i));
  const A = world('legacy', init), B = world('host', init), C = world('host', init);
  for (let step = 0; step < 14; step++) {
    const op = Math.floor(r() * 8), i = Math.floor(r() * 7), d = doc(r, 100 + step), rep = Array.from({ length: Math.floor(r() * 4) }, (_, k) => doc(r, 200 + k)), sv = r() < .5;
    for (const w of [A, B, C]) {
      if (op === 0) w.f.docsAdd(clone(d)); else if (op === 1) w.f.docsRemoveAt(i); else if (op === 2) w.f.docsInsertAt(i, clone(d));
      else if (op === 3) w.f.docsReplace(clone(rep), sv); else if (op === 4) w.f.saveDocs();
      else if (op === 5 && w === C && w.host) { w.host.release(); w.host.engage(); }              // bascule à chaud
      else if (op === 6 && w === C && w.host) { w.host.release(); }                                  // retour arrière en cours de route
      else if (op === 7 && w !== A) { /* réassignation « sauvage » du tableau : le magasin se resynchronise */ }
    }
    if (op === 6) { C.host.engage(); }
    assert.deepEqual(B.S.docs, A.S.docs, `B ≠ A (seed ${seed}, étape ${step}, op ${op})`); assert.deepEqual(C.S.docs, A.S.docs, `C ≠ A (seed ${seed}, étape ${step}, op ${op})`);
    assert.deepEqual(B.log, A.log, `écritures B ≠ A (seed ${seed}, étape ${step})`); assert.deepEqual(C.log, A.log, `écritures C ≠ A (seed ${seed}, étape ${step})`); checks += 4;
  }
}
// médias : séquences identiques hôte absent / engagé (identifiants, écritures de blobs, suppressions)
for (let seed = 1; seed <= 300; seed++) {
  const A = world('legacy', []), B = world('host', []);
  const rr = rng(seed + 7);
  for (let k = 0; k < 10; k++) {
    const op = Math.floor(rr() * 3), n = Math.floor(rr() * 4), blob = 'B' + k;
    const ra = [], rb = [];
    for (const [w, res] of [[A, ra], [B, rb]]) {
      if (op === 0) res.push(w.f.docmNewId()); else if (op === 1) { const id = w.f.docmNewId(); res.push(id, await w.f.docmSave(id, blob)); } else w.f.docmDiscard(n === 0 ? undefined : Array.from({ length: n }, (_, i) => ({ id: 'docm_x' + i, type: 'image' })));
    }
    assert.deepEqual(rb, ra, `médias résultats ${seed}/${k}`); assert.deepEqual(B.log, A.log, `médias écritures ${seed}/${k}`); checks += 2;
  }
}
// passerelle média : préfixe obligatoire, événements, référencés
{ const bus = new EventBus(), seen = []; ['saved', 'discarded'].forEach((t) => bus.on('documentation:media-' + t, (p) => seen.push(t)));
  const m = createDocumentationMedia({ eventBus: bus }); let n = 0; assert.equal(m.newId(() => 'abc'), 'docm_abc'); assert.equal(m.isOwn('docm_1'), true); assert.equal(m.isOwn('img_1'), false); assert.equal(m.isOwn(5), false);
  await assert.rejects(m.put('img_1', {}, async () => {}), /docm_/); await assert.rejects(m.put('docm_1', {}), /écriture requise/); assert.equal(await m.put('docm_1', 'b', async (id) => { n++; return id; }), 'docm_1'); assert.equal(n, 1);
  assert.equal(m.discard(undefined, () => {}), 0); assert.equal(m.discard([{ id: 'a' }, { id: 'b' }], () => n++), 2); assert.equal(n, 3); assert.throws(() => m.discard([{}], null), /suppression requise/); assert.deepEqual(seen, ['saved', 'discarded']);
  assert.deepEqual([...m.referenced([{ media: [{ id: 'docm_1' }, { id: 'img_2' }, null] }, {}, { media: [{ id: 'docm_1' }, { id: 'docm_2' }] }])].sort(), ['docm_1', 'docm_2']); assert.deepEqual([...m.referenced(null)], []);
  const bad = createDocumentationMedia({ eventBus: { emit() { throw new Error('x'); } } }); assert.equal(await bad.put('docm_9', 1, async () => 'ok'), 'ok'); }
// réassignation sauvage : S.docs remplacé → le magasin adopte le nouveau tableau, rien n'est perdu
{ const w = world('host', [{ id: 'a' }]); w.f.docsAdd({ id: 'b' }); w.S.docs = [{ id: 'zz' }]; w.f.docsAdd({ id: 'c' }); assert.deepEqual(w.S.docs.map((x) => x.id), ['c', 'zz']); assert.equal(w.f.docsStore().list(), w.S.docs); assert.equal(JSON.parse(w.log.at(-1)[1]).length, 2); }
// restauration au démarrage (restoreAuxiliary) : remplacement sans écriture
{ const w = world('host', []); w.f.docsReplace([{ id: 'r' }]); assert.equal(w.log.length, 0); assert.deepEqual(w.S.docs, [{ id: 'r' }]); }
// hôte relâché ⇒ code historique pur
{ const w = world('host', [{ id: 'a' }]); w.host.release(); assert.equal(w.f.docsStore(), null); w.f.docsAdd({ id: 'n' }); assert.deepEqual(w.S.docs.map((x) => x.id), ['n', 'a']); }
console.log('jalon4_1 OK —', checks, 'comparaisons');
