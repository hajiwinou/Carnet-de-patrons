// Phase 3.7 — module Downloads : client Cobalt équivalent au code historique (messages et appels réseau compris)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installDownloadsHost } from '../dreamOS/downloads/downloads-host.js';
import { createCobaltClient } from '../dreamOS/downloads/cobalt-client.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const block = grab(/  function dlHost\(\)[\s\S]*?(?=\n  async function igUseFile)/, 'dlHost..igHeaders/igErrMsg');
const fname = grab(/  function igFileName\(\)[^\n]*\n/, 'igFileName');
const build = new Function('S', 'location', 'fetch', 'AbortController', 'setTimeout', 'clearTimeout', 'render', 'window', `${block}\n${fname}\nreturn { igEndpoint, igIsLoopback, igNetworkCheck, igAbs, igRequest, igHeaders, igErrMsg, igFileName };`);

const attempt = async (f) => { try { return { ok: true, value: await f() }; } catch (e) { return { ok: false, name: e.name, message: e.message }; } };
const S = (endpoint, key, title, ext) => ({ igCfg: { endpoint, key }, ig: { title, ext } });
const legacyWith = (s, protocol, fetchImpl, withHost) => {
  const win = {}; const location = { protocol };
  const fns = build(s, location, fetchImpl, AbortController, setTimeout, clearTimeout, () => {}, win);
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installDownloadsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win, env: { protocol: () => location.protocol, fetch: fetchImpl } }); h.engage(); assert.equal(reg.ownerOf('logic', 'cobalt-client'), 'downloads'); }
  return fns;
};

// ---- fonctions pures
const ENDPOINTS = ['', ' ', undefined, 'localhost:9000', '127.0.0.1:9000/', 'cobalt.example.com', 'http://a.b', 'ftp://x', 'https://user:pw@x.y', 'http://192.168.1.5:9000', '10.0.0.2', 'javascript:alert(1)', 'https://x y', 'HTTPS://UP.CASE/api/', ' https://cobalt.tail1234.ts.net ', 'http://[::1]:9000'];
const HOSTS = ['localhost', 'LOCALHOST', '127.0.0.1', '127.1.2.3', '[::1]', 'example.com', '192.168.0.2', '127.0.0.1.evil.com', ''];
const PROTOS = ['https:', 'http:', 'file:'];
const KEYS = [undefined, '', '   ', 'abc', '  k e y  '];
const CODES = [undefined, '', 'error.api.auth.key.missing', 'error.api.rate_exceeded', 'error.api.content.video.private', 'error.api.content.video.age', 'error.api.service.unsupported', 'error.api.link.invalid', 'error.api.content.video.unavailable', 'error.api.fetch.empty', 'autre', 42];
const TITLES = [[undefined, undefined], ['', ''], ['Ma vidéo', 'mp4'], ['a/b:c*d?"e<f>g|h', 'webm'], ['   espaces    multiples   ', ''], ['///', 'mov'], ['ÉTÉ — tricot', 'mkv']];
for (const ep of ENDPOINTS) for (const pr of PROTOS) {
  const a = legacyWith(S(ep, ''), pr, null, false), b = legacyWith(S(ep, ''), pr, null, true);
  assert.equal(b.igEndpoint(), a.igEndpoint(), `endpoint « ${ep} »`);
  const norm = a.igEndpoint();
  for (const probe of [norm, 'http://example.com/x', 'https://u:p@x.y/', 'ftp://x', 'video.mp4', '/rel/file.mp4', 'http://localhost:9000/v']) {
    if (norm) assert.deepEqual(await attempt(() => b.igNetworkCheck(probe)), await attempt(() => a.igNetworkCheck(probe)), `networkCheck ${probe} ${pr}`);
    if (norm) assert.deepEqual(await attempt(() => b.igAbs(probe, norm)), await attempt(() => a.igAbs(probe, norm)), `absolute ${probe} ${pr}`);
  }
}
const a0 = legacyWith(S('', ''), 'https:', null, false), b0 = legacyWith(S('', ''), 'https:', null, true);
for (const h of HOSTS) assert.equal(b0.igIsLoopback(h), a0.igIsLoopback(h), `loopback « ${h} »`);
for (const k of KEYS) { const a = legacyWith(S('x', k), 'https:', null, false), b = legacyWith(S('x', k), 'https:', null, true); for (const post of [true, false]) assert.deepEqual(b.igHeaders(post), a.igHeaders(post), `headers ${k} ${post}`); }
for (const c of CODES) assert.equal(b0.igErrMsg(c), a0.igErrMsg(c), `igErrMsg ${c}`);
for (const [t, e] of TITLES) { const a = legacyWith(S('x', '', t, e), 'https:', null, false), b = legacyWith(S('x', '', t, e), 'https:', null, true); assert.equal(b.igFileName(), a.igFileName(), `fileName « ${t} »`); }

// ---- requêtes réseau simulées (mêmes appels fetch, mêmes résultats, mêmes messages)
const resp = (o) => ({ ok: o.ok !== false, status: o.status || 200, text: async () => o.text ?? '', blob: async () => new Blob(o.blobParts ?? ['x'], { type: o.type ?? 'video/mp4' }) });
const SCENARIOS = {
  jsonOk: { mode: 'json', f: () => resp({ text: JSON.stringify({ status: 'tunnel', url: 'https://x/y' }) }) },
  jsonErr: { mode: 'json', f: () => resp({ ok: false, status: 400, text: JSON.stringify({ error: { code: 'error.api.rate_exceeded' } }) }) },
  jsonErrNoCode: { mode: 'json', f: () => resp({ ok: false, status: 500, text: '{}' }) },
  notJson: { mode: 'json', f: () => resp({ text: '<html>' }) },
  blobOk: { mode: 'blob', f: () => resp({ type: 'video/mp4', blobParts: ['abcdef'] }) },
  blobEmpty: { mode: 'blob', f: () => resp({ blobParts: [], type: 'video/mp4' }) },
  blobHtml: { mode: 'blob', f: () => resp({ type: 'text/html' }) },
  blobJson: { mode: 'blob', f: () => resp({ type: 'application/json' }) },
  blobHttpErr: { mode: 'blob', f: () => resp({ ok: false, status: 404 }) },
  networkDown: { mode: 'json', f: () => { throw new TypeError('Failed to fetch'); } },
  otherError: { mode: 'json', f: () => { throw new Error('autre'); } },
  hang: { mode: 'json', timeout: 25, f: (req) => new Promise((_, rej) => req.signal.addEventListener('abort', () => { const e = new Error('aborted'); e.name = 'AbortError'; rej(e); })) },
  cloneThenOk: { mode: 'json', clone: true, f: () => resp({ text: '{"a":1}' }) },
  cloneThenHang: { mode: 'json', clone: true, timeout: 25, hangSecond: true, f: () => new Promise(() => {}) }
};
let nets = 0;
for (const [name, sc] of Object.entries(SCENARIOS)) for (const options of [undefined, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }]) {
  const run = async (withHost) => {
    const calls = []; let n = 0;
    const fetchImpl = (url, req) => { calls.push({ url, method: req.method, headers: req.headers, cache: req.cache, hasSignal: !!req.signal, body: req.body });
      n++; if (sc.clone && n === 1) { const e = new Error('x could not be cloned'); e.name = 'DataCloneError'; throw e; } return Promise.resolve(sc.f(req)); };
    const fns = legacyWith(S('https://c.example/', ''), 'https:', fetchImpl, withHost);
    const out = await attempt(() => fns.igRequest('https://c.example/api', options, SCENARIOS[name].mode, sc.timeout));
    if (out.ok && out.value instanceof Blob) out.value = { size: out.value.size, type: out.value.type };
    return { out, calls };
  };
  const a = await run(false), b = await run(true);
  assert.deepEqual(b, a, `request ${name}`); nets++;
}
// scénarios indispensables réellement exercés
assert.equal((await attempt(() => legacyWith(S('x'), 'https:', () => { throw new TypeError('x'); }, true).igRequest('u', {}, 'json'))).message.startsWith('Connexion au service impossible'), true);

// ---- propriété, retour arrière, garde-fous
const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m));
const host = installDownloadsHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win: {} });
assert.equal(host.enabled, false); assert.equal(reg.ownerOf('logic', 'cobalt-client'), 'legacy');
host.engage(); host.release(); assert.equal(reg.ownerOf('logic', 'cobalt-client'), 'legacy');
assert.equal((app.match(/DreamOSDownloadsHost/g) || []).length, 2, 'seuls dlHost (3.7) et igCfgSet (4.5) consultent l\'hôte');
assert.ok(!/downloads-host|cobalt-client/.test(app), 'app.js n’importe aucun module ES');
const code = fs.readFileSync(path.join(root, 'dreamOS/downloads/cobalt-client.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
assert.ok(!/localStorage|carnet\.igApi|console\.|IDB|indexedDB/.test(code), 'le client ne lit ni ne journalise la clé');
console.log(`phase3_7 : OK (${nets * 2} scénarios réseau, ${ENDPOINTS.length * PROTOS.length} adresses × protocoles, hôte absent vs engagé)`);
