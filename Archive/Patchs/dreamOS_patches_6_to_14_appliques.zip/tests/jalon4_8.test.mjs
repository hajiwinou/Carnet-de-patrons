// Jalon 4.8 — PDF Reader possède l'écriture de ses données (position de reprise, repère, marqueurs de marge, surlignages, compteur) (vrai code d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installPdfReaderHost, PDF_READER_RESOURCES } from '../dreamOS/pdf-reader/pdf-reader-host.js';
import { createPdfReaderCommands } from '../dreamOS/pdf-reader/pdf-reader-commands.js';
import { createPdfReaderStore, isPdfReaderKey } from '../dreamOS/pdf-reader/pdf-reader-store.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const doorBlock = grab(/  function pdfHost\(\)[^\n]*\n[\s\S]*?\n  function vrCounterMin[^\n]*\n/, 'portes');
const vposSrc = grab(/  function vposNow\(\) \{[\s\S]*?\n  \}\n/, 'vposNow');
const clickSrc = grab(/  \$\('#vscroll'\)\.addEventListener\('click', function\(e\) \{[\s\S]*?\n  \}\);\n/, 'clic lecteur');

// 1. garde-fous statiques
const outside = app.replace(doorBlock, '');
for (const [re, what] of [[/keep\('carnet\.(vpos|vmark|vsm|vhl)\./g, 'données du lecteur'], [/keep\('carnet\.vrc(Pos|Min)'/g, 'compteur'], [/\bV\.mark\s*=\s*\{/g, 'repère'], [/\bV\.mark\s*=\s*null/g, 'repère retiré'], [/\bV\.(sm|hl)\[\w+\]\s*=\s*V\./g, 'marqueurs / surlignages'], [/\bsa\.(push|splice)\(/g, 'marqueurs'], [/\ba\.(push|splice)\(L \|\|/g, 'surlignage']]) assert.deepEqual(outside.match(re) || [], [], 'hors portes : ' + what);
for (const n of ['vrKeep', 'vrCmd', 'vrToggleMark', 'vrToggleSm', 'vrToggleHl', 'vrPosValue', 'vrCounterPos', 'vrCounterMin']) assert.ok(new RegExp('function ' + n + '\\(').test(doorBlock), n);
// restauration d'une sauvegarde : écriture en bloc, reportée au Jalon 8 (une seule forme attendue)
assert.equal((app.match(/keep\(k, data\.viewer\[k\]\)/g) || []).length, 1);
for (const [re, c] of [[/vrKeep\('carnet\.vrcMin',0\);vrKeep\('carnet\.vrcPos',null\)/g, 1], [/vrKeep\('carnet\.vrcMin', vrCounterMin\(m\)\)/g, 1], [/vrKeep\('carnet\.vrcPos', vrCounterPos\(r, vb\)\)/g, 1]]) assert.equal((app.match(re) || []).length, c, String(re));
for (const k of ['carnet.vrcPos', 'carnet.vrcMin', 'carnet.vmark.*', 'carnet.vsm.*', 'carnet.vpos.*', 'carnet.vhl.*']) assert.ok(PDF_READER_RESOURCES.some(([t, n, o]) => t === 'storage' && n === k && o === 'pdf-reader'), k);

// 2. clés, magasin et commandes seuls
for (const k of ['carnet.vrcPos', 'carnet.vrcMin', 'carnet.vpos.abc', 'carnet.vmark.x', 'carnet.vsm.x', 'carnet.vhl.x']) assert.ok(isPdfReaderKey(k), k);
for (const k of ['carnet.vpos.', 'carnet.patterns', 'carnet.vposx', 'vrcPos', undefined, 'carnet.vrc']) assert.equal(isPdfReaderKey(k), false, String(k));
{ const ev = []; const st = createPdfReaderStore({ eventBus: { emit: (t, d) => ev.push([t, d.key]) } }); const w = []; st.persist('carnet.vpos.a', { i: 1 }, (k, v) => w.push([k, v])); assert.deepEqual(w, [['carnet.vpos.a', { i: 1 }]]); assert.deepEqual(ev, [['pdf-reader:persisted', 'carnet.vpos.a']]);
  assert.throws(() => st.persist('carnet.patterns', 1, () => {}), /non gérée/); assert.throws(() => st.persist('carnet.vpos.a', 1), /écriture requise/); assert.ok(Object.isFrozen(st));
  const c = createPdfReaderCommands(); assert.ok(Object.isFrozen(c));
  const V = { mark: null, sm: {}, hl: {} };
  assert.deepEqual(c.toggleMark(V, 2, 0.5, { y1: 0.55 }), { removed: false, prev: null }); assert.deepEqual(V.mark, { i: 2, y: 0.55 });
  assert.deepEqual(c.toggleMark(V, 2, 0.5, null).removed, false); assert.deepEqual(V.mark, { i: 2, y: 0.5 }); assert.equal(c.toggleMark(V, 2, 0.505, null).removed, true); assert.equal(V.mark, null);
  c.toggleMark(V, 2, 0.5, null); assert.equal(c.toggleMark(V, 3, 0.5, null).removed, false); assert.deepEqual(V.mark, { i: 3, y: 0.5 }); assert.equal(c.toggleMark(V, 3, 0.512, null).removed, false);
  assert.equal(c.toggleSideMarker(V, 1, 0.4, null), true); assert.deepEqual(V.sm, { 1: [{ x: 0.02, y: 0.4 }] }); assert.equal(c.toggleSideMarker(V, 1, 0.404, null), false); assert.deepEqual(V.sm, {});
  assert.equal(c.toggleSideMarker(V, 1, 0, { x0: 0.01, y0: 0.2, y1: 0.3 }), true); assert.deepEqual(V.sm[1], [{ x: 0.012, y: 0.25 }]);
  c.toggleHighlight(V, 0, 0.3, 0.3, null); assert.deepEqual(V.hl[0], [{ x0: 0.05, x1: 0.95, y0: 0.29, y1: 0.312 }]); c.toggleHighlight(V, 0, 0.3, 0.3, null); assert.deepEqual(V.hl[0], []); c.toggleHighlight(V, 0, 0, 0, { x0: 0.1, x1: 0.2, y0: 0, y1: 0.1 }); assert.deepEqual(V.hl[0], [{ x0: 0.1, x1: 0.2, y0: 0, y1: 0.1 }]);
  { const W = { sm: {}, hl: {} }; c.toggleSideMarker(W, 0, 0.4, null); assert.equal(c.toggleSideMarker(W, 0, 0.41, null), true); assert.equal(W.sm[0].length, 2); assert.equal(c.toggleSideMarker(W, 0, 0.4075, null), false); assert.equal(W.sm[0].length, 1);
    const H = { sm: {}, hl: { 0: [{ x0: 0.1, x1: 0.2, y0: 0, y1: 0.1 }] } }; c.toggleHighlight(H, 0, 0.215, 0.05, null); assert.equal(H.hl[0].length, 0); H.hl[0] = [{ x0: 0.1, x1: 0.2, y0: 0, y1: 0.1 }]; c.toggleHighlight(H, 0, 0.09, 0.05, null); assert.equal(H.hl[0].length, 0); H.hl[0] = [{ x0: 0.1, x1: 0.2, y0: 0, y1: 0.1 }]; c.toggleHighlight(H, 0, 0.23, 0.05, null); assert.equal(H.hl[0].length, 2); c.toggleHighlight(H, 0, 0.07, 0.05, null); assert.equal(H.hl[0].length, 1); }
  assert.deepEqual(c.readingPosition(3, 0.25), { i: 3, f: 0.25 }); assert.deepEqual(c.counterPosition({ left: 60, top: 30 }, { left: 10, top: 10, width: 100, height: 200 }), { x: 0.5, y: 0.1 }); assert.deepEqual([c.counterMin(true), c.counterMin(false)], [1, 0]); }

// 3. équivalence sur le vrai code
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const clone = (o) => JSON.parse(JSON.stringify(o)); const pick = (r, x) => x[Math.floor(r() * x.length)];
async function run(mode, st, sc) {
  const win = {}, log = []; const V = clone(st.V);
  if (mode !== 'absent') { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installPdfReaderHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); if (mode === 'hot') { h.release(); h.engage(); } }
  let handler = null; const box = { scrollTop: st.scrollTop };
  const $ = (s) => (s === '#vscroll' ? { scrollTop: box.scrollTop, addEventListener: (e, f) => { if (e === 'click') handler = f; } } : { classList: { toggle() {} } });
  V.pages = st.pages.map((pg) => ({ el: { offsetTop: pg.top, offsetHeight: pg.h, getBoundingClientRect: () => ({ left: 10, top: pg.top, width: 100, height: pg.h }) } }));
  const el = V.pages[sc.page].el; el.closest = undefined;
  const e = { clientX: sc.cx, clientY: sc.cy, target: { closest: () => (sc.noPage ? null : el) } };
  const ctx = { window: win, V, $, keep: (k, v) => log.push(['keep', k, JSON.stringify(v === undefined ? null : v)]), toast: (m) => log.push(['toast', m]), vLine: async () => sc.L, vOvPage: (i) => log.push(['ov', i]), vTools: () => log.push(['tools']) };
  const names = Object.keys(ctx);
  const body = `${doorBlock}${vposSrc}\n${clickSrc}\nif (sc.kind === 'pos') { vposNow(); } else { document.handler(e); }`;
  await new Function(...names, 'sc', 'e', 'document', body)(...names.map((k) => ctx[k]), sc, e, { get handler() { return handler; } });
  await new Promise((r) => setTimeout(r, 0));
  return JSON.stringify({ V: { mark: V.mark, hl: V.hl, sm: V.sm, tool: V.tool }, log });
}
let checks = 0;
for (let seed = 1; seed <= 250; seed++) {
  const r = rng(Math.imul(seed, 2654435761) >>> 0);
  const st = { scrollTop: pick(r, [0, 150, 600, 1200]), pages: [{ top: 0, h: 800 }, { top: 800, h: 800 }, { top: 1600, h: 800 }],
    V: { id: 'pdf1', pdf: {}, pinch: false, tool: 'x', mark: pick(r, [null, { i: 1, y: 0.5 }]), sm: pick(r, [{}, { 1: [{ x: 0.02, y: 0.4 }] }]), hl: pick(r, [{}, { 1: [{ x0: 0.1, x1: 0.9, y0: 0.45, y1: 0.55 }] }]) } };
  const L = pick(r, [null, { x0: 0.1, x1: 0.8, y0: 0.38, y1: 0.42 }, { x0: 0.005, x1: 0.3, y0: 0.48, y1: 0.52 }]);
  const cy = pick(r, [800 + 800 * 0.5, 800 + 800 * 0.4, 800 + 800 * 0.505, 800 + 800 * 0.9]), cx = pick(r, [30, 60, 100]);
  const tools = ['mark', 'sm', 'hl'];
  const scs = [...tools.map((t) => ({ kind: 'click', tool: t, page: 1, cx, cy, L })), { kind: 'pos', page: 1 }, { kind: 'noTool', page: 1, cx, cy, L, tool: '' }];
  for (const sc of scs) {
    const s2 = clone(st); if (sc.tool !== undefined) s2.V.tool = sc.tool; else if (sc.kind === 'click') s2.V.tool = sc.tool;
    const A = await run('absent', s2, sc), B = await run('engaged', s2, sc), C = await run('hot', s2, sc); assert.equal(B, A, `${sc.kind}/${sc.tool} engagé seed ${seed}`); assert.equal(C, A, `${sc.kind}/${sc.tool} relâché seed ${seed}`); checks += 2;
    const out = JSON.parse(A), keeps = out.log.filter((l) => l[0] === 'keep'), fx = (cx - 10) / 100, fy = (cy - 800) / 800;
    if (sc.kind === 'noTool') { assert.deepEqual(out.log, []); }
    if (sc.kind === 'pos') { assert.equal(keeps.length, 1); assert.equal(keeps[0][1], 'carnet.vpos.pdf1'); const ref = st.scrollTop + 90; let k = 0; st.pages.forEach((pg, i) => { if (pg.top <= ref) k = i; }); const f = Math.max(0, Math.min(1, (ref - st.pages[k].top) / Math.max(1, st.pages[k].h))); assert.deepEqual(JSON.parse(keeps[0][2]), { i: k, f }); }
    if (sc.kind === 'click' && sc.tool === 'mark') { const o = st.V.mark, rem = o && o.i === 1 && Math.abs(o.y - fy) < 0.012; assert.equal(keeps.length, 1); assert.equal(keeps[0][1], 'carnet.vmark.pdf1'); if (rem) { assert.equal(out.V.mark, null); assert.equal(keeps[0][2], 'null'); assert.equal(out.V.tool, ''); assert.deepEqual(out.log.filter((l) => l[0] === 'toast'), [['toast', 'Repère retiré · mode désactivé']]); } else { assert.deepEqual(out.V.mark, { i: 1, y: L ? L.y1 : fy }); assert.deepEqual(out.log.filter((l) => l[0] === 'toast'), [['toast', 'Repère posé et enregistré ✓']]); assert.equal(out.log.filter((l) => l[0] === 'ov').length, o ? (o.i === 1 ? 2 : 2) : 1); } }
    if (sc.kind === 'click' && sc.tool === 'sm') { assert.equal(keeps.length, 1); assert.equal(keeps[0][1], 'carnet.vsm.pdf1'); const sx = L ? Math.max(0.012, L.x0 - 0.03) : 0.02, sy = L ? (L.y0 + L.y1) / 2 : fy; const ex = (st.V.sm[1] || []).some((m) => Math.abs(m.y - sy) < 0.008); const t = out.log.find((l) => l[0] === 'toast')[1]; assert.equal(t, ex ? 'Marqueur retiré.' : 'Marqueur posé dans la marge ✓'); if (ex) assert.equal(out.V.sm[1] === undefined || out.V.sm[1].length === (st.V.sm[1] || []).filter((m) => !(Math.abs(m.y - sy) < 0.008)).length, true); else assert.ok(out.V.sm[1].some((m) => m.x === sx && m.y === sy)); }
    if (sc.kind === 'click' && sc.tool === 'hl') { assert.equal(keeps.length, 1); assert.equal(keeps[0][1], 'carnet.vhl.pdf1'); const was = (st.V.hl[1] || []), hit = was.some((h) => fy >= h.y0 && fy <= h.y1 && fx >= h.x0 - 0.02 && fx <= h.x1 + 0.02); assert.equal(out.V.hl[1].length, hit ? was.length - 1 : was.length + 1); if (!hit) assert.deepEqual(out.V.hl[1].at(-1), L || { x0: 0.05, x1: 0.95, y0: Math.max(0, fy - 0.01), y1: fy + 0.012 }); }
    checks++;
  }
}
console.log('jalon4_8 OK —', checks, 'comparaisons');
