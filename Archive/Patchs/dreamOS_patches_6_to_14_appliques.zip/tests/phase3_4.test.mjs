// Phase 3.4 — délégation de l'application de l'apparence au Theme Manager (via le vrai applyAppearance d'app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installThemeHost } from '../dreamOS/theme/theme-host.js';
import { createThemeManager } from '../dreamOS/theme/theme-manager.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
import { DREAM_PALETTES } from '../dreamOS/theme/theme-engine.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

const grab = (re) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + re); return m[0]; };
const src = [/var FONTS = \{[\s\S]*?\n  \};/, /var DREAM_PALETTES = \[[\s\S]*?\n  \];/, /function hexToRgba[\s\S]*?\n  \}\n(?=\s*applyAppearance\(\);)/].map(grab).join('\n');
const legacy = new Function('S', 'document', 'window', 'getBlobUrl', 'loadBlob', `${src}\nfunction stDreamPalette(p) { S.ui.dream = Object.assign({}, p); }\nreturn { applyAppearance };`);

const ALL = ['--dm', '--dm-ink', '--dd', '--dp', '--dpop', '--ink', '--muted', '--ink-in', '--accent', '--accent-soft', '--bg', '--surface', '--surface-alpha', '--bg-overlay', '--bg-image', '--font-body', '--font-head'];
function env(dark, withHost) {
  const style = new Map(ALL.map((v) => [v, 'initial'])); const attrs = new Map([['data-dream-palette', 'zzz'], ['data-theme', 'initial']]); const body = new Set();
  const rootEl = { style: { setProperty: (k, v) => style.set(k, v), removeProperty: (k) => style.delete(k) }, setAttribute: (k, v) => attrs.set(k, v), removeAttribute: (k) => attrs.delete(k) };
  const doc = { documentElement: rootEl, body: { classList: { add: (c) => body.add(c), remove: (c) => body.delete(c) } } };
  const win = { matchMedia: () => ({ matches: dark }) };
  const calls = { reapply: 0 };
  let host = null; let registry = null; const bus = new EventBus();
  if (withHost) {
    registry = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => registry.declare(m));
    host = installThemeHost({ themeManager: createThemeManager({ prefersDark: () => dark }), moduleRegistry: registry, legacy: { reapplyAppearance: () => { calls.reapply++; } }, eventBus: bus, win, doc });
  }
  return { style, attrs, body, doc, win, calls, host, registry, bus };
}
const run = (e, ui) => { const S = { ui: JSON.parse(JSON.stringify(ui)) }; legacy(S, e.doc, e.win, () => 'blob:wp', () => Promise.resolve(null)).applyAppearance(); return S; };

// 1. host absent ou non engagé : comportement strictement historique ; engagé : état final identique
const olds = [{ main: '#527b70', desk: '#c0d6c9', paper: '#f5f2e8', pop: '#d9a7b2' }];
const configs = [];
for (const theme of ['dreamos', 'dark', 'auto', 'light', undefined]) for (const dark of [false, true]) for (const font of ['jakarta', 'lora', 'inconnue'])
  for (const extra of [{}, { accent: '#9D4E6C' }, { bgColor: '#223344', surfaceColor: '#ffeedd', overlayOpacity: 0.3 }, { wallpaperId: 'wp_abc' }])
    for (const dream of theme === 'dreamos' ? [undefined, ...DREAM_PALETTES.map((p) => p[1]), ...olds, { main: '#123456', desk: '#abcdef', paper: '#101010', pop: '#ff00ff' }] : [undefined]) configs.push({ dark, ui: { theme, font, dream, ...extra } });
let n = 0;
for (const { dark, ui } of configs) {
  const ref = env(dark, false); const Sref = run(ref, ui);
  const idle = env(dark, true); const Sidle = run(idle, ui);               // host installé mais pas engagé
  assert.deepEqual([...idle.style], [...ref.style]); assert.deepEqual([...idle.attrs], [...ref.attrs]); assert.deepEqual(Sidle.ui, Sref.ui);
  const on = env(dark, true); on.host.engage();
  const Son = run(on, ui);
  const where = JSON.stringify({ dark, ui });
  assert.deepEqual([...on.style].sort(), [...ref.style].sort(), `variables : ${where}`);
  assert.deepEqual([...on.attrs].sort(), [...ref.attrs].sort(), `attributs : ${where}`);
  assert.deepEqual([...on.body].sort(), [...ref.body].sort(), `classes body : ${where}`);
  assert.deepEqual(Son.ui, Sref.ui, `S.ui (migration de palette) : ${where}`);
  n++;
}
// 2. une seule autorité : transfert enregistré, rendu au retour arrière, jamais de double propriétaire
const e = env(false, true);
assert.equal(e.registry.ownerOf('dom', 'appearance'), 'legacy');
e.host.engage(); assert.equal(e.registry.ownerOf('dom', 'appearance'), 'themeManager'); assert.equal(e.calls.reapply, 1); assert.equal(e.host.enabled, true);
e.host.engage(); assert.equal(e.calls.reapply, 1, 'engage est idempotent');
e.host.release(); assert.equal(e.registry.ownerOf('dom', 'appearance'), 'legacy'); assert.equal(e.host.enabled, false); assert.equal(e.calls.reapply, 2);
assert.equal(e.host.delegate({ theme: 'dark' }), false, 'relâché : le moteur historique applique');
// 3. erreur dans le Theme Manager : repli automatique et propriétaire rendu
const err = env(false, false); const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m));
const events = []; const bus = new EventBus(); bus.on('theme:error', (x) => events.push(x));
const bad = installThemeHost({ themeManager: { plan() { throw new Error('boum'); }, apply() {} }, moduleRegistry: reg, legacy: {}, eventBus: bus, win: err.win, doc: err.doc });
bad.engage(); assert.equal(reg.ownerOf('dom', 'appearance'), 'themeManager');
const S = run(err, { theme: 'dark', accent: '#111111' });
assert.equal(err.style.get('--accent'), '#111111', 'repli : le moteur historique a appliqué');
assert.equal(bad.enabled, false); assert.equal(bad.lastError, 'boum'); assert.equal(events.length, 1); assert.equal(reg.ownerOf('dom', 'appearance'), 'legacy');
// 4. garde-fous sur app.js
assert.equal((app.match(/DreamOSThemeHost/g) || []).length, 1, 'un seul point d’accès au host dans app.js');
assert.ok(app.includes('function applyWallpaper(u)'));
assert.equal((app.match(/reapplyAppearance/g) || []).length, 1);
assert.ok(!/themeManager|theme-engine|theme-host/.test(app), 'app.js n’importe aucun module ES');
console.log(`phase3_4 : OK (${n} configurations : historique seul, host inactif, host engagé)`);
