# dreamOS — Phase 3.5 — Tools : chronomètre et compteur de rangs
Runtime **3.5.0** · cache Service Worker **atelier-tricot-v15**.

## Principe
La **logique** du chronomètre et du compteur de rangs passe au module Tools, sous forme de services où **le projet est toujours passé explicitement**. Les **données** (`pr.timer`, `pr.rows`, `pr.rts`, `pr.sub`, `pr.log`…) restent possédées par Projects / app.js, qui continue d'enregistrer (`saveProjects`) et de rendre. Aucune seconde autorité d'écriture sur les données.

Le compteur du lecteur PDF passe déjà par `rowsApply` : il est donc automatiquement couvert, et le lecteur n'en devient pas propriétaire (invariant de la doc).

## Nouveaux fichiers
- `dreamOS/tools/stopwatch.js` : `elapsed`, `total`, `logMs`, `format`, `short`, `toggle(pr, ctx)` (un seul chrono actif ; lancer le chrono d'un projet « en attente » le démarre).
- `dreamOS/tools/row-counter.js` : `apply(pr, n, ctx)`, `advanceGoal`, `pace(pr)` (rythme moyen et temps restant, mêmes règles que `vrcStat`).
- `dreamOS/tools/tools-host.js` : `engage()` / `release()` ; transfert enregistré dans le Module Registry (ressources `logic:stopwatch` et `logic:row-counter`, `legacy` ↔ `tools`).

## Modifications d'app.js (hooks de 1 à 2 lignes, code d'origine conservé)
`toolsHost()` et `toolsCtx()` (contexte explicite : projets, étape, démarrage du projet, toast d'objectif), puis une ligne de délégation au début de `tmLogMs`, `tmMs`, `tmTotal`, `tmFmt`, `tmShort`, `subAdvance`, `rowsApply`, et un `if/else` dans `tmToggle` (qui garde `saveProjects(); render();`). Host absent ou relâché : le code d'origine s'exécute à l'identique.

## Retour arrière
- À chaud : `window.DreamOSToolsHost.release()`.
- Par l'adresse : `?tools=legacy`.
- Complet : remettre `app.js`, `bootstrap.js`, `sw.js`, `module-registry.js`, `manifest.js` de la 3.4.

## Tests
`tests/phase3_5.test.mjs` : **9 000 opérations aléatoires** (150 scénarios × 60 pas : bascule du chrono, +1, −1, +x, remise à zéro, objectifs, lectures et formats) exécutées avec le **vrai code d'app.js**, hôte absent puis hôte engagé ; comparaison après chaque pas des projets, des valeurs renvoyées et des effets de bord (changement d'étape, toast, enregistrement, rendu). Compare aussi `pace()` au vrai `vrcStat`. Vérifié : le test échoue si la limite de 40 horodatages ou le démarrage automatique d'un projet change. Tests 2.1-2.5, précache et 3.1-3.4 relancés : OK.

## Non fait, volontairement
- **Notes** (`tnSave`, journal de projet) : elles écrivent dans `pr.log` et dépendent du dialogue ; à traiter avec Projects (3.8) pour ne pas créer deux autorités sur le journal.
- Réglage `carnet.rowStep` (« +x ») : toujours lu par app.js.
- Aucune action n'est revendiquée par le routeur (elles appellent `render()` et lisent l'état privé d'app.js).

## À faire de votre côté (profil de test)
1. Recharger ; console : `window.DreamOSToolsHost.enabled` → `true`.
2. Lancer un chrono, vérifier qu'il avance, passer à un autre projet : le premier s'arrête.
3. Compter +1, −1, +x, remise à zéro ; fixer un objectif : le message 🎉 apparaît à l'arrivée.
4. Depuis le lecteur PDF : compteur flottant, estimation du temps restant.
5. `release()` puis `engage()` : aucune différence. Toujours en attente : `npm i jszip playwright-core` et tests navigateur 2.8.

## Suite : 3.6 Library + Documentation
