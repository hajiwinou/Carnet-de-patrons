# dreamOS — Phase 3.7 — Downloads (Instagram → MP4 via Cobalt)
Runtime **3.7.0** · cache Service Worker **atelier-tricot-v17**.

## Principe (même schéma qu'en 3.4 à 3.6)
La **logique réseau** de l'outil passe au module Downloads. Les **données** (`carnet.igApi` : adresse et clé), l'**état de l'écran** (`S.ig`), l'enregistrement du fichier dans Documentation (`igToDoc`, blob `docm_*`) et le rendu restent à app.js : aucune seconde autorité d'écriture.

## Nouveaux fichiers
- `dreamOS/downloads/cobalt-client.js` : `endpoint`, `isLoopback`, `networkCheck`, `absolute`, `headers`, `errorMessage`, `fileName`, `request` (JSON ou fichier, délai, repli `DataCloneError`). Mêmes messages d'erreur qu'avant. Navigateur injectable (fetch, minuterie, protocole de la page). **Ne lit ni ne journalise jamais la clé d'accès** : elle est passée à chaque appel et jamais conservée (vérifié par test sur le code du module).
- `dreamOS/downloads/downloads-host.js` : `engage()` / `release()` ; transfert enregistré dans le Module Registry (`logic:cobalt-client` : `legacy` ↔ `downloads`).

## Modifications d'app.js (une ligne de délégation par fonction, code d'origine conservé derrière)
`dlHost()` + `igEndpoint`, `igIsLoopback`, `igNetworkCheck`, `igAbs`, `igRequest`, `igHeaders`, `igErrMsg`, `igFileName`. `igGo`, `igTest`, `igUseFile`, `igToDoc` (état d'écran, détection du format du fichier, enregistrement) ne sont pas touchés.

## Retour arrière
- À chaud : `window.DreamOSDownloadsHost.release()`.
- Par l'adresse : `?downloads=legacy`.
- Complet : remettre `app.js`, `bootstrap.js`, `sw.js`, `manifest.js` de la 3.6.

## Tests
`tests/phase3_7.test.mjs` extrait le **vrai code d'app.js** et le compare, hôte absent puis engagé : 16 adresses × 3 protocoles de page (https, http, file), sondes réseau locales / distantes / invalides, en-têtes avec et sans clé, 12 codes d'erreur, 7 titres de fichier, et **28 scénarios réseau simulés × 2** (réponse JSON, erreur avec ou sans code, réponse non JSON, fichier valide / vide / page HTML / JSON / erreur HTTP, réseau coupé, autre erreur, délai dépassé, `DataCloneError` suivi d'un succès ou d'un blocage). On compare le résultat, le message et **les appels fetch** (adresse, méthode, en-têtes, cache, signal, corps). Quatre mutations volontaires détectées (loopback, préfixe `Api-Key`, fichier vide, `no-store`). Tests 2.1-2.5, précache et 3.1-3.6 relancés : OK.

## Non fait, volontairement
- Aucun appel réel à Cobalt, ni à Instagram : tout est simulé. Un test réel dépend de **votre** serveur Cobalt et de la plateforme.
- `igGo` (enchaînement des réponses : fichier direct, choix multiple, traitement local) reste dans app.js : très lié à l'état de l'écran ; à reprendre quand l'état partagé panneau / application sera défini (jalon 6).

## À faire de votre côté (profil de test)
1. Recharger ; console : `window.DreamOSDownloadsHost.enabled` → `true`.
2. Outils → Instagram : « Tester le service » avec votre adresse Cobalt (en local et, si vous l'utilisez, via Tailscale en HTTPS) : même diagnostic qu'avant.
3. Une vidéo publique : téléchargement, aperçu, ajout à Documentation.
4. Adresse HTTP distante depuis la version HTTPS : message d'avertissement habituel.
5. `release()` puis `engage()` : aucune différence. Toujours en attente : `npm i jszip playwright-core` et tests navigateur 2.8.

## Suite : 3.8 Patterns (puis Projects 3.9, PDF Reader 3.10)
