# Jalon 4.6d — Projects modifie champs, fils, plan de couleurs, objectif, rangs et simulation

Version 4.6.3 · cache `atelier-tricot-v30`.

## Ce qui a bougé
`projects-commands.js` gagne 17 commandes : champ simple (`setField`), « refaire », rangs au total, abandon d'objectif, pelotes prévues, compteur par couleur, champs et nom d'un fil, ajout / retrait de fil, ajout / retrait de couleur prévue (la première reprend les pelotes prévues et inversement), raisons de WIP Island, annulation / simulation de pause. 15 portes `pj…` dans `app.js` (module engagé → commande, sinon code d'origine) ; 19 sites routés (saisies, listes de fils, couleurs prévues, simulation de développement, abandon d'objectif).

## Ce qui reste
Création d'un objectif (`askGoal`), avancée de sous-étape / rangs (Tools), étape (`setPjStage`, déjà dans le moteur 3.9 mais pas encore écrite par le module), drapeaux `islandPin` / `leftIsland`, notes, `pr.patternId` (Patterns), migrations au chargement.

## Vérification
`tests/jalon4_6d.test.mjs` : 12 600 comparaisons (commandes seules + 14 scénarios sur le vrai code d'app.js, module absent / engagé / relâché puis réengagé), attentes absolues, garde-fous statiques sur 16 formes d'écriture directe. 16 mutations injectées : toutes détectées (3 ont d'abord échappé, assertions renforcées). Suite complète verte.

## Retour arrière
`?projects=legacy`.
