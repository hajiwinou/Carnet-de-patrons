# Jalon 4.9a — Settings écrit les réglages et le fond d'écran

Version 4.9.0 · cache `atelier-tricot-v37`. Aucune clé, aucun identifiant ni format modifié.

## Ce qui a bougé
- Nouveau dossier `dreamOS/settings/` : `settings-store.js` (écriture validée des 7 clés de réglages), `settings-media.js` (fond d'écran `wp_<id>` : création d'identifiant, écriture, suppression), `settings-host.js` (`window.DreamOSSettingsHost`, `engage()` / `release()`).
- `bootstrap.js` : le module est installé et engagé au démarrage (`?settings=legacy` pour l'éviter). `sw.js` : 3 fichiers de plus dans le précache.
- `app.js` : portes `setHost`, `setKeep`, `setWpNewId`, `setWpPut`, `setWpDiscard`, `pwFailPhys` / `pwFailSet` ; routés : apparence (`saveUiCfg`, `saveUiSoon`, île, statistiques), IA (`saveAiCfg`), options, verrou (empreinte enregistrée à l'activation, à la mise à niveau au déverrouillage, à la désactivation ; essais ratés), dernière sauvegarde, choix et retrait du fond d'écran.

## Sécurité du verrou
Le module n'écrit que l'empreinte (PBKDF2) fournie par app.js : il ne voit jamais le mot de passe. Le calcul de l'empreinte et la vérification restent à app.js.

## Ce qui reste (4.9b)
- Les valeurs elles-mêmes (`S.ui`, `S.ai`, `S.opts`) sont encore modifiées par app.js (couleurs, thème, police, fournisseurs d'IA, clés, modèles, options).
- Restauration d'une sauvegarde : écriture en bloc des blobs, y compris le fond d'écran (Jalon 8). Le chargement initial des réglages reste dans app.js.
- Rien d'autre que ce qui est listé n'a changé : le Theme Manager applique toujours l'apparence.

## Vérification
`tests/jalon4_9a.test.mjs` : 9 000 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), magasin et médias seuls, attentes absolues, garde-fous statiques. 18 mutations injectées : toutes détectées. Tests 6b et 7b adaptés (nouvelle porte de suppression et d'écriture du fond d'écran). Suite complète verte. Le site de mise à niveau de l'empreinte au déverrouillage est dans une grande fonction asynchrone : vérifié par garde-fou statique.

## Retour arrière
`?settings=legacy`.
