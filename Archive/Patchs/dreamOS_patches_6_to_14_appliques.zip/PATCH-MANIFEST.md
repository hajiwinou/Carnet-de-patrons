# PATCH-14 — Jalon 5.2 (après PATCH-1 à 13)
Ajoutés : `tests/jalon5_2.test.mjs`, `docs/phase3/JALON-5.2-README.md`
Modifiés : `app.js` (bloc aperçu BLISS, ~35 lignes + 1 ligne dans le rendu), `index.html` (`<header id="topbar" hidden>`), `theme/components.css` (barre du haut), `theme-test.html`, `sw.js` (v42), `dreamOS/bootstrap.js` (5.2.0), `tests/jalon5_0.test.mjs`, `tests/jalon5_1.test.mjs`, `docs/phase3/inventory.json`, `docs/phase3/INVENTORY.md`, `docs/project/{PROJECT-STATUS,PATCH-LOG,CHANGELOG}.md`
Supprimés : rien.
Retour arrière : voir JALON-5.2-README (remettre les fichiers du PATCH-13).
Tests ici : suite Node complète ; 7 mutations détectées ; captures PC/téléphone. À lancer chez vous : `phase2_8_backup_format`, `phase2_8_regression.browser`.
