# Jalon 4.6e — Projects crée les projets, change l'étape, gère l'île et les liens avec les patrons

Version 4.6.4 · cache `atelier-tricot-v31`.

## Ce qui a bougé
`projects-commands.js` : `createProject` (enregistrement initial d'un projet), `changeStage` (étape précédente, arrêt du chrono à « terminé », drapeaux de l'île effacés, reprise du travail en WIP), `setStageDate`, `pinToIsland` (envoi manuel et « Remettre sur l'île »), `exitIsland`, `touch`, `ensureLog`, `setPatternId`, `linkProjects`, `unlinkPattern`, `relinkPattern`. 11 nouvelles portes `pj…` dans `app.js` ; sites routés : `newProject`, `setPjStage`, `islandExit`, `sendIsland`, `islandBack`, `pjSetPattern`, suppression de patron (douce avec annulation, définitive), remplacement de patron, migration des étapes, note écrite depuis le PDF.

## Ce qui reste (hors lot 4.6)
Migrations au chargement (`pjMigrate`), repli des Tools (chrono, rangs : `workAt` y reste côté Tools), étape des patrons (`setStage`, c'est la donnée Patterns), création d'un objectif (`askGoal`).

## Bilan du lot 4.6
Projects possède maintenant : sa liste (4.6a), ses médias (4.6b), le journal / photos / couverture / inspiration (4.6c), champs / fils / couleurs / objectif / simulation (4.6d), création / étape / île / liens patrons (4.6e). Les écritures directes de ces champs hors des portes sont interdites par des tests statiques.

## Vérification
`tests/jalon4_6e.test.mjs` : 9 000 comparaisons (module absent / engagé / relâché puis réengagé), commandes seules, attentes absolues, garde-fous statiques. 18 mutations injectées : toutes détectées (2 ont d'abord échappé, tests renforcés). `jalon4_6a` reçoit l'horloge du module. Suite complète verte.

## Retour arrière
`?projects=legacy`.
