# dreamOS — Jalon 4.5 : Downloads propriétaire de sa configuration (carnet.igApi)

## Ce qui change
- `dreamOS/downloads/downloads-store.js` : **seule autorité d'écriture** de la configuration du service Cobalt (adresse + clé d'accès) quand le module est engagé. Limité aux deux champs connus (`endpoint`, `key`).
- **Confidentialité** : la clé n'est jamais copiée, journalisée ni placée dans un événement (seul le NOM du champ modifié est publié) ; le test le vérifie.
- Le registre transfère `storage:carnet.igApi` de `legacy` à `downloads`.
- app.js : une porte unique `igCfgSet()` ; code d'origine en repli.
- Version 4.5.0, cache du service worker `atelier-tricot-v26`.

## Ne change pas
Le client réseau (3.7), l'état d'écran de l'outil (`S.ig`), l'enregistrement d'une vidéo téléchargée (qui passe par Documentation : article + média `docm_*`, étapes 4.1 / 4.2), le rendu, les formats.

## Retour arrière
`window.DreamOSDownloadsHost.release()` (même à chaud) ou `?downloads=legacy`.

## Tests (tous OK ici)
`tests/jalon4_5.test.mjs` : 3 200 comparaisons — vrai code d'app.js (saisie de l'adresse / de la clé) hôte absent / engagé / bascule à chaud sur 800 séries de saisies ; une écriture par saisie ; dernière valeur conservée ; magasin (champs, écriture, événements sans valeurs, abonné défaillant, aucun accès console / réseau / DOM) ; garde-fous statiques ; 8 mutations toutes détectées. `phase3_7` adapté (deux accesseurs à l'hôte).

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : saisir l'adresse et la clé Cobalt, recharger (elles doivent rester), télécharger une vidéo et l'enregistrer dans Documentation.

## Étape suivante : 4.6 Projects (le plus couplé : projets, journal, photos pjc_/pjp_/pji_, notes de projet, compteur de rangs), à découper en sous-étapes.
