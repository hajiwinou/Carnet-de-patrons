# dreamOS — Jalon 4.4 : Tools propriétaire de ses données + correctif d'import

## Correctif (demandé)
« Plusieurs photos d'un coup » : si le **premier** fichier choisi n'était ni une image ni une vidéo, l'import s'arrêtait sans rien ajouter. La boucle confondait « premier fichier ignoré » et « annulation par l'utilisateur ». Désormais les fichiers ignorés (PDF, etc.) sont simplement sautés ; l'annulation (bouton pendant l'import) est toujours respectée entre deux fichiers importés. Test : tous les fichiers image / vidéo sont importés quel que soit l'ordre ; l'ancienne règle est détectée comme défaillante.

## Ce qui change (Tools)
- `dreamOS/tools/tools-store.js` : **seule autorité d'écriture** des données de l'espace Outils quand le module est engagé.
  - Grilles (`carnet.grids`) : ajout, mise à jour, suppression, annulation, remplacement (import / restauration) — le magasin adopte le tableau d'app.js (même référence), miroir IndexedDB `meta_grids` conservé.
  - Valeurs d'écran (`carnet.chart`, `carnet.r3`, `carnet.rowStep`, `carnet.scratchpad`) : app.js les édite en mémoire, **l'enregistrement** passe par `persist()` (liste blanche de 4 clés).
- Le registre transfère ces 5 ressources `storage` de `legacy` à `tools`.
- app.js : 8 fonctions « porte unique » (`toolsSave`, `gridsAdd…`) ; code d'origine en repli.
- Version 4.4.0, cache du service worker `atelier-tricot-v25`.

## Ne change pas
Formats de données et de sauvegarde, rendu, chronomètre et compteur de rangs (logique déjà portée en 3.5 ; leurs données sont celles des projets). Le bloc-notes de chaque projet (`tnSave`) viendra avec Projects.

## Retour arrière
`window.DreamOSToolsHost.release()` (même à chaud) ou `?tools=legacy`.

## Tests (tous OK ici)
`tests/jalon4_4.test.mjs` : ≈ 26 000 comparaisons. Vrai code d'app.js (supprimer / annuler une grille, enregistrer / mettre à jour, nouvelle grille, ouvrir, outil / cellule / effacer du graphique, bloc-notes, calculateur, pas de rangs) exécuté hôte absent / engagé sur 600 états ; vérifications absolues par scénario ; 600 séquences avec bascule / retour arrière à chaud ; magasin ; garde-fous statiques (plus aucune écriture directe ; clés enregistrées = liste blanche). 16 mutations contrôlées, toutes détectées.

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : importer plusieurs photos en commençant par un PDF (doit importer les photos) ; dessiner une grille, l'enregistrer, la rouvrir, la supprimer puis annuler ; écrire dans le bloc-notes ; changer « +x » ; recharger.

## Étape suivante : 4.5 Downloads (journal / état Instagram), puis Projects et Patterns.
