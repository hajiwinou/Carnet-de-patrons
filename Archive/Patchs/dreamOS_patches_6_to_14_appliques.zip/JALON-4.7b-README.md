# Jalon 4.7b — Patterns possède les médias de patrons (pdf_ / th_ / img_)

Version 4.7.1 · cache `atelier-tricot-v33`. Aucun identifiant ni format modifié.

## Ce qui a bougé
- Nouveau `dreamOS/patterns/patterns-media.js` : création d'identifiant (`img_`+uid, `pdf_`/`th_`+id du patron), écriture d'un NOUVEAU média (préfixe imposé), écriture d'un média à identifiant EXISTANT (`restore`, pour les imports anciens dont l'identifiant a un autre format), suppression (sans contrainte de préfixe, pour les anciens patrons).
- `patterns-host.js` : expose `media` ; ressources `pdf_*`, `th_*`, `img_*` transférées au module à l'engagement.
- `app.js` : 7 portes `patm…` ; sites routés : PDF d'un patron (import et ajout, 2 sites), miniature, ajout de photos, retrait d'une photo, suppression définitive et douce d'un patron, import de photos depuis un ZIP. Module absent → code d'origine.

## Ce qui reste
Restauration groupée d'une sauvegarde (écriture en masse des blobs, volontairement laissée au futur service de sauvegarde) ; fond d'écran (`wall_*`, Réglages, 4.9) ; champs d'un patron (4.7c).

## Vérification
`tests/jalon4_7b.test.mjs` : 3 393 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), passerelle seule, propriété des ressources, garde-fous statiques (plus aucune écriture ni suppression directe de ces médias hors des portes ; seules restent la restauration groupée et le fond d'écran). 14 mutations injectées : toutes détectées (1 d'abord échappée : site d'import, garde statique ajouté). Suite complète verte (`phase3_1` et `jalon4_6b` adaptés).

## Retour arrière
`?patterns=legacy`.
