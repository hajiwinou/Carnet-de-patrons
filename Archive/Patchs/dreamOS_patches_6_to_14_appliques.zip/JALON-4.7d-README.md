# Jalon 4.7d — Patterns crée patrons et dossiers, enregistre l'analyse et les préférences d'affichage

Version 4.7.3 · cache `atelier-tricot-v35`. Aucun champ, identifiant ni format modifié.

## Ce qui a bougé
- `patterns-commands.js` : 12 commandes de plus — `createPattern`, `markGuess` (auteur / vêtement déduits, avec leur preuve), `restorePattern` (patron reconstruit depuis une sauvegarde), `setAnalysis` (résultat de l'analyse par IA), `createFolder`, `renameFolder`, `toggleFavAuthor`, `toggleGroup`, `collapseGroups`, `expandGroups`.
- `patterns-store.js` / `patterns-host.js` : le module possède aussi les clés `carnet.favAuthors`, `carnet.collapsed`, `carnet.group`.
- `app.js` : 11 portes (`patCreate`, `patMarkGuess`, `patRestore`, `patSetAnalysis`, `patNewFolder`, `patRenameFolder`, `patToggleFavAuthor`, `patToggleGroup`, `patCollapseGroups`, `patExpandGroups`, `patSetGroup`) ; routés : nouveau patron, restauration, analyse, création et renommage de dossier, étoile d'auteur, repli / dépli des groupes, choix du groupement. `saveCollapsed` supprimée (remplacée par les portes).

## À savoir
Le remplissage de la fiche par l'IA (valeurs, indices, drapeaux, variantes, grilles) était déjà dans `patterns-engine.js` depuis 3.8 : il n'y avait donc plus que l'enregistrement du résultat (`analysis`) à transférer. Le code de secours d'`app.js` (utilisé seulement si le module est absent) garde ses écritures d'origine ; il disparaîtra au Jalon 8.
Le chargement initial des préférences (lecture au démarrage) reste dans `app.js`.
`restorePattern` et `setAnalysis` sont vérifiés seuls (commandes) et par garde-fou statique (un seul site chacun) : leurs sites d'origine sont dans de grandes fonctions asynchrones non exécutables isolément.

## Vérification
`tests/jalon4_7d.test.mjs` : 7 500 comparaisons sur le vrai code (module absent / engagé / relâché puis réengagé), commandes seules, attentes absolues, garde-fous statiques. 18 mutations injectées : toutes détectées (une d'abord échappée : ordre des auteurs favoris, car les valeurs de départ du générateur étaient trop peu variées ; corrigé). Tests 7a, 7b, 7c adaptés (fin du bloc de portes, horloge du module, liste des clés). Suite complète verte.

## Retour arrière
`?patterns=legacy`.
