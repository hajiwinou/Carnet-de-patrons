# dreamOS — Phase 3.11 : module Documentation (logique pure)

## Ce qui change
- `dreamOS/documentation/documentation-engine.js` : catégories, brouillon vide, validité du brouillon, construction d'un article (écrit ou vidéo téléchargée), type de média, libellés de date / catégorie, index de réinsertion après annulation d'une suppression.
- `dreamOS/documentation/documentation-host.js` : `window.DreamOSDocumentationHost` (`engage()` / `release()`), ressource `logic:documentation-engine` transférée de `legacy` à `documentation`.
- app.js : `docHost()` + points de délégation dans viewDocs, docSave, docDel, ajout de médias, igToDoc ; code d'origine en repli.
- Version 3.11.0, cache du service worker `atelier-tricot-v21`.
- La recherche dans les articles reste portée par Library (3.6).

## Ne change pas
`carnet.docs`, médias `docm_*`, enregistrement, téléversement, rendu.

## Retour arrière
`window.DreamOSDocumentationHost.release()` ou `?documentation=legacy`.

## Tests (tous OK ici)
`tests/phase3_11.test.mjs` : le VRAI code d'app.js (viewDocs, docSave, docDel avec annulation, ajout de médias, igToDoc) est extrait et exécuté hôte absent / engagé sur 600 états aléatoires × 5 scénarios ; on compare l'état, les messages, les enregistrements et le HTML. 12 mutations toutes détectées ; garde-fou « pas de DOM / stockage ».

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser` (jszip / playwright absents ici). Puis : écrire un article avec photo/vidéo, le supprimer puis annuler, chercher dans la documentation.

## Étape suivante : bilan du Jalon 3 (8 modules, registre, inventaire final, plan jalon 4).
