# dreamOS — Jalon 4.6a : Projects propriétaire de la LISTE des projets (1ʳᵉ sous-étape)

Projects est le module le plus couplé : il est découpé en trois sous-étapes.
- **4.6a (cette livraison)** : la liste des projets et son enregistrement.
- 4.6b : les médias `pjc_` / `pjp_` / `pji_`.
- 4.6c : les modifications des champs d'un projet (journal, rangs, fils, notes) par le module.

## Ce qui change
- `dreamOS/projects/projects-store.js` : **autorité d'écriture** de la liste (`carnet.projects`) : création, suppression, annulation, remplacement (import / restauration) — et **tout enregistrement de la liste**, y compris celui qui suit une modification d'un champ de projet (une quarantaine de points d'appel de `saveProjects()` passent par le magasin). Aussi `carnet.pjStage` (onglet courant) et `carnet.migPj` (migration faite), via une liste blanche.
- Le registre transfère `storage:carnet.projects`, `carnet.pjStage` et `carnet.migPj` de `legacy` à `projects` ; les médias restent à `legacy` jusqu'à 4.6b (le test le vérifie).
- app.js : `projStore()`, `projectsAdd / RemoveAt / InsertAt / Replace`, `pjSettingSave()` ; code d'origine en repli. `saveProjectsQuiet()` (identique à `saveProjects()`) y est ramené.
- Version 4.6.0, cache du service worker `atelier-tricot-v27`.

## Ce qui reste dans app.js (volontairement)
Les champs d'un projet sont encore modifiés en mémoire par app.js (4.6c) ; les liens projet ↔ patron modifiés par Patterns (`patternId`) aussi ; l'écriture physique (localStorage + miroir IndexedDB `meta_projects`).

## Retour arrière
`window.DreamOSProjectsHost.release()` (même à chaud) ou `?projects=legacy`.

## Tests (tous OK ici)
`tests/jalon4_6a.test.mjs` : ≈ 24 600 comparaisons. Vrai code d'app.js (nouveau projet, migration des étapes, supprimer / annuler un projet avec ses médias — l'idée partagée est conservée —, changement de couverture, onglet courant, suppression d'un patron qui détache ses projets) hôte absent / engagé sur 600 états ; vérifications absolues ; 600 séquences avec bascule et retour arrière à chaud ; magasin ; garde-fous statiques. Mutations contrôlées toutes détectées.

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : créer un projet, le modifier (rangs, notes, photo), le supprimer puis annuler, supprimer un patron qui a un projet, exporter / réimporter un ZIP, recharger.

## Étape suivante : 4.6b médias de projets (couvertures, photos du journal, inspiration).
