# Jalon 4.8 — PDF Reader possède l'écriture de ses données

Version 4.8.0 · cache `atelier-tricot-v36`. Aucun champ, clé ni format modifié.

## Ce qui a bougé
- Nouveau `dreamOS/pdf-reader/pdf-reader-store.js` : écriture validée des clés du lecteur (`carnet.vpos.<id>`, `carnet.vmark.<id>`, `carnet.vsm.<id>`, `carnet.vhl.<id>`, `carnet.vrcPos`, `carnet.vrcMin`) ; toute autre clé est refusée. L'écriture physique reste la fonction `keep` d'app.js.
- Nouveau `dreamOS/pdf-reader/pdf-reader-commands.js` : repère de rang (posé / retiré), marqueurs de marge, surlignages, valeur de la position de reprise, position et état réduit du compteur. Transcriptions fidèles ; ni enregistrement, ni rendu, ni message.
- `pdf-reader-host.js` : expose `store` et `commands` ; les six ressources de stockage passent au module quand il est engagé.
- `app.js` : 8 portes `vr…` ; routés : clic sur le PDF (repère, marqueur, surlignage), position de reprise (2 formes), réinitialisation, réduction et déplacement du compteur. `sw.js` : 2 fichiers de plus dans le précache.

## Ce qui reste
- Restauration d'une sauvegarde : écriture en bloc des positions et surlignages (`keep(k, data.viewer[k])`), Jalon 8.
- Les lectures (`load`) à l'ouverture du PDF restent dans app.js.
- Le compteur de rangs lui-même reste à Projects (le lecteur ne l'écrit jamais).

## Vérification
`tests/jalon4_8.test.mjs` : 3 750 comparaisons sur le vrai code (clic du lecteur et `vposNow`, module absent / engagé / relâché puis réengagé), clés et magasin seuls, commandes seules, attentes absolues, garde-fous statiques. 17 mutations injectées : toutes détectées (deux d'abord échappées : seuil des marqueurs et marge des surlignages, assertions ajoutées). Suite complète verte. Les trois sites du compteur (réinitialisation, réduction, déplacement) sont dans de grandes fonctions d'interface : vérifiés par garde-fou statique et commandes seules.

## Retour arrière
`?pdfreader=legacy`.
