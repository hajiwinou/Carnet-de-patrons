# dreamOS — Jalon 4.6b : Projects propriétaire des médias de projets (pjc_ / pjp_ / pji_)

Deuxième sous-étape de Projects (4.6a : liste des projets ; **4.6b : médias** ; 4.6c : champs d'un projet).

## Ce qui change
- `dreamOS/projects/projects-media.js` : **autorité d'écriture** des médias de projets quand le module est engagé — identifiant (`pjc_` couverture / photos, `pjp_` photos du journal, `pji_` inspiration propre au projet), écriture d'un blob (refuse tout autre préfixe), suppression, liste des médias référencés par une liste de projets (base d'un futur nettoyage d'orphelins).
- Le registre transfère `media:pjc_*`, `pjp_*`, `pji_*` de `legacy` à `projects`. Les médias d'idées (`ideam_*`) restent à Library : une idée ajoutée à l'inspiration d'un projet garde son média, et supprimer le projet ne le supprime pas (vérifié).
- app.js : `pjmNewId()`, `pjmSave()`, `pjmDiscard()` ; 4 écritures (couverture, photos du projet, photos du journal, inspiration) et 4 suppressions (photo, entrée du journal, photo d'inspiration, projet entier) y passent ; code d'origine en repli.
- La suppression n'impose aucun préfixe : d'anciens projets peuvent référencer des identifiants plus anciens, qu'il faut pouvoir libérer.
- Version 4.6.1, cache du service worker `atelier-tricot-v28`.

## Ne change pas
L'écriture physique (cache de blobs + IndexedDB, passée en paramètre), la lecture des images, le rendu, les formats.

## Hors du module (volontairement)
La restauration d'une sauvegarde écrit encore tous les blobs en bloc (service de sauvegarde). Les champs d'un projet restent modifiés en mémoire par app.js (4.6c).

## Retour arrière
`window.DreamOSProjectsHost.release()` (même à chaud) ou `?projects=legacy`.

## Tests (tous OK ici)
`tests/jalon4_6b.test.mjs` : 8 000 comparaisons. Vrai code d'app.js (couverture par photo, photos du projet, photos du journal, inspiration, et les 4 suppressions) hôte absent / engagé sur 500 états, avec fichiers défaillants ; vérifications absolues (préfixe correct, bons médias supprimés, idée partagée conservée) ; passerelle ; garde-fous statiques (plus aucune écriture, suppression ni identifiant `pjc_/pjp_/pji_` hors de la porte unique) ; bascule à chaud. 14 mutations contrôlées, toutes détectées. `phase3_1` (détection des préfixes) et `jalon4_6a` adaptés.

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : ajouter une photo de couverture, des photos au projet, une photo avec une entrée de journal, des photos d'inspiration (et une épingle de la bibliothèque) ; supprimer chacune ; supprimer un projet entier puis annuler ; recharger.

## Étape suivante : 4.6c — modifications des champs d'un projet (journal, rangs, fils, notes, plan de couleurs) par le module.
