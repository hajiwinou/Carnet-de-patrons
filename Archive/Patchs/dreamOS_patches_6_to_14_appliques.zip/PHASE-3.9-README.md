# dreamOS — Phase 3.9 : module Projects (moteur pur)

## Ce qui change
- `dreamOS/projects/projects-engine.js` : 20 fonctions + 3 catalogues extraits **mot pour mot** d'app.js (étape d'un projet, dernière activité, couverture historique, fils/pelotes prévus et utilisés, plan de couleurs, note moyenne, nom d'une couleur, raisons WIP Island, dates).
- `dreamOS/projects/projects-host.js` : `window.DreamOSProjectsHost` (`engage()` / `release()`), ressource `logic:projects-engine` transférée de `legacy` à `projects`.
- app.js : `projHost()` + 20 points de délégation (code d'origine conservé en repli).
- `tools/gen-projects-engine.mjs` (basé sur `tools/lib/engine-extractor.mjs`) régénère le module ; le test vérifie qu'il est identique à app.js.
- Version 3.9.0, cache du service worker `atelier-tricot-v19`.

## Ne change pas
Données (`carnet.projects`, journal, médias `pjc_/pjp_/pji_`), enregistrement, rendu, chrono et compteur de rangs : restent à app.js.

## Retour arrière
`window.DreamOSProjectsHost.release()` ou `?projects=legacy` dans l'URL.

## Tests (tous OK ici)
`tests/phase3_9.test.mjs` : ~230 000 comparaisons (3000 projets aléatoires, hôte absent / engagé / moteur seul, mutation du projet incluse), cas dirigés aux seuils, garde-fou « pas de stockage / DOM / état », mutations détectées.

## À faire de votre côté
Lancer `tests/phase2_8_backup_format.test.mjs` et `tests/phase2_8_regression.browser.mjs` (jszip / playwright indisponibles ici), puis ouvrir l'appli et vérifier un projet (fils, pelotes, note, raisons WIP Island).

## Étape suivante : 3.10 PDF Reader (le plus couplé).
