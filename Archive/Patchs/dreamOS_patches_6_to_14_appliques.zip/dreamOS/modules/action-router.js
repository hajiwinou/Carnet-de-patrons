/**
 * dreamOS — Routeur d'actions (Phase 3.2)
 * Se place en phase de capture sur `document`, AVANT le gestionnaire de clic historique d'app.js.
 *  - Par défaut il ne fait qu'observer : il émet `action:dispatched {action, module, handled:false}` sur l'Event Bus
 *    et laisse app.js agir (comportement identique à la 2.8).
 *  - Quand un module revendique une action (claim), le routeur l'exécute et empêche le gestionnaire historique de la
 *    traiter (stopImmediatePropagation) : jamais deux exécutions, une seule autorité par action.
 * Aucun module ne revendique encore d'action : le routeur est inerte.
 */
import { ACTION_MAP } from './action-map.js';

export class ActionRouter {
  #map; #claims = new Map(); #bus; #target; #listener = null;

  constructor({ eventBus = null, target = null, map = ACTION_MAP } = {}) {
    this.#bus = eventBus; this.#target = target; this.#map = map;
  }

  moduleFor(action) { return this.#map[action] || null; }
  actions(module) { return Object.keys(this.#map).filter((a) => !module || this.#map[a] === module); }

  /** Un module prend en charge une action. Refuse les actions inconnues, d'un autre module ou déjà revendiquées. */
  claim(module, action, handler) {
    if (this.#map[action] === undefined) throw new Error(`Action inconnue : "${action}".`);
    if (this.#map[action] !== module) throw new Error(`L'action "${action}" appartient au module "${this.#map[action]}", pas à "${module}".`);
    if (this.#claims.has(action)) throw new Error(`L'action "${action}" est déjà revendiquée.`);
    if (typeof handler !== 'function') throw new TypeError('Le gestionnaire doit être une fonction.');
    this.#claims.set(action, handler);
    return () => this.#claims.delete(action); // permet le retour arrière
  }
  claimed() { return [...this.#claims.keys()]; }

  /** Cœur testable : renvoie true si un module a traité l'action. */
  dispatch(action, ctx) {
    const handler = this.#claims.get(action);
    this.#bus?.emit('action:dispatched', { action, module: this.moduleFor(action), handled: !!handler });
    if (!handler) return false;
    try {
      const r = handler(ctx);
      if (r && typeof r.catch === 'function') r.catch((e) => this.#bus?.emit('action:error', { action, message: e?.message || String(e) }));
    } catch (e) {
      this.#bus?.emit('action:error', { action, message: e?.message || String(e) });
    }
    return true;
  }

  start() {
    if (this.#listener || !this.#target) return this;
    this.#listener = (event) => {
      const t = event.target;
      if (!t || typeof t.closest !== 'function' || t.closest('[data-stop]')) return;
      const el = t.closest('[data-act]');
      if (!el) return;
      const handled = this.dispatch(el.dataset.act, { event, element: el, id: el.dataset.id, value: el.dataset.v });
      if (handled) { event.stopImmediatePropagation(); event.preventDefault(); }
    };
    this.#target.addEventListener('click', this.#listener, true);
    return this;
  }
  dispose() { if (this.#listener) this.#target.removeEventListener('click', this.#listener, true); this.#listener = null; this.#claims.clear(); }
}

export function createActionRouter(options) { return new ActionRouter(options); }
