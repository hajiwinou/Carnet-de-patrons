/**
 * dreamOS — Theme Host (Phase 3.4)
 * Premier transfert d'autorité d'écriture : l'APPLICATION de l'apparence au DOM (variables CSS, data-theme,
 * palette dreamOS) passe du moteur historique au Theme Manager. La DONNÉE (S.ui, clé carnet.ui) reste
 * possédée et enregistrée par app.js. Le fond d'écran (blob wp_*) reste appliqué par app.js via le rappel fourni.
 *
 * app.js appelle window.DreamOSThemeHost.delegate(ui, { wallpaper }) au début de applyAppearance() :
 *  - true  → le Theme Manager a tout appliqué, le code historique ne s'exécute pas (jamais de double écriture) ;
 *  - false → désactivé, absent ou en erreur : app.js applique lui-même, comme avant.
 */
export const APPEARANCE_RESOURCE = ['dom', 'appearance'];

export function installThemeHost({ themeManager, moduleRegistry, legacy, eventBus, win = globalThis.window, doc = globalThis.document } = {}) {
  if (!themeManager || !win || !doc) throw new TypeError('installThemeHost : themeManager, window et document sont requis.');
  if (win.DreamOSThemeHost) return win.DreamOSThemeHost;
  const OWNER = 'themeManager';
  let enabled = false;
  let lastError = null;

  const host = {
    delegate(ui, { wallpaper } = {}) {
      if (!enabled) return false;
      try {
        const plan = themeManager.plan(ui);
        themeManager.apply(doc.documentElement, plan);
        if (plan.dream) ui.dream = { ...plan.dream }; // le moteur historique réécrivait S.ui.dream avec cette valeur
        if (!plan.dream && typeof wallpaper === 'function') wallpaper(ui);
        return true;
      } catch (error) {
        lastError = error;
        enabled = false; // retour automatique au moteur historique
        try { moduleRegistry?.transferOwnership(...APPEARANCE_RESOURCE, OWNER, 'legacy'); } catch { /* déjà rendu */ }
        eventBus?.emit('theme:error', { message: error?.message || String(error) });
        return false;
      }
    },
    /** Le Theme Manager devient l'unique autorité d'application de l'apparence. */
    engage() {
      if (enabled) return true;
      moduleRegistry?.transferOwnership(...APPEARANCE_RESOURCE, 'legacy', OWNER);
      enabled = true;
      legacy?.reapplyAppearance?.();
      eventBus?.emit('theme:engaged', {});
      return true;
    },
    /** Retour arrière à chaud : le moteur historique reprend la main. */
    release() {
      if (!enabled) return true;
      enabled = false;
      moduleRegistry?.transferOwnership(...APPEARANCE_RESOURCE, OWNER, 'legacy');
      legacy?.reapplyAppearance?.();
      eventBus?.emit('theme:released', {});
      return true;
    },
    get enabled() { return enabled; },
    get lastError() { return lastError ? lastError.message : null; }
  };
  Object.defineProperty(win, 'DreamOSThemeHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSThemeHost;
}
