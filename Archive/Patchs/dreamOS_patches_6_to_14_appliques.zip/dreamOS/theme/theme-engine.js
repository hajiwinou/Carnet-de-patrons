/**
 * dreamOS — Moteur de thème (Phase 3.3)
 * Fonctions PURES reproduisant à l'identique applyAppearance() de app.js : à partir de la configuration `ui`,
 * elles calculent un « plan » (attributs, variables CSS à poser / retirer, fond d'écran). Rien n'est écrit dans le DOM
 * ni dans le stockage. app.js reste l'unique autorité d'écriture tant que le module Settings n'est pas migré ;
 * tests/phase3_3.test.mjs compare ce moteur au code historique sur une grille de configurations.
 */
export const DREAM_PALETTES = Object.freeze([
  ['Ciel', { main: '#315b91', desk: '#8fb5d8', paper: '#f7f0e7', pop: '#d99eae' }],
  ['Cyberpop 98', { main: '#24102f', desk: '#d889f4', paper: '#fff0fb', pop: '#00ddc2' }],
  ['Retro Dream', { main: '#55486f', desk: '#b9a8ff', paper: '#fff4e8', pop: '#f4a7d0' }],
  ['Pixel Dream', { main: '#6842a6', desk: '#bba4ff', paper: '#fbf1ff', pop: '#f08bdc' }],
  ['Bliss 95', { main: '#1556b8', desk: '#80bdf4', paper: '#f8f3e5', pop: '#65d8f2' }],
  ['Nuit', { main: '#2a3a6e', desk: '#1d2540', paper: '#e9e6f2', pop: '#e58fb0' }]
]);
export const DREAM_PALETTE_IDS = Object.freeze(['ciel', 'cyberpop98', 'retrodream', 'pixeldream', 'bliss95', 'nuit']);

export const FONTS = Object.freeze({
  jakarta: { name: 'Plus Jakarta Sans (Moderne & doux)', body: "'Plus Jakarta Sans', system-ui, sans-serif", head: "'Plus Jakarta Sans', system-ui, sans-serif" },
  dm: { name: 'DM Sans (Géométrique & épuré)', body: "'DM Sans', system-ui, sans-serif", head: "'DM Sans', system-ui, sans-serif" },
  lora: { name: 'Lora & Playfair (Éditorial / Magazine)', body: "'Lora', Georgia, serif", head: "'Playfair Display', Georgia, serif" },
  times: { name: 'Times New Roman (Classique Serif)', body: "'Times New Roman', Times, Georgia, serif", head: "'Times New Roman', Times, Georgia, serif" },
  inter: { name: 'Inter & Space Grotesk (Classique)', body: "'Inter', system-ui, sans-serif", head: "'Space Grotesk', sans-serif" },
  system: { name: 'Police système (Apple / Android)', body: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif", head: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" }
});

// Anciennes palettes enregistrées → nouvelle identité (indices dans DREAM_PALETTES).
const OLD_DREAM_PRESETS = [
  [{ main: '#527b70', desk: '#c0d6c9', paper: '#f5f2e8', pop: '#d9a7b2' }, 2],
  [{ main: '#9f5578', desk: '#e8b9ca', paper: '#fbf2ed', pop: '#8da9c3' }, 1],
  [{ main: '#665d86', desk: '#c9c3dc', paper: '#f7f3f5', pop: '#d7aebc' }, 3],
  [{ main: '#a96d57', desk: '#e8c6ae', paper: '#fbf3e9', pop: '#879eae' }, 4]
];
const DREAM_VARS = ['--dm', '--dm-ink', '--dd', '--dp', '--dpop', '--ink', '--muted', '--ink-in'];
const DREAM_ONLY_REMOVED = ['--accent', '--accent-soft', '--bg', '--surface', '--surface-alpha', '--bg-overlay'];

const expand = (hex) => { let c = String(hex || '').replace('#', ''); if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2]; return c; };

export function hexToRgba(hex, alpha) {
  const c = expand(hex);
  if (c.length !== 6) return `rgba(255,255,255,${alpha})`;
  return `rgba(${parseInt(c.slice(0, 2), 16)},${parseInt(c.slice(2, 4), 16)},${parseInt(c.slice(4, 6), 16)},${alpha})`;
}
export function luminance(hex) {
  const c = expand(hex);
  if (c.length !== 6) return 1;
  const v = [0, 2, 4].map((i) => { const x = parseInt(c.substr(i, 2), 16) / 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
  return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
}
export function mixHex(a, b, t) {
  const p = (h) => [0, 2, 4].map((i) => parseInt(expand(h).substr(i, 2), 16) || 0);
  const x = p(a); const y = p(b);
  return '#' + x.map((v, i) => ('0' + Math.round(v * (1 - t) + y[i] * t).toString(16)).slice(-2)).join('');
}
/** Rapport de contraste WCAG (≥ 4,5 requis pour le texte courant, doc §10). */
export function contrastRatio(a, b) {
  const la = luminance(a); const lb = luminance(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}

function fontPlan(ui) {
  if (ui.theme === 'dreamos') return { remove: ['--font-body', '--font-head'], set: {} };
  const f = FONTS[ui.font] || FONTS.jakarta;
  return { remove: [], set: { '--font-body': f.body, '--font-head': f.head } };
}

/**
 * @param {object} ui configuration (S.ui)
 * @param {{prefersDark?: boolean}} env
 * @returns {{dataTheme: string|null, dreamPalette?: string, vars: object, remove: string[], dream: object|null, wallpaperId: string, hasWallpaper: boolean}}
 */
export function computeAppearance(ui, { prefersDark = false } = {}) {
  const u = ui || {};
  const isDark = u.theme === 'dark' || (u.theme === 'auto' && !!prefersDark);
  const dreamOn = u.theme === 'dreamos';
  const plan = { dataTheme: dreamOn ? 'dreamos' : isDark ? 'dark' : null, vars: {}, remove: [], dream: null, wallpaperId: '', hasWallpaper: false };
  const font = fontPlan(u);

  if (dreamOn) {
    let dz = Object.assign({}, DREAM_PALETTES[0][1], u.dream || {});
    for (const [old, idx] of OLD_DREAM_PRESETS) {
      if (Object.keys(old).every((k) => dz[k] === old[k])) dz = Object.assign({}, DREAM_PALETTES[idx][1]);
    }
    plan.dream = Object.assign({}, dz); // l'ancien moteur réécrit S.ui.dream avec cette valeur
    let id = 'custom';
    DREAM_PALETTES.forEach((pl, i) => { if (Object.keys(pl[1]).every((k) => dz[k] === pl[1][k])) id = DREAM_PALETTE_IDS[i]; });
    plan.dreamPalette = id;
    const darkPaper = luminance(dz.paper) < 0.4;
    Object.assign(plan.vars, {
      '--dm': dz.main, '--dd': dz.desk, '--dp': dz.paper, '--dpop': dz.pop,
      '--dm-ink': luminance(dz.main) > 0.55 ? '#1b1b22' : '#ffffff',
      '--ink': darkPaper ? '#f3eee8' : '#24242a',
      '--muted': darkPaper ? '#c9c2bb' : '#68636a',
      '--ink-in': luminance(mixHex(dz.paper, '#ffffff', 0.35)) < 0.4 ? '#f3eee8' : '#24242a'
    });
    plan.remove.push(...DREAM_ONLY_REMOVED, ...font.remove);
    return plan;
  }

  plan.remove.push(...DREAM_VARS);
  Object.assign(plan.vars, font.set);
  const acc = u.accent || (isDark ? '#8FA3FF' : '#2A47C9');
  plan.vars['--accent'] = acc;
  plan.vars['--accent-soft'] = hexToRgba(acc, isDark ? 0.22 : 0.12);
  if (u.bgColor) plan.vars['--bg'] = u.bgColor; else plan.remove.push('--bg');
  if (u.surfaceColor) { plan.vars['--surface'] = u.surfaceColor; plan.vars['--surface-alpha'] = hexToRgba(u.surfaceColor, 0.92); }
  else plan.remove.push('--surface', '--surface-alpha');
  const baseBg = u.bgColor || (isDark ? '#11151D' : '#F3F4F7');
  plan.vars['--bg-overlay'] = hexToRgba(baseBg, typeof u.overlayOpacity === 'number' ? u.overlayOpacity : 0.72);
  plan.wallpaperId = u.wallpaperId || '';
  plan.hasWallpaper = !!u.wallpaperId;
  if (!u.wallpaperId) plan.vars['--bg-image'] = 'none';
  return plan;
}
