/**
 * dreamOS — Theme Manager (Phase 3.3) : utilisable seul (doc, jalon 3 / Settings).
 * Calcule et vérifie l'apparence ; n'écrit dans le DOM que si on appelle explicitement apply(root, plan).
 * Pendant la transition, app.js reste l'autorité d'écriture : aucun appel automatique.
 */
import { computeAppearance, contrastRatio, DREAM_PALETTES, DREAM_PALETTE_IDS, FONTS } from './theme-engine.js';

export class ThemeManager {
  #prefersDark;
  constructor({ prefersDark = () => false } = {}) { this.#prefersDark = prefersDark; }

  palettes() { return DREAM_PALETTES.map(([name, colors], i) => ({ id: DREAM_PALETTE_IDS[i], name, colors: { ...colors } })); }
  fonts() { return Object.entries(FONTS).map(([id, f]) => ({ id, name: f.name })); }
  plan(ui) { return computeAppearance(ui, { prefersDark: !!this.#prefersDark() }); }

  /** Contraste du texte sur chaque palette dreamOS : une palette sous 4,5:1 est signalée (chantier Bliss, jalon 8). */
  auditContrast(ui) {
    const plan = this.plan({ ...ui, theme: 'dreamos' });
    const v = plan.vars;
    const pairs = { 'texte sur papier': [v['--ink'], v['--dp']], 'texte discret sur papier': [v['--muted'], v['--dp']], 'texte sur barre principale': [v['--dm-ink'], v['--dm']] };
    return Object.entries(pairs).map(([label, [fg, bg]]) => { const ratio = Math.round(contrastRatio(fg, bg) * 100) / 100; return { label, ratio, ok: ratio >= 4.5 }; });
  }

  /** Écrit un plan dans un élément racine (à n'appeler que quand Settings devient propriétaire de l'apparence). */
  apply(root, plan) {
    for (const name of plan.remove) root.style.removeProperty(name);
    for (const [name, value] of Object.entries(plan.vars)) root.style.setProperty(name, value);
    if (plan.dataTheme) root.setAttribute('data-theme', plan.dataTheme); else root.removeAttribute('data-theme');
    if (plan.dreamPalette) root.setAttribute('data-dream-palette', plan.dreamPalette);
    return plan;
  }
  dispose() {}
}
export function createThemeManager(options) { return new ThemeManager(options); }
