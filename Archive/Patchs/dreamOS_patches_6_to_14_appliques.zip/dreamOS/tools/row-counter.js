/**
 * dreamOS — Compteur de rangs (Phase 3.5)
 * Reproduit rowsApply / subAdvance de app.js. Le compteur appartient au PROJET (pr.rows, pr.rts, pr.sub…) :
 * le lecteur PDF n'en est jamais propriétaire, il appelle ce service avec le projet lié (invariant de la doc).
 * Le service modifie l'objet projet fourni ; enregistrement et rendu restent à la charge de l'appelant.
 */
export function createRowCounter({ now = () => Date.now() } = {}) {
  function advanceGoal(pr, d, { onGoalReached } = {}) {
    const sb = pr && pr.sub;
    if (!sb || !(sb.target > 0) || !d) return false;
    sb.n = Math.max(0, (sb.n || 0) + d);
    if (sb.n >= sb.target) {
      const t = sb.target; pr.sub = null; pr.subDone = (pr.subDone || 0) + 1;
      if (onGoalReached) onGoalReached(t);
      return true;
    }
    return false;
  }
  return Object.freeze({
    advanceGoal,
    /**
     * @param {object} pr projet
     * @param {number} n +1, -1, +x ou 0 (remise à zéro)
     * @param {{stageOf: (pr)=>string, startProject: (pr)=>void, onGoalReached?: (target:number)=>void}} ctx
     * @returns {boolean} true si la valeur a changé
     */
    apply(pr, n, ctx) {
      const was = pr.rows || 0;
      pr.rows = n === 0 ? 0 : Math.max(0, was + n);
      if (pr.rows === was) return false;
      if (n > 0 && ctx.stageOf(pr) === 'attente') ctx.startProject(pr); // compter un rang = le projet est commencé
      if (n === 1) { (pr.rts = pr.rts || []).push(now()); if (pr.rts.length > 40) pr.rts.shift(); }
      else if (n === -1) { if (pr.rts && pr.rts.length) pr.rts.pop(); }
      else pr.rts = [];
      pr.workAt = now();
      if (n !== 0) advanceGoal(pr, pr.rows - was, ctx);
      return true;
    },
    /** Rythme moyen sur les 20 derniers intervalles (< 15 min) et temps restant estimé ; mêmes règles que vrcStat. */
    pace(pr) {
      const t = (pr && pr.rts) || []; const iv = [];
      for (let i = 1; i < t.length; i++) { const d = t[i] - t[i - 1]; if (d > 0 && d < 900000) iv.push(d); }
      const total = (pr && pr.rowsTotal) || 0; const rows = (pr && pr.rows) || 0;
      if (!iv.length) return { avgMs: 0, remainingMs: 0, done: false, rows, total };
      const l = iv.slice(-20); const avgMs = l.reduce((a, b) => a + b, 0) / l.length;
      return { avgMs, remainingMs: total > rows ? avgMs * (total - rows) : 0, done: !!total && total <= rows, rows, total };
    }
  });
}
