/**
 * dreamOS — Tools Store (Jalon 4.4)
 * Seule AUTORITÉ D'ÉCRITURE des données de l'espace Outils quand le module Tools est engagé :
 *  - grilles enregistrées (carnet.grids) : le magasin ADOPTE le tableau d'app.js (même référence) et le modifie sur place ;
 *  - valeurs d'état de l'écran (graphique carnet.chart, calculateur carnet.r3, pas de rangs carnet.rowStep, bloc-notes carnet.scratchpad) :
 *    app.js les édite en mémoire, mais leur ENREGISTREMENT passe par persist(), limité à cette liste blanche.
 * L'écriture physique reste celle d'app.js (keep + miroir IndexedDB des grilles), fournie par app.js : le magasin décide quand l'appeler.
 */
export const TOOLS_PERSISTED_KEYS = Object.freeze(['carnet.chart', 'carnet.r3', 'carnet.rowStep', 'carnet.scratchpad']);
export function createToolsStore({ eventBus } = {}) {
  let arr = null, write = null;
  const emit = (type, extra) => { try { eventBus?.emit('tools:' + type, { count: arr ? arr.length : 0, ...extra }); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  const need = () => { if (!arr) throw new Error('Tools Store (grilles) : aucun tableau adopté.'); return arr; };
  const grids = {
    adopt(a, writeFn) { if (!Array.isArray(a)) throw new TypeError('Tools Store : tableau requis.'); arr = a; if (typeof writeFn === 'function') write = writeFn; return true; },
    get adopted() { return !!arr; },
    list() { return arr; },
    count() { return arr ? arr.length : 0; },
    save() { if (write) write(need()); emit('grids-saved'); return true; },
    addFirst(g) { need().unshift(g); grids.save(); emit('grid-added', { id: g && g.id }); return g; },
    /** Met à jour une grille existante (objet de champs) puis enregistre. */
    patch(g, data) { Object.assign(g, data); grids.save(); emit('grid-updated', { id: g && g.id }); return g; },
    removeAt(i) { const r = need().splice(i, 1)[0]; grids.save(); emit('grid-removed', { id: r && r.id }); return r; },
    insertAt(i, g) { const a = need(); a.splice(Math.min(i, a.length), 0, g); grids.save(); emit('grid-restored', { id: g && g.id }); return true; },
    replaceAll(next, save) { const a = need(); const copy = Array.isArray(next) ? next.slice() : []; a.splice(0, a.length, ...copy); if (save) grids.save(); emit('grids-replaced'); return a; }
  };
  return Object.freeze({
    grids: Object.freeze(grids),
    /** Enregistre une valeur d'état d'écran via l'écriture d'app.js ; refuse toute clé hors liste blanche. */
    persist(key, value, writer) {
      if (!TOOLS_PERSISTED_KEYS.includes(key)) throw new TypeError('Tools Store : clé non gérée « ' + String(key) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('Tools Store : écriture requise.');
      writer(key, value); emit('persisted', { key }); return true;
    }
  });
}
