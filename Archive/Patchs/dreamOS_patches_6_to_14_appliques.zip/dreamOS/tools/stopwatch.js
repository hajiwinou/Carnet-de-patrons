/**
 * dreamOS — Chronomètre (Phase 3.5)
 * Service réutilisable : le projet concerné est TOUJOURS passé explicitement (pas d'état global caché).
 * Reproduit à l'identique tmMs / tmTotal / tmLogMs / tmFmt / tmShort / tmToggle de app.js.
 * Les données (pr.timer, pr.log, pr.workAt) restent possédées par Projects/app.js : le service les lit et, pour
 * toggle(), les modifie sur l'objet fourni, sans jamais enregistrer ni rendre (c'est à l'appelant de le faire).
 */
export function createStopwatch({ now = () => Date.now() } = {}) {
  const logMs = (entry) => {
    if (entry && typeof entry.ms === 'number') return entry.ms;
    const m = /^Temps tricoté : (\d+):(\d\d):(\d\d)/.exec((entry && entry.text) || '');
    return m ? ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 : 0;
  };
  const elapsed = (pr) => { const t = pr.timer; return t ? (t.acc || 0) + (t.start ? now() - t.start : 0) : 0; };
  const pad = (n) => (n < 10 ? '0' : '') + n;

  return Object.freeze({
    logMs,
    elapsed,
    /** Temps du chrono en cours + temps déjà inscrits au journal du projet. */
    total(pr) { let t = elapsed(pr); (pr.log || []).forEach((en) => { t += logMs(en); }); return t; },
    format(ms) { let s = Math.floor(ms / 1000); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); s %= 60; return `${pad(h)}:${pad(m)}:${pad(s)}`; },
    short(ms) {
      const m = Math.floor(ms / 60000); const h = Math.floor(m / 60);
      if (ms > 0 && m < 1) return '< 1 min';
      return h ? `${h} h ${m % 60 < 10 ? '0' : ''}${m % 60}` : `${m} min`;
    },
    /**
     * Démarre/arrête le chrono du projet. Un seul chrono tourne à la fois : les autres projets sont arrêtés.
     * @param {object} pr projet
     * @param {{projects: object[], stageOf: (pr)=>string, startProject: (pr)=>void}} ctx contexte explicite fourni par l'appelant
     */
    toggle(pr, { projects, stageOf, startProject }) {
      projects.forEach((x) => { if (x !== pr && x.timer && x.timer.start) { x.timer.acc += now() - x.timer.start; x.timer.start = 0; } });
      if (!pr.timer) pr.timer = { acc: 0, start: 0 };
      if (!pr.timer.start && stageOf(pr) === 'attente') startProject(pr); // lancer le chrono = le projet est commencé
      pr.workAt = now();
      if (pr.timer.start) { pr.timer.acc += now() - pr.timer.start; pr.timer.start = 0; } else pr.timer.start = now();
      return pr.timer.start !== 0;
    }
  });
}
