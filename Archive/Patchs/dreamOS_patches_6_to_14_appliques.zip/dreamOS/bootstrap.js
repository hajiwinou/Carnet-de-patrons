/**
 * dreamOS — Bootstrap ESM (Phase 2.1)
 *
 * Point d’entrée du futur environnement modulaire.
 * Le moteur historique (app.js / app-late.js) reste chargé séparément
 * et conserve la responsabilité du démarrage métier et des données.
 */
import { createEventBus } from './event-bus.js';
import { createServiceRegistry } from './service-registry.js';
import { createStorageManager } from './storage-manager.js';
import { createMediaManager } from './media-manager.js';
import { createBackupManager } from './backup-manager.js';
import { createAIManager } from './ai/ai-manager.js';
import { createNotificationManager } from './notifications/notification-manager.js';
import { createDialogManager } from './dialogs/dialog-manager.js';
import { createLegacyAdapter } from './legacy-adapter.js';
import { createIdGenerator } from './core/stable-ids.js';
import { createModuleRegistry } from './modules/module-registry.js';
import { MODULE_MANIFEST } from './modules/manifest.js';
import { createThemeManager } from './theme/theme-manager.js';
import { installPatternsHost } from './patterns/patterns-host.js';
import { installProjectsHost } from './projects/projects-host.js';
import { installPdfReaderHost } from './pdf-reader/pdf-reader-host.js';
import { installDocumentationHost } from './documentation/documentation-host.js';
import { installDownloadsHost } from './downloads/downloads-host.js';
import { installLibraryHost } from './library/library-host.js';
import { installToolsHost } from './tools/tools-host.js';
import { installThemeHost } from './theme/theme-host.js';
import { installSettingsHost } from './settings/settings-host.js';
import { createActionRouter } from './modules/action-router.js';

const DREAMOS_VERSION = '5.2.0';

function domReady() {
  if (document.readyState !== 'loading') return Promise.resolve();
  return new Promise((resolve) => {
    document.addEventListener('DOMContentLoaded', resolve, { once: true });
  });
}

async function bootstrap() {
  if (window.dreamOS) return window.dreamOS;

  const events = createEventBus();
  const services = createServiceRegistry();

  services.register('eventBus', () => events);
  services.register('serviceRegistry', () => services);
  // Même base, même version et même magasin que le moteur historique.
  // Le service reste paresseux : aucune ouverture ni migration au bootstrap.
  services.register('storageManager', () => createStorageManager());
  // Le MediaManager réutilise le StorageManager historique et reste paresseux.
  services.register('mediaManager', async (registry) =>
    createMediaManager({ storage: await registry.resolve('storageManager') })
  );
  // Le BackupManager contrôle/crée le format ZIP v1 sans remplacer la restauration legacy.
  services.register('backupManager', async (registry) =>
    createBackupManager({ storage: await registry.resolve('storageManager') })
  );
  // AIManager reste indépendant du state privé legacy : la configuration est fournie
  // explicitement à chaque appel, sans copie ni déplacement des clés API.
  services.register('aiManager', () => createAIManager());
  // Les services utilisent les conteneurs historiques #toast et #dlg, sans
  // remplacer les fonctions legacy ; ils ne prennent le contrôle qu'à l'appel.
  services.register('notificationManager', () => createNotificationManager({ eventBus: events }));
  services.register('dialogManager', () => createDialogManager({ eventBus: events }));
  // Phase 3.1 : socle additif. Aucun des deux n'écrit de donnée ni n'est appelé par app.js.
  services.register('idGenerator', () => createIdGenerator());
  services.register('moduleRegistry', () => {
    const registry = createModuleRegistry();
    MODULE_MANIFEST.forEach((descriptor) => registry.declare(descriptor));
    return registry;
  });
  // Phase 3.3 : Theme Manager (calcul pur ; n'écrit rien tant qu'on n'appelle pas apply()).
  services.register('themeManager', () => createThemeManager({
    prefersDark: () => !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)
  }));
  // Phase 3.2 : routeur d'actions, en capture avant app.js. Inerte tant qu'aucun module ne revendique d'action.
  services.register('actionRouter', () => createActionRouter({ eventBus: events, target: document }).start(), { eager: true });
  // Pont limité : l'état métier reste détenu par l'IIFE historique.
  const legacy = createLegacyAdapter({ bridge: window.DreamOSLegacy, eventBus: events });
  services.register('legacyAdapter', legacy);

  const runtime = Object.freeze({
    version: DREAMOS_VERSION,
    events,
    services,
    legacy,
    status: 'ready'
  });

  // API additive, en lecture seule au niveau de la propriété globale.
  Object.defineProperty(window, 'dreamOS', {
    configurable: false,
    enumerable: true,
    writable: false,
    value: runtime
  });

  await services.startEager();

  // Phase 3.4 : le Theme Manager applique l'apparence (retour arrière : window.DreamOSThemeHost.release()
  // ou ?theme=legacy dans l'adresse). La donnée S.ui reste possédée par app.js.
  const themeHost = installThemeHost({
    themeManager: services.get('themeManager'),
    moduleRegistry: services.get('moduleRegistry'),
    legacy,
    eventBus: events
  });
  // Phase 3.8 : le module Patterns porte le moteur pur (texte, schéma de fiche, IA, grilles) (retour arrière :
  // window.DreamOSPatternsHost.release() ou ?patterns=legacy). Données, enregistrement, doublons, IA réseau et rendu restent à app.js.
  const ids = services.get('idGenerator');
  const patternsHost = installPatternsHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events, uid: () => ids.next('p') });
  if (!/[?&]patterns=legacy\b/.test(location.search)) {
    try { patternsHost.engage(); } catch (error) { console.warn('[dreamOS] Patterns non engagé', error); }
  }
  // Phase 3.9 : le module Projects porte le moteur pur (étape, fils et pelotes, plan de couleurs, notes, WIP Island, dates)
  // (retour arrière : window.DreamOSProjectsHost.release() ou ?projects=legacy). Données, enregistrement et rendu restent à app.js.
  const projectsHost = installProjectsHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events, uid: () => ids.next('p') });
  if (!/[?&]projects=legacy\b/.test(location.search)) {
    try { projectsHost.engage(); } catch (error) { console.warn('[dreamOS] Projects non engagé', error); }
  }
  // Jalon 4.9 : le module Settings écrit les réglages (apparence, options, IA, verrou, dernière sauvegarde) et le fond d'écran wp_*
  // (retour arrière : window.DreamOSSettingsHost.release() ou ?settings=legacy). Valeurs, empreinte du mot de passe et rendu restent à app.js.
  const settingsHost = installSettingsHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]settings=legacy\b/.test(location.search)) {
    try { settingsHost.engage(); } catch (error) { console.warn('[dreamOS] Settings non engagé', error); }
  }
  // Phase 3.10 : le module PDF Reader porte les calculs purs du lecteur (page, durées, zoom, surcouches)
  // (retour arrière : window.DreamOSPdfReaderHost.release() ou ?pdfreader=legacy). DOM et pdf.js restent à app.js ; depuis 4.8 le module écrit aussi les positions et surlignages.
  const pdfReaderHost = installPdfReaderHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]pdfreader=legacy\b/.test(location.search)) {
    try { pdfReaderHost.engage(); } catch (error) { console.warn('[dreamOS] PDF Reader non engagé', error); }
  }
  // Phase 3.11 : le module Documentation porte la logique pure (brouillon, publication, types de médias, libellés)
  // (retour arrière : window.DreamOSDocumentationHost.release() ou ?documentation=legacy). Données, médias docm_* et rendu restent à app.js.
  const documentationHost = installDocumentationHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]documentation=legacy\b/.test(location.search)) {
    try { documentationHost.engage(); } catch (error) { console.warn('[dreamOS] Documentation non engagée', error); }
  }
  // Phase 3.7 : le module Downloads porte le client Cobalt (retour arrière : window.DreamOSDownloadsHost.release()
  // ou ?downloads=legacy). Adresse, clé et état de l'écran restent à app.js.
  const downloadsHost = installDownloadsHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]downloads=legacy\b/.test(location.search)) {
    try { downloadsHost.engage(); } catch (error) { console.warn('[dreamOS] Downloads non engagé', error); }
  }
  // Phase 3.6 : Search Manager, Library et Documentation portent la recherche et les filtres (retour arrière :
  // window.DreamOSLibraryHost.release() ou ?library=legacy). Données et rendu restent à app.js.
  const libraryHost = installLibraryHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]library=legacy\b/.test(location.search)) {
    try { libraryHost.engage(); } catch (error) { console.warn('[dreamOS] Library non engagée', error); }
  }
  // Phase 3.5 : le module Tools porte la logique du chronomètre et du compteur de rangs (retour arrière :
  // window.DreamOSToolsHost.release() ou ?tools=legacy). Les données restent possédées par Projects / app.js.
  const toolsHost = installToolsHost({ moduleRegistry: services.get('moduleRegistry'), legacy, eventBus: events });
  if (!/[?&]tools=legacy\b/.test(location.search)) {
    try { toolsHost.engage(); } catch (error) { console.warn('[dreamOS] Module Tools non engagé', error); }
  }
  if (!/[?&]theme=legacy\b/.test(location.search)) {
    try { themeHost.engage(); } catch (error) { console.warn('[dreamOS] Theme Manager non engagé', error); }
  }
  await domReady();

  events.emit('dreamos:ready', {
    version: DREAMOS_VERSION,
    timestamp: Date.now()
  });

  // Simple constat de présence : ce signal ne prétend pas que le boot métier
  // asynchrone du legacy (IndexedDB/restauration/rendu) est terminé.
  const legacyScriptPresent = [...document.scripts].some((script) =>
    /(?:^|\/)app\.js(?:\?|$)/.test(script.getAttribute('src') || '')
  );
  events.emit('dreamos:legacy-script-detected', { present: legacyScriptPresent });
  if (legacyScriptPresent) events.emit('legacy:script-loaded', { status: legacy.status });

  document.dispatchEvent(new CustomEvent('dreamos:ready', {
    detail: { version: DREAMOS_VERSION }
  }));

  return runtime;
}

bootstrap().catch((error) => {
  console.error('[dreamOS] Échec du bootstrap ESM', error);
  document.dispatchEvent(new CustomEvent('dreamos:error', { detail: { error } }));
});
