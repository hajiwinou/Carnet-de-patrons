/**
 * dreamOS — Backup Manager (Phase 2.4)
 * Outils additifs de création et de contrôle des archives historiques v1.
 * La restauration métier reste pilotée par le moteur historique : aucune
 * donnée n'est écrasée ou fusionnée par ce service.
 */

const FORMAT_VERSION = 1;
const MEDIA_PREFIX = /^(pdf_|img_|th_|docm_|pjc_|pjp_|wall_|idea_|inspo_)/;
// Préfixes réellement créés par app.js (fonds d'écran, médias d'idées, inspirations de projet), absents de la liste
// historique ci-dessus. Leur absence dans une archive est signalée (warnings) sans bloquer la restauration, afin de
// ne pas refuser d'anciennes archives qui restaient restaurables (décision Phase 3.1).
const SOFT_MEDIA_PREFIX = /^(wp_|ideam_|pji_)/;
const IGNORED_REFERENCE_FIELDS = new Set(['raw', 'text', 'content', 'note', 'name', 'title', 'file']);
const ZIP_URL = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
const ZIP_INTEGRITY = 'sha384-+mbV2IY1Zk/X1p/nWllGySJSUN8uMs+gUAN10Or95UBH0fpj6GfKgPmgC5EXieXG';
let zipLoadPromise = null;

async function defaultZipProvider() {
  if (globalThis.JSZip) return globalThis.JSZip;
  if (typeof document === 'undefined') return null;
  if (!zipLoadPromise) {
    zipLoadPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = ZIP_URL;
      script.integrity = ZIP_INTEGRITY;
      script.crossOrigin = 'anonymous';
      script.onload = () => resolve(globalThis.JSZip || null);
      script.onerror = () => { zipLoadPromise = null; reject(new Error('Chargement de la bibliothèque ZIP impossible.')); };
      document.head.appendChild(script);
    });
  }
  return zipLoadPromise;
}

function assertData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new TypeError('Les données de sauvegarde doivent être un objet.');
  }
  if (data.v !== FORMAT_VERSION) {
    throw new Error(`Format de sauvegarde non pris en charge (v${String(data.v)}).`);
  }
  if (!Array.isArray(data.patterns)) {
    throw new Error('Sauvegarde invalide : la liste des patrons est absente.');
  }
  for (const field of ['folders', 'projects', 'grids', 'docs', 'ideas', 'boards']) {
    if (data[field] !== undefined && !Array.isArray(data[field])) {
      throw new Error(`Sauvegarde invalide : « ${field} » doit être une liste.`);
    }
  }
  return data;
}

function referencedMedia(data, pattern = MEDIA_PREFIX) {
  const refs = new Set();
  const visit = (value, field) => {
    if (!value) return;
    if (typeof value === 'string') {
      if (!IGNORED_REFERENCE_FIELDS.has(field) && pattern.test(value)) refs.add(value);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((item) => visit(item, field));
      return;
    }
    if (typeof value === 'object') {
      Object.keys(value).forEach((key) => visit(value[key], key));
    }
  };
  visit(data, '');
  return refs;
}

function parseJson(text, label) {
  try { return JSON.parse(text); }
  catch (error) { throw new Error(`${label} est invalide : ${error.message}`); }
}

export class BackupManager {
  #storage;
  #zipProvider;
  #maxBytes;
  #running = false;
  #disposed = false;

  constructor({ storage, zipProvider = defaultZipProvider, maxBytes = 200 * 1024 * 1024 } = {}) {
    if (!storage || typeof storage.keys !== 'function' || typeof storage.get !== 'function') {
      throw new TypeError('BackupManager nécessite un StorageManager compatible.');
    }
    if (typeof zipProvider !== 'function') throw new TypeError('Un fournisseur ZIP est requis.');
    if (!Number.isFinite(maxBytes) || maxBytes <= 0) throw new TypeError('La limite de taille doit être positive.');
    this.#storage = storage;
    this.#zipProvider = zipProvider;
    this.#maxBytes = maxBytes;
  }

  #assertActive() {
    if (this.#disposed) throw new Error('BackupManager est fermé.');
  }

  get formatVersion() { return FORMAT_VERSION; }
  get isRunning() { return this.#running; }

  validateData(data) {
    this.#assertActive();
    assertData(data);
    return Object.freeze({ valid: true, formatVersion: FORMAT_VERSION, patternCount: data.patterns.length });
  }

  async createArchive(data) {
    this.#assertActive();
    if (this.#running) throw new Error('Une opération de sauvegarde est déjà en cours.');
    assertData(data);
    const JSZip = await this.#zipProvider();
    if (!JSZip) throw new Error('La bibliothèque ZIP n’est pas chargée. Ouvrez d’abord une fonction de sauvegarde historique, puis réessayez.');

    this.#running = true;
    try {
      const zip = new JSZip();
      const payload = JSON.stringify(data);
      zip.file('data.json', payload);
      const keys = (await this.#storage.keys()).filter((key) => !String(key).startsWith('meta_'));
      const required = referencedMedia(data);
      const available = new Set(keys);
      for (const key of required) {
        if (!available.has(key)) throw new Error(`Fichier référencé manquant : ${key}`);
      }
      const types = {};
      let totalBytes = 0;
      for (const key of keys) {
        const blob = await this.#storage.get(key);
        if (blob === undefined || blob === null) {
          if (required.has(key)) throw new Error(`Fichier référencé illisible : ${key}`);
          continue;
        }
        if (!(blob instanceof Blob)) throw new Error(`Contenu non reconnu dans le stockage : ${key}`);
        totalBytes += blob.size;
        if (totalBytes > this.#maxBytes) {
          throw new Error(`Les médias dépassent la limite de ${Math.round(this.#maxBytes / 1024 / 1024)} Mo de ce service. Utilisez la sauvegarde historique, qui sait découper les gros ZIP.`);
        }
        zip.file(`blobs/${key}`, blob);
        types[key] = blob.type || '';
      }
      zip.file('types.json', JSON.stringify(types));
      return await zip.generateAsync({ type: 'blob', compression: 'STORE' });
    } finally {
      this.#running = false;
    }
  }

  async inspectArchive(file) {
    this.#assertActive();
    if (this.#running) throw new Error('Une opération de sauvegarde est déjà en cours.');
    const JSZip = await this.#zipProvider();
    if (!JSZip || typeof JSZip.loadAsync !== 'function') {
      throw new Error('La bibliothèque ZIP n’est pas chargée. Ouvrez d’abord une fonction de sauvegarde historique, puis réessayez.');
    }
    if (!file || typeof file.arrayBuffer !== 'function') throw new TypeError('Un fichier ZIP est requis.');

    this.#running = true;
    try {
      const zip = await JSZip.loadAsync(file);
      const dataEntry = zip.file('data.json');
      if (!dataEntry) throw new Error('Archive invalide : data.json est absent.');
      const data = assertData(parseJson(await dataEntry.async('string'), 'data.json'));
      let types = {};
      const typesEntry = zip.file('types.json');
      if (typesEntry) types = parseJson(await typesEntry.async('string'), 'types.json');
      if (!types || typeof types !== 'object' || Array.isArray(types)) throw new Error('types.json doit contenir un objet.');

      const mediaEntries = [];
      const folder = zip.folder('blobs');
      if (folder && typeof folder.forEach === 'function') {
        folder.forEach((relative, entry) => { if (entry && !entry.dir) mediaEntries.push(`blobs/${relative}`); });
      }
      const available = new Set(mediaEntries.map((path) => path.slice('blobs/'.length)));
      const missing = [...referencedMedia(data)].filter((key) => !available.has(key));
      if (missing.length) throw new Error(`Archive incomplète : ${missing.length} média(s) référencé(s) manquant(s) (${missing.slice(0, 3).join(', ')}).`);

      const warnings = [...referencedMedia(data, SOFT_MEDIA_PREFIX)].filter((key) => !available.has(key)).map((key) => `Média référencé absent de l’archive : ${key}`);

      return Object.freeze({
        valid: true,
        warnings: Object.freeze(warnings),
        formatVersion: FORMAT_VERSION,
        patternCount: data.patterns.length,
        mediaCount: mediaEntries.length,
        data,
        mediaEntries: Object.freeze(mediaEntries),
        types: Object.freeze({ ...types })
      });
    } finally {
      this.#running = false;
    }
  }

  dispose() { this.#disposed = true; }
}

export function createBackupManager(options) { return new BackupManager(options); }
