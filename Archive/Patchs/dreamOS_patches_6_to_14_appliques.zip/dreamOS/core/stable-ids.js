/**
 * dreamOS — Générateur d'identifiants stables (Phase 3.1)
 * Format identique à l'uid() historique de app.js : base36(Date.now()) + 4 caractères aléatoires,
 * avec un préfixe de type optionnel ('j' projet, 'y' fil, 'e' entrée de journal, 'd' dossier…).
 * Module pur : n'écrit rien, ne lit aucune donnée. Il n'est PAS branché sur app.js (une seule
 * autorité d'écriture : l'ancien moteur continue de générer ses identifiants).
 */
const LEGACY_ID = /^[a-z]{0,3}[0-9a-z]{8,}$/;

export function createIdGenerator({ now = () => Date.now(), random = () => Math.random() } = {}) {
  let lastMs = 0;
  let seq = 0;
  const rnd = () => random().toString(36).slice(2, 6).padEnd(4, '0');

  return Object.freeze({
    /** @param {string} [prefix] ex. 'j', 'y', 'e' */
    next(prefix = '') {
      if (typeof prefix !== 'string' || !/^[a-z]{0,3}$/.test(prefix)) {
        throw new TypeError('Le préfixe doit comporter 0 à 3 lettres minuscules.');
      }
      const ms = now();
      // Deux appels dans la même milliseconde ne doivent jamais produire le même identifiant.
      seq = ms === lastMs ? seq + 1 : 0;
      lastMs = ms;
      const tail = seq === 0 ? rnd() : seq.toString(36).padStart(4, '0'); // compteur déterministe : jamais de collision dans la même ms
      return `${prefix}${ms.toString(36)}${tail}`;
    },
    /** Un identifiant historique (ex. 'pmgx1a2b3c4d') est accepté tel quel : jamais réécrit. */
    isValid(id) { return typeof id === 'string' && LEGACY_ID.test(id); },
    /** Instant de création approximatif encodé dans l'identifiant, ou null. */
    createdAt(id, prefix = '') {
      if (!this.isValid(id) || !id.startsWith(prefix)) return null;
      const ms = parseInt(id.slice(prefix.length, id.length - 4), 36);
      return Number.isFinite(ms) && ms > 0 ? ms : null;
    }
  });
}
