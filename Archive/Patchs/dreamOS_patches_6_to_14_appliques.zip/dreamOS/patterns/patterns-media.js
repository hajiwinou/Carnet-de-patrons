/**
 * dreamOS — Patterns Media (Jalon 4.7b)
 * AUTORITÉ D'ÉCRITURE des médias de patrons quand le module Patterns est engagé :
 *  - pdf_<id du patron> : le PDF du patron ;
 *  - th_<id du patron>  : sa miniature (première page) ;
 *  - img_<uid>          : ses photos (modèle, détails…).
 * Création d'identifiant, écriture d'un blob et suppression passent par ici. L'écriture physique reste celle d'app.js (cache de blobs +
 * IndexedDB), passée en paramètre ; la lecture (getBlobUrl, lecteur PDF) reste partagée.
 * Deux voies d'écriture : put() pour un NOUVEAU média (préfixe pdf_ / th_ / img_ imposé) ; restore() pour un identifiant DÉJÀ existant
 * (import d'un ZIP ou d'une sauvegarde anciens, dont l'identifiant peut avoir un autre format : il est conservé tel quel).
 * La suppression n'impose pas de préfixe (anciens patrons) ; la restauration groupée d'une sauvegarde reste au futur service de sauvegarde.
 */
export const PATTERN_MEDIA_PREFIXES = Object.freeze(['pdf_', 'th_', 'img_']);
export function createPatternsMedia({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('patterns:media-' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une écriture */ } };
  const own = (id) => typeof id === 'string' && PATTERN_MEDIA_PREFIXES.some((p) => id.startsWith(p));
  const prefixOk = (prefix) => { if (!PATTERN_MEDIA_PREFIXES.includes(prefix)) throw new TypeError('Patterns Media : préfixe non géré « ' + String(prefix) + ' ».'); };
  return Object.freeze({
    prefixes: PATTERN_MEDIA_PREFIXES,
    isOwn: own,
    /** Nouvel identifiant : préfixe suivi de l'identifiant fourni (même format qu'avant). */
    newId(prefix, uid) { prefixOk(prefix); return prefix + uid(); },
    /** Identifiant dérivé de celui du patron (pdf_ / th_). */
    idFor(prefix, patternId) { prefixOk(prefix); if (typeof patternId !== 'string' || !patternId) throw new TypeError('Patterns Media : identifiant de patron requis.'); return prefix + patternId; },
    async put(id, blob, writer) {
      if (!own(id)) throw new TypeError('Patterns Media : identifiant pdf_ / th_ / img_ requis (reçu « ' + String(id) + ' »).');
      if (typeof writer !== 'function') throw new TypeError('Patterns Media : écriture requise.');
      const r = await writer(id, blob); emit('saved', { id }); return r;
    },
    /** Écrit un média dont l'identifiant existe déjà (import, restauration) : l'identifiant est conservé. */
    async restore(id, blob, writer) {
      if (typeof id !== 'string' || !id) throw new TypeError('Patterns Media : identifiant requis.');
      if (typeof writer !== 'function') throw new TypeError('Patterns Media : écriture requise.');
      const r = await writer(id, blob); emit('restored', { id }); return r;
    },
    discard(id, remover) {
      if (typeof remover !== 'function') throw new TypeError('Patterns Media : suppression requise.');
      remover(id); emit('discarded', { id }); return true;
    },
    /** Identifiants de médias de patrons référencés par une liste de patrons (PDF, miniature, photos). */
    referenced(patterns) {
      const s = new Set();
      (patterns || []).forEach((p) => {
        if (!p) return;
        if (p.source && own(p.source.pdf)) s.add(p.source.pdf);
        if (own(p.thumb)) s.add(p.thumb);
        (p.photos || []).forEach((ph) => { if (ph && own(ph.id)) s.add(ph.id); });
      });
      return s;
    }
  });
}
