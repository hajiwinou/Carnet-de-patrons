/**
 * dreamOS — Patterns Host (Phase 3.8)
 * Transfère la LOGIQUE PURE de Patterns (moteur extrait d'app.js : nettoyage / découpage du texte, devinettes auteur et
 * vêtement, schéma et complétude de la fiche, application des résultats de l'IA, fusion des grilles et options) au module Patterns.
 * Les DONNÉES (carnet.patterns, carnet.folders…, médias pdf_* / th_* / img_*), l'enregistrement, les dossiers, les doublons,
 * les appels aux fournisseurs d'IA et le rendu restent à app.js : le patron concerné est passé en paramètre et seul cet objet est modifié.
 * Jalon 4.7a : le module est aussi l'autorité d'écriture de la LISTE des patrons et des dossiers et de leur enregistrement (patterns-store.js) ;
 * Jalon 4.7b : et des médias de patrons pdf_* / th_* / img_* (patterns-media.js).
 * Jalon 4.7c : et des commandes de modification directe d'un patron (patterns-commands.js) ; 
 * Jalon 4.7d : et de la création d'un patron / dossier, de l'enregistrement de l'analyse par IA et des préférences d'affichage (auteurs favoris, groupes repliés, groupement).
 * app.js consulte window.DreamOSPatternsHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createPatternsEngine } from './patterns-engine.js';
import { createPatternsStore } from './patterns-store.js';
import { createPatternsMedia } from './patterns-media.js';
import { createPatternsCommands } from './patterns-commands.js';

export const PATTERNS_RESOURCES = Object.freeze([['logic', 'patterns-engine', 'patterns'], ['storage', 'carnet.patterns', 'patterns'], ['storage', 'carnet.ts', 'patterns'], ['storage', 'carnet.folders', 'patterns'], ['storage', 'carnet.favAuthors', 'patterns'], ['storage', 'carnet.collapsed', 'patterns'], ['storage', 'carnet.group', 'patterns'], ['media', 'pdf_*', 'patterns'], ['media', 'th_*', 'patterns'], ['media', 'img_*', 'patterns']]);

export function installPatternsHost({ moduleRegistry, legacy, eventBus, uid, now = () => Date.now(), win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installPatternsHost : window requis.');
  if (win.DreamOSPatternsHost) return win.DreamOSPatternsHost;
  let enabled = false;
  const move = (toOwner) => PATTERNS_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    engine: createPatternsEngine({ uid }),
    store: createPatternsStore({ eventBus }),
    media: createPatternsMedia({ eventBus }),
    commands: createPatternsCommands({ uid, now }),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('patterns:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('patterns:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSPatternsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSPatternsHost;
}
