/**
 * dreamOS — Patterns Store (Jalon 4.7a)
 * AUTORITÉ D'ÉCRITURE de la LISTE des patrons (carnet.patterns) et de celle des dossiers (carnet.folders), ainsi que de leur
 * DÉCLENCHEMENT d'enregistrement, quand le module Patterns est engagé.
 *
 * Périmètre de cette sous-étape (4.7a) — volontairement limité :
 *  - structure des listes : ajout, retrait, annulation, remplacement (import, restauration, récupération) ;
 *  - enregistrement : tout enregistrement différé (save) ou immédiat (saveNow) des patrons, et celui des dossiers, passe ici ;
 *  - les champs d'un patron (titre, texte, grilles, photos…) et les médias (pdf_ / th_ / img_) restent à app.js (4.7b, 4.7c).
 * Même principe qu'ailleurs : le magasin ADOPTE les tableaux d'app.js (même référence) et les modifie en place ; l'écriture
 * physique (IndexedDB « meta_patterns », localStorage, miroir « meta_folders ») reste la fonction fournie par app.js.
 * Les ajouts / retraits ne sauvegardent PAS d'eux-mêmes (le code d'origine sauvegarde à part, parfois plus tard) : l'appelant
 * demande save() / saveNow() exactement comme avant.
 */
export const PATTERNS_PERSISTED_KEYS = Object.freeze(['carnet.patterns', 'carnet.ts', 'carnet.folders', 'carnet.favAuthors', 'carnet.collapsed', 'carnet.group']);
function createList(label, emit) {
  let arr = null, writers = {};
  const need = () => { if (!arr) throw new Error('Patterns Store : aucun tableau « ' + label + ' » adopté.'); return arr; };
  const l = {
    adopt(a, w) { if (!Array.isArray(a)) throw new TypeError('Patterns Store : tableau requis (' + label + ').'); arr = a; if (w) writers = { ...writers, ...w }; return true; },
    get adopted() { return !!arr; },
    list() { return arr; },
    count() { return arr ? arr.length : 0; },
    save(...args) { emit(label + ':saved'); return writers.save ? writers.save(need(), ...args) : undefined; },
    saveNow() { emit(label + ':saved'); return writers.saveNow ? writers.saveNow(need()) : undefined; },
    append(x) { need().push(x); emit(label + ':added', { id: x && x.id }); return x; },
    prepend(x) { need().unshift(x); emit(label + ':added', { id: x && x.id }); return x; },
    removeAt(i) { const r = need().splice(i, 1)[0]; emit(label + ':removed', { id: r && r.id }); return r; },
    insertAt(i, x) { const a = need(); a.splice(Math.min(i, a.length), 0, x); emit(label + ':restored', { id: x && x.id }); return true; },
    /** Retire TOUS les éléments portant cet identifiant (même sémantique que l'ancien filter). */
    removeById(id) { const a = need(); let n = 0; for (let i = a.length - 1; i >= 0; i--) if (a[i].id === id) { a.splice(i, 1); n++; } if (n) emit(label + ':removed', { id }); return n; },
    upsert(x) { const a = need(), i = a.findIndex((y) => y.id === x.id); if (i >= 0) a[i] = x; else a.unshift(x); emit(label + ':upserted', { id: x && x.id }); return x; },
    replaceAll(next) { const a = need(), copy = Array.isArray(next) ? next.slice() : []; a.splice(0, a.length, ...copy); emit(label + ':replaced'); return a; }
  };
  return l;
}
export function createPatternsStore({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('patterns:' + type, extra || {}); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  const patterns = createList('patterns', emit), folders = createList('folders', emit);
  return Object.freeze({
    patterns: Object.freeze(patterns), folders: Object.freeze(folders),
    persist(key, value, writer) {
      if (!PATTERNS_PERSISTED_KEYS.includes(key)) throw new TypeError('Patterns Store : clé non gérée « ' + String(key) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('Patterns Store : écriture requise.');
      writer(key, value); emit('persisted', { key }); return true;
    }
  });
}
