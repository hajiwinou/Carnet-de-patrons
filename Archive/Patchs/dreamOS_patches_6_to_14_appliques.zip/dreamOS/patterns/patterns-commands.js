/**
 * dreamOS — Patterns Commands (Jalon 4.7c)
 * Les MODIFICATIONS directes d'un patron par l'utilisatrice ou par l'import (titre, texte, statut, dossier, étape, source PDF, miniature, photos,
 * fiche technique, variantes), qui étaient écrites en ligne dans app.js, sont ici des commandes nommées appliquées au patron passé en paramètre.
 * Transcriptions fidèles du code d'origine : mêmes champs, même ordre, mêmes valeurs. Elles ne font ni enregistrement, ni suppression de média,
 * ni rendu : app.js enregistre (persist → magasin 4.7a) et gère les médias (passerelle 4.7b).
 * Jalon 4.7d : ajoute la création d'un patron / d'un dossier, l'enregistrement de l'analyse par IA et les préférences d'affichage de la bibliothèque (auteurs favoris, groupes repliés).
 * Le remplissage de la fiche par l'IA lui-même est dans patterns-engine.js (appliqué par app.js via les portes).
 */
export function createPatternsCommands({ uid, now = () => Date.now() } = {}) {
  if (typeof uid !== 'function') throw new TypeError('Patterns Commands : uid requis.');
  return Object.freeze({
    /** Champ simple (titre, statut…). */
    setField(p, field, value) { p[field] = value; },
    /** Texte du patron : coupé à 90 000 caractères, version incrémentée. */
    setRaw(p, value) { p.raw = value.slice(0, 90000); p._v = (p._v || 0) + 1; },
    /** Texte obtenu par transcription OCR : le patron n'est plus « scanné ». */
    setTranscript(p, text) { p.raw = text; p.scanned = false; p._v = (p._v || 0) + 1; },
    markScanned(p) { p.scanned = true; },
    /** Dossier choisi dans la liste (valeur vide = sortir du dossier). */
    setFolderField(p, value) { if (value) p.folder = value; else delete p.folder; },
    setFolder(p, id) { p.folder = id; },
    setPhotoKind(p, index, value) { p.photos[+index].kind = value; },
    addPhoto(p, id, kind) { p.photos = (p.photos || []).concat([{ id: id, kind: kind }]); },
    /** Changement d'étape (de → vers) avec sa date et l'étape précédente. */
    setStage(p, from, st) { p.stage = st; p.stageAt = p.stageAt || {}; p.stageAt[st] = now(); p.stagePrev = from; },
    /** Renommage : titre et nom du fichier source. */
    rename(p, name) { p.title = name; p.source = p.source || {}; p.source.file = name + '.pdf'; },
    ensureSource(p) { p.source = p.source || {}; },
    setSourcePdf(p, id) { p.source.pdf = id; },
    setSourceFileDefault(p, name) { p.source.file = p.source.file || name; },
    setSourcePages(p, n) { p.source.pages = n; },
    clearThumb(p) { delete p.thumb; },
    setThumb(p, id) { p.thumb = id; },
    /** Valeur d'une information de la fiche (vide = effacée) ; elle n'est plus « détectée par IA ». */
    setFact(p, key, value) { if (value === '' || value === undefined) delete p.f[key]; else p.f[key] = value; delete p.ai[key]; },
    /** Information à choix multiples : liste vide = effacée. */
    setChipFact(p, key, arr) { if (arr.length) p.f[key] = arr; else delete p.f[key]; },
    addOption(p) { p.opts = p.opts || []; p.opts.push({ id: uid(), group: 'Manches', name: '', desc: '', f: {}, measures: {}, counts: {}, ai: 0 }); },
    removeOption(p, index) { p.opts.splice(+index, 1); },
    /** Mesure ou nombre de rangs d'une variante pour une taille (vide = effacé). */
    setOptionGrid(o, grid, row, size, value) { const g = o[grid] = o[grid] || {}; g[row] = g[row] || {}; if (value === '') delete g[row][size]; else g[row][size] = parseFloat(value); },
    /** Information de fiche d'une variante (valeur déjà normalisée) ; la variante n'est plus « détectée par IA ». */
    setOptionFact(o, key, value) { if (value === '' || value === undefined) delete o.f[key]; else o.f[key] = value; o.ai = 0; },
    setOptionProp(o, key, value) { o[key] = value; o.ai = 0; },
    /** Nouveau patron vide (les devinettes auteur / vêtement s'ajoutent ensuite avec markGuess). */
    createPattern(title, raw, source) {
      return { id: uid(), title: title || 'Patron sans titre', created: now(), status: 'brouillon', source: source || {}, raw: raw || '', f: {}, g: { measures: {}, counts: {} }, photos: [], ai: {}, ev: {}, gai: {}, opts: [] };
    },
    /** Information déduite du texte ou du titre : marquée « détectée par IA » avec sa preuve. */
    markGuess(p, key, value, evidence) { p.f[key] = value; p.ai[key] = 1; p.ev[key] = evidence; },
    /** Patron reconstruit depuis une sauvegarde (enregistrement du fichier JSONL, photos déjà restaurées). */
    restorePattern(rec, photos) {
      return {
        id: rec.id, title: rec.title || 'Patron restauré', created: rec.created || now(),
        status: rec.status || 'brouillon', stage: rec.stage || undefined, folder: rec.folder || undefined, source: rec.source || {},
        raw: rec.raw || rec.text || '', f: rec.fields || {},
        g: { measures: rec.measures || {}, counts: rec.counts || {} },
        photos: photos, ai: {}, ev: {}, gai: {}, opts: rec.options || []
      };
    },
    /** Résultat de l'analyse par IA : nombre de valeurs remplies, de variantes et fournisseur utilisé. */
    setAnalysis(p, n, provider) { p.analysis = { at: now(), n: n, opts: (p.opts || []).length, provider: provider }; },
    createFolder(name) { return { id: 'd' + uid(), name: name, created: now() }; },
    renameFolder(f, name) { f.name = name; },
    /** Auteur favori : ajouté s'il n'y est pas, retiré sinon (la liste est modifiée en place). */
    toggleFavAuthor(list, key) { const i = list.indexOf(key); if (i >= 0) list.splice(i, 1); else list.push(key); },
    /** Groupe replié par défaut : absent = replié ; on enregistre 0 pour l'ouvrir, 1 pour le replier. */
    toggleGroup(map, id) { const cur = map[id] !== undefined ? !!map[id] : true; map[id] = cur ? 0 : 1; },
    collapseGroups(map, ids) { ids.forEach((id) => { map[id] = 1; }); },
    expandGroups(map, ids) { ids.forEach((id) => { delete map[id]; }); }
  });
}
