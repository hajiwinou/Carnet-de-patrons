/**
 * dreamOS — Moteur pur de Patterns (Phase 3.8)
 * Extrait VERBATIM d'app.js par tools/gen-patterns-engine.mjs (analyse TypeScript), sans aucune modification de logique :
 * nettoyage et découpage du texte importé, devinettes auteur / vêtement, schéma de la fiche, complétude, contrôles
 * de cohérence, application des données de l'IA, fusion des options et des grilles de tailles.
 * Aucune lecture ni écriture de stockage, de DOM ou d'état : les fonctions reçoivent le patron concerné en paramètre
 * (et modifient cet objet, comme le code historique) ; l'enregistrement et le rendu restent à app.js.
 * Seule dépendance externe : le générateur d'identifiants (uid), injecté.
 */
export function createPatternsEngine({ uid }) {
  if (typeof uid !== 'function') throw new TypeError('createPatternsEngine : uid requis.');
  const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];

  const MEASURES = [
      ['bust', 'Tour de poitrine fini'], ['waist', 'Tour de taille'], ['hip', 'Tour de hanches'],
      ['length', 'Longueur totale'], ['back_len', 'Longueur jusqu\'à l\'emmanchure'], ['armhole', 'Hauteur d\'emmanchure'],
      ['shoulder', 'Largeur d\'épaules'], ['neck_w', 'Largeur d\'encolure'], ['sleeve', 'Longueur de manche'],
      ['upper_arm', 'Tour de bras'], ['wrist', 'Tour de poignet'], ['hem_h', 'Hauteur des côtes du bas']
    ];

  const COUNTS = [
      ['caston', 'Montage du corps'], ['chest', 'Mailles au tour de poitrine'], ['waist', 'Mailles à la taille'],
      ['hip', 'Mailles aux hanches'], ['sl_caston', 'Montage des manches'], ['sl_max', 'Mailles de manche (max)'],
      ['neck', 'Mailles d\'encolure'], ['shoulder', 'Mailles par épaule'], ['rows_body', 'Rangs du corps'],
      ['rows_sleeve', 'Rangs de manche'], ['yarn_m', 'Métrage nécessaire (m)']
    ];

  const CORE_ROWS = { measures: ['bust', 'length', 'shoulder', 'sleeve'], counts: ['caston', 'chest'] };

  const GROUPDEF = {
      'Manches': { fields: ['sleeves', 'sleeve_shape', 'cuffs'], m: ['sleeve', 'upper_arm', 'wrist'], c: ['sl_caston', 'sl_max', 'rows_sleeve'] },
      'Encolure': { fields: ['neckline', 'neck_finish'], m: ['neck_w'], c: ['neck'] },
      'Bas et longueur': { fields: ['length', 'hem'], m: ['length', 'back_len', 'hem_h'], c: ['caston', 'hip', 'rows_body'] },
      'Fermeture': { fields: ['closure', 'buttons'], m: [], c: [] },
      'Poches': { fields: ['pockets'], m: [], c: [] },
      'Finitions': { fields: ['hem', 'cuffs', 'neck_finish', 'bind_off', 'blocking'], m: [], c: [] },
      'Autre': { fields: [], m: [], c: [] }
    };

  const GROUP_NAMES = Object.keys(GROUPDEF);

  const SCHEMA = [
      {
        id: 'ident', t: 'Identité du patron',
        why: 'Classe le patron et permet de filtrer les données par type de vêtement et de niveau.',
        f: [
          { k: 'designer', l: 'Créateur·rice', t: 'text' },
          { k: 'language', l: 'Langue du patron', t: 'select', o: ['Français', 'Anglais', 'Autre'], core: 1 },
          { k: 'garment', l: 'Type de vêtement', t: 'select', o: ['Pull', 'Cardigan', 'Gilet sans manches', 'Top / débardeur', 'Robe', 'Jupe', 'Pantalon / short', 'Bonnet', 'Écharpe / snood', 'Châle', 'Chaussettes', 'Mitaines / gants', 'Couverture', 'Sac', 'Autre'], core: 1 },
          { k: 'target', l: 'Public', t: 'select', o: ['Femme', 'Homme', 'Enfant', 'Bébé', 'Unisexe'], core: 1 },
          { k: 'difficulty', l: 'Niveau', t: 'select', o: ['Débutant', 'Facile', 'Intermédiaire', 'Avancé'], core: 1 },
          { k: 'season', l: 'Saison', t: 'select', o: ['Été', 'Mi-saison', 'Hiver', 'Toute saison'] }
        ]
      },
      {
        id: 'shape', t: 'Silhouette et coupe',
        why: 'Ce que l\'IA doit reconnaître sur une photo ou un croquis pour choisir la bonne construction.',
        f: [
          { k: 'silhouette', l: 'Silhouette', t: 'select', o: ['Droite', 'Trapèze', 'Ajustée', 'Boxy', 'Oversize', 'Cropped', 'Longue / tunique'], core: 1 },
          { k: 'ease_cm', l: 'Aisance au buste', t: 'number', u: 'cm', h: 'Positif = ample, négatif = ajusté', core: 1 },
          { k: 'length', l: 'Longueur du vêtement', t: 'select', o: ['Cropped (au-dessus de la taille)', 'Taille', 'Hanches', 'Mi-cuisse', 'Genou ou plus'], core: 1 },
          { k: 'neckline', l: 'Encolure', t: 'select', o: ['Rond', 'V', 'Bateau', 'Carré', 'Col roulé', 'Col montant', 'Col châle', 'Capuche', 'Ouvert (sans col)'], core: 1 },
          { k: 'sleeves', l: 'Manches', t: 'select', o: ['Longues', '3/4', 'Courtes', 'Sans manches', 'Bretelles'], core: 1 },
          { k: 'sleeve_shape', l: 'Forme des manches', t: 'select', o: ['Droite', 'Ajustée', 'Évasée', 'Ballon', 'Chauve-souris', 'Raglan effilé'] },
          { k: 'shoulder', l: 'Type d\'épaule', t: 'select', o: ['Tombante (drop)', 'Montée (set-in)', 'Raglan', 'Empiècement rond (yoke)', 'Saddle'], core: 1 },
          { k: 'construction', l: 'Construction', t: 'select', o: ['De haut en bas, sans couture', 'De bas en haut, sans couture', 'À plat, pièces cousues', 'Une seule pièce', 'De côté en côté'], core: 1 },
          { k: 'shaping_notes', l: 'Notes de forme', t: 'long', h: 'Taille cintrée, dos plus long, fentes latérales…' }
        ]
      },
      {
        id: 'sizes', t: 'Tailles et mesures',
        why: 'La base du patron multi-tailles. Les tableaux relient chaque taille à des mesures finies et à des nombres de mailles.',
        f: [
          { k: 'sizes', l: 'Tailles proposées', t: 'multi', o: SIZES, core: 1 },
          { k: 'size_system', l: 'Système de tailles du patron', t: 'select', o: ['Tailles vêtement (XS à 3XL)', 'Tour de poitrine (cm)', 'Âge enfant'] },
          { k: 'model_size', l: 'Taille portée sur la photo', t: 'text', core: 1 },
          { k: 'model_info', l: 'Mensurations du modèle', t: 'text', h: 'Taille, tour de poitrine…' },
          { k: 'size_map', l: 'Noms des tailles dans le patron', t: 'text', h: 'Ex. : XS = 34, S = 36, M = 38' },
          { k: '@measures' },
          { k: '@counts' }
        ]
      },
      {
        id: 'gauge', t: 'Échantillon',
        why: 'Permet de recalculer les mailles pour n\'importe quel échantillon (multi-gauge).',
        f: [
          { k: 'gauge_sts', l: 'Mailles pour 10 cm', t: 'number', core: 1 },
          { k: 'gauge_rows', l: 'Rangs pour 10 cm', t: 'number', core: 1 },
          { k: 'gauge_stitch', l: 'Point de l\'échantillon', t: 'select', o: ['Jersey', 'Côtes 1/1', 'Côtes 2/2', 'Point mousse', 'Point de riz', 'Point fantaisie', 'Torsades', 'Jacquard'], core: 1 },
          { k: 'needle_mm', l: 'Aiguilles', t: 'number', u: 'mm', core: 1 },
          { k: 'needle_type', l: 'Type d\'aiguilles', t: 'select', o: ['Circulaire', 'Droites', 'Double pointes', 'Mixte'] },
          { k: 'gauge_blocked', l: 'Mesuré', t: 'select', o: ['Après blocage', 'Avant blocage'], core: 1 },
          { k: 'gauge_range', l: 'Autres échantillons proposés', t: 'text', h: 'Ex. : 18 m. = tailles XS–S' }
        ]
      },
      {
        id: 'yarn', t: 'Fil',
        why: 'Associe un échantillon et un rendu (tombé, volume) à un type de fil.',
        f: [
          { k: 'yarn_name', l: 'Fil utilisé', t: 'text', core: 1 },
          { k: 'yarn_weight', l: 'Grosseur du fil', t: 'select', o: ['Dentelle', 'Fingering / 4 plis', 'Sport', 'DK', 'Worsted', 'Aran', 'Bulky', 'Super bulky'], core: 1 },
          { k: 'yarn_fiber', l: 'Composition', t: 'text', core: 1 },
          { k: 'yarn_meters', l: 'Mètres pour 100 g', t: 'number' },
          { k: 'yarn_colors', l: 'Nombre de couleurs', t: 'number' },
          { k: 'yarn_sub', l: 'Substituts conseillés', t: 'long' }
        ]
      },
      {
        id: 'stitches', t: 'Points et techniques',
        why: 'Liste ce que l\'IA devra savoir écrire : points, répétitions, augmentations, diminutions, montage.',
        f: [
          { k: 'stitches', l: 'Points utilisés', t: 'multi', o: ['Jersey', 'Côtes', 'Point mousse', 'Point de riz', 'Torsades', 'Ajouré', 'Jacquard', 'Intarsia', 'Mailles glissées', 'Bobbles', 'Rayures', 'Boutonnières'], core: 1 },
          { k: 'repeat', l: 'Multiple de mailles', t: 'text', h: 'Ex. : multiple de 4 + 2' },
          { k: 'cast_on', l: 'Montage', t: 'select', o: ['Classique', 'Italien', 'Provisoire', 'Tubulaire', 'Au crochet', 'Autre'] },
          { k: 'increases', l: 'Augmentations', t: 'text', h: 'Ex. : M1L / M1R, jetés' },
          { k: 'decreases', l: 'Diminutions', t: 'text', h: 'Ex. : 2 m. ens., surjet simple' },
          { k: 'short_rows', l: 'Rangs raccourcis', t: 'select', o: ['Non', 'Oui, rangs raccourcis', 'Oui, allemands (DS)', 'Oui, wrap & turn'] },
          { k: 'charts', l: 'Présentation des motifs', t: 'select', o: ['Texte seulement', 'Diagrammes seulement', 'Texte et diagrammes'], core: 1 }
        ]
      },
      {
        id: 'finish', t: 'Finitions',
        why: 'Les finitions changent le rendu final : elles doivent être décrites séparément pour pouvoir être choisies.',
        f: [
          { k: 'hem', l: 'Bas du vêtement', t: 'text', core: 1 },
          { k: 'cuffs', l: 'Poignets', t: 'text' },
          { k: 'neck_finish', l: 'Finition de l\'encolure', t: 'text', core: 1 },
          { k: 'closure', l: 'Fermeture', t: 'text', h: 'Boutons, zip, aucune…' },
          { k: 'buttons', l: 'Nombre de boutons', t: 'number' },
          { k: 'pockets', l: 'Poches', t: 'select', o: ['Aucune', 'Plaquées', 'Invisibles', 'Fentes'] },
          { k: 'bind_off', l: 'Rabat', t: 'select', o: ['Classique', 'Élastique', 'Tubulaire', 'Autre'] },
          { k: 'assembly', l: 'Ordre d\'assemblage', t: 'long' },
          { k: 'blocking', l: 'Blocage', t: 'text' }
        ]
      },
      {
        id: 'writing', t: 'Rédaction du patron',
        why: 'Définit le style d\'écriture que l\'IA devra reproduire pour que le patron reste fluide à lire.',
        f: [
          { k: 'notation', l: 'Notation', t: 'select', o: ['Abréviations françaises', 'Abréviations anglaises', 'Mots complets'] },
          { k: 'structure', l: 'Écriture des tailles', t: 'select', o: ['Une section par taille', 'Toutes les tailles entre parenthèses', 'Tableau par taille'], core: 1 },
          { k: 'parts', l: 'Parties du patron', t: 'text', h: 'Dos, devant, manches, finitions…', core: 1 },
          { k: 'abbrev', l: 'Glossaire du patron', t: 'long' },
          { k: 'errata', l: 'Erreurs connues', t: 'long' }
        ]
      },
      {
        id: 'result', t: 'Résultat tricoté',
        why: 'Compare le patron à la réalité. C\'est ce qui apprend à l\'IA si un patron donne bien l\'objet de la photo.',
        f: [
          { k: 'r_size', l: 'Taille tricotée', t: 'text' },
          { k: 'r_sts', l: 'Mailles obtenues pour 10 cm', t: 'number' },
          { k: 'r_rows', l: 'Rangs obtenus pour 10 cm', t: 'number' },
          { k: 'r_bust', l: 'Tour de poitrine mesuré', t: 'number', u: 'cm' },
          { k: 'r_length', l: 'Longueur mesurée', t: 'number', u: 'cm' },
          { k: 'r_fit', l: 'Écart au patron', t: 'select', o: ['Conforme', 'Plus petit', 'Plus grand', 'Plus court', 'Plus long'] },
          { k: 'r_rating', l: 'Conformité à la photo (1 à 5)', t: 'select', o: ['1', '2', '3', '4', '5'], core: 1 },
          { k: 'r_hours', l: 'Heures de tricot', t: 'number' },
          { k: 'r_yarn', l: 'Fil réellement utilisé', t: 'text' },
          { k: 'r_mods', l: 'Modifications faites', t: 'long' },
          { k: 'r_issues', l: 'Problèmes rencontrés', t: 'long' }
        ]
      }
    ];

  const ALLF = [];

  SCHEMA.forEach(function(s) {
      s.f.forEach(function(f) {
        if (f.k[0] !== '@') ALLF.push(f);
      });
    });

  const ABBR = [
      [/\bk2tog\b/gi, '2 mailles ensemble à l\'endroit (k2tog)'],
      [/\bp2tog\b/gi, '2 mailles ensemble à l\'envers (p2tog)'],
      [/\bssk\b/gi, 'surjet simple (ssk)'],
      [/\byo\b/gi, 'jeté (yo)'],
      [/\bm1l\b/gi, 'augmentation inclinée à gauche (m1l)'],
      [/\bm1r\b/gi, 'augmentation inclinée à droite (m1r)'],
      [/\bsts\b/gi, 'mailles'],
      [/\brnds?\b/gi, 'tour'],
      [/\brep\b/gi, 'répéter'],
      [/\bfoll\b/gi, 'suivant'],
      [/\bbeg\b/gi, 'début'],
      [/\bcont\b/gi, 'continuer'],
      [/\binc\b/gi, 'augmenter'],
      [/\bdec\b/gi, 'diminuer'],
      [/\balt\b/gi, 'alterner'],
      [/\bapprox\b/gi, 'environ'],
      [/\bpatt\b/gi, 'motif'],
      [/\brs\b/g, 'endroit de l\'ouvrage'],
      [/\bws\b/g, 'envers de l\'ouvrage'],
      [/\bend\.(?=\s|$)/gi, 'endroit'],
      [/\benv\.(?=\s|$)/gi, 'envers'],
      [/\bjers\.(?=\s|$)/gi, 'jersey'],
      [/\baug\.(?=\s|$)/gi, 'augmentation'],
      [/\bdim\.(?=\s|$)/gi, 'diminution'],
      [/\brgs?\b\.?/gi, 'rang']
    ];

  function cleanText(raw, o) {
      var pages = String(raw || '').split('\f').map(function(s) {
        return s.split('\n').map(function(l) { return l.trim(); });
      });
      if (o.headers && pages.length >= 3) {
        var cnt = new Map(), key = function(l) { return l.replace(/\d+/g, '#').toLowerCase(); };
        pages.forEach(function(pg) {
          var ed = new Set(pg.slice(0, 2).concat(pg.slice(-2)).filter(Boolean).map(key));
          ed.forEach(function(k) { cnt.set(k, (cnt.get(k) || 0) + 1); });
        });
        var th = Math.max(2, Math.ceil(pages.length * 0.5));
        pages = pages.map(function(pg) {
          return pg.filter(function(l, i) {
            if (!l) return true;
            var edge = i < 2 || i >= pg.length - 2;
            return !(edge && cnt.get(key(l)) >= th && l.length < 90);
          });
        });
      }
      var t = pages.map(function(pg) { return pg.join('\n'); }).join('\n');
      t = t.normalize('NFC').replace(/[\u00AD]/g, '').replace(/ﬁ/g, 'fi').replace(/ﬂ/g, 'fl').replace(/\u00A0/g, ' ')
        .replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, '-').replace(/…/g, '...').replace(/[•▪●◦]\s*/g, '- ')
        .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
      t = t.replace(/^\s*(?:page\s*)?\d{1,3}\s*(?:\/|sur|of)?\s*\d{0,3}\s*$/gim, '');
      t = t.replace(/([a-zà-ÿ])-\n([a-zà-ÿ])/g, '$1$2');
      t = t.replace(/([^\n.:;!?)\]])\n(?=[a-zàâçéèêëîïôûùüÿœ(])/g, '$1 ');
      t = t.replace(/(\d),(\d+)(\s*(?:mm|cm|m|g|kg|%))/g, '$1.$2$3')
        .replace(/(\d)\s*(?:millim[eè]tres?|mm)\b/gi, '$1 mm')
        .replace(/(\d)\s*(?:centim[eè]tres?|cm)\b/gi, '$1 cm');
      if (o.expand) ABBR.forEach(function(a) { t = t.replace(a[0], a[1]); });
      t = t.split('\n').map(function(l) { return l.replace(/[ \t]+/g, ' ').trim(); }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
      return t;
    }

  const HEAD = /^(taille|tailles|dos|devant|manches?|encolure|finitions?|montage|empi[eè]cement|assemblage|body|back|front|sleeves?|neck|neckline|yoke|finishing|assembly|mat[eé]riel|fournitures|[eé]chantillon|gauge|abr[eé]viations|materials)\b.{0,32}$/i;

  function isHeading(l) {
      return l.length < 46 && !/[.;]$/.test(l) && (HEAD.test(l) || (/^[A-ZÉÈÀÂÊÎÔÛÇ0-9 '\/&:-]{4,}$/.test(l) && /[A-ZÉÈÀ]{3}/.test(l)));
    }

  function chunkText(clean, o) {
      var min = Math.max(5, +o.min || 20), max = Math.max(min + 2, +o.max || 30), out = [], section = '', buf = [];
      function flush() {
        if (buf.length) {
          out.push({ section: section, text: buf.join(' '), words: buf.length });
          buf = [];
        }
      }
      function units(s) {
        var w = s.split(/\s+/).filter(Boolean);
        if (w.length <= max) return [w];
        var parts = s.replace(/([,;:])\s+/g, '$1\u0001').split('\u0001'), res = [];
        parts.forEach(function(p) {
          var pw = p.split(/\s+/).filter(Boolean);
          for (var i = 0; i < pw.length; i += max) res.push(pw.slice(i, i + max));
        });
        return res;
      }
      clean.split('\n').forEach(function(line) {
        line = line.trim();
        if (!line) { flush(); return; }
        if (isHeading(line)) { flush(); section = line.replace(/:$/, ''); return; }
        if (/^(rang|tour|row|rnd|rd)\b/i.test(line) && buf.length >= min / 2) flush();
        line.replace(/([.!?])\s+(?=[A-ZÉÈÀ0-9*(\[])/g, '$1\u0001').split('\u0001').forEach(function(sent) {
          units(sent).forEach(function(w) {
            if (buf.length + w.length > max) flush();
            buf = buf.concat(w);
            if (buf.length >= min) flush();
          });
        });
      });
      flush();
      return out.map(function(c, i) { c.i = i + 1; return c; });
    }

  function guessAuthor(t) {
      t = String(t || '').slice(0, 8000);
      var cues = /(editor and designer|designed by|design by|designer|pattern by|created by|conçu par|créé par|modèle de|créatrice|créateur)\s*:?\s*/ig, m;
      while ((m = cues.exec(t))) {
        var rest = t.slice(m.index + m[0].length, m.index + m[0].length + 70);
        var n = rest.match(/^([A-ZÀ-Ý][\p{L}'’.-]+(?:[ \t]+[A-ZÀ-Ý][\p{L}'’.-]+){0,3})/u);
        if (n) return n[1].trim().replace(/[.,;:]+$/, '');
      }
      var c = t.match(/©\s*(?:\d{4}\s*)?([A-ZÀ-Ý][\p{L}'’.-]+(?:[ \t]+[A-ZÀ-Ý][\p{L}'’.-]+){0,2})/u);
      return c ? c[1].trim() : '';
    }

  const GARMENT_RE = [
      [/cardigan|gilet\b/i, 'Cardigan'], [/sweater|pullover|jumper|\bpull\b/i, 'Pull'],
      [/\b(?:hat|beanie|bonnet)\b/i, 'Bonnet'], [/scarf|snood|[eé]charpe|cowl/i, 'Écharpe / snood'],
      [/shawl|ch[aâ]le/i, 'Châle'], [/\bsocks?\b|chaussettes/i, 'Chaussettes'],
      [/mittens?|gloves?|mitaines|gants/i, 'Mitaines / gants'], [/blanket|couverture|plaid/i, 'Couverture'],
      [/\bdress\b|\brobe\b/i, 'Robe'], [/\bskirt\b|\bjupe\b/i, 'Jupe'],
      [/\b(?:trousers?|pants?|shorts?)\b|\bpantalon(?:s)?\b|\bshort\b/i, 'Pantalon / short'],
      [/\b(?:tank|top|d[eé]bardeur)\b/i, 'Top / débardeur'], [/\bvest\b/i, 'Gilet sans manches'],
      [/\bbag\b|\bsac\b/i, 'Sac']
    ];

  function guessGarment(t) {
      t = String(t || '').slice(0, 4000);
      for (var i = 0; i < GARMENT_RE.length; i++) if (GARMENT_RE[i][0].test(t)) return GARMENT_RE[i][1];
      return '';
    }

  function normAuthor(s) { return String(s || '').replace(/\s+/g, ' ').replace(/[.,;:]+$/, '').trim(); }

  function filled(v) { return Array.isArray(v) ? v.length > 0 : (v !== undefined && v !== null && v !== ''); }

  function completeness(p) {
      var tot = 0, done = 0;
      ALLF.forEach(function(f) { if (f.core) { tot++; if (filled(p.f[f.k])) done++; } });
      var sizes = p.f.sizes || [];
      ['measures', 'counts'].forEach(function(g) {
        CORE_ROWS[g].forEach(function(r) {
          sizes.forEach(function(s) {
            tot++;
            if (filled((p.g[g][r] || {})[s])) done++;
          });
        });
      });
      tot += 2;
      var ph = p.photos || [];
      if (ph.some(function(x) { return x.kind !== 'fini'; })) done++;
      if (ph.some(function(x) { return x.kind === 'fini'; })) done++;
      return tot ? done / tot : 0;
    }

  function checks(p) {
      var out = [], f = p.f, sizes = f.sizes || [], g = p.g, gs = +f.gauge_sts, gr = +f.gauge_rows;
      if (!(p.raw || '').trim()) out.push(['bad', 'Aucun texte de patron. Importez un PDF ou collez le texte.']);
      if (!gs || !gr) out.push(['bad', 'Échantillon incomplet : indiquez les mailles et les rangs pour 10 cm.']);
      if (!sizes.length) out.push(['bad', 'Aucune taille sélectionnée.']);
      MEASURES.forEach(function(m) {
        var vals = sizes.map(function(s) { return [s, +(g.measures[m[0]] || {})[s]]; }).filter(function(x) { return x[1]; });
        for (var i = 1; i < vals.length; i++) {
          if (vals[i][1] < vals[i - 1][1]) {
            out.push(['warn', m[1] + ' : la taille ' + vals[i][0] + ' (' + vals[i][1] + ') est plus petite que ' + vals[i - 1][0] + ' (' + vals[i - 1][1] + ').']);
            break;
          }
        }
      });
      var okc = 0;
      if (gs) sizes.forEach(function(s) {
        var b = +(g.measures.bust || {})[s], c = +(g.counts.chest || {})[s];
        if (b && c) {
          var w = c / gs * 10, d = Math.abs(w - b) / b;
          if (d > 0.04) out.push(['warn', 'Taille ' + s + ' : ' + c + ' mailles donnent ~' + Math.round(w) + ' cm au lieu de ' + b + ' cm.']);
          else okc++;
        }
      });
      if (okc) out.push(['ok', okc + ' taille(s) : mailles et tour de poitrine concordent avec l\'échantillon.']);
      var ph = p.photos || [];
      if (!ph.some(function(x) { return x.kind !== 'fini'; })) out.push(['warn', 'Pas de photo ni de croquis du patron.']);
      if (!ph.some(function(x) { return x.kind === 'fini'; })) out.push(['warn', 'Pas de photo du résultat tricoté.']);
      return out;
    }

  function coerce(f, v) {
      if (v === undefined || v === null || v === '') return undefined;
      if (f.t === 'select') { v = String(v); return f.o.indexOf(v) >= 0 ? v : undefined; }
      if (f.t === 'multi') {
        if (!Array.isArray(v)) return undefined;
        v = v.filter(function(x) { return f.o.indexOf(x) >= 0; });
        return v.length ? v : undefined;
      }
      if (f.t === 'number') { v = parseFloat(v); return isNaN(v) ? undefined : v; }
      return String(v).slice(0, 600);
    }

  function fieldDef(k) { return ALLF.find(function(x) { return x.k === k; }); }

  function applyAI(p, res, keys, over) {
      var n = 0;
      res = res || {};
      var fl = res.fields || (keys ? res : {});
      p.ev = p.ev || {};
      ALLF.forEach(function(f) {
        if (f.k.indexOf('r_') === 0) return;
        if (keys && keys.indexOf(f.k) < 0) return;
        var raw = fl[f.k], q = '';
        if (raw && typeof raw === 'object' && !Array.isArray(raw) && 'v' in raw) { q = raw.q || ''; raw = raw.v; }
        var v = coerce(f, raw);
        if (v === undefined) return;
        if (filled(p.f[f.k]) && !(over && p.ai[f.k])) return;
        p.f[f.k] = v;
        p.ai[f.k] = 1;
        if (q) p.ev[f.k] = String(q).slice(0, 160);
        n++;
      });
      if (p.f.sizes) p.f.sizes.sort(function(a, b) { return SIZES.indexOf(a) - SIZES.indexOf(b); });
      if (!keys && res.size_map && typeof res.size_map === 'object' && (!filled(p.f.size_map) || (over && p.ai.size_map))) {
        var sm = Object.keys(res.size_map).filter(function(s) { return SIZES.indexOf(s) >= 0; }).map(function(s) { return s + ' = ' + res.size_map[s]; }).join(', ');
        if (sm) { p.f.size_map = sm; p.ai.size_map = 1; n++; }
      }
      return n;
    }

  function putGrid(p, target, kind, rows, src, prefix, over, used) {
      var n = 0;
      if (!src || typeof src !== 'object') return 0;
      rows.forEach(function(r) {
        var row = src[r[0]];
        if (!row || typeof row !== 'object') return;
        Object.keys(row).forEach(function(sz) {
          if (SIZES.indexOf(sz) < 0) return;
          var v = parseFloat(row[sz]);
          if (isNaN(v)) return;
          var t = target[kind][r[0]] = target[kind][r[0]] || {}, key = prefix + kind + '.' + r[0] + '.' + sz;
          if (!filled(t[sz]) || (over && p.gai[key])) {
            t[sz] = v;
            p.gai[key] = 1;
            if (used) used[sz] = 1;
            n++;
          }
        });
      });
      return n;
    }

  function applyGrids(p, res, over) {
      p.gai = p.gai || {};
      var used = {}, n = 0;
      res = res || {};
      n += putGrid(p, p.g, 'measures', MEASURES, res.measures, '', over, used);
      n += putGrid(p, p.g, 'counts', COUNTS, res.counts, '', over, used);
      if (!(p.f.sizes || []).length) {
        var us = Object.keys(used).sort(function(a, b) { return SIZES.indexOf(a) - SIZES.indexOf(b); });
        if (us.length) { p.f.sizes = us; p.ai.sizes = 1; }
      }
      return n;
    }

  function findOpt(p, g, name) {
      var k = (String(g) + '|' + String(name)).toLowerCase();
      return (p.opts || []).find(function(o) { return (o.group + '|' + o.name).toLowerCase() === k; });
    }

  function applyOptGrids(p, list, over) {
      var n = 0;
      if (!Array.isArray(list)) return 0;
      p.gai = p.gai || {};
      list.forEach(function(it) {
        var o = it && findOpt(p, it.group, it.name);
        if (!o) return;
        var def = GROUPDEF[o.group] || GROUPDEF.Autre;
        o.measures = o.measures || {};
        o.counts = o.counts || {};
        n += putGrid(p, o, 'measures', MEASURES.filter(function(r) { return def.m.indexOf(r[0]) >= 0; }), it.measures, o.id + '.', over, null);
        n += putGrid(p, o, 'counts', COUNTS.filter(function(r) { return def.c.indexOf(r[0]) >= 0; }), it.counts, o.id + '.', over, null);
      });
      return n;
    }

  function mergeOptions(p, list, over) {
      if (!Array.isArray(list)) return 0;
      p.opts = p.opts || [];
      var n = 0;
      if (over) p.opts = p.opts.filter(function(o) { return !o.ai; });
      list.forEach(function(o) {
        if (!o || !o.name || !GROUPDEF[o.group]) return;
        if (findOpt(p, o.group, o.name)) return;
        var def = GROUPDEF[o.group], of = {};
        Object.keys(o.fields || {}).forEach(function(k) {
          if (def.fields.indexOf(k) < 0) return;
          var f = fieldDef(k);
          if (!f) return;
          var raw = o.fields[k];
          if (raw && typeof raw === 'object' && 'v' in raw) raw = raw.v;
          var v = coerce(f, raw);
          if (v !== undefined) of[k] = v;
        });
        p.opts.push({
          id: uid(), group: o.group, name: String(o.name).slice(0, 80),
          desc: String(o.desc || '').slice(0, 500), f: of, measures: {}, counts: {},
          q: String(o.q || '').slice(0, 160), ai: 1
        });
        n++;
      });
      return n;
    }

  function specText(keys) {
      return ALLF.filter(function(f) { return keys ? keys.indexOf(f.k) >= 0 : f.k.indexOf('r_') !== 0; }).map(function(f) {
        return f.k + ' (' + ({
          text: 'texte court', long: 'texte', number: 'nombre' + (f.u ? ' en ' + f.u : ''),
          select: 'une valeur parmi : ' + (f.o || []).join(' | '),
          multi: 'liste de valeurs parmi : ' + (f.o || []).join(' | ')
        }[f.t]) + ') = ' + f.l;
      }).join('\n');
    }

  function groupSpec() {
      return GROUP_NAMES.map(function(g) { var d = GROUPDEF[g]; return '- ' + g + (d.fields.length ? ' (clés permises : ' + d.fields.join(', ') + ')' : ''); }).join('\n');
    }

  function rowSpec() {
      return 'Lignes de "measures" (cm) :\n' + MEASURES.map(function(m) { return m[0] + ' = ' + m[1]; }).join('\n') + '\n\nLignes de "counts" :\n' + COUNTS.map(function(m) { return m[0] + ' = ' + m[1]; }).join('\n');
    }

  function optList(p) {
      var l = (p.opts || []).map(function(o) { var d = GROUPDEF[o.group] || GROUPDEF.Autre; return '- groupe "' + o.group + '", nom "' + o.name + '" (lignes permises : ' + d.m.concat(d.c).join(', ') + ')'; });
      return l.length ? l.join('\n') : '(aucune variante détectée)';
    }

  return Object.freeze({
    SIZES, MEASURES, COUNTS, CORE_ROWS, GROUPDEF, GROUP_NAMES, SCHEMA, ALLF, ABBR, HEAD, GARMENT_RE,
    cleanText, isHeading, chunkText, guessAuthor, guessGarment, normAuthor, filled, completeness, checks, coerce, fieldDef, applyAI, putGrid, applyGrids, findOpt, applyOptGrids, mergeOptions, specText, groupSpec, rowSpec, optList
  });
}
