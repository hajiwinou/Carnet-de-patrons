/**
 * dreamOS — Documentation Host (Phase 3.11)
 * Transfère la LOGIQUE PURE de Documentation (catégories, brouillon, validité, construction d'un article, type de média,
 * libellés de date et de catégorie) au module Documentation. Les DONNÉES (carnet.docs, médias docm_*), l'enregistrement,
 * le téléversement et le rendu restent à app.js. La recherche dans les articles est déjà portée par le module Library (3.6).
 * Jalon 4.1 : le module devient aussi propriétaire de carnet.docs (documentation-store.js : seule autorité d'écriture).
 * Jalon 4.2 : et de ses médias docm_* (documentation-media.js : seule autorité d'écriture et de suppression).
 * app.js consulte window.DreamOSDocumentationHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createDocumentationEngine } from './documentation-engine.js';
import { createDocumentationStore } from './documentation-store.js';
import { createDocumentationMedia } from './documentation-media.js';

export const DOCUMENTATION_RESOURCES = Object.freeze([['logic', 'documentation-engine', 'documentation'], ['storage', 'carnet.docs', 'documentation'], ['media', 'docm_*', 'documentation']]);

export function installDocumentationHost({ moduleRegistry, legacy, eventBus, win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installDocumentationHost : window requis.');
  if (win.DreamOSDocumentationHost) return win.DreamOSDocumentationHost;
  let enabled = false;
  const move = (toOwner) => DOCUMENTATION_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    engine: createDocumentationEngine(),
    store: createDocumentationStore({ eventBus }),
    media: createDocumentationMedia({ eventBus }),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('documentation:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('documentation:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSDocumentationHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSDocumentationHost;
}
