/**
 * dreamOS — Documentation Store (Jalon 4.1)
 * Seule AUTORITÉ D'ÉCRITURE des articles (carnet.docs) quand le module Documentation est engagé : ajout, suppression,
 * réinsertion (annulation), remplacement (import / restauration) et enregistrement passent tous par ici.
 *
 * Principe de transition (pas de copie, pas de dérive) : le magasin ADOPTE le tableau d'articles d'app.js et le modifie sur place ;
 * app.js continue donc à lire S.docs (même tableau), et un retour arrière (release / ?documentation=legacy) retrouve les mêmes données.
 * L'écriture physique (localStorage + miroir IndexedDB) reste la fonction `write` fournie par app.js : le magasin décide QUAND écrire.
 * Les médias (docm_*) restent écrits par app.js pour l'instant (étape suivante).
 */
export function createDocumentationStore({ eventBus } = {}) {
  let docs = null, write = null;
  const emit = (type, extra) => { try { eventBus?.emit('documentation:' + type, { count: docs ? docs.length : 0, ...extra }); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  const need = () => { if (!docs) throw new Error('Documentation Store : aucun tableau adopté.'); return docs; };
  return Object.freeze({
    /** Adopte le tableau d'app.js (même référence) et la fonction d'écriture. Idempotent. */
    adopt(arr, writeFn) { if (!Array.isArray(arr)) throw new TypeError('Documentation Store : tableau requis.'); docs = arr; if (typeof writeFn === 'function') write = writeFn; return true; },
    get adopted() { return !!docs; },
    list() { return docs; },
    count() { return docs ? docs.length : 0; },
    /** Écrit l'état courant (même effet que saveDocs() d'origine). */
    save() { if (write) write(need()); emit('saved'); return true; },
    /** Nouvel article en tête de liste, puis enregistrement. */
    add(post) { need().unshift(post); this.save(); emit('added', { id: post && post.id }); return post; },
    /** Retire l'article d'indice i (undefined si absent), puis enregistrement. */
    removeAt(i) { const r = need().splice(i, 1)[0]; this.save(); emit('removed', { id: r && r.id }); return r; },
    /** Réinsère un article à l'indice i (borné à la longueur), puis enregistrement — annulation d'une suppression. */
    insertAt(i, post) { const a = need(); a.splice(Math.min(i, a.length), 0, post); this.save(); emit('restored', { id: post && post.id }); return true; },
    /** Remplace tout le contenu SUR PLACE (import, restauration) ; save=true pour enregistrer aussitôt. */
    replaceAll(next, save) { const a = need(); const copy = Array.isArray(next) ? next.slice() : []; a.splice(0, a.length, ...copy); if (save) this.save(); emit('replaced'); return a; }
  });
}
