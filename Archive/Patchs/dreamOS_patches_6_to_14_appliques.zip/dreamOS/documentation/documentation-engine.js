/**
 * dreamOS — Moteur pur de Documentation (Phase 3.11)
 * Logique sans DOM ni stockage, reprise à l'identique d'app.js (docSave, igToDoc, docMediaIn, docDel, viewDocs) :
 * catégories, brouillon vide, validité du brouillon, construction d'un article, type de média, libellés de date et de catégorie.
 * Les identifiants et l'horodatage sont passés en paramètres ; aucune lecture ni écriture de carnet.docs ni de média docm_*.
 */
export function createDocumentationEngine() {
  var CATEGORIES = Object.freeze(['Technique', 'Tutoriel Vidéo', 'Fils & Échantillons', 'Astuce Tricot', 'Autre']);
  function emptyDraft() { return { title: '', category: 'Technique', content: '', media: [] }; }
  function draftIsEmpty(d) { return !d.title.trim() && !d.content.trim() && !d.media.length; }
  function buildPost(d, id, now) { return { id: id, title: d.title.trim() || 'Article sans titre', category: d.category, content: d.content, media: d.media, created: now }; }
  function buildVideoPost(ig, mediaId, id, now) { return { id: id, title: (ig.title || '').trim() || 'Vidéo téléchargée', category: 'Tutoriel Vidéo', content: 'Source : ' + ig.src, media: [{ id: mediaId, type: 'video' }], created: now }; }
  function isVideoFile(f) { return f.type.indexOf('video/') === 0; }
  function mediaEntry(id, isVid) { return { id: id, type: isVid ? 'video' : 'image' }; }
  function categoryOf(post) { return post.category || 'Note'; }
  function dateLabel(ts) { return new Date(ts).toLocaleDateString('fr-FR'); }
  function reinsertIndex(i, len) { return Math.min(i, len); }
  return Object.freeze({ CATEGORIES, emptyDraft, draftIsEmpty, buildPost, buildVideoPost, isVideoFile, mediaEntry, categoryOf, dateLabel, reinsertIndex });
}
