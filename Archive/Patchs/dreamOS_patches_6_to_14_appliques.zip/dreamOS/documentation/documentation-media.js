/**
 * dreamOS — Documentation Media (Jalon 4.2)
 * Seule AUTORITÉ D'ÉCRITURE des médias d'articles (docm_*) quand le module Documentation est engagé :
 * création d'identifiant, écriture d'un blob et suppression passent par ici.
 *
 * L'écriture physique reste celle d'app.js (cache de blobs + IndexedDB) : elle est passée en paramètre à chaque appel, de sorte que
 * le comportement (cache, URL temporaires, gestion d'échec de stockage) reste identique et que le retour arrière est immédiat.
 * La lecture (getBlobUrl) reste partagée : lire n'est pas écrire.
 */
export const DOC_MEDIA_PREFIX = 'docm_';
export function createDocumentationMedia({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('documentation:media-' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une écriture */ } };
  return Object.freeze({
    prefix: DOC_MEDIA_PREFIX,
    isOwn(id) { return typeof id === 'string' && id.startsWith(DOC_MEDIA_PREFIX); },
    /** Nouvel identifiant de média d'article (même format qu'avant : docm_ + identifiant). */
    newId(uid) { return DOC_MEDIA_PREFIX + uid(); },
    /** Écrit un blob sous un identifiant docm_* via l'écriture d'app.js ; refuse tout autre préfixe. */
    async put(id, blob, writer) {
      if (!this.isOwn(id)) throw new TypeError('Documentation Media : identifiant docm_* requis (reçu « ' + String(id) + ' »).');
      if (typeof writer !== 'function') throw new TypeError('Documentation Media : écriture requise.');
      const r = await writer(id, blob);
      emit('saved', { id });
      return r;
    },
    /** Supprime les médias d'un article (liste {id,type}) via la suppression d'app.js ; sans effet si la liste est absente. */
    discard(media, remover) {
      if (!media) return 0;
      if (typeof remover !== 'function') throw new TypeError('Documentation Media : suppression requise.');
      let n = 0; media.forEach((m) => { remover(m.id); n++; });
      if (n) emit('discarded', { count: n });
      return n;
    },
    /** Identifiants docm_* référencés par une liste d'articles (base d'un futur nettoyage des orphelins). */
    referenced(docs) { const s = new Set(); (docs || []).forEach((d) => (d.media || []).forEach((m) => { if (m && this.isOwn(m.id)) s.add(m.id); })); return s; }
  });
}
