/**
 * dreamOS — Downloads Host (Phase 3.7)
 * Transfère la LOGIQUE réseau de l'outil Instagram → MP4 (client Cobalt) au module Downloads.
 * Les DONNÉES (carnet.igApi : adresse et clé ; état de l'écran S.ig ; enregistrement dans Documentation) et le rendu
 * restent à app.js.
 * Jalon 4.5 : Downloads devient aussi propriétaire de carnet.igApi (downloads-store.js : seule autorité d'écriture ; la clé reste secrète). app.js consulte window.DreamOSDownloadsHost à chaque appel ; absent ou relâché → code historique.
 */
import { createCobaltClient } from './cobalt-client.js';
import { createDownloadsStore } from './downloads-store.js';

export const DOWNLOADS_RESOURCES = Object.freeze([['logic', 'cobalt-client', 'downloads'], ['storage', 'carnet.igApi', 'downloads']]);

export function installDownloadsHost({ moduleRegistry, legacy, eventBus, win = globalThis.window, env } = {}) {
  if (!win) throw new TypeError('installDownloadsHost : window requis.');
  if (win.DreamOSDownloadsHost) return win.DreamOSDownloadsHost;
  let enabled = false;
  const move = (toOwner) => DOWNLOADS_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    client: createCobaltClient(env),
    store: createDownloadsStore({ eventBus }),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('downloads:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('downloads:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSDownloadsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSDownloadsHost;
}
