/**
 * dreamOS — Client Cobalt du module Downloads (Phase 3.7)
 * Reproduit à l'identique, avec les mêmes messages, les fonctions réseau de l'outil « vidéo Instagram → MP4 » d'app.js :
 * igEndpoint, igIsLoopback, igNetworkCheck, igAbs, igHeaders, igErrMsg, igFileName et igRequest.
 * Aucune donnée n'est lue ni écrite : l'adresse, la clé, le titre et l'extension sont passés explicitement ; le navigateur
 * (fetch, minuterie, protocole de la page) est injectable pour les tests. app.js garde l'état de l'écran (S.ig), le
 * téléchargement vers Documentation (igToDoc, blob docm_*) et le rendu.
 * La clé d'accès (carnet.igApi) n'est jamais conservée ni journalisée par ce module.
 */
const LOOPBACK = /^(localhost|127(?:\.\d{1,3}){3}|\[::1\])$/i;

export function createCobaltClient(env = {}) {
  const proto = () => (env.protocol ? env.protocol() : globalThis.location?.protocol);
  const doFetch = (...a) => (env.fetch ? env.fetch(...a) : globalThis.fetch(...a));
  const timeoutSet = (f, ms) => (env.setTimeout ? env.setTimeout(f, ms) : globalThis.setTimeout(f, ms));
  const timeoutClear = (t) => (env.clearTimeout ? env.clearTimeout(t) : globalThis.clearTimeout(t));
  const newAbort = () => (env.AbortController ? new env.AbortController() : new AbortController());

  const isLoopback = (host) => LOOPBACK.test(host);

  function errorMessage(code) {
    code = String(code || 'inconnu');
    if (/auth/.test(code)) return 'Clé d’accès absente ou refusée (' + code + ').';
    if (/rate|limit/.test(code)) return 'Limite du service atteinte. Réessayez plus tard (' + code + ').';
    if (/private|login|age/.test(code)) return 'Ce contenu demande une connexion ou n’est pas accessible à cette instance (' + code + ').';
    if (/unsupported|disabled/.test(code)) return 'Cette plateforme ou ce type de lien n’est pas pris en charge par votre serveur (' + code + ').';
    if (/unavailable|not_found|empty|fetch/.test(code)) return 'Vidéo indisponible ou récupération bloquée par la plateforme (' + code + ').';
    return 'Demande refusée par le service (' + code + ').';
  }

  return Object.freeze({
    isLoopback,
    errorMessage,
    /** Adresse de l'API normalisée, ou '' si invalide. */
    endpoint(raw) {
      let u = (raw || '').trim(); if (!u) return '';
      if (!/^https?:\/\//i.test(u)) u = (/^(localhost|127\.|192\.168\.|10\.)/i.test(u) ? 'http://' : 'https://') + u;
      try { const x = new URL(u); if (!/^https?:$/.test(x.protocol) || x.username || x.password) return ''; return x.href; } catch (e) { return ''; }
    },
    /** localhost reste autorisé en HTTP : Cobalt peut tourner sur l'appareil qui utilise la page. */
    networkCheck(ep, pageProtocol = proto()) {
      const u = new URL(ep);
      if (!/^https?:$/.test(u.protocol) || u.username || u.password) throw new Error('Adresse du service invalide.');
      if (pageProtocol === 'https:' && u.protocol === 'http:' && !isLoopback(u.hostname)) throw new Error('Ce service distant est en HTTP. Depuis cette application HTTPS, utilisez une adresse HTTPS, par exemple celle de Tailscale Serve.');
    },
    absolute(u, ep, pageProtocol = proto()) {
      const x = new URL(u, ep);
      if (!/^https?:$/.test(x.protocol) || x.username || x.password) throw new Error('Adresse vidéo invalide renvoyée par le service.');
      if (pageProtocol === 'https:' && x.protocol === 'http:' && !isLoopback(x.hostname)) throw new Error('Le fichier vidéo est renvoyé en HTTP par un serveur distant. Vérifiez son adresse HTTPS et API_URL dans Cobalt.');
      return x.href;
    },
    /** @param {boolean} post ; @param {string} key clé d'accès (peut être vide) */
    headers(post, key) {
      const h = { Accept: 'application/json' };
      if (post) h['Content-Type'] = 'application/json';
      if ((key || '').trim()) h.Authorization = 'Api-Key ' + key.trim();
      return h;
    },
    fileName(title, ext) { return ((title || 'video').replace(/[\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim() || 'video') + '.' + (ext || 'bin'); },
    async request(url, options, mode, timeout) {
      const ctl = newAbort(); const timer = timeoutSet(() => { ctl.abort(); }, timeout || 30000);
      try {
        const req = Object.assign({}, options || {}, { signal: ctl.signal });
        if (mode === 'blob') {
          req.headers = Object.assign({}, req.headers || {}, { Accept: 'video/*,application/octet-stream;q=0.9,*/*;q=0.8' });
          req.cache = 'no-store';
        }
        let r;
        try { r = await doFetch(url, req); } catch (e0) {
          if (e0 && (e0.name === 'DataCloneError' || /could not be cloned/i.test(e0.message || ''))) {
            const req2 = Object.assign({}, req); delete req2.signal;
            r = await Promise.race([doFetch(url, req2), new Promise((_, rej) => { timeoutSet(() => { const te = new Error('timeout'); te.name = 'AbortError'; rej(te); }, timeout || 30000); })]);
          } else throw e0;
        }
        if (mode === 'blob') {
          if (!r.ok) throw new Error('Le fichier répond HTTP ' + r.status + '.');
          const media = await r.blob();
          if (!media.size) throw new Error('Le serveur a renvoyé un fichier vide.');
          if (/^(text\/|application\/(json|html))/i.test(media.type || '')) throw new Error('Cobalt a répondu avec une page ou un message au lieu du fichier vidéo. Vérifiez le lien de téléchargement annoncé par son API.');
          return media;
        }
        const text = await r.text(); let j;
        try { j = JSON.parse(text); } catch (e) { throw new Error('Réponse HTTP ' + r.status + ' non reconnue : utilisez l’adresse de l’API Cobalt, pas celle de son interface web.'); }
        if (!r.ok) throw new Error(errorMessage(j.error && j.error.code) + ' (HTTP ' + r.status + ')');
        return j;
      } catch (e) {
        if (e.name === 'AbortError') throw new Error('Délai dépassé. Vérifiez que Cobalt est lancé et que son adresse est correcte. Pour un accès à distance seulement, vérifiez aussi Tailscale et que le PC reste allumé.');
        if (e instanceof TypeError) throw new Error('Connexion au service impossible ou bloquée par le navigateur. Vérifiez que Cobalt est lancé, son adresse, CORS et les éventuelles autorisations d’accès au réseau local. Tailscale est nécessaire seulement si vous utilisez cette voie d’accès à distance.');
        throw e;
      } finally { timeoutClear(timer); }
    }
  });
}
