/**
 * dreamOS — Downloads Store (Jalon 4.5)
 * Seule AUTORITÉ D'ÉCRITURE de la configuration du service Cobalt (carnet.igApi : adresse et clé d'accès) quand le module Downloads est engagé.
 * app.js garde l'objet de configuration en mémoire (S.igCfg) ; son ENREGISTREMENT passe par setConfig(), limité aux deux champs connus.
 * Confidentialité : la clé d'accès n'est jamais recopiée, journalisée ni placée dans un événement (seul le NOM du champ modifié est publié).
 * L'écriture physique reste celle d'app.js, passée en paramètre.
 */
export const DOWNLOADS_CONFIG_KEY = 'carnet.igApi';
export const DOWNLOADS_CONFIG_FIELDS = Object.freeze(['endpoint', 'key']);
export function createDownloadsStore({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('downloads:' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  return Object.freeze({
    key: DOWNLOADS_CONFIG_KEY,
    fields: DOWNLOADS_CONFIG_FIELDS,
    /** Modifie un champ de la configuration fournie puis l'enregistre (même effet que le code d'origine). */
    setConfig(cfg, field, value, writer) {
      if (!cfg || typeof cfg !== 'object') throw new TypeError('Downloads Store : configuration requise.');
      if (!DOWNLOADS_CONFIG_FIELDS.includes(field)) throw new TypeError('Downloads Store : champ non géré « ' + String(field) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('Downloads Store : écriture requise.');
      cfg[field] = value;
      writer(DOWNLOADS_CONFIG_KEY, cfg);
      emit('config-saved', { field }); // jamais la valeur : la clé d'accès reste secrète
      return true;
    }
  });
}
