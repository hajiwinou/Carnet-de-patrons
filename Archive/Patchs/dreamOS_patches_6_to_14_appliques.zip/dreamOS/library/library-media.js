/**
 * dreamOS — Library Media (Jalon 4.3)
 * Seule AUTORITÉ D'ÉCRITURE des médias d'idées (ideam_*) quand le module Library est engagé : création d'identifiant,
 * écriture d'un blob et suppression. L'écriture physique reste celle d'app.js, passée en paramètre à chaque appel ;
 * la lecture (getBlobUrl) reste partagée. Une idée ajoutée à l'inspiration d'un projet garde son média : seul l'appelant décide de supprimer.
 */
export const LIBRARY_MEDIA_PREFIX = 'ideam_';
export function createLibraryMedia({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('library:media-' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une écriture */ } };
  return Object.freeze({
    prefix: LIBRARY_MEDIA_PREFIX,
    isOwn(id) { return typeof id === 'string' && id.startsWith(LIBRARY_MEDIA_PREFIX); },
    newId(uid) { return LIBRARY_MEDIA_PREFIX + uid(); },
    async put(id, blob, writer) {
      if (!this.isOwn(id)) throw new TypeError('Library Media : identifiant ideam_* requis (reçu « ' + String(id) + ' »).');
      if (typeof writer !== 'function') throw new TypeError('Library Media : écriture requise.');
      const r = await writer(id, blob); emit('saved', { id }); return r;
    },
    /** Supprime un média via la suppression d'app.js (l'appelant a déjà vérifié que l'identifiant existe). */
    discard(id, remover) {
      if (typeof remover !== 'function') throw new TypeError('Library Media : suppression requise.');
      remover(id); emit('discarded', { id }); return true;
    },
    referenced(ideas) { const s = new Set(); (ideas || []).forEach((i) => { if (i && this.isOwn(i.mediaId)) s.add(i.mediaId); }); return s; }
  });
}
