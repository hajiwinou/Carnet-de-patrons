/**
 * dreamOS — Library Store (Jalon 4.3)
 * Seule AUTORITÉ D'ÉCRITURE des idées / épingles (carnet.ideas) et des tableaux (carnet.boards) quand le module Library est engagé.
 * Même principe que le magasin de Documentation : chaque collection ADOPTE le tableau d'app.js (même référence) et le modifie sur place ;
 * l'écriture physique reste la fonction `write` fournie par app.js, le magasin décide quand l'appeler.
 */
function collection(name, eventBus) {
  let arr = null, write = null;
  const emit = (type, extra) => { try { eventBus?.emit('library:' + name + '-' + type, { count: arr ? arr.length : 0, ...extra }); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  const need = () => { if (!arr) throw new Error('Library Store (' + name + ') : aucun tableau adopté.'); return arr; };
  const api = {
    adopt(a, writeFn) { if (!Array.isArray(a)) throw new TypeError('Library Store : tableau requis.'); arr = a; if (typeof writeFn === 'function') write = writeFn; return true; },
    get adopted() { return !!arr; },
    list() { return arr; },
    count() { return arr ? arr.length : 0; },
    save() { if (write) write(need()); emit('saved'); return true; },
    /** Remplace tout le contenu SUR PLACE (import, restauration) ; save=true pour enregistrer aussitôt. */
    replaceAll(next, save) { const a = need(); const copy = Array.isArray(next) ? next.slice() : []; a.splice(0, a.length, ...copy); if (save) api.save(); emit('replaced'); return a; },
    removeAt(i) { const r = need().splice(i, 1)[0]; api.save(); emit('removed', { id: r && r.id }); return r; },
    insertAt(i, item) { const a = need(); a.splice(Math.min(i, a.length), 0, item); api.save(); emit('restored', { id: item && item.id }); return true; }
  };
  return api;
}
export function createLibraryStore({ eventBus } = {}) {
  const ideas = collection('ideas', eventBus), boards = collection('boards', eventBus);
  const ideasApi = Object.freeze({
    adopt: ideas.adopt, get adopted() { return ideas.adopted; }, list: ideas.list, count: ideas.count, save: ideas.save, replaceAll: ideas.replaceAll, removeAt: ideas.removeAt, insertAt: ideas.insertAt,
    /** Nouvelle idée en tête de liste. */
    addFirst(item) { const a = ideas.list(); if (!a) throw new Error('Library Store (ideas) : aucun tableau adopté.'); a.unshift(item); ideas.save(); return item; },
    /** Plusieurs idées en tête de liste (importation de photos), dans l'ordre fourni. */
    addMany(made) { const a = ideas.list(); if (!a) throw new Error('Library Store (ideas) : aucun tableau adopté.'); const old = a.slice(); a.splice(0, a.length, ...made, ...old); ideas.save(); return a; },
    /** Retire toutes les idées dont l'identifiant est dans ids. */
    removeByIds(ids) { const a = ideas.list(); if (!a) throw new Error('Library Store (ideas) : aucun tableau adopté.'); const keep = a.filter((x) => ids.indexOf(x.id) < 0); a.splice(0, a.length, ...keep); ideas.save(); return a; },
    /** Modifie des idées (objet de champs, ou fonction idée → champs / null) puis enregistre une seule fois. */
    patch(items, p) { items.forEach((it) => { const q = typeof p === 'function' ? p(it) : p; if (q) Object.assign(it, q); }); ideas.save(); return items.length; }
  });
  const boardsApi = Object.freeze({
    adopt: boards.adopt, get adopted() { return boards.adopted; }, list: boards.list, count: boards.count, save: boards.save, replaceAll: boards.replaceAll,
    /** Nouveau tableau en fin de liste. */
    append(b) { const a = boards.list(); if (!a) throw new Error('Library Store (boards) : aucun tableau adopté.'); a.push(b); boards.save(); return b; },
    rename(b, name) { b.name = name; boards.save(); return b; },
    removeById(id) { const a = boards.list(); if (!a) throw new Error('Library Store (boards) : aucun tableau adopté.'); const keep = a.filter((x) => x.id !== id); a.splice(0, a.length, ...keep); boards.save(); return a; }
  });
  return Object.freeze({ ideas: ideasApi, boards: boardsApi });
}
