/**
 * dreamOS — Logique des épingles de la Library (Phase 3.6)
 * Reproduit ideaTags / pinBoardIds / pinsShown d'app.js. Les idées et tableaux sont passés explicitement et jamais modifiés.
 */
export const DEFAULT_TAGS = Object.freeze(['Inspiration', 'Point / Motif', 'Association Fils', 'Coupe / Col', 'Projet Futur']);

export function createPinLogic() {
  const boardIds = (item, boards) => (item.boards || []).filter((id) => boards.some((b) => b.id === id));
  return Object.freeze({
    boardIds,
    /** Étiquettes proposées : les 5 par défaut, puis celles créées par l'utilisatrice. */
    tags(ideas) { const t = [...DEFAULT_TAGS]; ideas.forEach((i) => { if (i.tag && t.indexOf(i.tag) < 0) t.push(i.tag); }); return t; },
    /** @param {string} board 'all' | 'none' | identifiant de tableau ; @param {string} tag 'all' | étiquette */
    shown(ideas, boards, board, tag) {
      const out = [];
      ideas.forEach((item) => {
        const ids = boardIds(item, boards);
        if (board === 'none' ? ids.length : (board !== 'all' && ids.indexOf(board) < 0)) return;
        if (tag !== 'all' && (item.tag || 'Inspiration') !== tag) return;
        out.push(item);
      });
      return out;
    }
  });
}
