/**
 * dreamOS — Projects Media (Jalon 4.6b)
 * AUTORITÉ D'ÉCRITURE des médias de projets quand le module Projects est engagé :
 *  - pjc_* : couverture et photos du projet ;
 *  - pjp_* : photos des entrées du journal ;
 *  - pji_* : photos d'inspiration propres au projet (une idée réutilisée garde son média ideam_*, qui reste à Library).
 * Création d'identifiant, écriture d'un blob (refuse tout autre préfixe) et suppression passent par ici. L'écriture physique reste celle
 * d'app.js (cache de blobs + IndexedDB), passée en paramètre ; la lecture (getBlobUrl) reste partagée.
 * La suppression n'impose pas de préfixe : d'anciens projets peuvent référencer des identifiants plus anciens, qu'il faut pouvoir libérer.
 */
export const PROJECT_MEDIA_PREFIXES = Object.freeze(['pjc_', 'pjp_', 'pji_']);
export function createProjectsMedia({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('projects:media-' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une écriture */ } };
  const own = (id) => typeof id === 'string' && PROJECT_MEDIA_PREFIXES.some((p) => id.startsWith(p));
  return Object.freeze({
    prefixes: PROJECT_MEDIA_PREFIXES,
    isOwn: own,
    /** Nouvel identifiant : prefix ∈ {pjc_, pjp_, pji_}, suivi de l'identifiant fourni (même format qu'avant). */
    newId(prefix, uid) {
      if (!PROJECT_MEDIA_PREFIXES.includes(prefix)) throw new TypeError('Projects Media : préfixe non géré « ' + String(prefix) + ' ».');
      return prefix + uid();
    },
    async put(id, blob, writer) {
      if (!own(id)) throw new TypeError('Projects Media : identifiant pjc_ / pjp_ / pji_ requis (reçu « ' + String(id) + ' »).');
      if (typeof writer !== 'function') throw new TypeError('Projects Media : écriture requise.');
      const r = await writer(id, blob); emit('saved', { id }); return r;
    },
    /** Supprime un média via la suppression d'app.js (l'appelant a déjà vérifié que l'identifiant existe). */
    discard(id, remover) {
      if (typeof remover !== 'function') throw new TypeError('Projects Media : suppression requise.');
      remover(id); emit('discarded', { id }); return true;
    },
    /** Identifiants de médias de projets référencés par une liste de projets (couverture, photos, inspiration propre, journal). */
    referenced(projects) {
      const s = new Set();
      (projects || []).forEach((pr) => {
        if (!pr) return;
        if (own(pr.cover)) s.add(pr.cover);
        (pr.photos || []).forEach((id) => { if (own(id)) s.add(id); });
        (pr.inspo || []).forEach((e) => { if (e && e.mediaId && !e.ideaId && own(e.mediaId)) s.add(e.mediaId); });
        (pr.log || []).forEach((en) => (en.photos || []).forEach((id) => { if (own(id)) s.add(id); }));
      });
      return s;
    }
  });
}
