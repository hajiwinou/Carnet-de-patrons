/**
 * dreamOS — Projects Commands (Jalon 4.6c)
 * Les MODIFICATIONS du journal, des photos et de la couverture d'un projet, qui étaient écrites en ligne dans app.js, sont ici des
 * commandes nommées, appliquées au projet passé en paramètre (jamais à un état global). Ce sont des transcriptions fidèles du code d'origine :
 * mêmes champs, même ordre, mêmes identifiants (`e` + uid pour une entrée, `i` + uid pour une photo d'inspiration).
 * Elles ne font ni enregistrement, ni suppression de média, ni rendu : app.js enregistre (saveProjects → magasin 4.6a) et supprime les
 * médias (passerelle 4.6b).
 */
export function createProjectsCommands({ uid, now = () => Date.now() } = {}) {
  if (typeof uid !== 'function') throw new TypeError('Projects Commands : uid requis.');
  return Object.freeze({
    /** Ajoute une entrée en tête du journal (texte déjà nettoyé, photos éventuelles). */
    addLogEntry(pr, text, photos) { const e = { id: 'e' + uid(), ts: now(), text: text, photos: photos }; pr.log.unshift(e); return e; },
    /** Ajoute le temps tricoté au journal, marque la reprise du travail et remet le chronomètre à zéro. */
    addTimeEntry(pr, ms, label) { pr.log.unshift({ id: 'e' + uid(), ts: now(), text: label, ms: ms, photos: [] }); pr.workAt = now(); pr.timer = { acc: 0, start: 0 }; },
    ensureTimer(pr) { if (!pr.timer) pr.timer = { acc: 0, start: 0 }; },
    resetTimer(pr) { pr.timer = { acc: 0, start: 0 }; },
    ensurePhotos(pr) { if (!pr.photos) pr.photos = []; },
    ensureInspo(pr) { if (!Array.isArray(pr.inspo)) pr.inspo = []; },
    addPhoto(pr, id) { pr.photos.push(id); },
    /** Nouvelle photo devenue la couverture. */
    addCoverPhoto(pr, id) { if (!pr.photos) pr.photos = []; pr.photos.push(id); pr.cover = id; pr.coverPdf = false; },
    addInspoPhoto(pr, mediaId) { const e = { id: 'i' + uid(), mediaId: mediaId, mediaType: 'image' }; pr.inspo.push(e); return e; },
    /** Rattache une idée de la bibliothèque au tableau d'inspiration (l'idée reste à Library). */
    addInspoIdea(pr, ideaId) { const e = { id: 'i' + uid(), ideaId: ideaId }; pr.inspo.push(e); return e; },
    clearCover(pr) { pr.cover = ''; },
    clearCoverIf(pr, id) { if (pr.cover === id) pr.cover = ''; },
    /** Choix de la couverture : '__auto' (automatique), '__pdf' (page du PDF) ou l'identifiant d'une photo. */
    pickCover(pr, key) {
      if (key === '__auto') { pr.cover = ''; pr.coverPdf = false; }
      else if (key === '__pdf') { pr.coverPdf = true; }
      else { pr.cover = key; pr.coverPdf = false; }
    },
    /** Retire une photo du projet ; la couverture est libérée si c'était elle. Le média est supprimé par l'appelant. */
    removePhoto(pr, id) { if (pr.cover === id) pr.cover = ''; pr.photos = (pr.photos || []).filter(function(x) { return x !== id; }); },
    /** Retire une entrée du journal ; renvoie les photos de l'entrée (à supprimer par l'appelant). */
    removeLogEntry(pr, entryId) {
      const en = pr.log.find(function(x) { return x.id === entryId; });
      let photos = [];
      if (en) { photos = (en.photos || []).slice(); if (pr.cover && (en.photos || []).indexOf(pr.cover) >= 0) pr.cover = ''; }
      pr.log = pr.log.filter(function(x) { return x.id !== entryId; });
      return photos;
    },
    removeInspo(pr, inspoId) { pr.inspo = pr.inspo.filter(function(x) { return x.id !== inspoId; }); },
    /* ---- 4.6d : champs, fils, plan de couleurs, raisons de l'île, objectif, simulation ---- */
    /** Champ simple d'un projet (nom, aiguilles, taille, pattern…) : valeur recopiée telle quelle. */
    setField(pr, field, value) { pr[field] = value; },
    setAgain(pr, checked) { pr.again = checked; },
    setRowsTotal(pr, value) { pr.rowsTotal = parseInt(value, 10) || 0; },
    dropGoal(pr) { pr.sub = null; },
    setPlannedSkeins(pr, value) { pr.plannedSkeins = Math.max(0, parseInt(value, 10) || 0); },
    setPlannedCount(color, value) { color.planned = Math.max(0, parseInt(value, 10) || 0); },
    /** Champ d'un fil : « planned » est un entier positif, les autres champs restent du texte. */
    setYarnField(y, field, value) { y[field] = field === 'planned' ? Math.max(0, parseInt(value, 10) || 0) : value; },
    setYarnName(y, value) { y.name = value; },
    addYarn(yarns) { const y = { id: 'y' + uid(), name: '', used: 0 }; yarns.push(y); return y; },
    removeYarn(pr, yarns, yarnId) { pr.yarns = yarns.filter(function(x) { return x.id !== yarnId; }); },
    /** Nouvelle couleur prévue ; si c'est la première, elle reprend le nombre de pelotes prévues du projet. */
    addPlannedColor(pr) {
      if (!Array.isArray(pr.plannedColors)) pr.plannedColors = [];
      const c = { id: 'pc' + uid(), hex: '', name: '', yarn: 'À définir' };
      if (!pr.plannedColors.length && pr.plannedSkeins > 0) { c.planned = pr.plannedSkeins; pr.plannedSkeins = 0; }
      pr.plannedColors.push(c); return c;
    },
    removePlannedColor(pr, colorId) {
      const old = (pr.plannedColors || []).find(function(x) { return x.id === colorId; });
      pr.plannedColors = (pr.plannedColors || []).filter(function(x) { return x.id !== colorId; });
      if (!pr.plannedColors.length && old && old.planned > 0) pr.plannedSkeins = old.planned;
    },
    /** Coche / décoche une raison de WIP Island. */
    toggleIslandReason(pr, reason, checked) {
      if (!Array.isArray(pr.islandReasons)) pr.islandReasons = [];
      if (checked && pr.islandReasons.indexOf(reason) < 0) pr.islandReasons.push(reason);
      if (!checked) pr.islandReasons = pr.islandReasons.filter(function(x) { return x !== reason; });
    },
    devReset(pr) { delete pr.devAge; delete pr.islandSince; },
    devPause(pr, months) { pr.devAge = now() - months * 30.44 * 86400000 - 86400000; delete pr.islandSince; delete pr.islandSeen; },
    /* ---- 4.6e : création, étape, île, liens avec les patrons ---- */
    /** Nouveau projet (enregistrement initial) : la date d'étape est posée, un WIP démarre « travaillé maintenant ». L'ajout à la liste reste à l'appelant. */
    createProject(o, seq) {
      const pr = { id: 'j' + uid(), seq: seq, name: o.name || 'Projet ' + seq, stage: o.stage || 'attente', patternId: o.patternId || '', cover: '', size: '', yarns: [], needles: '', rows: 0, log: [], timer: { acc: 0, start: 0 }, created: now(), stageAt: {} };
      pr.stageAt[pr.stage] = now();
      if (pr.stage === 'wip') pr.workAt = now();
      return pr;
    },
    /** Changement d'étape (de → vers) : mémorise l'étape précédente, arrête le chrono à la fin, efface les drapeaux de l'île à « terminé », marque la reprise du travail au passage en WIP. */
    changeStage(pr, from, st) {
      pr.stagePrev = from;
      if (st === 'termine' && pr.timer && pr.timer.start) { pr.timer.acc += now() - pr.timer.start; pr.timer.start = 0; }
      pr.stage = st;
      pr.stageAt[st] = now();
      if (st === 'termine') { delete pr.islandSince; delete pr.islandPin; delete pr.leftIsland; }
      else if (st === 'wip' && from !== 'wip') { pr.workAt = now(); }
    },
    setStageDate(pr, stage, ts) { pr.stageAt[stage] = ts; },
    /** Épingle le projet sur WIP island (envoi manuel ou « Remettre sur l'île »). */
    pinToIsland(pr) { pr.islandPin = true; delete pr.leftIsland; pr.islandSeen = true; },
    /** Sortie de l'île : l'épingle tombe ; si le projet y était, on garde la date pour pouvoir le remettre. */
    exitIsland(pr, was) { delete pr.islandPin; if (was) pr.leftIsland = now(); },
    touch(pr) { pr.workAt = now(); },
    ensureLog(pr) { if (!Array.isArray(pr.log)) pr.log = []; },
    setPatternId(pr, id) { pr.patternId = id || ''; },
    /** Rattache une liste de projets à un patron ('' pour détacher). */
    linkProjects(list, patternId) { list.forEach(function(x) { x.patternId = patternId; }); },
    /** Détache les projets d'un patron supprimé. */
    unlinkPattern(projects, patternId) { projects.forEach(function(x) { if (x.patternId === patternId) x.patternId = ''; }); },
    /** Les projets de l'ancien patron passent au nouveau (remplacement). */
    relinkPattern(projects, fromId, toId) { projects.forEach(function(x) { if (x.patternId === fromId) x.patternId = toId; }); },
    /** Marque comme vus les projets de l'« île » (isIsland fourni par l'appelant). */
    ackIsland(projects, isIsland) { projects.forEach(function(x) { if (isIsland(x)) x.islandSeen = true; }); }
  });
}
