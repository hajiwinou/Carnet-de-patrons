/**
 * dreamOS — Moteur pur de Projects (Phase 3.9)
 * Extrait VERBATIM d'app.js par tools/gen-projects-engine.mjs (analyse TypeScript), sans aucune modification de logique :
 * étape d'un projet, dernière activité, couverture historique, fils et pelotes (prévu / utilisé), plan de couleurs,
 * notes moyennes, nom d'une couleur depuis son code, raisons du WIP Island, dates.
 * Aucune lecture ni écriture de stockage, de DOM ou d'état : les fonctions reçoivent le projet concerné en paramètre
 * (pjYarns et pjApplyPlan le complètent comme le code historique) ; l'enregistrement et le rendu restent à app.js.
 * Seule dépendance externe : le générateur d'identifiants (uid), injecté.
 */
export function createProjectsEngine({ uid }) {
  if (typeof uid !== 'function') throw new TypeError('createProjectsEngine : uid requis.');
  function pjStageOf(pr) { return pr.stage === 'wip' || pr.stage === 'termine' ? pr.stage : 'attente'; }

  function isAutoPjName(n) { return !n || n === 'Nouveau projet' || /^Projet \d+$/.test(n); }

  function lastActivity(pr) { return (pr.log && pr.log[0] && pr.log[0].ts) || pr.stageAt[pr.stage] || pr.created; }

  function pjLegacyCover(pr) {
      /* ancienne couverture envoyée à part (pas une photo du projet, du journal ni de l'inspiration) */
      var c = pr.cover;
      if (!c || String(c).indexOf('pjc_') !== 0) return false;
      if ((pr.photos || []).indexOf(c) >= 0) return false;
      return !(pr.log || []).some(function(en) { return (en.photos || []).indexOf(c) >= 0; });
    }

  function pjPlannedTotal(pr) {
      var cols = pr.plannedColors || [];
      if (cols.length) return cols.reduce(function(t, c) { return t + (c.planned > 0 ? c.planned : 0); }, 0);
      return pr.plannedSkeins > 0 ? pr.plannedSkeins : 0;
    }

  function pjApplyPlan(pr) {
      var ys = pjYarns(pr), cols = Array.isArray(pr.plannedColors) ? pr.plannedColors : [];
      function sync(src, base) {
        var y = src.yarnId && ys.find(function(x) { return x.id === src.yarnId; });
        if (y) { if (!(y.planned > 0) && src.planned > 0) y.planned = src.planned; return; }
        if (!(src.planned > 0 || base.hex || base.color)) return;
        y = { id: 'y' + uid(), name: '', brand: '', color: base.color || '', hex: base.hex || '', used: 0, planned: src.planned > 0 ? src.planned : 0 };
        ys.push(y); src.yarnId = y.id;
      }
      if (cols.length) cols.forEach(function(c) { sync(c, { color: c.name, hex: c.hex }); });
      else if (pr.plannedSkeins > 0) { var hold = { planned: pr.plannedSkeins, yarnId: pr.plannedYarnId }; sync(hold, {}); pr.plannedYarnId = hold.yarnId; }
    }

  function fmtEntryDate(ts) {
      var d = new Date(ts);
      return d.toLocaleDateString('fr-BE', { day: 'numeric', month: 'long', year: 'numeric' }) + ' à ' + d.toLocaleTimeString('fr-BE', { hour: '2-digit', minute: '2-digit' });
    }

  function pjYarns(pr) {
      if (!Array.isArray(pr.yarns)) {
        pr.yarns = [];
        if (pr.yarn && String(pr.yarn).trim()) pr.yarns.push({ id: 'y' + uid(), name: String(pr.yarn).trim(), used: 0 });
        delete pr.yarn;
      }
      return pr.yarns;
    }

  function pjSkeins(pr) { return pjYarns(pr).reduce(function(t, y) { return t + (y.used || 0); }, 0); }

  function pjYarnNames(pr) { return pjYarns(pr).map(function(y) { return [y.name, y.brand, y.color].join(' '); }).join(' '); }

  function pjLastTouch(pr) {
      if (pr.timer && pr.timer.start) return Date.now();
      if (pr.devAge) return pr.devAge; // simulation de test des réglages
      var rowsAt=(pr.rts&&pr.rts.length)?pr.rts[pr.rts.length-1]:0;
      return Math.max(pr.workAt||0, rowsAt||0, (pr.stageAt&&pr.stageAt.wip)||0, pr.created||0);
    }

  function pjStartTs(pr) { var t = (pr.stageAt && pr.stageAt.wip) || pr.created; return pr.devAge ? Math.min(t, pr.devAge) : t; }

  const ISLAND_REASON_GROUPS = [
      ['Envie', [
        ['demotivated', 'Plus envie de le tricoter'], ['pattern', 'Le modèle ne me plaît plus'], ['colors', 'Les couleurs ne me plaisent plus'],
        ['newproj', 'Un autre projet est prioritaire'], ['boring', 'Trop répétitif'], ['pause', 'Pause volontaire']]],
      ['Technique', [
        ['modifications', 'À modifier'], ['mistake', 'Erreur à défaire'], ['gauge', 'Problème d’échantillon'],
        ['fit', 'La taille ne convient pas'], ['confusing', 'Patron difficile à suivre'], ['sleeve', 'Sleeve Island'], ['secondsock', 'Second sock syndrome']]],
      ['Matériel', [
        ['yarn', 'Manque de fil'], ['needles', 'Manque d’aiguilles'], ['buttons', 'J’attends boutons / accessoires']]],
      ['Vie', [
        ['time', 'Pas le temps en ce moment'], ['season', 'Pas la bonne saison'], ['lostnotes', 'Notes ou patron perdus'],
        ['finishing', 'Il ne reste que les finitions'], ['blocking', 'À bloquer / essayer'], ['gift', 'Cadeau sans urgence']]]
    ];

  const ISLAND_REASONS = [];

  ISLAND_REASON_GROUPS.forEach(function(g) { g[1].forEach(function(r) { ISLAND_REASONS.push(r); }); });

  function islandReasonLabel(id) { var r = ISLAND_REASONS.find(function(x) { return x[0] === id; }); return r ? r[1] : ''; }

  function islandReasonList(pr) { return (Array.isArray(pr.islandReasons) ? pr.islandReasons : []).map(islandReasonLabel).filter(Boolean); }

  function yarnCountTxt(y) { return (y.used || 0) + (y.planned > 0 ? ' / ' + y.planned : ''); }

  function pjSkeinsTxt(pr) { var pl = pjYarns(pr).reduce(function(t, y) { return t + (y.planned || 0); }, 0); return pjSkeins(pr) + (pl > 0 ? ' / ' + pl : ''); }

  function ratingAvg(pr) {
      var r = pr.rating || {}, s = 0, n = 0;
      ['pattern', 'yarn', 'result', 'fit', 'comfort'].forEach(function(k) { if (r[k] > 0) { s += r[k]; n++; } });
      return n ? (Math.round(s / n * 10) / 10).toString().replace('.', ',') : '';
    }

  const YARN_COLORS = [
      ['Blanc', '#ffffff'], ['Écru', '#f1e9d8'], ['Crème', '#f7ecc9'], ['Beige', '#d9c3a0'], ['Camel', '#b98a55'], ['Marron', '#7b5233'], ['Chocolat', '#4b3022'],
      ['Gris perle', '#cfd3d6'], ['Gris', '#8c9096'], ['Anthracite', '#3d4147'], ['Noir', '#1a1a1a'],
      ['Rose pâle', '#f5d3dc'], ['Rose poudré', '#e3a9b8'], ['Rose vif', '#e0507f'], ['Fuchsia', '#b8236b'], ['Corail', '#ee7d6b'], ['Rouge', '#c62d2d'], ['Bordeaux', '#7a1f2e'],
      ['Orange', '#ec8a2d'], ['Moutarde', '#d6a21f'], ['Jaune', '#f2d43c'],
      ['Vert menthe', '#b9e0c4'], ['Vert sauge', '#9fb59a'], ['Vert', '#4f9a5a'], ['Vert sapin', '#25523b'], ['Kaki', '#7a7a45'],
      ['Turquoise', '#3fb5b0'], ['Bleu ciel', '#a9d2ee'], ['Bleu', '#3d78c4'], ['Bleu marine', '#1f2f5c'],
      ['Lavande', '#c4b2e0'], ['Violet', '#7a4fa8'], ['Prune', '#52284f']
    ];

  function colorNameFromHex(hex) {
      var m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
      if (!m) return '';
      var n = parseInt(m[1], 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255, best = '', bd = 1e9;
      YARN_COLORS.forEach(function(c) {
        var q = parseInt(c[1].slice(1), 16), d = Math.pow(r - ((q >> 16) & 255), 2) + Math.pow(g - ((q >> 8) & 255), 2) + Math.pow(b - (q & 255), 2);
        if (d < bd) { bd = d; best = c[0]; }
      });
      return best;
    }

  function colorTarget(pr, key) {
      var k = String(key).split(':');
      if (k[0] === 'y') return pjYarns(pr).find(function(x) { return x.id === k[1]; });
      return (pr.plannedColors || []).find(function(x) { return x.id === k[1]; });
    }

  function daysSince(ts) { return Math.max(0, Math.floor((Date.now() - ts) / 86400000)); }

  return Object.freeze({
    YARN_COLORS, ISLAND_REASON_GROUPS, ISLAND_REASONS,
    pjStageOf, isAutoPjName, lastActivity, pjLegacyCover, pjPlannedTotal, pjApplyPlan, pjYarns, pjSkeins, pjYarnNames, pjSkeinsTxt, yarnCountTxt, pjLastTouch, pjStartTs, ratingAvg, colorNameFromHex, colorTarget, islandReasonLabel, islandReasonList, fmtEntryDate, daysSince
  });
}
