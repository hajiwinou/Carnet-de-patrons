/**
 * dreamOS — Projects Store (Jalon 4.6a)
 * AUTORITÉ D'ÉCRITURE de la LISTE des projets (carnet.projects) et de son enregistrement, ainsi que de deux réglages d'écran
 * (carnet.pjStage : onglet courant ; carnet.migPj : migration faite) quand le module Projects est engagé.
 *
 * Périmètre de cette sous-étape (4.6a) — volontairement limité :
 *  - structure de la liste : création, suppression, annulation, remplacement (import / restauration) ;
 *  - enregistrement : TOUT enregistrement de la liste passe par save(), y compris celui qui suit une modification d'un champ de projet ;
 *  - les champs d'un projet (journal, rangs, fils, notes…) sont encore modifiés en mémoire par app.js (étape 4.6c) ;
 *  - les médias de projets (pjc_ / pjp_ / pji_) viendront en 4.6b.
 * Même principe qu'ailleurs : le magasin ADOPTE le tableau d'app.js (même référence) ; l'écriture physique (localStorage + miroir
 * IndexedDB « meta_projects ») reste la fonction fournie par app.js.
 */
export const PROJECTS_PERSISTED_KEYS = Object.freeze(['carnet.pjStage', 'carnet.migPj']);
export function createProjectsStore({ eventBus } = {}) {
  let arr = null, write = null;
  const emit = (type, extra) => { try { eventBus?.emit('projects:' + type, { count: arr ? arr.length : 0, ...extra }); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  const need = () => { if (!arr) throw new Error('Projects Store : aucun tableau adopté.'); return arr; };
  const list = {
    adopt(a, writeFn) { if (!Array.isArray(a)) throw new TypeError('Projects Store : tableau requis.'); arr = a; if (typeof writeFn === 'function') write = writeFn; return true; },
    get adopted() { return !!arr; },
    list() { return arr; },
    count() { return arr ? arr.length : 0; },
    save() { if (write) write(need()); emit('saved'); return true; },
    addFirst(pr) { need().unshift(pr); list.save(); emit('added', { id: pr && pr.id }); return pr; },
    removeAt(i) { const r = need().splice(i, 1)[0]; list.save(); emit('removed', { id: r && r.id }); return r; },
    insertAt(i, pr) { const a = need(); a.splice(Math.min(i, a.length), 0, pr); list.save(); emit('restored', { id: pr && pr.id }); return true; },
    replaceAll(next, save) { const a = need(); const copy = Array.isArray(next) ? next.slice() : []; a.splice(0, a.length, ...copy); if (save) list.save(); emit('replaced'); return a; }
  };
  return Object.freeze({
    adopt: list.adopt, get adopted() { return list.adopted; }, list: list.list, count: list.count, save: list.save, addFirst: list.addFirst, removeAt: list.removeAt, insertAt: list.insertAt, replaceAll: list.replaceAll,
    persist(key, value, writer) {
      if (!PROJECTS_PERSISTED_KEYS.includes(key)) throw new TypeError('Projects Store : clé non gérée « ' + String(key) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('Projects Store : écriture requise.');
      writer(key, value); emit('persisted', { key }); return true;
    }
  });
}
