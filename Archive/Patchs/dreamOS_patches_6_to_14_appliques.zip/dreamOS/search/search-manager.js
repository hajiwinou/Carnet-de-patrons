/**
 * dreamOS — Search Manager (Phase 3.6)
 * Recherche transversale (patrons, projets, documentation, épingles). Reproduit les règles de findHtml / docHit d'app.js :
 * normalisation sans accents ni casse, au moins 2 lettres, 20 résultats par groupe.
 * Les collections sont passées explicitement ; le service renvoie les objets d'origine (le rendu HTML reste à l'appelant)
 * et ne modifie rien.
 */
export const MIN_QUERY_LENGTH = 2;
export const GROUP_LIMIT = 20;

export const normalize = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

export function createSearchManager() {
  const has = (haystackParts, key) => normalize(haystackParts.join(' ')).indexOf(key) >= 0;
  const boardIds = (item, boards) => (item.boards || []).filter((id) => boards.some((b) => b.id === id));

  return Object.freeze({
    normalize,
    /** Un article de documentation correspond-il à la requête ? (requête vide = tout) */
    docMatches(post, query) {
      const q = normalize(query);
      return !q || has([post.title, post.content, post.category], q);
    },
    /**
     * @param {string} query requête brute
     * @param {{patterns:object[], projects:object[], ideas:object[], boards:object[], docs:object[]}} data collections fournies par l'appelant
     * @param {{yarnNames?: (project)=>string}} [options] yarnNames : noms des fils d'un projet (fourni par Projects)
     * @returns {{tooShort:boolean, key:string, patterns:object[], projects:object[], docs:object[], pins:object[]}}
     */
    run(query, { patterns = [], projects = [], ideas = [], boards = [], docs = [] } = {}, { yarnNames = () => '' } = {}) {
      const key = normalize(query);
      if (key.length < MIN_QUERY_LENGTH) return { tooShort: true, key, patterns: [], projects: [], docs: [], pins: [] };
      const top = (list, pred) => list.filter(pred).slice(0, GROUP_LIMIT);
      return {
        tooShort: false, key,
        patterns: top(patterns, (p) => normalize(p.title + ' ' + JSON.stringify(p.f || {})).indexOf(key) >= 0),
        projects: top(projects, (x) => has([x.name, (x.log || []).map((e) => e.text || '').join(' '), yarnNames(x), x.needles, x.size], key)),
        docs: top(docs, (x) => has([x.title, x.content, x.category], key)),
        pins: top(ideas, (i) => {
          const names = boardIds(i, boards).map((id) => boards.filter((b) => b.id === id)[0].name).join(' ');
          return has([i.title, i.note, i.tag, names], key);
        })
      };
    }
  });
}
