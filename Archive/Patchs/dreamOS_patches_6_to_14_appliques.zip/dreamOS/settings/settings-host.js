/**
 * dreamOS — Settings Host (Jalon 4.9a)
 * Le module Settings devient l'autorité d'écriture des réglages (settings-store.js) et du fond d'écran personnalisé wp_* (settings-media.js).
 * Jalon 4.9b : et des modifications des valeurs (S.ui, S.ai, S.opts : settings-commands.js).
 * Le calcul de l'empreinte du mot de passe, l'application de l'apparence et le rendu restent à app.js. L'application de l'apparence reste au Theme Manager (ressource dom « appearance »).
 * app.js consulte window.DreamOSSettingsHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createSettingsStore } from './settings-store.js';
import { createSettingsMedia } from './settings-media.js';
import { createSettingsCommands } from './settings-commands.js';

export const SETTINGS_RESOURCES = Object.freeze([['storage', 'carnet.ui', 'settings'], ['storage', 'carnet.theme', 'settings'], ['storage', 'carnet.opts', 'settings'], ['storage', 'carnet.ai', 'settings'], ['storage', 'carnet.pwHash', 'settings'], ['storage', 'carnet.pwFail', 'settings'], ['storage', 'carnet.lastBackup', 'settings'], ['media', 'wp_*', 'settings']]);

export function installSettingsHost({ moduleRegistry, legacy, eventBus, win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installSettingsHost : window requis.');
  if (win.DreamOSSettingsHost) return win.DreamOSSettingsHost;
  let enabled = false;
  const move = (toOwner) => SETTINGS_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    store: createSettingsStore({ eventBus }),
    media: createSettingsMedia({ eventBus }),
    commands: createSettingsCommands(),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('settings:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('settings:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSSettingsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSSettingsHost;
}
