/**
 * dreamOS — Settings Commands (Jalon 4.9b)
 * Transcriptions fidèles des modifications des VALEURS de réglages, appliquées à l'objet passé en paramètre (ui = apparence, ai = IA,
 * opts = options) : couleurs et palette, thème et police, statistiques, île, fond d'écran, fournisseurs d'IA (adresse, clé, modèle,
 * préférences, bascule automatique), options. Ni enregistrement, ni rendu, ni message : l'appelant (app.js) s'en charge exactement
 * comme avant (setKeep, applyAppearance, render, toast). Aucune de ces commandes ne touche au verrou (l'empreinte reste à app.js).
 */
export const DEFAULT_ACCENT = '#2A47C9';
export function createSettingsCommands() {
  return Object.freeze({
    /** Champ simple d'apparence (thème, police, couleurs, opacité du voile : nombre). */
    setUiField(ui, key, value) { ui[key] = key === 'overlayOpacity' ? parseFloat(value) : value; },
    /** Une couleur de la palette personnalisable ; les couleurs absentes reprennent la palette par défaut. */
    setDreamColor(ui, defaults, key, value) { ui.dream = Object.assign({}, defaults, ui.dream || {}); ui.dream[key] = value; },
    /** Palette complète (choix d'un jeu de couleurs, conversion d'une ancienne palette). */
    setDreamPalette(ui, palette) { ui.dream = Object.assign({}, palette); },
    setAccent(ui, value) { ui.accent = value; },
    resetColors(ui) { ui.bgColor = ''; ui.surfaceColor = ''; ui.accent = DEFAULT_ACCENT; },
    /** Une statistique affichée ou masquée (l'objet est remplacé, pas modifié sur place). */
    setStat(ui, key, checked) { const o = Object.assign({}, ui.stats || {}); o[key] = checked; ui.stats = o; },
    /** Option de l'île : « on » (actif), « animal » (animal) ou le nombre de mois (au moins 1, 3 par défaut). Renvoie l'île. */
    setIslandOption(ui, which, value, checked, defaultAnimal) {
      const io = Object.assign({ on: false, months: 3, animal: defaultAnimal }, ui.island || {});
      if (which === 'on') io.on = checked; else if (which === 'animal') io.animal = value; else io.months = Math.max(1, parseInt(value, 10) || 3);
      ui.island = io; return io;
    },
    enableIsland(ui) { ui.island = Object.assign({}, ui.island || {}, { on: true }); },
    /** Valeur d'apparence posée telle quelle (restauration d'une sauvegarde, fond d'écran). */
    setUiValue(ui, key, value) { ui[key] = value; },
    setProviderUrl(ai, id, value) { ai.urls[id] = value.trim(); },
    setProviderKey(ai, id, value) { ai.keys[id] = value; },
    /** Fournisseur devenu utilisable : il devient le choix par défaut du texte (et de la vision s'il la gère) quand il n'y en a pas d'utilisable. */
    adoptDefaultProviders(ai, id, hasVision, isReady) {
      if (!ai.prefText || !isReady(ai.prefText)) ai.prefText = id;
      if (hasVision && (!ai.prefVision || !isReady(ai.prefVision))) ai.prefVision = id;
    },
    setOmniVision(ai, checked) { ai.omniVision = checked; },
    setModel(ai, id, value) { ai.models[id] = value; },
    setPreference(ai, key, value) { ai[key] = value; },
    setAutoFailover(ai, checked) { ai.autoFailover = checked; },
    /** Option : case à cocher = booléen ; sinon entier d'au moins 1 (ancienne valeur si illisible). */
    setOption(opts, key, isCheckbox, checked, value) { opts[key] = isCheckbox ? checked : Math.max(1, parseInt(value, 10) || opts[key]); }
  });
}
