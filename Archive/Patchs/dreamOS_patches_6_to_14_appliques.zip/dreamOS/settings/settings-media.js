/**
 * dreamOS — Settings Media (Jalon 4.9a)
 * AUTORITÉ D'ÉCRITURE du fond d'écran personnalisé (blob wp_<uid>) quand le module Settings est engagé : création d'identifiant,
 * écriture et suppression passent par ici. L'écriture physique (cache de blobs + IndexedDB) reste celle d'app.js, passée en paramètre ;
 * la lecture (getBlobUrl, loadBlob) et l'application du fond restent à app.js / au Theme Manager.
 * put() impose le préfixe wp_ ; la suppression n'en impose pas (un ancien fond peut avoir un autre identifiant).
 * La restauration groupée d'une sauvegarde reste au futur service de sauvegarde.
 */
export const SETTINGS_MEDIA_PREFIXES = Object.freeze(['wp_']);
export function createSettingsMedia({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('settings:media-' + type, extra); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une écriture */ } };
  const own = (id) => typeof id === 'string' && SETTINGS_MEDIA_PREFIXES.some((p) => id.startsWith(p));
  return Object.freeze({
    prefixes: SETTINGS_MEDIA_PREFIXES,
    isOwn: own,
    newId(uid) { return 'wp_' + uid(); },
    async put(id, blob, writer) {
      if (!own(id)) throw new TypeError('Settings Media : identifiant wp_ requis (reçu « ' + String(id) + ' »).');
      if (typeof writer !== 'function') throw new TypeError('Settings Media : écriture requise.');
      const r = await writer(id, blob); emit('saved', { id }); return r;
    },
    discard(id, remover) {
      if (typeof remover !== 'function') throw new TypeError('Settings Media : suppression requise.');
      remover(id); emit('discarded', { id }); return true;
    }
  });
}
