/**
 * dreamOS — Settings Store (Jalon 4.9a)
 * AUTORITÉ D'ÉCRITURE des réglages quand le module Settings est engagé : apparence (carnet.ui), thème (carnet.theme), options
 * (carnet.opts), configuration des fournisseurs d'IA (carnet.ai), verrou de l'application (carnet.pwHash : empreinte du mot de passe,
 * jamais le mot de passe ; carnet.pwFail : essais ratés), date de la dernière sauvegarde (carnet.lastBackup).
 * L'écriture physique (localStorage) reste la fonction fournie par app.js ; le module la déclenche après validation de la clé.
 * Le calcul de l'empreinte (PBKDF2), l'application de l'apparence et le rendu restent à app.js / au Theme Manager.
 */
export const SETTINGS_PERSISTED_KEYS = Object.freeze(['carnet.ui', 'carnet.theme', 'carnet.opts', 'carnet.ai', 'carnet.pwHash', 'carnet.pwFail', 'carnet.lastBackup']);
export function createSettingsStore({ eventBus } = {}) {
  const emit = (type, key) => { try { eventBus?.emit('settings:' + type, { key }); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  return Object.freeze({
    keys: SETTINGS_PERSISTED_KEYS,
    persist(key, value, writer) {
      if (!SETTINGS_PERSISTED_KEYS.includes(key)) throw new TypeError('Settings Store : clé non gérée « ' + String(key) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('Settings Store : écriture requise.');
      writer(key, value); emit('persisted', key); return true;
    }
  });
}
