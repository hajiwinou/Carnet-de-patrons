/**
 * dreamOS — PDF Reader Store (Jalon 4.8)
 * AUTORITÉ D'ÉCRITURE des données du lecteur PDF quand le module est engagé : position de reprise de chaque PDF (carnet.vpos.<id>),
 * repère de rang (carnet.vmark.<id>), marqueurs de marge (carnet.vsm.<id>), surlignages (carnet.vhl.<id>), position et état
 * réduit du compteur de rangs (carnet.vrcPos, carnet.vrcMin).
 * L'écriture physique (localStorage via keep) reste la fonction fournie par app.js ; le module la déclenche après validation de la clé.
 * Ne touche JAMAIS au compteur de rangs lui-même (propriété de Projects) ni aux PDF (médias de Patterns).
 */
export const PDF_READER_FIXED_KEYS = Object.freeze(['carnet.vrcPos', 'carnet.vrcMin']);
export const PDF_READER_KEY_PREFIXES = Object.freeze(['carnet.vmark.', 'carnet.vsm.', 'carnet.vpos.', 'carnet.vhl.']);
export function isPdfReaderKey(key) {
  if (typeof key !== 'string') return false;
  if (PDF_READER_FIXED_KEYS.includes(key)) return true;
  return PDF_READER_KEY_PREFIXES.some((p) => key.startsWith(p) && key.length > p.length);
}
export function createPdfReaderStore({ eventBus } = {}) {
  const emit = (type, extra) => { try { eventBus?.emit('pdf-reader:' + type, extra || {}); } catch (e) { /* un abonné défaillant ne doit jamais bloquer une sauvegarde */ } };
  return Object.freeze({
    persist(key, value, writer) {
      if (!isPdfReaderKey(key)) throw new TypeError('PDF Reader Store : clé non gérée « ' + String(key) + ' ».');
      if (typeof writer !== 'function') throw new TypeError('PDF Reader Store : écriture requise.');
      writer(key, value); emit('persisted', { key }); return true;
    }
  });
}
