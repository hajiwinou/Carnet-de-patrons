/**
 * dreamOS — PDF Reader Commands (Jalon 4.8)
 * Transcriptions fidèles des modifications du lecteur sur l'état de lecture passé en paramètre (V) : repère de rang, marqueurs de
 * marge, surlignages. Ni enregistrement, ni rendu, ni message : l'appelant (app.js) s'en charge exactement comme avant.
 * L = ligne de texte détectée sous le doigt ({x0, x1, y0, y1}) ou null ; fx / fy = position du toucher dans la page (0..1).
 */
export function createPdfReaderCommands() {
  return Object.freeze({
    /** Repère de rang : retiré s'il est touché de nouveau (à 1,2 % près), sinon posé. Renvoie { removed, prev }. */
    toggleMark(V, i, fy, L) {
      const o = V.mark;
      if (o && o.i === i && Math.abs(o.y - fy) < 0.012) { V.mark = null; return { removed: true, prev: o }; }
      V.mark = { i: i, y: L ? L.y1 : fy };
      return { removed: false, prev: o };
    },
    /** Marqueur de marge : retiré s'il existe déjà à cette hauteur (à 0,8 % près), sinon posé. Renvoie true si posé. */
    toggleSideMarker(V, i, fy, L) {
      const sa = V.sm[i] = V.sm[i] || [];
      const sx = L ? Math.max(0.012, L.x0 - 0.03) : 0.02, sy = L ? (L.y0 + L.y1) / 2 : fy;
      const sk = sa.findIndex((m) => Math.abs(m.y - sy) < 0.008);
      let placed;
      if (sk >= 0) { sa.splice(sk, 1); placed = false; } else { sa.push({ x: sx, y: sy }); placed = true; }
      if (!sa.length) delete V.sm[i];
      return placed;
    },
    /** Surlignage : retiré s'il est touché (marge de 2 % sur les côtés), sinon ajouté (ligne détectée, ou bande par défaut). */
    toggleHighlight(V, i, fx, fy, L) {
      const a = V.hl[i] = V.hl[i] || [];
      const k = a.findIndex((h) => fy >= h.y0 && fy <= h.y1 && fx >= h.x0 - 0.02 && fx <= h.x1 + 0.02);
      if (k >= 0) a.splice(k, 1); else a.push(L || { x0: 0.05, x1: 0.95, y0: Math.max(0, fy - 0.01), y1: fy + 0.012 });
    },
    /** Position de reprise enregistrée pour un PDF : page (0-based) et fraction de hauteur. */
    readingPosition(k, f) { return { i: k, f: f }; },
    /** Position du compteur de rangs après déplacement, en fractions de la zone du lecteur. */
    counterPosition(rect, viewerRect) { return { x: (rect.left - viewerRect.left) / viewerRect.width, y: (rect.top - viewerRect.top) / viewerRect.height }; },
    /** État réduit du compteur : 1 réduit, 0 normal. */
    counterMin(minimized) { return minimized ? 1 : 0; }
  });
}
