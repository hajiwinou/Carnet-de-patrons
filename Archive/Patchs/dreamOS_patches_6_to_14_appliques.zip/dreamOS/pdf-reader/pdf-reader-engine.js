/**
 * dreamOS — Moteur pur du PDF Reader (Phase 3.10)
 * Calculs sans DOM ni stockage, repris à l'identique des fonctions d'app.js (pageLabel, vCurPage, vposNow, vrcFmt, vrcStat,
 * noteCtx, setZoom, vrcPlace, sheetSize, vOvPage, vRestore) : les mesures du DOM (positions, hauteurs) sont passées en paramètres.
 * Invariant : le lecteur n'est jamais propriétaire du compteur de rangs (il le pilote via Projects) ; rien ici n'écrit un projet.
 */
export function createPdfReaderEngine() {
  // Index (0-based) de la dernière page dont le haut est au-dessus de la ligne de référence ; dflt si aucune.
  function pageIndexAt(offsets, ref, dflt) { var k = dflt; offsets.forEach(function(o, i) { if (o <= ref) k = i; }); return k; }
  function pageLabelText(n, total) { return total ? n + ' / ' + total : ''; }
  function vrcFmt(ms) {
    var s = Math.round(ms / 1000);
    if (s < 60) return s + ' s';
    var m = Math.floor(s / 60);
    if (m < 60) return m + ' min' + (m < 10 && s % 60 ? ' ' + String(s % 60).padStart(2, '0') : '');
    return Math.floor(m / 60) + ' h ' + String(m % 60).padStart(2, '0');
  }
  function vrcStatText(pr) {
    var t = pr.rts || [], iv = [], i;
    for (i = 1; i < t.length; i++) { var d = t[i] - t[i - 1]; if (d > 0 && d < 900000) iv.push(d); }
    var tot = pr.rowsTotal || 0, rows = pr.rows || 0, out = '';
    if (iv.length) {
      var l = iv.slice(-20), avg = l.reduce(function(a, b) { return a + b; }, 0) / l.length;
      out = '⏱ ' + vrcFmt(avg) + ' / rang';
      if (tot > rows) out += ' · reste ≈ ' + vrcFmt(avg * (tot - rows));
      else if (tot) out += ' · terminé 🎉';
    } else if (tot) out = rows + ' / ' + tot + ' rangs';
    return out;
  }
  function noteCtxText(hasPages, page, rows) {
    var parts = [];
    if (hasPages) parts.push('p. ' + (page || 1));
    if (rows) parts.push('rang ' + rows);
    return parts.join(' · ');
  }
  function clampZoom(z) { return Math.max(0.6, Math.min(4, z)); }
  function placeXY(pos, W, H, w, h) {
    if (!pos || typeof pos.x !== 'number') return null;
    return { x: Math.max(4, Math.min(W - w - 4, pos.x * W)), y: Math.max(4, Math.min(H - h - 4, pos.y * H)) };
  }
  function sheetHeights(vh, snap) {
    if (snap === 'compact') return { height: '', maxHeight: Math.round(vh * 0.6) + 'px' };
    return { height: Math.round(vh * (snap === 'full' ? 0.9 : 0.52)) + 'px', maxHeight: '' };
  }
  function posFraction(ref, offsetTop, offsetHeight) { return { f: Math.max(0, Math.min(1, (ref - offsetTop) / Math.max(1, offsetHeight))) }; }
  function restoreTop(offsetTop, offsetHeight, f, clientHeight, useMark) { return Math.max(0, offsetTop + f * offsetHeight - (useMark ? clientHeight * 0.3 : 90)); }
  function overlayHtml(hl, mark, sm, i) {
    var h = '';
    (hl[i] || []).forEach(function(r) { h += '<i class="vhl" style="left:' + r.x0 * 100 + '%;top:' + r.y0 * 100 + '%;width:' + (r.x1 - r.x0) * 100 + '%;height:' + (r.y1 - r.y0) * 100 + '%"></i>'; });
    if (mark && mark.i === i) h += '<i class="vmk" style="top:' + mark.y * 100 + '%"></i>';
    ((sm && sm[i]) || []).forEach(function(m) { h += '<i class="vsm" style="left:' + m.x * 100 + '%;top:' + m.y * 100 + '%"></i>'; });
    return h;
  }
  return Object.freeze({ pageIndexAt, pageLabelText, vrcFmt, vrcStatText, noteCtxText, clampZoom, placeXY, sheetHeights, posFraction, restoreTop, overlayHtml });
}
