# dreamOS — Jalon 4.1 : Documentation propriétaire de ses données (pilote)

## Ce qui change
- `dreamOS/documentation/documentation-store.js` : **seule autorité d'écriture** des articles (`carnet.docs`) quand le module est engagé — `add`, `removeAt`, `insertAt` (annulation), `replaceAll` (import / restauration), `save`. Événements `documentation:added|removed|restored|replaced|saved`.
- Le registre transfère aussi `storage:carnet.docs` de `legacy` à `documentation` (en plus de `logic:documentation-engine`).
- app.js : toutes les écritures sur `S.docs` passent par 4 fonctions (`docsAdd`, `docsRemoveAt`, `docsInsertAt`, `docsReplace`) + `saveDocs()` ; code d'origine conservé en repli.
- Version 4.1.0, cache du service worker `atelier-tricot-v22`.

## Pourquoi c'est sûr
Le magasin **adopte le tableau d'app.js** (même référence) et le modifie sur place : app.js continue de lire `S.docs`, aucune copie ne peut diverger, et le retour arrière retrouve exactement les mêmes données. L'écriture physique (localStorage + miroir IndexedDB) reste la fonction `keep` d'app.js ; le magasin décide seulement quand l'appeler. Si le tableau est remplacé « sauvagement », le magasin se resynchronise à l'appel suivant.

## Ne change pas
Format des données et des sauvegardes ; médias `docm_*` (encore écrits par app.js : étape suivante) ; rendu.

## Retour arrière
`window.DreamOSDocumentationHost.release()` (même à chaud, en cours d'usage) ou `?documentation=legacy`.

## Tests (tous OK ici)
`tests/jalon4_1.test.mjs` : 44 800 comparaisons — 800 séquences aléatoires de 14 opérations, hôte absent / engagé / bascule et retour arrière à chaud (données ET écritures identiques) ; magasin (références, une écriture par opération, événements, abonné défaillant) ; propriété dans le registre ; **garde-fou statique** : toute écriture directe sur `S.docs` ou `carnet.docs` hors de la porte unique fait échouer le test. 8 mutations sur 9 détectées (la 9ᵉ est équivalente : `splice` borne déjà l'indice). `phase3_11` adapté.

## À faire de votre côté
`phase2_8_backup_format` et `phase2_8_regression.browser`. Puis : publier un article, le supprimer puis annuler, exporter un ZIP et réimporter, recharger la page (les articles doivent revenir), essayer `?documentation=legacy`.

## Étape suivante : 4.2 médias `docm_*` (écriture des blobs d'articles par le module), puis Library.
