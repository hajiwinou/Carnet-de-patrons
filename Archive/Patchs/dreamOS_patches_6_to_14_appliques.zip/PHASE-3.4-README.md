# dreamOS — Phase 3.4 — Settings : le Theme Manager applique l'apparence
Runtime **3.4.0** · cache Service Worker **atelier-tricot-v14**.
**Première modification d'app.js depuis la 2.7** (petite et additive, voir ci-dessous).

## Ce qui change
Le **calcul et l'application** de l'apparence (variables CSS, `data-theme`, palette dreamOS) passent du moteur historique au Theme Manager. La **donnée** (`S.ui`, clé `carnet.ui`, enregistrement, réglages à l'écran) reste possédée par app.js : une seule autorité d'écriture par ressource.

### Modifications d'app.js (3 points, ~15 lignes)
1. Début de `applyAppearance()` : si `window.DreamOSThemeHost.delegate(u, {wallpaper})` renvoie `true`, la fonction s'arrête ; sinon le code d'origine s'exécute **à l'identique** (host absent, relâché ou en erreur).
2. Le bloc « fond d'écran » est **déplacé tel quel** dans `applyWallpaper(u)` (fonction appelée par le code d'origine et par le host). Aucune ligne de ce bloc n'a changé.
3. Le pont `DreamOSLegacy` gagne `reapplyAppearance()`.

### Nouveaux fichiers
- `dreamOS/theme/theme-host.js` : `engage()`, `release()`, `delegate()`. Bascule enregistrée dans le Module Registry (ressource `dom:appearance` : `legacy` ↔ `themeManager`). **Repli automatique** vers le moteur historique si le Theme Manager lève une erreur (événement `theme:error`).
- `bootstrap.js` : installe le host et l'engage au démarrage.
- Registre de modules : nouveau type de ressource `dom` (Settings possède `dom:appearance`).

## Retour arrière (3 niveaux)
- À chaud, console : `window.DreamOSThemeHost.release()` (le moteur historique ré-applique immédiatement).
- Par l'adresse : ajouter `?theme=legacy` (le host n'est pas engagé).
- Complet : remettre `app.js`, `bootstrap.js`, `sw.js`, `legacy-adapter.js`, `module-registry.js` et `manifest.js` de la 3.3.

## Tests
`tests/phase3_4.test.mjs` exécute le **vrai `applyAppearance()` extrait d'app.js** sur 312 configurations dans trois situations (sans host, host installé non engagé, host engagé) et exige les mêmes variables CSS, attributs, classe `no-wallpaper` et `S.ui` (migration de palette comprise). Il couvre aussi : transfert d'autorité et retour, idempotence d'`engage`, repli sur erreur, garde-fous sur app.js (un seul point d'accès au host, aucun import ES). Vérifié : il échoue si le fond d'écran n'est plus appliqué. Tests 2.1-2.5, précache, 3.1-3.3 relancés : OK.

## Non fait, volontairement
- Les actions d'apparence (`dreamPal`, `setAccent`, `resetColors`…) **ne sont pas revendiquées** par le routeur : elles modifient `S.ui`, état privé d'app.js ; les déplacer créerait une seconde autorité sur `carnet.ui`. Elles seront revendiquées quand la donnée Settings aura migré (jalon 6).
- Verrouillage (PBKDF2), polices chargées, multi-IA : non touchés.

## À faire de votre côté (profil de test, jamais vos vraies données)
1. Recharger : thème, palette, police, fond d'écran identiques à avant.
2. Console : `window.DreamOSThemeHost.enabled` → `true` ; changer de palette dans Réglages : appliquée immédiatement.
3. `window.DreamOSThemeHost.release()` puis `engage()` : aucun changement visible.
4. Hors ligne (installation puis coupure) : thème appliqué ; mise à jour du cache v14.
5. iPhone : mêmes vérifications. Toujours en attente : `npm i jszip playwright-core` et les tests navigateur 2.8.

## Suite : 3.5 Tools (compteur, chronomètre, notes en services à contexte projet explicite)
