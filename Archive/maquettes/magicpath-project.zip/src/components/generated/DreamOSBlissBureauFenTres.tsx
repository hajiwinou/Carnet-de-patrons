import React, { useEffect, useRef, useState } from "react";
import "./DreamOSBlissBureauFenTres.css";
import "./DreamOSWipToolbox.css";
import "./DreamOSToolDashboard.css";
type Counter = {
  id: number;
  name: string;
  value: number;
  target: number;
};
type PanelLayout = {
  x: number;
  y: number;
  width: number;
  height: number;
  visible: boolean;
};
const folders = [{
  name: "Pull",
  count: 18,
  color: "mint",
  icon: "🧶"
}, {
  name: "Écharpe",
  count: 9,
  color: "blue",
  icon: "🧣"
}, {
  name: "Jupe",
  count: 6,
  color: "yellow",
  icon: "🪡"
}, {
  name: "Cardigan",
  count: 12,
  color: "pink",
  icon: "🧥"
}, {
  name: "Accessoires",
  count: 7,
  color: "lavender",
  icon: "🎀"
}, {
  name: "À classer",
  count: 3,
  color: "mint",
  icon: "📁"
}];
const themes = ["Bliss", "Doodle", "Classique 95", "Pixel RPG"];
const initialCounters: Counter[] = [{
  id: 1,
  name: "Corps",
  value: 42,
  target: 120
}, {
  id: 2,
  name: "Manche gauche",
  value: 18,
  target: 64
}, {
  id: 3,
  name: "Manche droite",
  value: 0,
  target: 64
}, {
  id: 4,
  name: "Col",
  value: 6,
  target: 24
}];
const defaultLayout: PanelLayout = {
  x: 22,
  y: 24,
  width: 310,
  height: 430,
  visible: true
};
const pdfs = ["Pull marinière · patron principal", "Gilet Ondine · empiècement", "Notes personnelles · mesures"];
export const DreamOSBlissBureauFenTres = () => {
  const [search, setSearch] = useState("");
  const [openFolder, setOpenFolder] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState("Thèmes");
  const [selectedTheme, setSelectedTheme] = useState("Bliss");
  const [showTools, setShowTools] = useState(false);
  const [activeGlobalTool, setActiveGlobalTool] = useState<string | null>(null);
  const [patternOpen, setPatternOpen] = useState(false);
  const [wipOpen, setWipOpen] = useState(false);
  const [wipTab, setWipTab] = useState<"overview" | "documents" | "tools">("overview");
  const [selectedWipTool, setSelectedWipTool] = useState<string | null>(null);
  const [journalNote, setJournalNote] = useState("");
  const [timerRunning, setTimerRunning] = useState(false);
  const [readerOpen, setReaderOpen] = useState(false);
  const [activeWip, setActiveWip] = useState("Pull marinière — version personnalisée");
  const [activePdf, setActivePdf] = useState(pdfs[0]);
  const [zoom, setZoom] = useState(100);
  const [page, setPage] = useState(3);
  const [counters, setCounters] = useState<Counter[]>(initialCounters);
  const [newCounterName, setNewCounterName] = useState("");
  const [panelLayout, setPanelLayout] = useState<PanelLayout>(defaultLayout);
  const dragRef = useRef<{
    x: number;
    y: number;
    startX: number;
    startY: number;
  } | null>(null);
  const resizeRef = useRef<{
    x: number;
    y: number;
    width: number;
    height: number;
  } | null>(null);
  const filtered = folders.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));
  useEffect(() => {
    try {
      const saved = localStorage.getItem("dreamos-counter-panel:" + activeWip);
      setPanelLayout(saved ? {
        ...defaultLayout,
        ...JSON.parse(saved)
      } : defaultLayout);
      const savedCounters = localStorage.getItem("dreamos-counters:" + activeWip);
      setCounters(savedCounters ? JSON.parse(savedCounters) : initialCounters);
    } catch {
      setPanelLayout(defaultLayout);
      setCounters(initialCounters);
    }
  }, [activeWip]);
  useEffect(() => {
    try {
      localStorage.setItem("dreamos-counter-panel:" + activeWip, JSON.stringify(panelLayout));
    } catch {}
  }, [activeWip, panelLayout]);
  useEffect(() => {
    try {
      localStorage.setItem("dreamos-counters:" + activeWip, JSON.stringify(counters));
    } catch {}
  }, [activeWip, counters]);
  const closeAll = () => {
    setOpenFolder(null);
    setPatternOpen(false);
    setWipOpen(false);
    setReaderOpen(false);
    setShowSettings(false);
  };
  const openPattern = () => {
    setOpenFolder(null);
    setPatternOpen(true);
  };
  const openWip = () => {
    setPatternOpen(false);
    setWipOpen(true);
  };
  const openReader = (pdf = activePdf) => {
    setActivePdf(pdf);
    setWipOpen(false);
    setReaderOpen(true);
  };
  const updateCounter = (id: number, delta: number) => setCounters(items => items.map(c => c.id === id ? {
    ...c,
    value: Math.max(0, c.value + delta)
  } : c));
  const startDrag = (e: React.PointerEvent) => {
    dragRef.current = {
      x: e.clientX,
      y: e.clientY,
      startX: panelLayout.x,
      startY: panelLayout.y
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const moveDrag = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    setPanelLayout(p => ({
      ...p,
      x: Math.max(0, dragRef.current!.startX + e.clientX - dragRef.current!.x),
      y: Math.max(0, dragRef.current!.startY + e.clientY - dragRef.current!.y)
    }));
  };
  const stopDrag = () => {
    dragRef.current = null;
  };
  const startResize = (e: React.PointerEvent) => {
    e.stopPropagation();
    resizeRef.current = {
      x: e.clientX,
      y: e.clientY,
      width: panelLayout.width,
      height: panelLayout.height
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const moveResize = (e: React.PointerEvent) => {
    if (!resizeRef.current) return;
    setPanelLayout(p => ({
      ...p,
      width: Math.max(270, Math.min(520, resizeRef.current!.width + e.clientX - resizeRef.current!.x)),
      height: Math.max(300, Math.min(690, resizeRef.current!.height + e.clientY - resizeRef.current!.y))
    }));
  };
  const stopResize = () => {
    resizeRef.current = null;
  };
  return <main className="dreamos">
    <header className="dreamos-topbar">
      <div className="brand">dreamOS</div>
      <div className="topbar-tools">
        <label className="global-search"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher patrons, projets, fichiers…" /></label>
        <button className="top-tool" onClick={() => setShowTools(v => !v)}>⌘ <span>Outils</span></button>
        <button className="top-tool" onClick={() => {
          setWipOpen(false);
          setReaderOpen(true);
        }}>▤ <span>PDF</span></button>
        <button className="top-tool" onClick={() => setShowSettings(true)}>⚙ <span>Paramètres</span></button>
        <span className="sync-pill"><i /> Synchronisé</span>
      </div>
    </header>
    {showTools && <div className="tool-dashboard-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) {
        setShowTools(false);
        setActiveGlobalTool(null);
      }
    }}>
      <section className="tool-dashboard" role="dialog" aria-modal="true" aria-label="Boîte à outils dreamOS">
        <header className="tool-dashboard-head">
          <div><p className="eyebrow">DREAMOS · ESPACE CRÉATIF</p><h2>Ma boîte à outils</h2><p>Tout le nécessaire pour imaginer, calculer et créer tes projets tricot.</p></div>
          <button className="tool-dashboard-close" onClick={() => {
            setShowTools(false);
            setActiveGlobalTool(null);
          }} aria-label="Fermer la boîte à outils">×</button>
        </header>
        <div className="tool-dashboard-toolbar"><span>TES OUTILS</span><small>7 outils disponibles · 3 modules à venir</small></div>
        <div className="tool-dashboard-grid">
          {[{
            name: "Rangs raccourcis",
            icon: "↪",
            group: "TRICOT",
            desc: "Calcule les rangs raccourcis pour les épaules, le dos ou le col.",
            detail: "Répartition des mailles et instructions selon la méthode choisie."
          }, {
            name: "Convertisseur d’échantillon",
            icon: "▤",
            group: "TRICOT",
            desc: "Adapte un patron à ton propre échantillon.",
            detail: "Compare la gauge du patron à ton échantillon et recalcule les mailles, rangs ou dimensions."
          }, {
            name: "Depuis une photo",
            icon: "✿",
            group: "CRÉATION",
            desc: "Montage et rangs sur mesure à partir d’une photo d’inspiration.",
            detail: "Outil de calcul à partir d’une inspiration photo et des dimensions souhaitées."
          }, {
            name: "Règle de 3",
            icon: "÷",
            group: "CALCULS",
            desc: "Convertis des centimètres en mailles ou en rangs, et inversement.",
            detail: "Entre ta gauge, une mesure ou un nombre de mailles/rangs pour obtenir l’équivalence."
          }, {
            name: "Grilles de points",
            icon: "▦",
            group: "CRÉATION",
            desc: "Dessine des diagrammes : jacquard, dentelle et torsades.",
            detail: "Crée, enregistre et exporte tes grilles de points."
          }, {
            name: "Télécharger une vidéo (Cobalt)",
            icon: "▣",
            group: "RESSOURCES",
            desc: "Récupère une vidéo depuis les plateformes prises en charge par ton serveur Cobalt.",
            detail: "Enregistrement sur l’appareil ou dans Documentation, selon la configuration de Cobalt."
          }, {
            name: "Calculatrice",
            icon: "⌗",
            group: "CALCULS",
            desc: "Additions, pourcentages et calculs rapides.",
            detail: "Calculatrice intégrée, habillée aux couleurs du thème actif."
          }].map(tool => <button key={tool.name} className={"tool-dashboard-card " + (activeGlobalTool === tool.name ? "selected" : "")} onClick={() => setActiveGlobalTool(activeGlobalTool === tool.name ? null : tool.name)}>
            <span className="tool-dashboard-icon">{tool.icon}</span><span className="tool-dashboard-card-copy"><small>{tool.group}</small><b>{tool.name}</b><span>{tool.desc}</span></span><span className="tool-dashboard-arrow">↗</span>
          </button>)}
          {[{
            name: "Laboratoire de teinture",
            icon: "🧶",
            group: "LABORATOIRE",
            desc: "Un espace dédié à la teinture des fils."
          }, {
            name: "Chromatique",
            icon: "◉",
            group: "LABORATOIRE",
            desc: "Explore les couleurs et imagine des combinaisons harmonieuses."
          }, {
            name: "Atelier des fils",
            icon: "✧",
            group: "LABORATOIRE",
            desc: "Gestion de laine, inventaire, liste de souhaits et encyclopédie textile."
          }].map(tool => <article key={tool.name} className="tool-dashboard-card coming">
            <span className="tool-dashboard-icon">{tool.icon}</span><span className="tool-dashboard-card-copy"><small>{tool.group}</small><b>{tool.name}</b><span>{tool.desc}</span></span><span className="tool-coming">À venir</span>
          </article>)}
        </div>
        {activeGlobalTool && <div className="tool-dashboard-detail"><div><small>APERÇU DE L’OUTIL</small><b>{activeGlobalTool}</b><p>{([["Rangs raccourcis", "Répartition des mailles et instructions selon la méthode choisie."], ["Convertisseur d’échantillon", "Compare la gauge du patron à ton échantillon et recalcule les mailles, rangs ou dimensions."], ["Depuis une photo", "Outil de calcul à partir d’une inspiration photo et des dimensions souhaitées."], ["Règle de 3", "Entre ta gauge, une mesure ou un nombre de mailles/rangs pour obtenir l’équivalence."], ["Grilles de points", "Crée, enregistre et exporte tes grilles de points."], ["Télécharger une vidéo (Cobalt)", "Enregistrement sur l’appareil ou dans Documentation, selon la configuration de Cobalt."], ["Calculatrice", "Calculatrice intégrée, habillée aux couleurs du thème actif."]] as [string, string][]).find(x => x[0] === activeGlobalTool)?.[1]}</p><span>La maquette présente l’organisation visuelle ; les outils métier restent ceux de l’application existante.</span></div><button onClick={() => setActiveGlobalTool(null)}>Fermer l’aperçu</button></div>}
        <footer className="tool-dashboard-foot"><span>♡ Les résultats des outils peuvent être ajoutés au journal d’un WIP.</span><span>Les trois laboratoires sont en préparation.</span></footer>
      </section>
    </div>}

    <section className="desktop">
      <div className="page-heading"><div><p className="eyebrow">BIBLIOTHÈQUE PERSONNELLE</p><h1>Mes patrons</h1><p className="muted">Tes patrons, tes idées et tous tes projets réunis au même endroit ♡</p></div><button className="pink-button" onClick={() => setOpenFolder("Nouveau dossier")}>＋ Nouveau dossier</button></div>
      <div className="library-toolbar"><div className="crumb">Bibliothèque <span>›</span> <b>Tous les dossiers</b></div><span className="folder-total">6 dossiers · 55 patrons</span></div>
      <div className="folder-grid">{filtered.map(folder => <button key={folder.name} className="folder-card" onClick={() => setOpenFolder(folder.name)}>
        <div className={"folder-art " + folder.color}><div className="folder-tab" /><span className="folder-emoji">{folder.icon}</span><span className="folder-sticker">♡</span></div>
        <div className="folder-meta"><strong>{folder.name}</strong><span>{folder.count} patrons</span></div><span className="folder-arrow">↗</span>
      </button>)}</div>
      <div className="bottom-hint"><span>✿</span> Ouvre un dossier, puis une fiche patron pour retrouver ses projets associés.</div>
    </section>

    {openFolder && <div className="window-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) setOpenFolder(null);
    }}><section className="os-window folder-window">
      <div className="window-title mint-title"><strong>{openFolder}</strong><div className="window-controls"><button onClick={() => setOpenFolder(null)}>—</button><button onClick={() => setOpenFolder(null)}>□</button><button onClick={() => setOpenFolder(null)}>×</button></div></div>
      <div className="window-content"><div className="crumb">Bibliothèque <span>›</span> {openFolder}</div><h2>{openFolder === "Nouveau dossier" ? "Créer un dossier" : "Les patrons du dossier"}</h2>
        {openFolder === "Nouveau dossier" ? <input className="folder-name-input" placeholder="Nom du dossier…" /> : <div className="pdf-library-grid">
          {[{
              title: openFolder === "Pull" ? "Pull marinière" : openFolder + " torsadé",
              pages: 12,
              tag: "Modifié récemment",
              kind: "sweater"
            }, {
              title: openFolder === "Écharpe" ? "Écharpe nuage" : openFolder + " douceur",
              pages: 8,
              tag: "Ajouté cette semaine",
              kind: "scarf"
            }].map(pdf => <button className="pdf-file-card" key={pdf.title} onClick={openPattern}>
            <span className={"pdf-thumb " + pdf.kind}><span className="pdf-thumb-top"><i /><i /><i /></span><span className="pdf-thumb-title">{pdf.title}</span><span className="pdf-thumb-illustration"><i /><i /><i /><i /><i /><i /><b>✿</b></span><span className="pdf-thumb-lines"><i /><i /><i /><i /></span><span className="pdf-thumb-page">1</span></span>
            <span className="pdf-file-info"><b>{pdf.title}</b><small>PDF · {pdf.pages} pages</small><small>{pdf.tag}</small><small className="open-sheet-hint">Ouvrir la fiche du patron ↗</small></span><span className="pdf-open-arrow">↗</span>
          </button>)}
        </div>}
      </div>
    </section></div>}

    {patternOpen && <div className="window-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) setPatternOpen(false);
    }}><section className="os-window detail-window">
      <div className="window-title blue-title"><strong>Fiche patron · Pull marinière</strong><div className="window-controls"><button onClick={() => setPatternOpen(false)}>—</button><button onClick={() => setPatternOpen(false)}>□</button><button onClick={() => setPatternOpen(false)}>×</button></div></div>
      <div className="window-content">
        <div className="detail-hero"><div className="detail-art">🧶<span>♡</span></div><div><p className="eyebrow">PATRON · PULL</p><h2>Pull marinière</h2><p className="muted">Un pull doux à rayures, col rond et coupe confortable.</p><div className="detail-tags"><span>Intermédiaire</span><span>4 mm</span><span>Laine DK</span></div></div></div>
        <div className="detail-columns"><section className="detail-card"><h3>À propos</h3><p>Notes, tailles, échantillon, fils et aiguilles associés au patron. Les informations du patron restent regroupées dans cette fiche.</p><div className="detail-stats"><span><b>12</b> pages PDF</span><span><b>4</b> photos</span><span><b>3</b> projets liés</span></div></section>
        <section className="detail-card"><h3>Documents du patron</h3><div className="document-row"><span>📄</span><div><b>Pull marinière.pdf</b><small>12 pages · document original</small></div><button onClick={() => openReader(pdfs[0])}>Ouvrir PDF</button></div></section></div>
        <div className="linked-wips"><div className="section-heading"><div><h3>Projets liés à ce patron</h3><p className="muted">Chaque WIP garde ses propres avancées et réglages.</p></div><span className="active-tag">3 projets</span></div>
          {[{
              name: "Pull marinière — version personnalisée",
              status: "En cours",
              progress: "42 / 120 rangs",
              icon: "🧶"
            }, {
              name: "Pull marinière — cadeau",
              status: "En attente",
              progress: "Échantillon",
              icon: "🎁"
            }, {
              name: "Marinière mix & match",
              status: "En cours",
              progress: "2 patrons · 3 PDF",
              icon: "🪡"
            }].map((w, i) => <button className="wip-row" key={w.name} onClick={() => {
              setActiveWip(w.name);
              setWipOpen(true);
              setPatternOpen(false);
            }}><span className="wip-icon">{w.icon}</span><span className="wip-main"><b>{w.name}</b><small>{w.progress}</small></span><span className="wip-status">{w.status}</span><span>↗</span></button>)}
        </div>
      </div>
    </section></div>}

    {wipOpen && <div className="window-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) setWipOpen(false);
    }}><section className="os-window detail-window">
      <div className="window-title mint-title"><strong>Projet WIP · {activeWip}</strong><div className="window-controls"><button onClick={() => setWipOpen(false)}>—</button><button onClick={() => setWipOpen(false)}>□</button><button onClick={() => setWipOpen(false)}>×</button></div></div>
      <div className="window-content wip-sheet-content">
        <div className="wip-overview"><div className="detail-art">🧵</div><div className="wip-heading-copy"><p className="eyebrow">WORK IN PROGRESS</p><h2>{activeWip}</h2><p className="muted">Ton atelier personnel : tout ce qui concerne ce projet, au même endroit.</p><div className="detail-tags"><span>En cours</span><span>Débuté le 12 nov.</span><span>3 documents</span></div></div></div>
        <nav className="wip-tabs" aria-label="Sections du projet">
          <button className={wipTab === "overview" ? "active" : ""} onClick={() => {
              setWipTab("overview");
              setSelectedWipTool(null);
            }}>Vue d’ensemble</button>
          <button className={wipTab === "documents" ? "active" : ""} onClick={() => {
              setWipTab("documents");
              setSelectedWipTool(null);
            }}>Documents <span>3</span></button>
          <button className={wipTab === "tools" ? "active" : ""} onClick={() => {
              setWipTab("tools");
              setSelectedWipTool(null);
            }}>✿ Outils</button>
        </nav>
        {wipTab === "overview" && <>
          <div className="wip-dashboard"><div className="detail-card"><h3>Avancement du projet</h3><strong className="progress-number">35%</strong><div className="progress-track"><i /></div><p className="muted">Tes compteurs et ton suivi restent propres à ce WIP.</p></div><div className="detail-card wip-next-step"><h3>Reprendre mon tricot</h3><p>Retrouve tes documents et tes outils sans perdre le fil.</p><button className="pink-button" onClick={() => openReader(pdfs[0])}>▤ Ouvrir l’atelier PDF</button></div></div>
          <div className="section-heading"><div><h3>Accès rapides</h3><p className="muted">Tes outils les plus utiles pour ce projet.</p></div><button onClick={() => setWipTab("tools")}>Toute la boîte à outils ↗</button></div>
          <div className="wip-tool-grid compact">
            <button className="wip-tool-card" onClick={() => {
                setWipTab("tools");
                setSelectedWipTool("Compteurs");
              }}><span className="wip-tool-icon">🔢</span><b>Compteurs</b><small>{counters.length} compteurs personnalisés</small></button>
            <button className="wip-tool-card" onClick={() => {
                setWipTab("tools");
                setSelectedWipTool("Minuteur");
              }}><span className="wip-tool-icon">⏱️</span><b>Minuteur</b><small>Sessions de tricot</small></button>
            <button className="wip-tool-card" onClick={() => {
                setWipTab("tools");
                setSelectedWipTool("Journal");
              }}><span className="wip-tool-icon">📓</span><b>Journal</b><small>Notes et modifications</small></button>
          </div>
        </>}
        {wipTab === "documents" && <>
          <div className="section-heading"><div><h3>Documents de ce WIP</h3><p className="muted">Plusieurs PDF peuvent appartenir au même projet, même issus de patrons différents.</p></div><span className="active-tag">Multi-PDF</span></div>
          <div className="wip-pdf-list">{pdfs.map((pdf, i) => <div className="wip-pdf-row" key={pdf}><span className="pdf-mini-icon">📄</span><div><b>{pdf}</b><small>{i === 0 ? "Patron lié · 12 pages" : i === 1 ? "Patron complémentaire · 8 pages" : "Document personnel · 3 pages"}</small></div><button className={i === 0 ? "pink-button" : ""} onClick={() => openReader(pdf)}>Ouvrir PDF</button></div>)}</div>
          <div className="detail-footer-actions"><button onClick={() => openReader(pdfs[0])} className="pink-button">▤ Ouvrir l’atelier PDF</button></div>
        </>}
        {wipTab === "tools" && <>
          <div className="toolbox-intro"><div><p className="eyebrow">TON ATELIER PERSONNEL</p><h3>La boîte à outils</h3><p className="muted">Des petits outils pour t’accompagner à chaque étape de ton projet.</p></div><span className="toolbox-sticker">✿</span></div>
          <div className="wip-tool-grid">
            {[{
                name: "Compteurs",
                icon: "🔢",
                desc: "Rangs, répétitions et sections",
                meta: counters.length + " compteurs"
              }, {
                name: "Minuteur",
                icon: "⏱️",
                desc: "Garder une trace de tes sessions",
                meta: "Temps de tricot"
              }, {
                name: "Calculatrice tricot",
                icon: "🧮",
                desc: "Échantillon, mailles et rangs",
                meta: "Calculs pratiques"
              }, {
                name: "Fils & aiguilles",
                icon: "🧶",
                desc: "Tes matières et ton matériel",
                meta: "Stock du projet"
              }, {
                name: "Journal",
                icon: "📓",
                desc: "Tes notes et petites découvertes",
                meta: "Carnet de bord"
              }, {
                name: "Suivi du projet",
                icon: "🌷",
                desc: "Étapes, objectifs et progression",
                meta: "Checklist"
              }].map(tool => <button className={"wip-tool-card " + (selectedWipTool === tool.name ? "chosen" : "")} key={tool.name} onClick={() => setSelectedWipTool(tool.name)}><span className="wip-tool-icon">{tool.icon}</span><span className="wip-tool-copy"><b>{tool.name}</b><small>{tool.desc}</small><em>{tool.meta}</em></span><span className="wip-tool-arrow">↗</span></button>)}
          </div>
          {selectedWipTool && <section className="tool-detail-card">
            <div className="tool-detail-head"><div><p className="eyebrow">OUTIL DU PROJET</p><h3>{selectedWipTool}</h3></div><button onClick={() => setSelectedWipTool(null)}>Fermer ×</button></div>
            {selectedWipTool === "Compteurs" && <><p className="muted">Chaque compteur est indépendant et reste attaché à ce WIP, même lorsque tu changes de PDF.</p><div className="tool-counter-list">{counters.map(c => <div className="tool-counter-row" key={c.id}><b>{c.name}</b><span>{c.value} / {c.target}</span><button onClick={() => updateCounter(c.id, -1)}>−</button><button className="pink-button" onClick={() => updateCounter(c.id, 1)}>+1</button></div>)}</div><button className="pink-button" onClick={() => openReader(pdfs[0])}>Ouvrir les compteurs dans le lecteur PDF</button></>}
            {selectedWipTool === "Minuteur" && <><p className="muted">Lance une session quand tu commences à tricoter. Le temps sera associé à ce projet.</p><div className="tool-timer-face">00:00:00</div><button className="pink-button" onClick={() => setTimerRunning(v => !v)}>{timerRunning ? "Ⅱ Mettre en pause" : "▶ Démarrer une session"}</button><span className="tool-status-note">{timerRunning ? "Session en cours (aperçu prototype)" : "Minuteur en pause"}</span></>}
            {selectedWipTool === "Calculatrice tricot" && <><p className="muted">Un espace pour préparer tes calculs d’échantillon et d’ajustement.</p><div className="tool-calc-preview"><label>Mailles mesurées <input type="number" defaultValue="22" /></label><label>Largeur de l’échantillon (cm) <input type="number" defaultValue="10" /></label><label>Largeur souhaitée (cm) <input type="number" defaultValue="48" /></label></div><span className="tool-status-note">Calculatrice à finaliser — valeurs de démonstration.</span></>}
            {selectedWipTool === "Fils & aiguilles" && <><p className="muted">Le matériel utilisé pour ce WIP, sans modifier la fiche du patron d’origine.</p><div className="tool-material-row"><span>🧶</span><div><b>Laine DK · coloris écru</b><small>Fil principal · 4 pelotes (démo)</small></div></div><div className="tool-material-row"><span>🪡</span><div><b>Aiguilles circulaires 4 mm</b><small>Matériel du projet (démo)</small></div></div><button>＋ Ajouter du matériel</button></>}
            {selectedWipTool === "Journal" && <><p className="muted">Garde ici les changements, idées et petites victoires de ton projet.</p><textarea className="tool-journal-input" value={journalNote} onChange={e => setJournalNote(e.target.value)} placeholder="Une idée, une modification, une note à garder…" /><span className="tool-status-note">Brouillon de démonstration · sauvegarde à connecter.</span></>}
            {selectedWipTool === "Suivi du projet" && <><p className="muted">Visualise les étapes qui te rapprochent du projet terminé.</p><div className="tool-check-row">✓ Échantillon réalisé</div><div className="tool-check-row">✓ Dos terminé</div><div className="tool-check-row">○ Devant à terminer</div><div className="tool-check-row">○ Assembler et rentrer les fils</div><span className="tool-status-note">Étapes de démonstration personnalisables à définir.</span></>}
          </section>}
        </>}
        <div className="detail-footer-actions"><button onClick={() => {
              setWipOpen(false);
              setPatternOpen(true);
            }}>Voir le patron lié</button></div>
      </div>
    </section></div>}

    {showSettings && <div className="window-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) setShowSettings(false);
    }}><section className="os-window settings-window">
      <div className="window-title blue-title"><strong>Paramètres</strong><div className="window-controls"><button onClick={() => setShowSettings(false)}>—</button><button onClick={() => setShowSettings(false)}>□</button><button onClick={() => setShowSettings(false)}>×</button></div></div>
      <div className="settings-layout"><nav className="settings-nav">{["Apparence", "Thèmes", "Polices", "Fond d’écran", "Verrouillage", "Intelligence artificielle", "Sauvegarde"].map(t => <button className={settingsTab === t ? "chosen" : ""} onClick={() => setSettingsTab(t)} key={t}>{t}</button>)}</nav><div className="settings-body"><h2>{settingsTab}</h2><p className="muted">Un thème change l’apparence, jamais le comportement.</p>{settingsTab === "Thèmes" ? <><div className="theme-grid">{themes.map((t, i) => <div className={"theme-card " + (selectedTheme === t ? "selected" : "")} key={t}><b>{t}</b><div className={"swatches swatch-" + i}><i /><i /><i /><i /></div>{selectedTheme === t ? <span className="active-tag">Actif</span> : <button onClick={() => setSelectedTheme(t)}>Choisir</button>}</div>)}</div><h3>Sauvegarde</h3><div className="settings-panel"><button className="pink-button">Exporter une sauvegarde ZIP</button><button>Restaurer</button><p>Les données du projet restent indépendantes de son apparence.</p></div><h3>Verrouillage</h3><div className="settings-panel lock-row">Mot de passe local · masque l’interface, ne protège pas les fichiers <button>Définir</button></div></> : <div className="settings-panel">Options {settingsTab.toLowerCase()} et préférences de dreamOS.</div>}</div></div>
    </section></div>}

    {readerOpen && <div className="window-backdrop reader-backdrop" onMouseDown={e => {
      if (e.target === e.currentTarget) setReaderOpen(false);
    }}><section className="os-window reader-window">
      <div className="window-title mint-title"><strong>Atelier PDF · {activeWip}</strong><div className="window-controls"><button onClick={() => setReaderOpen(false)}>—</button><button onClick={() => setReaderOpen(false)}>□</button><button onClick={() => setReaderOpen(false)}>×</button></div></div>
      <div className="pdf-tabs">{pdfs.map(t => <button className={activePdf === t ? "current" : ""} onClick={() => setActivePdf(t)} key={t}>{t}</button>)}</div>
      <div className="reader-toolbar"><button onClick={() => setPage(p => Math.max(1, p - 1))}>←</button><span>Page <b>{page}</b> / 12</span><button onClick={() => setPage(p => p + 1)}>→</button><span className="toolbar-divider" /><button onClick={() => setZoom(z => Math.max(50, z - 10))}>−</button><span>{zoom}%</span><button onClick={() => setZoom(z => Math.min(200, z + 10))}>＋</button><span className="toolbar-spacer" /><button>Surligner</button><button>Repère</button><button>Note</button><button onClick={() => setPanelLayout(p => ({
            ...p,
            visible: !p.visible
          }))}>{panelLayout.visible ? "Masquer" : "Afficher"} les compteurs</button></div>
      <div className="reader-stage"><div className="pdf-main"><article className="paper"><p className="eyebrow">{activePdf}</p><h2>Épaules</h2><div className="paper-lines"><i /><i /><i /><i /><i /><i /></div><div className="pattern-note"><b>Rang 41 à 48</b><p>Rabattre 4 mailles de chaque côté, puis tricoter droit. Les annotations et repères restent associés à ce document dans le projet.</p></div><div className="paper-lines"><i /><i /><i /><i /></div></article></div>
        {panelLayout.visible && <aside className="floating-counter-panel" style={{
            left: panelLayout.x,
            top: panelLayout.y,
            width: panelLayout.width,
            height: panelLayout.height
          }} onPointerMove={e => {
            if (dragRef.current) moveDrag(e);
            if (resizeRef.current) moveResize(e);
          }} onPointerUp={() => {
            stopDrag();
            stopResize();
          }} onPointerCancel={() => {
            stopDrag();
            stopResize();
          }}>
          <div className="floating-panel-head" onPointerDown={startDrag}><span>✥</span><b>Mes compteurs</b><small>WIP · {activeWip.split(" — ")[0]}</small><button onPointerDown={e => e.stopPropagation()} onClick={() => setPanelLayout(p => ({
                ...p,
                visible: false
              }))}>×</button></div>
          <div className="floating-panel-content">{counters.map(c => <div className="multi-counter" key={c.id}><div className="multi-counter-top"><b>{c.name}</b><small>{c.value} / {c.target}</small></div><div className="counter-progress"><i style={{
                    width: Math.min(100, c.value / c.target * 100) + "%"
                  }} /></div><div className="counter-actions"><button onClick={() => updateCounter(c.id, -1)}>−</button><strong>{c.value}</strong><button className="pink-button" onClick={() => updateCounter(c.id, 1)}>+1</button></div></div>)}
            <div className="add-counter"><input value={newCounterName} onChange={e => setNewCounterName(e.target.value)} placeholder="Nom du compteur…" /><button onClick={() => {
                  if (newCounterName.trim()) {
                    setCounters(c => [...c, {
                      id: Date.now(),
                      name: newCounterName.trim(),
                      value: 0,
                      target: 100
                    }]);
                    setNewCounterName("");
                  }
                }}>＋</button></div>
            <p className="panel-footnote">Ces compteurs appartiennent à ce WIP, pas au PDF.</p>
          </div>
          <div className="panel-resize-handle" onPointerDown={startResize} aria-label="Redimensionner le panneau" />
        </aside>}
      </div>
    </section></div>}

    <footer className="desktop-footer"><span>dreamKnittingOS</span><span>Un petit coin rien qu’à toi ♡</span><span>Bliss · {selectedTheme}</span></footer>
  </main>;
};