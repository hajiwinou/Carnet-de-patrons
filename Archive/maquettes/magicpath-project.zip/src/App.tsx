import { Theme } from './settings/types';
import { DreamOSBlissBureauFenTres } from './components/generated/DreamOSBlissBureauFenTres';

let theme: Theme = 'light';

function App() {
  function setTheme(theme: Theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setTheme(theme);

  return (
    <>
      <DreamOSBlissBureauFenTres />
    </>
  ); // %EXPORT_STATEMENT%
}

export default App;
