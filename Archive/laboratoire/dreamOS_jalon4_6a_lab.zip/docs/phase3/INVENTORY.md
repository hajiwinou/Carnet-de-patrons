# Inventaire app.js (généré — Phase 3.0)

- sha256 : `caa09eb9461e38aa…` · 7023 lignes · 489 déclarations de fonctions (453 de premier niveau)
- Répartition heuristique par plage de lignes (voir `RANGES` dans tools/audit-app.mjs).

| Module cible | Fonctions | Lignes | Appels vers d'autres modules |
|---|---:|---:|---:|
| engine:event-handlers | 2 | 1125 | 182 |
| projects | 99 | 796 | 61 |
| pdf-reader | 45 | 554 | 51 |
| tools | 27 | 539 | 43 |
| patterns:views | 32 | 515 | 36 |
| patterns:fiche-ai | 48 | 483 | 35 |
| service:backup | 31 | 410 | 27 |
| library | 18 | 258 | 28 |
| service:media | 5 | 237 | 0 |
| service:ai | 17 | 234 | 9 |
| service:storage | 13 | 217 | 2 |
| settings | 4 | 211 | 14 |
| core:loader | 4 | 167 | 0 |
| settings:theme | 34 | 167 | 33 |
| patterns:import-pdf | 5 | 163 | 26 |
| patterns:import-text | 8 | 158 | 4 |
| downloads | 14 | 155 | 10 |
| documentation | 6 | 147 | 21 |
| legacy:bridge | 4 | 113 | 20 |
| patterns:delete-folders | 12 | 111 | 11 |
| core:utils | 3 | 76 | 1 |
| settings:lock | 12 | 72 | 2 |
| service:dialogs | 5 | 56 | 5 |
| service:notifications | 5 | 49 | 7 |

## Gestionnaires d'événements globaux
- l.883 `#unlockBtn` · click
- l.884 `#unlockInput` · keydown
- l.1021 `document` · visibilitychange
- l.1105 `#dlg` · click
- l.1106 `document` · keydown
- l.3478 `#vscroll` · pointerdown
- l.3537 `document` · visibilitychange
- l.3612 `#vscroll` · click
- l.4719 `document` · keydown
- l.5052 `document` · keydown
- l.5858 `document` · click
- l.5862 `document` · input
- l.6064 `document` · change
- l.6264 `document` · toggle
- l.6269 `document` · click
- l.6857 `document` · keydown
- l.6866 `document` · dragover
- l.6870 `document` · dragleave
- l.6874 `document` · drop

## Actions du gestionnaire de clic (168 distinctes ; classement heuristique par nom puis par appel, à valider)
- **dialogs** (2) : dlgYes, dlgNo
- **settings** (10) : dreamMin, dreamMax, dreamClose, testAi, dreamPal, setAccent, resetColors, lockNow, fullBackup, zip
- **navigation/engine** (5) : tab, open, back, grp, cancel
- **tools** (10) : toolSub, kcKey, gridSave, gridSaveNew, gridNew, gridOpen, gridDel, gridPng, ctool, cclear
- **downloads** (6) : igGo, igNew, igDevice, igDoc, igPick, igTest
- **projects** (47) : goPj, pjStage, tmToggle, tmReset, tmLog, islandBack, rate, islandReasonsToggle, colorOpen, colorSet, inspoFromIdeas, inspoPickDone, inspoPickCancel, inspoDel, newPj, newProjFor, openPj, pjStep, undoPj, pjRows, pjGoal, pjXSet, pjGoalDrop, devAge, devReset, islandOpen, islandClose, islandAck, pjEditEntry, pjEditCancel, pjEditSave, yarnInc, yarnAdd, yarnDel, pjAddNote, pjDelEntry, pjDelEntryNo, pjDelEntryYes, pjCar, pjPhotoDel, pjCoverDel, patPickOpen, patPickSet, pjDel, pjDelNo, pjDelYes, stage
- **library** (16) : ideaBoard, pinSelMode, pinPick, pinPickAll, pinPickNone, pinBulk, pinBoards, boardNew, boardRen, boardDel, lightbox, lbClose, lbPrev, lbNext, ideaAdd, ideaDel
- **indéterminé** (26) : plannedColorAdd, plannedColorDel, coverPick, rgRun, cell, toggleGrp, collapseAll, expandAll, clearWallpaper, setPw, removePw, copySr, undoStage, fileAuthor, dupOk, chip, paste, favAuth, tnSave, favPat, addF, renSave, viewPdf, addOpt, delPhoto, file
- **documentation** (5) : docFind, docSearch, docToggleEditor, docSave, docDel
- **engine** (12) : fStatus, fStage, bkHide, fDiff, resetFilters, toggleEdit, setActiveSize, tv, renF, renCancel, delAsk, delNo
- **patterns** (18) : undoDel, dupBoth, dupNo, dupBack, dupAllBoth, dupAllNew, dupAllOld, dupKeepOld, dupKeepNew, delF, autoAuthor, autoGarment, aiFill, aiRe, aiVisual, aiPhoto, aiRead, delYes
- **service** (2) : resultPhoto, delOpt
- **pdf-reader** (9) : sub, vclose, vzoomin, vzoomout, vmark, vhl, vsm, pdfNoteClear, pdfNoteSave

## Préfixes d'identifiants média réellement utilisés
`docm_`, `f_`, `ideam_`, `img_`, `pdf_`, `pjc_`, `pji_`, `pjp_`, `t_`, `th_`, `wp_`

## Préfixes d'identifiants métier (`id: 'x' + uid()`)
`d`, `e`, `i`, `j`, `pc`, `sm`, `y`

## Clés carnet.*
- `carnet.ai` (2 occ.)
- `carnet.boards` (2 occ.)
- `carnet.chart` (8 occ.)
- `carnet.collapsed` (2 occ.)
- `carnet.docs` (3 occ.)
- `carnet.favAuthors` (2 occ.)
- `carnet.folders` (3 occ.)
- `carnet.grids` (3 occ.)
- `carnet.group` (2 occ.)
- `carnet.ideas` (2 occ.)
- `carnet.igApi` (2 occ.)
- `carnet.lastBackup` (2 occ.)
- `carnet.migPj` (2 occ.)
- `carnet.opts` (2 occ.)
- `carnet.patterns` (4 occ.)
- `carnet.pjStage` (3 occ.)
- `carnet.projects` (3 occ.)
- `carnet.pwFail` (1 occ.)
- `carnet.pwHash` (4 occ.)
- `carnet.r3` (2 occ.)
- `carnet.rowStep` (2 occ.)
- `carnet.scratchpad` (4 occ.)
- `carnet.theme` (1 occ.)
- `carnet.ts` (4 occ.)
- `carnet.ui` (5 occ.)
- `carnet.vhl.` (2 occ.)
- `carnet.vmark.` (3 occ.)
- `carnet.vpos.` (3 occ.)
- `carnet.vrcMin` (3 occ.)
- `carnet.vrcPos` (6 occ.)
- `carnet.vsm.` (2 occ.)

## Fonctions les plus volumineuses
- `refreshMeta` l.5852 · 1059 lignes · engine:event-handlers
- `resolveLazyMedia` l.242 · 173 lignes · service:media
- `needZip` l.33 · 145 lignes · core:loader
- `viewSettings` l.5132 · 139 lignes · settings
- `keep` l.423 · 138 lignes · service:storage
- `callSingleProvider` l.1405 · 101 lignes · service:ai
- `handleFiles` l.2900 · 97 lignes · patterns:import-pdf
- `lbClose` l.4972 · 88 lignes · library
- `viewToolGauge` l.4140 · 83 lignes · tools
- `vrcAdd` l.3403 · 81 lignes · pdf-reader
- `applyAppearance` l.680 · 80 lignes · settings:theme
- `restoreBackup` l.3961 · 71 lignes · tools
- `viewPjd` l.2281 · 70 lignes · projects
- `render` l.5786 · 66 lignes · engine:event-handlers
- `computeShortRows` l.4032 · 62 lignes · tools

## Fonctions de premier niveau avec le plus d'appels inter-modules
- `refreshMeta` (engine:event-handlers) → completeness, patPickClose, cur, patchFrom, viewFind, patPickFilter, curPj, pjPlannedTotal
- `render` (engine:event-handlers) → syncLockScreen, viewLib, viewAdd, viewDet, viewPj, viewPjd, viewFind, viewFav
- `pinBulk` (library) → toast, askName, boardNameCheck, uid, boardsAppend, ideasPatch, pjStageOf, inspoAddIdeas
- `restoreBackup` (tools) → restoreParts, render, needZip, restoreFull, toast, docsReplace, ideasReplace, boardsReplace
- `restoreFromMirror` (legacy:bridge) → load, keep, projectsReplace, gridsReplace, migrateStages, migratePjV32, persist, checkStorage
- `handleFiles` (patterns:import-pdf) → toast, persist, safetySnapshot, storageFailure, render, saveBlob, newProject, persistNow
- `viewTools` (documentation) → ico, esc, viewToolGauge, viewToolR3, viewToolRag, viewToolChart, viewToolIg, viewToolShortRows
- `restoreFull` (service:backup) → projectsReplace, migratePjV32, saveProjects, gridsReplace, ideasReplace, boardsReplace, toolsSave, saveFolders
- `tryUnlock` (service:notifications) → pwFailGet, pwSupported, checkPw, pwFailSet, hashPw, syncLockScreen, render
- `igToDoc` (tools) → docmNewId, docmSave, docHost, docsAdd, uid, render, toast
- `aiVisual` (patterns:fiche-ai) → getPdf, toast, render, callAI, persist, aiMsg
- `aiPhoto` (patterns:import-pdf) → toast, render, loadBlob, callAI, persist, aiMsg
- `aiRead` (patterns:import-pdf) → getPdf, toast, render, callAI, persist, aiMsg
- `attachPdf` (pdf-reader) → render, pdfOpen, saveBlob, storeThumb, persist, toast
- `vrcAdd` (pdf-reader) → saveProjectsQuiet, dlgOpen, toast, askConfirm, keep, load
