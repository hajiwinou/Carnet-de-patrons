/**
 * dreamOS — PDF Reader Host (Phase 3.10)
 * Transfère les CALCULS PURS du lecteur PDF (numéro de page, formatage des durées, statistiques de rythme, contexte de note,
 * zoom, position du compteur, hauteur du panneau, surcouches de surlignage / repères, position de reprise) au module PDF Reader.
 * Les mesures du DOM sont passées en paramètres. Le DOM, pdf.js, les positions enregistrées (carnet.vpos.*, vhl, vmark, vsm)
 * et le compteur de rangs (propriété de Projects) restent à app.js.
 * app.js consulte window.DreamOSPdfReaderHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createPdfReaderEngine } from './pdf-reader-engine.js';

export const PDF_READER_RESOURCES = Object.freeze([['logic', 'pdf-reader-engine', 'pdf-reader']]);

export function installPdfReaderHost({ moduleRegistry, legacy, eventBus, win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installPdfReaderHost : window requis.');
  if (win.DreamOSPdfReaderHost) return win.DreamOSPdfReaderHost;
  let enabled = false;
  const move = (toOwner) => PDF_READER_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    engine: createPdfReaderEngine(),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('pdf-reader:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('pdf-reader:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSPdfReaderHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSPdfReaderHost;
}
