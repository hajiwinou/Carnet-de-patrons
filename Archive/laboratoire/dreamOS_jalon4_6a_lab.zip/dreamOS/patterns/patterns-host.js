/**
 * dreamOS — Patterns Host (Phase 3.8)
 * Transfère la LOGIQUE PURE de Patterns (moteur extrait d'app.js : nettoyage / découpage du texte, devinettes auteur et
 * vêtement, schéma et complétude de la fiche, application des résultats de l'IA, fusion des grilles et options) au module Patterns.
 * Les DONNÉES (carnet.patterns, carnet.folders…, médias pdf_* / th_* / img_*), l'enregistrement, les dossiers, les doublons,
 * les appels aux fournisseurs d'IA et le rendu restent à app.js : le patron concerné est passé en paramètre et seul cet objet est modifié.
 * app.js consulte window.DreamOSPatternsHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createPatternsEngine } from './patterns-engine.js';

export const PATTERNS_RESOURCES = Object.freeze([['logic', 'patterns-engine', 'patterns']]);

export function installPatternsHost({ moduleRegistry, legacy, eventBus, uid, win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installPatternsHost : window requis.');
  if (win.DreamOSPatternsHost) return win.DreamOSPatternsHost;
  let enabled = false;
  const move = (toOwner) => PATTERNS_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    engine: createPatternsEngine({ uid }),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('patterns:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('patterns:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSPatternsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSPatternsHost;
}
