/**
 * dreamOS — Manifeste des 8 modules métier (Phase 3.1)
 * Généré à partir de l'audit (docs/phase3/INVENTORY.md) puis relu à la main.
 * Aucune ressource n'est encore transférée : tout reste possédé par 'legacy'.
 * Les clés se terminant par * désignent une famille (ex. carnet.vmark.<id>).
 */
export const MODULE_MANIFEST = [
  { name: 'patterns', title: 'Patterns',
    resources: { storage: ['carnet.patterns', 'carnet.ts', 'carnet.folders', 'carnet.favAuthors', 'carnet.collapsed', 'carnet.group'], media: ['pdf_*', 'th_*', 'img_*'] },
    uses: ['storageManager', 'mediaManager', 'aiManager', 'dialogManager', 'notificationManager'],
    notes: 'removePSoft() (réversible) et removeP() (direct) : usages à trancher avant toute fusion.' },
  { name: 'projects', title: 'Projects',
    resources: { storage: ['carnet.projects', 'carnet.pjStage', 'carnet.migPj'], media: ['pjc_*', 'pjp_*', 'pji_*'] },
    uses: ['storageManager', 'mediaManager', 'dialogManager', 'notificationManager'],
    notes: 'Propriétaire du compteur de rangs et du chronomètre (champs du projet). migratePjV32 / migrateStages à conserver. WIP Island déjà présente dans le code (fonctions island*, ~79 lignes) : à préserver.' },
  { name: 'pdf-reader', title: 'PDF Reader',
    resources: { storage: ['carnet.vrcPos', 'carnet.vrcMin', 'carnet.vmark.*', 'carnet.vsm.*', 'carnet.vpos.*', 'carnet.vhl.*'], media: [] },
    uses: ['mediaManager', 'storageManager'],
    notes: 'Invariant : le lecteur n’est jamais propriétaire du compteur (il le pilote via Projects).' },
  { name: 'library', title: 'Library', resources: { storage: ['carnet.ideas', 'carnet.boards'], media: ['ideam_*'] },
    uses: ['storageManager', 'mediaManager'], notes: 'Les inspirations d’un projet (pji_*) restent liées à Projects.' },
  { name: 'documentation', title: 'Documentation', resources: { storage: ['carnet.docs'], media: ['docm_*'] },
    uses: ['storageManager', 'mediaManager'], notes: 'Absente de certaines listes sources : ne pas supprimer par omission.' },
  { name: 'downloads', title: 'Downloads', resources: { storage: ['carnet.igApi'], media: [] },
    uses: ['notificationManager', 'mediaManager'], notes: 'Instagram → MP4 via une API compatible Cobalt (igRequest, l.4214 de app.js) : existence confirmée par l’audit.' },
  { name: 'tools', title: 'Tools', resources: { storage: ['carnet.grids', 'carnet.chart', 'carnet.r3', 'carnet.rowStep', 'carnet.scratchpad'], media: [] },
    uses: ['storageManager', 'notificationManager'], notes: 'Compteur, chronomètre et notes deviennent des services à contexte métier explicite.' },
  { name: 'settings', title: 'Settings', resources: { storage: ['carnet.ui', 'carnet.theme', 'carnet.opts', 'carnet.ai', 'carnet.pwHash', 'carnet.pwFail', 'carnet.lastBackup'], media: ['wp_*'] },
    uses: ['storageManager', 'backupManager', 'aiManager', 'mediaManager', 'dialogManager'],
    notes: 'carnet.ai et carnet.pwHash ne doivent jamais apparaître dans un snapshot ni dans un journal.' }
];
