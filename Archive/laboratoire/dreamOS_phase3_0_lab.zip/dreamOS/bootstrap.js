/**
 * dreamOS — Bootstrap ESM (Phase 2.1)
 *
 * Point d’entrée du futur environnement modulaire.
 * Le moteur historique (app.js / app-late.js) reste chargé séparément
 * et conserve la responsabilité du démarrage métier et des données.
 */
import { createEventBus } from './event-bus.js';
import { createServiceRegistry } from './service-registry.js';
import { createStorageManager } from './storage-manager.js';
import { createMediaManager } from './media-manager.js';
import { createBackupManager } from './backup-manager.js';
import { createAIManager } from './ai/ai-manager.js';
import { createNotificationManager } from './notifications/notification-manager.js';
import { createDialogManager } from './dialogs/dialog-manager.js';
import { createLegacyAdapter } from './legacy-adapter.js';
import { createIdGenerator } from './core/stable-ids.js';
import { createModuleRegistry } from './modules/module-registry.js';
import { MODULE_MANIFEST } from './modules/manifest.js';

const DREAMOS_VERSION = '3.1.0';

function domReady() {
  if (document.readyState !== 'loading') return Promise.resolve();
  return new Promise((resolve) => {
    document.addEventListener('DOMContentLoaded', resolve, { once: true });
  });
}

async function bootstrap() {
  if (window.dreamOS) return window.dreamOS;

  const events = createEventBus();
  const services = createServiceRegistry();

  services.register('eventBus', () => events);
  services.register('serviceRegistry', () => services);
  // Même base, même version et même magasin que le moteur historique.
  // Le service reste paresseux : aucune ouverture ni migration au bootstrap.
  services.register('storageManager', () => createStorageManager());
  // Le MediaManager réutilise le StorageManager historique et reste paresseux.
  services.register('mediaManager', async (registry) =>
    createMediaManager({ storage: await registry.resolve('storageManager') })
  );
  // Le BackupManager contrôle/crée le format ZIP v1 sans remplacer la restauration legacy.
  services.register('backupManager', async (registry) =>
    createBackupManager({ storage: await registry.resolve('storageManager') })
  );
  // AIManager reste indépendant du state privé legacy : la configuration est fournie
  // explicitement à chaque appel, sans copie ni déplacement des clés API.
  services.register('aiManager', () => createAIManager());
  // Les services utilisent les conteneurs historiques #toast et #dlg, sans
  // remplacer les fonctions legacy ; ils ne prennent le contrôle qu'à l'appel.
  services.register('notificationManager', () => createNotificationManager({ eventBus: events }));
  services.register('dialogManager', () => createDialogManager({ eventBus: events }));
  // Phase 3.1 : socle additif. Aucun des deux n'écrit de donnée ni n'est appelé par app.js.
  services.register('idGenerator', () => createIdGenerator());
  services.register('moduleRegistry', () => {
    const registry = createModuleRegistry();
    MODULE_MANIFEST.forEach((descriptor) => registry.declare(descriptor));
    return registry;
  });
  // Pont limité : l'état métier reste détenu par l'IIFE historique.
  const legacy = createLegacyAdapter({ bridge: window.DreamOSLegacy, eventBus: events });
  services.register('legacyAdapter', legacy);

  const runtime = Object.freeze({
    version: DREAMOS_VERSION,
    events,
    services,
    legacy,
    status: 'ready'
  });

  // API additive, en lecture seule au niveau de la propriété globale.
  Object.defineProperty(window, 'dreamOS', {
    configurable: false,
    enumerable: true,
    writable: false,
    value: runtime
  });

  await services.startEager();
  await domReady();

  events.emit('dreamos:ready', {
    version: DREAMOS_VERSION,
    timestamp: Date.now()
  });

  // Simple constat de présence : ce signal ne prétend pas que le boot métier
  // asynchrone du legacy (IndexedDB/restauration/rendu) est terminé.
  const legacyScriptPresent = [...document.scripts].some((script) =>
    /(?:^|\/)app\.js(?:\?|$)/.test(script.getAttribute('src') || '')
  );
  events.emit('dreamos:legacy-script-detected', { present: legacyScriptPresent });
  if (legacyScriptPresent) events.emit('legacy:script-loaded', { status: legacy.status });

  document.dispatchEvent(new CustomEvent('dreamos:ready', {
    detail: { version: DREAMOS_VERSION }
  }));

  return runtime;
}

bootstrap().catch((error) => {
  console.error('[dreamOS] Échec du bootstrap ESM', error);
  document.dispatchEvent(new CustomEvent('dreamos:error', { detail: { error } }));
});
