// Phase 3.1 — identifiants stables, registre des modules, cohérence avec l'audit et avec app.js
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { fileURLToPath } from 'node:url';
import { createIdGenerator } from '../dreamOS/core/stable-ids.js';
import { createModuleRegistry, LEGACY_OWNER } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// --- identifiants : unicité même dans la même milliseconde, format legacy, lecture de la date
const gen = createIdGenerator({ now: () => 1_800_000_000_000 });
const ids = new Set(Array.from({ length: 5000 }, () => gen.next('j')));
assert.equal(ids.size, 5000, 'aucun doublon dans la même milliseconde');
const one = createIdGenerator({ now: () => 1_800_000_000_000, random: () => 0.123456 }).next('y');
assert.match(one, /^y[0-9a-z]{12}$/);
assert.equal(createIdGenerator({ now: () => 1_800_000_000_000 }).createdAt(one, 'y'), 1_800_000_000_000);
const real = createIdGenerator(); const a = real.next(); const b = real.next();
assert.notEqual(a, b); assert.ok(real.isValid(a));
assert.ok(real.isValid('pmgx1a2b3c4d') && real.isValid('jmgx1a2b3c4d'), 'les anciens identifiants restent acceptés');
assert.ok(!real.isValid('') && !real.isValid(null) && !real.isValid('x'));
assert.throws(() => real.next('ABC'), /préfixe/); assert.throws(() => real.next('abcd'), /préfixe/);
assert.ok(Math.abs(real.createdAt(a) - Date.now()) < 5000);

// --- registre : une seule autorité d'écriture
const reg = createModuleRegistry();
MODULE_MANIFEST.forEach((m) => reg.declare(m));
assert.equal(reg.names().length, 8);
assert.throws(() => reg.declare(MODULE_MANIFEST[0]), /déjà déclaré/);
assert.throws(() => createModuleRegistry().declare({ name: 'a', resources: { storage: ['k'] } }).declare({ name: 'b', resources: { storage: ['k'] } }), /déjà revendiquée/);
assert.equal(reg.ownerOf('storage', 'carnet.projects'), LEGACY_OWNER);
assert.equal(reg.moduleOf('storage', 'carnet.vmark.abc'), 'pdf-reader');
assert.equal(reg.moduleOf('media', 'pjp_xyz'), 'projects');
assert.equal(reg.moduleOf('media', 'ideam_xyz'), 'library');
assert.equal(reg.moduleOf('media', 'wp_xyz'), 'settings');
assert.equal(reg.moduleOf('storage', 'carnet.inconnue'), null);
assert.throws(() => reg.transferOwnership('storage', 'carnet.docs', 'autre', 'docsService'), /transfert refusé/);
reg.transferOwnership('storage', 'carnet.docs', LEGACY_OWNER, 'docsService');
assert.equal(reg.ownerOf('storage', 'carnet.docs'), 'docsService');
assert.throws(() => reg.transferOwnership('storage', 'carnet.docs', LEGACY_OWNER, 'autre'), /transfert refusé/, 'pas de double propriétaire');

// --- cohérence avec le code réel : toute clé carnet.* et tout préfixe média utilisés par app.js sont revendiqués
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const fresh = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => fresh.declare(m));
const unclaimed = [...new Set([...app.matchAll(/'(carnet\.[A-Za-z0-9_.]+)'/g)].map((m) => m[1]))]
  .filter((k) => !fresh.moduleOf('storage', k) && !fresh.moduleOf('storage', k.replace(/\.$/, '.x')));
assert.deepEqual(unclaimed, [], `clés carnet.* non revendiquées : ${unclaimed}`);
const PFX = '(?:pdf|img|th|docm|pjc|pjp|pji|wp|ideam)';
const mediaPrefixes = [...new Set([...app.matchAll(new RegExp(`'(${PFX})_'\\s*\\+|NewId\\('(${PFX})_'\\)`, 'g'))].map((m) => `${m[1] || m[2]}_`))];
assert.ok(mediaPrefixes.length >= 8);
for (const p of mediaPrefixes) assert.ok(fresh.moduleOf('media', `${p}x`), `préfixe média non revendiqué : ${p}`);

// --- l'inventaire correspond bien à l'app.js fourni (sinon : relancer node tools/audit-app.mjs)
const inv = JSON.parse(fs.readFileSync(path.join(root, 'docs/phase3/inventory.json'), 'utf8'));
assert.equal(inv.sha256, crypto.createHash('sha256').update(app).digest('hex'), 'inventaire périmé');
assert.ok(!('unclassified' in inv.summary), 'fonction hors plage');

// --- app.js n'utilise PAS les nouveaux services (aucune double autorité)
assert.ok(!/idGenerator|moduleRegistry/.test(app), 'app.js ne doit pas encore dépendre du socle 3.1');
console.log('phase3_1 : OK');
