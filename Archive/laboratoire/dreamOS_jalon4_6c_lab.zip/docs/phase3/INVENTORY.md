# Inventaire app.js (généré — Phase 3.0)

- sha256 : `733a5967b939a9a4…` · 7045 lignes · 511 déclarations de fonctions (475 de premier niveau)
- Répartition heuristique par plage de lignes (voir `RANGES` dans tools/audit-app.mjs).

| Module cible | Fonctions | Lignes | Appels vers d'autres modules |
|---|---:|---:|---:|
| engine:event-handlers | 4 | 1165 | 214 |
| projects | 121 | 823 | 66 |
| tools | 28 | 605 | 62 |
| pdf-reader | 43 | 533 | 55 |
| patterns:views | 30 | 470 | 31 |
| patterns:fiche-ai | 46 | 450 | 28 |
| service:backup | 31 | 385 | 14 |
| library | 21 | 332 | 42 |
| service:media | 5 | 237 | 0 |
| service:ai | 17 | 234 | 9 |
| service:storage | 13 | 217 | 2 |
| settings | 4 | 211 | 14 |
| patterns:import-pdf | 7 | 196 | 33 |
| core:loader | 4 | 167 | 0 |
| settings:theme | 34 | 167 | 33 |
| patterns:import-text | 8 | 158 | 4 |
| downloads | 13 | 116 | 8 |
| legacy:bridge | 4 | 113 | 20 |
| patterns:delete-folders | 12 | 111 | 11 |
| documentation | 5 | 92 | 8 |
| core:utils | 3 | 76 | 1 |
| settings:lock | 12 | 72 | 2 |
| service:dialogs | 5 | 56 | 5 |
| service:notifications | 5 | 49 | 7 |

## Gestionnaires d'événements globaux
- l.883 `#unlockBtn` · click
- l.884 `#unlockInput` · keydown
- l.1021 `document` · visibilitychange
- l.1105 `#dlg` · click
- l.1106 `document` · keydown
- l.3505 `#vscroll` · pointerdown
- l.3564 `document` · visibilitychange
- l.3639 `#vscroll` · click
- l.4746 `document` · keydown
- l.5079 `document` · keydown
- l.5885 `document` · click
- l.5889 `document` · input
- l.6091 `document` · change
- l.6289 `document` · toggle
- l.6294 `document` · click
- l.6879 `document` · keydown
- l.6888 `document` · dragover
- l.6892 `document` · dragleave
- l.6896 `document` · drop

## Actions du gestionnaire de clic (168 distinctes ; classement heuristique par nom puis par appel, à valider)
- **dialogs** (2) : dlgYes, dlgNo
- **settings** (10) : dreamMin, dreamMax, dreamClose, testAi, dreamPal, setAccent, resetColors, lockNow, fullBackup, zip
- **navigation/engine** (5) : tab, open, back, grp, cancel
- **tools** (10) : toolSub, kcKey, gridSave, gridSaveNew, gridNew, gridOpen, gridDel, gridPng, ctool, cclear
- **downloads** (6) : igGo, igNew, igDevice, igDoc, igPick, igTest
- **projects** (47) : goPj, pjStage, tmToggle, tmReset, tmLog, islandBack, rate, islandReasonsToggle, colorOpen, colorSet, inspoFromIdeas, inspoPickDone, inspoPickCancel, inspoDel, newPj, newProjFor, openPj, pjStep, undoPj, pjRows, pjGoal, pjXSet, pjGoalDrop, devAge, devReset, islandOpen, islandClose, islandAck, pjEditEntry, pjEditCancel, pjEditSave, yarnInc, yarnAdd, yarnDel, pjAddNote, pjDelEntry, pjDelEntryNo, pjDelEntryYes, pjCar, pjPhotoDel, pjCoverDel, patPickOpen, patPickSet, pjDel, pjDelNo, pjDelYes, stage
- **library** (16) : ideaBoard, pinSelMode, pinPick, pinPickAll, pinPickNone, pinBulk, pinBoards, boardNew, boardRen, boardDel, lightbox, lbClose, lbPrev, lbNext, ideaAdd, ideaDel
- **indéterminé** (26) : plannedColorAdd, plannedColorDel, coverPick, rgRun, cell, toggleGrp, collapseAll, expandAll, clearWallpaper, setPw, removePw, copySr, undoStage, fileAuthor, dupOk, chip, paste, favAuth, tnSave, favPat, addF, renSave, viewPdf, addOpt, delPhoto, file
- **documentation** (5) : docFind, docSearch, docToggleEditor, docSave, docDel
- **engine** (12) : fStatus, fStage, bkHide, fDiff, resetFilters, toggleEdit, setActiveSize, tv, renF, renCancel, delAsk, delNo
- **patterns** (18) : undoDel, dupBoth, dupNo, dupBack, dupAllBoth, dupAllNew, dupAllOld, dupKeepOld, dupKeepNew, delF, autoAuthor, autoGarment, aiFill, aiRe, aiVisual, aiPhoto, aiRead, delYes
- **service** (2) : resultPhoto, delOpt
- **pdf-reader** (9) : sub, vclose, vzoomin, vzoomout, vmark, vhl, vsm, pdfNoteClear, pdfNoteSave

## Préfixes d'identifiants média réellement utilisés
`docm_`, `f_`, `ideam_`, `img_`, `pdf_`, `t_`, `th_`, `wp_`

## Préfixes d'identifiants métier (`id: 'x' + uid()`)
`d`, `e`, `i`, `j`, `pc`, `sm`, `y`

## Clés carnet.*
- `carnet.ai` (2 occ.)
- `carnet.boards` (2 occ.)
- `carnet.chart` (8 occ.)
- `carnet.collapsed` (2 occ.)
- `carnet.docs` (3 occ.)
- `carnet.favAuthors` (2 occ.)
- `carnet.folders` (3 occ.)
- `carnet.grids` (3 occ.)
- `carnet.group` (2 occ.)
- `carnet.ideas` (2 occ.)
- `carnet.igApi` (2 occ.)
- `carnet.lastBackup` (2 occ.)
- `carnet.migPj` (2 occ.)
- `carnet.opts` (2 occ.)
- `carnet.patterns` (4 occ.)
- `carnet.pjStage` (3 occ.)
- `carnet.projects` (3 occ.)
- `carnet.pwFail` (1 occ.)
- `carnet.pwHash` (4 occ.)
- `carnet.r3` (2 occ.)
- `carnet.rowStep` (2 occ.)
- `carnet.scratchpad` (4 occ.)
- `carnet.theme` (1 occ.)
- `carnet.ts` (4 occ.)
- `carnet.ui` (5 occ.)
- `carnet.vhl.` (2 occ.)
- `carnet.vmark.` (3 occ.)
- `carnet.vpos.` (3 occ.)
- `carnet.vrcMin` (3 occ.)
- `carnet.vrcPos` (6 occ.)
- `carnet.vsm.` (2 occ.)

## Fonctions les plus volumineuses
- `refreshMeta` l.5879 · 1054 lignes · engine:event-handlers
- `resolveLazyMedia` l.242 · 173 lignes · service:media
- `needZip` l.33 · 145 lignes · core:loader
- `viewSettings` l.5159 · 139 lignes · settings
- `keep` l.423 · 138 lignes · service:storage
- `callSingleProvider` l.1405 · 101 lignes · service:ai
- `handleFiles` l.2927 · 97 lignes · patterns:import-pdf
- `lbClose` l.4999 · 88 lignes · library
- `viewToolGauge` l.4167 · 83 lignes · tools
- `vrcAdd` l.3430 · 81 lignes · pdf-reader
- `applyAppearance` l.680 · 80 lignes · settings:theme
- `restoreBackup` l.3988 · 71 lignes · tools
- `viewPjd` l.2308 · 70 lignes · projects
- `render` l.5813 · 66 lignes · engine:event-handlers
- `computeShortRows` l.4059 · 62 lignes · tools

## Fonctions de premier niveau avec le plus d'appels inter-modules
- `refreshMeta` (engine:event-handlers) → completeness, patPickClose, cur, patchFrom, viewFind, patPickFilter, curPj, pjPlannedTotal
- `render` (engine:event-handlers) → syncLockScreen, viewLib, viewAdd, viewPj, viewPjd, viewFind, viewFav, viewTools
- `restoreFull` (tools) → restoreBlobsFrom, mergeById, projectsReplace, migratePjV32, saveProjects, gridsReplace, docsReplace, ideasReplace
- `pinBulk` (library) → toast, askName, boardNameCheck, uid, boardsAppend, ideasPatch, pjStageOf, inspoAddIdeas
- `viewDet` (engine:event-handlers) → cur, viewLib, completeness, esc, statusChip, projectsBlock, projectsOf, ico
- `restoreFromMirror` (legacy:bridge) → load, keep, projectsReplace, gridsReplace, migrateStages, migratePjV32, persist, checkStorage
- `handleFiles` (patterns:import-pdf) → toast, persist, safetySnapshot, storageFailure, render, saveBlob, newProject, persistNow
- `restoreBackup` (tools) → render, needZip, toast, docsReplace, ideasReplace, boardsReplace, toolsSave, uid
- `viewTools` (library) → ico, esc, viewToolGauge, viewToolR3, viewToolRag, viewToolChart, viewToolIg, viewToolCalc
- `tryUnlock` (service:notifications) → pwFailGet, pwSupported, checkPw, pwFailSet, hashPw, syncLockScreen, render
- `igToDoc` (tools) → docmNewId, docmSave, docHost, docsAdd, uid, render, toast
- `aiVisual` (patterns:import-pdf) → getPdf, toast, render, callAI, persist, aiMsg
- `aiPhoto` (patterns:import-pdf) → toast, render, loadBlob, callAI, persist, aiMsg
- `aiRead` (patterns:import-pdf) → getPdf, toast, render, callAI, persist, aiMsg
- `attachPdf` (pdf-reader) → render, pdfOpen, saveBlob, storeThumb, persist, toast
