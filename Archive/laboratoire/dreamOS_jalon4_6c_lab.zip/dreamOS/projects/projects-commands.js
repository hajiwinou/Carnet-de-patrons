/**
 * dreamOS — Projects Commands (Jalon 4.6c)
 * Les MODIFICATIONS du journal, des photos et de la couverture d'un projet, qui étaient écrites en ligne dans app.js, sont ici des
 * commandes nommées, appliquées au projet passé en paramètre (jamais à un état global). Ce sont des transcriptions fidèles du code d'origine :
 * mêmes champs, même ordre, mêmes identifiants (`e` + uid pour une entrée, `i` + uid pour une photo d'inspiration).
 * Elles ne font ni enregistrement, ni suppression de média, ni rendu : app.js enregistre (saveProjects → magasin 4.6a) et supprime les
 * médias (passerelle 4.6b).
 */
export function createProjectsCommands({ uid, now = () => Date.now() } = {}) {
  if (typeof uid !== 'function') throw new TypeError('Projects Commands : uid requis.');
  return Object.freeze({
    /** Ajoute une entrée en tête du journal (texte déjà nettoyé, photos éventuelles). */
    addLogEntry(pr, text, photos) { const e = { id: 'e' + uid(), ts: now(), text: text, photos: photos }; pr.log.unshift(e); return e; },
    /** Ajoute le temps tricoté au journal, marque la reprise du travail et remet le chronomètre à zéro. */
    addTimeEntry(pr, ms, label) { pr.log.unshift({ id: 'e' + uid(), ts: now(), text: label, ms: ms, photos: [] }); pr.workAt = now(); pr.timer = { acc: 0, start: 0 }; },
    ensureTimer(pr) { if (!pr.timer) pr.timer = { acc: 0, start: 0 }; },
    resetTimer(pr) { pr.timer = { acc: 0, start: 0 }; },
    ensurePhotos(pr) { if (!pr.photos) pr.photos = []; },
    ensureInspo(pr) { if (!Array.isArray(pr.inspo)) pr.inspo = []; },
    addPhoto(pr, id) { pr.photos.push(id); },
    /** Nouvelle photo devenue la couverture. */
    addCoverPhoto(pr, id) { if (!pr.photos) pr.photos = []; pr.photos.push(id); pr.cover = id; pr.coverPdf = false; },
    addInspoPhoto(pr, mediaId) { const e = { id: 'i' + uid(), mediaId: mediaId, mediaType: 'image' }; pr.inspo.push(e); return e; },
    /** Rattache une idée de la bibliothèque au tableau d'inspiration (l'idée reste à Library). */
    addInspoIdea(pr, ideaId) { const e = { id: 'i' + uid(), ideaId: ideaId }; pr.inspo.push(e); return e; },
    clearCover(pr) { pr.cover = ''; },
    clearCoverIf(pr, id) { if (pr.cover === id) pr.cover = ''; },
    /** Choix de la couverture : '__auto' (automatique), '__pdf' (page du PDF) ou l'identifiant d'une photo. */
    pickCover(pr, key) {
      if (key === '__auto') { pr.cover = ''; pr.coverPdf = false; }
      else if (key === '__pdf') { pr.coverPdf = true; }
      else { pr.cover = key; pr.coverPdf = false; }
    },
    /** Retire une photo du projet ; la couverture est libérée si c'était elle. Le média est supprimé par l'appelant. */
    removePhoto(pr, id) { if (pr.cover === id) pr.cover = ''; pr.photos = (pr.photos || []).filter(function(x) { return x !== id; }); },
    /** Retire une entrée du journal ; renvoie les photos de l'entrée (à supprimer par l'appelant). */
    removeLogEntry(pr, entryId) {
      const en = pr.log.find(function(x) { return x.id === entryId; });
      let photos = [];
      if (en) { photos = (en.photos || []).slice(); if (pr.cover && (en.photos || []).indexOf(pr.cover) >= 0) pr.cover = ''; }
      pr.log = pr.log.filter(function(x) { return x.id !== entryId; });
      return photos;
    },
    removeInspo(pr, inspoId) { pr.inspo = pr.inspo.filter(function(x) { return x.id !== inspoId; }); },
    /** Marque comme vus les projets de l'« île » (isIsland fourni par l'appelant). */
    ackIsland(projects, isIsland) { projects.forEach(function(x) { if (isIsland(x)) x.islandSeen = true; }); }
  });
}
