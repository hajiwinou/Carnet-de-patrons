/**
 * dreamOS — Projects Host (Phase 3.9)
 * Transfère la LOGIQUE PURE de Projects (étape d'un projet, dernière activité, fils et pelotes prévus / utilisés, plan de couleurs,
 * notes moyennes, nom d'une couleur, raisons du WIP Island, dates) au module Projects.
 * Les DONNÉES (carnet.projects, journal, médias pjc_* / pjp_* / pji_*), l'enregistrement et le rendu restent à app.js :
 * le projet concerné est passé en paramètre. app.js consulte window.DreamOSProjectsHost à chaque appel ;
 * Jalon 4.6a : Projects devient aussi propriétaire de la liste carnet.projects et de son enregistrement, plus de carnet.pjStage et carnet.migPj
 * (projects-store.js ; les champs d'un projet et les médias viennent aux étapes suivantes).
 * Jalon 4.6b : et des médias de projets pjc_* / pjp_* / pji_* (projects-media.js : seule autorité d'écriture et de suppression).
 * Jalon 4.6c : et des commandes de modification du journal, des photos et de la couverture d'un projet (projects-commands.js ;
 * fils, plan de couleurs, objectif, notes et rangs viendront ensuite).
 * absent ou relâché → code historique, à l'identique.
 */
import { createProjectsEngine } from './projects-engine.js';
import { createProjectsStore } from './projects-store.js';
import { createProjectsMedia } from './projects-media.js';
import { createProjectsCommands } from './projects-commands.js';

export const PROJECTS_RESOURCES = Object.freeze([['logic', 'projects-engine', 'projects'], ['storage', 'carnet.projects', 'projects'], ['storage', 'carnet.pjStage', 'projects'], ['storage', 'carnet.migPj', 'projects'], ['media', 'pjc_*', 'projects'], ['media', 'pjp_*', 'projects'], ['media', 'pji_*', 'projects']]);

export function installProjectsHost({ moduleRegistry, legacy, eventBus, uid, now = () => Date.now(), win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installProjectsHost : window requis.');
  if (win.DreamOSProjectsHost) return win.DreamOSProjectsHost;
  let enabled = false;
  const move = (toOwner) => PROJECTS_RESOURCES.forEach(([k, n, o]) => (toOwner ? moduleRegistry?.transferOwnership(k, n, 'legacy', o) : moduleRegistry?.transferOwnership(k, n, o, 'legacy')));
  const host = {
    engine: createProjectsEngine({ uid }),
    store: createProjectsStore({ eventBus }),
    media: createProjectsMedia({ eventBus }),
    commands: createProjectsCommands({ uid, now }),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('projects:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('projects:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSProjectsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSProjectsHost;
}
