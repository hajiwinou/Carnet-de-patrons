# Inventaire app.js (généré — Phase 3.0)

- sha256 : `e0248dd6c25381d9…` · 6933 lignes · 448 déclarations de fonctions (412 de premier niveau)
- Répartition heuristique par plage de lignes (voir `RANGES` dans tools/audit-app.mjs).

| Module cible | Fonctions | Lignes | Appels vers d'autres modules |
|---|---:|---:|---:|
| engine:event-handlers | 1 | 1059 | 141 |
| projects | 96 | 769 | 61 |
| patterns:fiche-ai | 45 | 595 | 36 |
| tools | 30 | 580 | 17 |
| pdf-reader | 48 | 573 | 42 |
| patterns:views | 29 | 546 | 54 |
| service:backup | 25 | 390 | 16 |
| library | 16 | 294 | 26 |
| service:media | 5 | 237 | 0 |
| service:storage | 18 | 230 | 4 |
| service:ai | 9 | 204 | 3 |
| settings | 5 | 174 | 14 |
| patterns:import-text | 8 | 170 | 5 |
| core:loader | 4 | 167 | 0 |
| settings:theme | 6 | 134 | 2 |
| downloads | 15 | 132 | 8 |
| legacy:bridge | 4 | 113 | 13 |
| patterns:delete-folders | 10 | 110 | 9 |
| settings:lock | 14 | 103 | 2 |
| documentation | 6 | 98 | 12 |
| patterns:import-pdf | 3 | 57 | 8 |
| core:utils | 7 | 56 | 0 |
| service:notifications | 1 | 52 | 0 |
| service:dialogs | 5 | 46 | 1 |
| patterns:schema | 2 | 34 | 0 |

## Gestionnaires d'événements globaux
- l.824 `#unlockBtn` · click
- l.825 `#unlockInput` · keydown
- l.962 `document` · visibilitychange
- l.1046 `#dlg` · click
- l.1047 `document` · keydown
- l.3387 `#vscroll` · pointerdown
- l.3446 `document` · visibilitychange
- l.3517 `#vscroll` · click
- l.4629 `document` · keydown
- l.4962 `document` · keydown
- l.5768 `document` · click
- l.5772 `document` · input
- l.5974 `document` · change
- l.6172 `document` · toggle
- l.6177 `document` · click
- l.6767 `document` · keydown
- l.6776 `document` · dragover
- l.6780 `document` · dragleave
- l.6784 `document` · drop

## Actions du gestionnaire de clic (168 distinctes ; classement heuristique par nom puis par appel, à valider)
- **dialogs** (2) : dlgYes, dlgNo
- **settings** (10) : dreamMin, dreamMax, dreamClose, testAi, dreamPal, setAccent, resetColors, lockNow, fullBackup, zip
- **navigation/engine** (5) : tab, open, back, grp, cancel
- **tools** (10) : toolSub, kcKey, gridSave, gridSaveNew, gridNew, gridOpen, gridDel, gridPng, ctool, cclear
- **downloads** (6) : igGo, igNew, igDevice, igDoc, igPick, igTest
- **projects** (47) : goPj, pjStage, tmToggle, tmReset, tmLog, islandBack, rate, islandReasonsToggle, colorOpen, colorSet, inspoFromIdeas, inspoPickDone, inspoPickCancel, inspoDel, newPj, newProjFor, openPj, pjStep, undoPj, pjRows, pjGoal, pjXSet, pjGoalDrop, devAge, devReset, islandOpen, islandClose, islandAck, pjEditEntry, pjEditCancel, pjEditSave, yarnInc, yarnAdd, yarnDel, pjAddNote, pjDelEntry, pjDelEntryNo, pjDelEntryYes, pjCar, pjPhotoDel, pjCoverDel, patPickOpen, patPickSet, pjDel, pjDelNo, pjDelYes, stage
- **library** (16) : ideaBoard, pinSelMode, pinPick, pinPickAll, pinPickNone, pinBulk, pinBoards, boardNew, boardRen, boardDel, lightbox, lbClose, lbPrev, lbNext, ideaAdd, ideaDel
- **indéterminé** (26) : plannedColorAdd, plannedColorDel, coverPick, rgRun, cell, toggleGrp, collapseAll, expandAll, clearWallpaper, setPw, removePw, copySr, undoStage, fileAuthor, dupOk, chip, paste, favAuth, tnSave, favPat, addF, renSave, viewPdf, addOpt, delPhoto, file
- **documentation** (5) : docFind, docSearch, docToggleEditor, docSave, docDel
- **patterns** (30) : fStatus, fStage, undoDel, bkHide, dupBoth, dupNo, dupBack, dupAllBoth, dupAllNew, dupAllOld, dupKeepOld, dupKeepNew, fDiff, resetFilters, toggleEdit, setActiveSize, tv, renF, renCancel, delF, autoAuthor, autoGarment, aiFill, aiRe, aiVisual, aiPhoto, aiRead, delAsk, delNo, delYes
- **service** (2) : resultPhoto, delOpt
- **pdf-reader** (9) : sub, vclose, vzoomin, vzoomout, vmark, vhl, vsm, pdfNoteClear, pdfNoteSave

## Préfixes d'identifiants média réellement utilisés
`docm_`, `f_`, `ideam_`, `img_`, `pdf_`, `pjc_`, `pji_`, `pjp_`, `t_`, `th_`, `wp_`

## Préfixes d'identifiants métier (`id: 'x' + uid()`)
`d`, `e`, `i`, `j`, `pc`, `sm`, `y`

## Clés carnet.*
- `carnet.ai` (2 occ.)
- `carnet.boards` (2 occ.)
- `carnet.chart` (8 occ.)
- `carnet.collapsed` (2 occ.)
- `carnet.docs` (2 occ.)
- `carnet.favAuthors` (2 occ.)
- `carnet.folders` (3 occ.)
- `carnet.grids` (3 occ.)
- `carnet.group` (2 occ.)
- `carnet.ideas` (2 occ.)
- `carnet.igApi` (2 occ.)
- `carnet.lastBackup` (2 occ.)
- `carnet.migPj` (2 occ.)
- `carnet.opts` (2 occ.)
- `carnet.patterns` (4 occ.)
- `carnet.pjStage` (3 occ.)
- `carnet.projects` (4 occ.)
- `carnet.pwFail` (1 occ.)
- `carnet.pwHash` (4 occ.)
- `carnet.r3` (2 occ.)
- `carnet.rowStep` (2 occ.)
- `carnet.scratchpad` (4 occ.)
- `carnet.theme` (1 occ.)
- `carnet.ts` (4 occ.)
- `carnet.ui` (5 occ.)
- `carnet.vhl.` (2 occ.)
- `carnet.vmark.` (3 occ.)
- `carnet.vpos.` (2 occ.)
- `carnet.vrcMin` (3 occ.)
- `carnet.vrcPos` (6 occ.)
- `carnet.vsm.` (2 occ.)

## Fonctions les plus volumineuses
- `refreshMeta` l.5762 · 1059 lignes · engine:event-handlers
- `resolveLazyMedia` l.242 · 173 lignes · service:media
- `needZip` l.33 · 145 lignes · core:loader
- `viewSettings` l.5042 · 139 lignes · settings
- `keep` l.423 · 138 lignes · service:storage
- `callSingleProvider` l.1348 · 101 lignes · service:ai
- `handleFiles` l.2821 · 97 lignes · patterns:fiche-ai
- `lbClose` l.4882 · 88 lignes · library
- `viewToolGauge` l.4046 · 83 lignes · tools
- `vrcAdd` l.3312 · 81 lignes · pdf-reader
- `applyAppearance` l.621 · 80 lignes · settings:theme
- `restoreBackup` l.3867 · 71 lignes · service:backup
- `viewPjd` l.2202 · 70 lignes · projects
- `render` l.5696 · 66 lignes · patterns:views
- `computeShortRows` l.3938 · 62 lignes · tools

## Fonctions de premier niveau avec le plus d'appels inter-modules
- `refreshMeta` (engine:event-handlers) → completeness, patPickClose, cur, patchFrom, viewFind, patPickFilter, curPj, pjPlannedTotal
- `render` (patterns:views) → syncLockScreen, viewPj, viewPjd, viewFind, viewFav, viewTools, viewDocs, viewIdeas
- `pinBulk` (library) → toast, askName, boardNameCheck, uid, saveBoards, saveIdeas, pjStageOf, inspoAddIdeas
- `handleFiles` (patterns:fiche-ai) → toast, persist, safetySnapshot, storageFailure, saveBlob, newProject, persistNow, openP
- `viewSettings` (settings) → provReady, esc, provVision, selected, dreamColorsHtml, genericColorsHtml, statOn, islandCfg
- `restoreFromMirror` (legacy:bridge) → load, keep, migrateStages, migratePjV32, persist, checkStorage, applyAppearance, syncLockScreen
- `vrcAdd` (pdf-reader) → saveProjectsQuiet, dlgOpen, toast, askConfirm, keep, load
- `viewDet` (patterns:views) → cur, esc, statusChip, projectsBlock, projectsOf, ico
- `aiPhoto` (patterns:fiche-ai) → toast, loadBlob, callAI, persist, aiMsg
- `igToDoc` (downloads) → uid, saveBlob, saveDocs, render, toast
- `findHtml` (documentation) → gkey, esc, pjYarnNames, pjStageOf, pinBoardIds
- `addPhotos` (patterns:import-text) → uid, saveBlob, toast, persist
- `viewPjd` (projects) → ico, esc, rowStepX, pjSubHtml
- `analyze` (patterns:fiche-ai) → toast, callAI, persist, aiMsg
- `aiVisual` (patterns:fiche-ai) → toast, callAI, persist, aiMsg
