#!/usr/bin/env node
// Extrait VERBATIM, avec l'analyseur TypeScript, le moteur pur de Patterns depuis app.js (Phase 3.8).
// Usage : node tools/gen-patterns-engine.mjs  → dreamOS/patterns/patterns-engine.js
// Le fichier généré est ensuite versionné : app.js reste la référence tant que le module n'est pas seul propriétaire ;
// tests/phase3_8.test.mjs compare les deux sur des données aléatoires et détecte toute dérive.
import fs from 'node:fs'; import path from 'node:path'; import { createRequire } from 'node:module'; import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url); const ts = require('typescript');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export function collect(text, strip = true) {
const sf = ts.createSourceFile('app.js', text, ts.ScriptTarget.ES2020, true);
let iife = null;
sf.forEachChild((n) => { if (ts.isExpressionStatement(n)) { let e = n.expression; while (ts.isParenthesizedExpression(e) || ts.isCallExpression(e)) e = ts.isParenthesizedExpression(e) ? e.expression : e.expression; if (ts.isFunctionExpression(e)) iife = e; } });
if (!iife) throw new Error('IIFE introuvable');
const CONSTS = ['SIZES', 'MEASURES', 'COUNTS', 'CORE_ROWS', 'GROUPDEF', 'GROUP_NAMES', 'SCHEMA', 'ALLF', 'ABBR', 'HEAD', 'GARMENT_RE'];
const FUNCS = ['cleanText', 'isHeading', 'chunkText', 'guessAuthor', 'guessGarment', 'normAuthor', 'filled', 'completeness', 'checks', 'coerce', 'fieldDef', 'applyAI', 'putGrid', 'applyGrids', 'findOpt', 'applyOptGrids', 'mergeOptions', 'specText', 'groupSpec', 'rowSpec', 'optList'];
const found = new Map(); let allfPopulate = null;
for (const st of iife.body.statements) {
  let src = text.slice(st.getStart(sf), st.end);
  if (strip) src = src.replace(/var ph = patHost\(\); if \(ph\) return ph\.engine\.\w+\([^)]*\);\s*/g, '');
  if (ts.isVariableStatement(st)) { for (const d of st.declarationList.declarations) if (CONSTS.includes(d.name.text)) found.set(d.name.text, { pos: st.getStart(sf), src }); }
  else if (ts.isFunctionDeclaration(st) && FUNCS.includes(st.name.text)) found.set(st.name.text, { pos: st.getStart(sf), src });
  else if (ts.isExpressionStatement(st) && /^ALLF\b|ALLF\.push/.test(src) && src.startsWith('SCHEMA.forEach')) allfPopulate = { pos: st.getStart(sf), src };
}
const missing = [...CONSTS, ...FUNCS].filter((n) => !found.has(n)); if (missing.length || !allfPopulate) throw new Error('éléments introuvables : ' + missing + (allfPopulate ? '' : ' ALLF.populate'));
return { found, ordered: [...found.values(), allfPopulate].sort((a, b) => a.pos - b.pos).map((x) => x.src), FUNCS };
}
export function generate(text) {
const { found, ordered, FUNCS } = collect(text, true);
const items = ordered.map((x) => x.replace(/^var /, 'const ').replace(/^/gm, '  '));
// ALLF est rempli après sa déclaration : le garder en « const » est valide (push), SCHEMA aussi.
const out = `/**
 * dreamOS — Moteur pur de Patterns (Phase 3.8)
 * Extrait VERBATIM d'app.js par tools/gen-patterns-engine.mjs (analyse TypeScript), sans aucune modification de logique :
 * nettoyage et découpage du texte importé, devinettes auteur / vêtement, schéma de la fiche, complétude, contrôles
 * de cohérence, application des données de l'IA, fusion des options et des grilles de tailles.
 * Aucune lecture ni écriture de stockage, de DOM ou d'état : les fonctions reçoivent le patron concerné en paramètre
 * (et modifient cet objet, comme le code historique) ; l'enregistrement et le rendu restent à app.js.
 * Seule dépendance externe : le générateur d'identifiants (uid), injecté.
 */
export function createPatternsEngine({ uid }) {
  if (typeof uid !== 'function') throw new TypeError('createPatternsEngine : uid requis.');
${items.join('\n\n')}

  return Object.freeze({
    SIZES, MEASURES, COUNTS, CORE_ROWS, GROUPDEF, GROUP_NAMES, SCHEMA, ALLF, ABBR, HEAD, GARMENT_RE,
    ${FUNCS.join(', ')}
  });
}
`;
return { out, count: found.size };
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { out, count } = generate(fs.readFileSync(path.join(root, 'app.js'), 'utf8'));
  fs.mkdirSync(path.join(root, 'dreamOS/patterns'), { recursive: true });
  fs.writeFileSync(path.join(root, 'dreamOS/patterns/patterns-engine.js'), out);
  console.log('généré :', out.split('\n').length, 'lignes ;', count, 'éléments');
}
