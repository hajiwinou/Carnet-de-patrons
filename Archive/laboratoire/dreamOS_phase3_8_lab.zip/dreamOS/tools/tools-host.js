/**
 * dreamOS — Tools Host (Phase 3.5)
 * Transfère la LOGIQUE du chronomètre et du compteur de rangs (calculs et mutations du projet fourni) au module Tools.
 * Les DONNÉES (pr.timer, pr.rows, pr.sub…) restent possédées par Projects/app.js, qui continue d'enregistrer et de rendre.
 * app.js consulte window.DreamOSToolsHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 * Ces services ne font que de l'arithmétique sur l'objet projet fourni : pas de repli sur erreur (une exception
 * signalerait une donnée corrompue, que le code historique ne tolérerait pas non plus).
 */
import { createStopwatch } from './stopwatch.js';
import { createRowCounter } from './row-counter.js';

export const TOOLS_RESOURCES = Object.freeze([['logic', 'stopwatch'], ['logic', 'row-counter']]);

export function installToolsHost({ moduleRegistry, legacy, eventBus, win = globalThis.window, now } = {}) {
  if (!win) throw new TypeError('installToolsHost : window requis.');
  if (win.DreamOSToolsHost) return win.DreamOSToolsHost;
  let enabled = false;
  const move = (from, to) => TOOLS_RESOURCES.forEach((r) => moduleRegistry?.transferOwnership(...r, from, to));
  const host = {
    stopwatch: createStopwatch({ now }),
    counter: createRowCounter({ now }),
    engage() {
      if (enabled) return true;
      move('legacy', 'tools'); enabled = true;
      eventBus?.emit('tools:engaged', {}); legacy?.refresh?.();
      return true;
    },
    release() {
      if (!enabled) return true;
      enabled = false; move('tools', 'legacy');
      eventBus?.emit('tools:released', {}); legacy?.refresh?.();
      return true;
    },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSToolsHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSToolsHost;
}
