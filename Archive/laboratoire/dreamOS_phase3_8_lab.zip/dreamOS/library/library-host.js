/**
 * dreamOS — Library Host (Phase 3.6)
 * Transfère la LOGIQUE de recherche, de filtrage des épingles et de filtrage de la documentation aux modules
 * Library / Documentation / Search Manager. Les DONNÉES (carnet.ideas, carnet.boards, carnet.docs, médias ideam_* / docm_*)
 * et tout le rendu HTML restent à app.js. Ces services ne modifient jamais les collections fournies.
 * app.js consulte window.DreamOSLibraryHost à chaque appel ; absent ou relâché → code historique, à l'identique.
 */
import { createSearchManager } from '../search/search-manager.js';
import { createPinLogic } from './pins.js';

export const LIBRARY_RESOURCES = Object.freeze([
  ['logic', 'search', 'searchManager'], ['logic', 'pin-filter', 'library'], ['logic', 'doc-filter', 'documentation']
]);

export function installLibraryHost({ moduleRegistry, legacy, eventBus, win = globalThis.window } = {}) {
  if (!win) throw new TypeError('installLibraryHost : window requis.');
  if (win.DreamOSLibraryHost) return win.DreamOSLibraryHost;
  let enabled = false;
  const move = (toOwner) => LIBRARY_RESOURCES.forEach(([kind, name, owner]) => (toOwner ? moduleRegistry?.transferOwnership(kind, name, 'legacy', owner) : moduleRegistry?.transferOwnership(kind, name, owner, 'legacy')));
  const host = {
    search: createSearchManager(),
    pins: createPinLogic(),
    engage() { if (enabled) return true; move(true); enabled = true; eventBus?.emit('library:engaged', {}); legacy?.refresh?.(); return true; },
    release() { if (!enabled) return true; enabled = false; move(false); eventBus?.emit('library:released', {}); legacy?.refresh?.(); return true; },
    get enabled() { return enabled; }
  };
  Object.defineProperty(win, 'DreamOSLibraryHost', { configurable: true, enumerable: false, writable: false, value: Object.freeze(host) });
  return win.DreamOSLibraryHost;
}
