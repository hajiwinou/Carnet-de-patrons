// Phase 3.6 — Search Manager, Library, Documentation : équivalents au code historique (fuzzing sur le vrai app.js)
import assert from 'node:assert/strict'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { installLibraryHost } from '../dreamOS/library/library-host.js';
import { createModuleRegistry } from '../dreamOS/modules/module-registry.js';
import { MODULE_MANIFEST } from '../dreamOS/modules/manifest.js';
import { EventBus } from '../dreamOS/event-bus.js';
import { normalize } from '../dreamOS/search/search-manager.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const grab = (re, what) => { const m = app.match(re); assert.ok(m, 'introuvable : ' + what); return m[0]; };
const gkeySrc = grab(/  function gkey\(s\)[^\n]*\n/, 'gkey');
const helpers = grab(/  function libHost\(\)[\s\S]*?(?=\n  function pinHtml)/, 'libHost..pinBoardIds') + '\n' + grab(/  function pinsShown\(\) \{[\s\S]*?\n  \}\n/, 'pinsShown');
const findSrc = grab(/  function findHtml\(q\) \{[\s\S]*?(?=\n  function viewFav\(\))/, 'findHtml');
const docSrc = grab(/    function docHit\(post\)[^\n]*\n/, 'docHit');
const build = new Function('S', 'window', 'esc', 'pjStageOf', 'PJ_ONE', 'pjYarnNames', `${gkeySrc}\n${helpers}\n${findSrc}\nvar dq = gkey(S.docQ || '');\n${docSrc}\nreturn { gkey, ideaTags, pinBoardIds, pinsShown, findHtml, docHit, setDq: function() { dq = gkey(S.docQ || ''); } };`);

// données aléatoires
const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
const WORDS = ['laine', 'Mérinos', 'écharpe', 'Côtes', 'torsades', 'bonnet', 'ÉTÉ', 'coton', 'raglan', 'Pull', 'sans couture', 'point mousse', 'mohair', 'Noël'];
function data(seed) {
  const r = rng(seed); const pick = (a) => a[Math.floor(r() * a.length)]; const words = (n) => Array.from({ length: n }, () => pick(WORDS)).join(' ');
  const boards = Array.from({ length: 3 }, (_, i) => ({ id: 'b' + i, name: pick(WORDS) + ' ' + i }));
  return {
    boards,
    patterns: Array.from({ length: 5 + Math.floor(r() * 60) }, (_, i) => ({ id: 'p' + i, title: words(2), f: r() < 0.7 ? { designer: pick(WORDS), garment: pick(WORDS) } : undefined })),
    projects: Array.from({ length: 4 + Math.floor(r() * 40) }, (_, i) => ({ id: 'j' + i, name: words(2), stage: 'wip', log: r() < 0.6 ? [{ text: words(3) }, { id: 'x' }] : undefined, yarns: r() < 0.5 ? [{ name: pick(WORDS), brand: pick(WORDS) }] : [], needles: r() < 0.5 ? pick(['3 mm', '4,5 mm']) : undefined, size: r() < 0.5 ? pick(['M', 'S']) : undefined })),
    ideas: Array.from({ length: 4 + Math.floor(r() * 40) }, (_, i) => ({ id: 'i' + i, title: r() < 0.6 ? words(2) : '', note: r() < 0.5 ? words(2) : '', tag: r() < 0.6 ? pick(['Inspiration', 'Point / Motif', 'Mon tag', 'Étiquette é']) : undefined, boards: r() < 0.7 ? [pick(['b0', 'b1', 'b2', 'zzz']), pick(['b1', 'inconnu'])] : undefined, mediaId: r() < 0.5 ? 'ideam_' + i : undefined })),
    docs: Array.from({ length: 3 + Math.floor(r() * 30) }, (_, i) => ({ id: 'd' + i, title: words(2), content: words(8), category: r() < 0.6 ? pick(['Technique', 'Astuce Tricot']) : undefined }))
  };
}
function world(seed, withHost) {
  const d = data(seed); const S = { ...d, ideaBoard: 'all', ideaTag: 'all', docQ: '' }; const win = {};
  const fns = build(S, win, (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])), (x) => x.stage, { wip: 'En cours' }, (pr) => (pr.yarns || []).map((y) => [y.name, y.brand, y.color].join(' ')).join(' '));
  if (withHost) { const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m)); const h = installLibraryHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win }); h.engage(); assert.equal(reg.ownerOf('logic', 'search'), 'searchManager'); assert.equal(reg.ownerOf('logic', 'pin-filter'), 'library'); assert.equal(reg.ownerOf('logic', 'doc-filter'), 'documentation'); }
  return { S, fns };
}
const QUERIES = ['laine', 'LAINE', 'merinos', 'Mérinos', 'ete', 'été', 'écharpe', 'echarpe', 'côtes', 'point', 'mousse', 'noel', 'x', '', '  ', 'l', 'la', 'zzzzz', 'designer', '3 mm', '4,5', 'M', 'mon tag', 'étiquette', 'b0', 'astuce', 'technique', '<script>', 'sans  couture', '"'];
let checks = 0, big = 0;
for (let seed = 1; seed <= 120; seed++) {
  const a = world(seed, false); const b = world(seed, true);
  const cols = (S) => JSON.stringify({ boards: S.boards, patterns: S.patterns, projects: S.projects, ideas: S.ideas, docs: S.docs }); const snap = cols(b.S);
  for (const q of QUERIES) {
    const ra = a.fns.findHtml(q), rb = b.fns.findHtml(q);
    assert.equal(rb, ra, `findHtml seed ${seed} « ${q} »`); checks++;
    if ((ra.match(/data-act="open"/g) || []).length === 20) big++;
    a.S.docQ = b.S.docQ = q; a.fns.setDq(); b.fns.setDq();
    for (const doc of a.S.docs) assert.equal(b.fns.docHit(doc), a.fns.docHit(doc), `docHit seed ${seed} « ${q} »`);
  }
  assert.ok(cols(b.S) === snap, 'les collections ne sont jamais modifiées');
  assert.deepEqual(b.fns.ideaTags(), a.fns.ideaTags());
  for (const item of a.S.ideas) assert.deepEqual(b.fns.pinBoardIds(b.S.ideas.find((x) => x.id === item.id)), a.fns.pinBoardIds(item));
  for (const board of ['all', 'none', 'b0', 'b1', 'b2', 'zzz']) for (const tag of ['all', 'Inspiration', 'Mon tag', 'Point / Motif', 'inconnu']) {
    a.S.ideaBoard = b.S.ideaBoard = board; a.S.ideaTag = b.S.ideaTag = tag;
    assert.deepEqual(b.fns.pinsShown().map((i) => i.id), a.fns.pinsShown().map((i) => i.id), `pinsShown seed ${seed} ${board}/${tag}`); checks++;
  }
}
assert.ok(big > 20, 'la limite de 20 résultats par groupe est bien exercée');
for (const s of ['É', 'ÀÉÎ  ô', undefined, null, 0, 'Ça  va']) assert.equal(normalize(s), build({}, {}, 0, 0, 0, 0).gkey(s));
// propriété et retour arrière
const reg = createModuleRegistry(); MODULE_MANIFEST.forEach((m) => reg.declare(m));
const host = installLibraryHost({ moduleRegistry: reg, legacy: { refresh() {} }, eventBus: new EventBus(), win: {} });
assert.equal(host.enabled, false); assert.equal(reg.ownerOf('logic', 'search'), 'legacy');
host.engage(); host.release(); assert.equal(reg.ownerOf('logic', 'pin-filter'), 'legacy'); assert.equal(host.enabled, false);
assert.equal((app.match(/DreamOSLibraryHost/g) || []).length, 1);
assert.ok(!/library-host|search-manager|pins\.js/.test(app), 'app.js n’importe aucun module ES');
console.log(`phase3_6 : OK (${checks} comparaisons, ${big} requêtes plafonnées à 20, hôte absent vs engagé)`);
