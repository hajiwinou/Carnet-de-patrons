# dreamOS — Phase 2.5 · Checklist de validation manuelle

## Préparation
- Décompresser cette archive dans un nouveau dossier, sans remplacer l'original.
- Lancer le même serveur HTTP local que pour les phases précédentes.
- Ne pas saisir de clé API dans la console et ne pas modifier `localStorage`.

## Vérifications
- [ ] L'application s'ouvre sans page blanche.
- [ ] `window.dreamOS.version` affiche `2.5.0`.
- [ ] `window.dreamOS.services.names()` contient `aiManager`.
- [ ] `await window.dreamOS.services.resolve('aiManager')` fonctionne.
- [ ] `ai.providers` liste Gemini, Groq, OpenRouter, OpenAI et OmniRoute.
- [ ] Les paramètres IA historiques sont toujours visibles dans Réglages > IA.
- [ ] Les fournisseurs et modèles précédemment configurés sont toujours affichés.
- [ ] Aucun appel IA n'est déclenché automatiquement au démarrage.
- [ ] Les patrons, projets, dossiers, photos et PDF fonctionnent toujours.
- [ ] Après actualisation, les données et paramètres sont toujours présents.

## Console — test sans appel réseau et sans clé API

```javascript
const ai = await window.dreamOS.services.resolve('aiManager');
console.log({ providers: ai.providers, isRunning: ai.isRunning });
```

Résultat attendu : les cinq identifiants dans `providers` et `isRunning: false`.

Ce test ne contacte aucun fournisseur, ne lit pas les clés enregistrées et ne modifie aucune donnée.

## Limites de cette étape
- Le service est ajouté en parallèle ; le moteur historique continue de gérer les analyses IA de l'interface.
- Les clés API restent dans la configuration historique et ne sont ni copiées ni migrées.
- Les appels réels des cinq fournisseurs doivent être vérifiés seulement avec les clés déjà configurées, depuis l'interface historique, si l'utilisateur souhaite effectuer ce test.
- OmniRoute dépend de son adresse de serveur et de sa disponibilité réseau.
