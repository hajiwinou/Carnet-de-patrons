# dreamOS — Phase 2.4 : Backup Manager

## Objectif
Ajouter un service ESM indépendant pour créer et contrôler les archives ZIP du format historique v1, sans remplacer les commandes de sauvegarde/restauration du moteur legacy.

## Changements
- Ajout de `dreamOS/backup-manager.js`.
- Enregistrement paresseux du service `backupManager`.
- Version runtime `2.4.0`.
- Ajout du module au précache du Service Worker.
- Aucune modification de `app.js`, `app-late.js`, IndexedDB, localStorage ou des archives existantes.

## Contrat du service
- `formatVersion` : version prise en charge (1).
- `validateData(data)` : contrôle non destructif du manifeste `data.json`.
- `createArchive(data)` : crée un ZIP v1 avec `data.json`, `blobs/` et `types.json`.
- `inspectArchive(file)` : vérifie le ZIP, le manifeste et la présence des médias référencés ; ne restaure et n'écrit aucune donnée.
- Le ZIP ESM est limité à 200 Mo de médias. Pour les archives plus volumineuses, continuer d'utiliser l'export historique qui sait découper en parties.
- La bibliothèque JSZip est chargée à la demande depuis le même CDN et avec la même empreinte d’intégrité que le moteur historique.

## Tests automatiques
`node --test tests/phase2_1.test.mjs tests/phase2_2.test.mjs tests/phase2_3.test.mjs tests/phase2_4.test.mjs`

## Tests manuels
Voir la checklist de validation dans la conversation. Ne jamais vider le stockage du navigateur ni lancer une restauration pour tester cette phase.
