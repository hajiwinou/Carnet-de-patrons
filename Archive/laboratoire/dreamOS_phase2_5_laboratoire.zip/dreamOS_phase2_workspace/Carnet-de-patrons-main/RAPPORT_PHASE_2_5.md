# Rapport technique — Phase 2.5 · AI Manager

## Changements
- Ajout de `dreamOS/ai/ai-manager.js`, `providers.js`, `ai-errors.js` et des adaptateurs Gemini / OpenAI-compatible.
- Catalogue des cinq fournisseurs et modèles par défaut aligné sur les valeurs identifiées dans le moteur historique.
- Enregistrement singleton `aiManager` dans le Service Registry.
- Version runtime portée à `2.5.0`.
- Dépendances ESM ajoutées au précache du Service Worker.
- Tests automatisés isolés avec adaptateurs simulés ; aucun appel réseau ni aucune clé réelle.

## Compatibilité et limites
- `app.js` et `app-late.js` restent inchangés : les fonctions métier IA historiques ne sont pas encore redirigées vers ce service.
- Aucune clé API n'est déplacée, copiée ou journalisée.
- La configuration est fournie explicitement à `AIManager.generate()` ; le branchement Legacy Adapter sera réalisé dans sa phase dédiée.
- Les appels concurrents sont refusés (un seul appel actif) ; un délai maximal est appliqué.
- Les cinq fournisseurs sont déclarés ; OmniRoute utilise l'adresse passée dans `config.urls.omniroute`.
- Les tests manuels n'utilisent aucune vraie clé. Les appels réels restent à valider par l'utilisateur via l'interface historique.
