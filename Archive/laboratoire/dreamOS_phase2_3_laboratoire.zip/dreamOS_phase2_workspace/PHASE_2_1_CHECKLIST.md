# Phase 2.1 — checklist de validation

À effectuer sur `Carnet-de-patrons-main/`, jamais sur le dossier original.

## Contrôles automatiques déjà exécutés
- [x] Syntaxe ESM de `bootstrap.js`.
- [x] Syntaxe ESM de `event-bus.js`.
- [x] Syntaxe ESM de `service-registry.js`.
- [x] Tests unitaires du bus : abonnement, émission, désabonnement, once.
- [x] Tests unitaires du registre : enregistrement, singleton, résolution asynchrone, doublon.
- [x] Vérification que les scripts legacy sont toujours chargés avant le bootstrap.
- [x] Vérification que les trois modules sont listés dans le cache du service worker.

## Test navigateur sous Windows
1. Décompresser l’archive Phase 2.1 dans un nouveau dossier.
2. Ouvrir PowerShell dans `Carnet-de-patrons-main`.
3. Lancer `py -m http.server 8000`.
4. Ouvrir `http://localhost:8000/` dans le navigateur.
5. Dans les outils de développement, onglet Console, exécuter :
   `window.dreamOS && window.dreamOS.version`
   Résultat attendu : `"2.1.0"`.
6. Exécuter :
   `window.dreamOS.services.names()`
   Résultat attendu : `["eventBus", "serviceRegistry"]`.
7. Vérifier l’onglet Réseau : `bootstrap.js`, `event-bus.js` et `service-registry.js` répondent en 200.
8. Vérifier que l’application historique démarre et que les onglets/vues habituels restent accessibles.
9. Vérifier l’enregistrement du Service Worker. Après rechargement, confirmer que le cache `atelier-tricot-v5` est présent.
10. Si possible, effectuer les scénarios métier de la checklist Phase 2.0 : création/édition/rechargement d’un patron et d’un projet, image, PDF, export et restauration dans un profil de test.

## Résultat du test manuel
- Date :
- Navigateur / version :
- Démarrage legacy :
- Bootstrap ESM :
- Service Worker :
- Scénarios métier :
- Erreurs console :
- Décision : [ ] validé  [ ] corrections nécessaires

## Retour arrière immédiat
Arrêter le serveur local et revenir au dossier/copie Phase 2.0. Ne pas effacer les données du navigateur. Les changements de cette phase sont confinés à la copie de laboratoire.
