/**
 * dreamOS — Media Manager (Phase 2.3)
 * Gestion additive des Blob et des URL temporaires, sans déplacer les données.
 * Les Blob persistants restent dans le magasin IndexedDB historique « blobs ».
 */
export class MediaManager {
  #storage;
  #urlApi;
  #urls = new Map(); // owner -> object URL
  #urlOwners = new Map(); // object URL -> owner
  #disposed = false;

  constructor({ storage, urlApi = globalThis.URL } = {}) {
    if (!storage || typeof storage.get !== 'function' || typeof storage.put !== 'function' || typeof storage.delete !== 'function') {
      throw new TypeError('MediaManager nécessite un StorageManager compatible.');
    }
    if (!urlApi || typeof urlApi.createObjectURL !== 'function' || typeof urlApi.revokeObjectURL !== 'function') {
      throw new TypeError('Les URL temporaires ne sont pas prises en charge dans cet environnement.');
    }
    this.#storage = storage;
    this.#urlApi = urlApi;
  }

  #assertActive() {
    if (this.#disposed) throw new Error('MediaManager est fermé.');
  }

  async save(id, blob) {
    this.#assertActive();
    if (id === undefined || id === null || id === '') throw new TypeError('Un identifiant média est requis.');
    if (!blob || typeof blob !== 'object') throw new TypeError('Un Blob ou objet média est requis.');
    await this.#storage.put(id, blob);
    this.revokeOwner(id);
    return id;
  }

  async load(id) {
    this.#assertActive();
    if (id === undefined || id === null || id === '') return null;
    const value = await this.#storage.get(id);
    return value === undefined ? null : value;
  }

  async remove(id) {
    this.#assertActive();
    if (id === undefined || id === null || id === '') throw new TypeError('Un identifiant média est requis.');
    this.revokeOwner(id);
    await this.#storage.delete(id);
    return id;
  }

  createObjectURL(blob, owner = Symbol('media')) {
    this.#assertActive();
    if (!blob || typeof blob !== 'object') throw new TypeError('Un Blob ou objet média est requis.');
    this.revokeOwner(owner);
    const url = this.#urlApi.createObjectURL(blob);
    this.#urls.set(owner, url);
    this.#urlOwners.set(url, owner);
    return url;
  }

  async getObjectURL(id) {
    this.#assertActive();
    if (id === undefined || id === null || id === '') return '';
    if (this.#urls.has(id)) return this.#urls.get(id);
    const blob = await this.load(id);
    return blob ? this.createObjectURL(blob, id) : '';
  }

  revokeObjectURL(url) {
    if (!url || !this.#urlOwners.has(url)) return false;
    const owner = this.#urlOwners.get(url);
    this.#urlOwners.delete(url);
    if (this.#urls.get(owner) === url) this.#urls.delete(owner);
    this.#urlApi.revokeObjectURL(url);
    return true;
  }

  revokeOwner(owner) {
    const url = this.#urls.get(owner);
    return url ? this.revokeObjectURL(url) : false;
  }

  revokeAll() {
    for (const url of [...this.#urlOwners.keys()]) this.revokeObjectURL(url);
  }

  get activeURLCount() {
    return this.#urlOwners.size;
  }

  dispose() {
    if (this.#disposed) return;
    this.revokeAll();
    this.#disposed = true;
  }
}

export function createMediaManager(options) {
  return new MediaManager(options);
}
