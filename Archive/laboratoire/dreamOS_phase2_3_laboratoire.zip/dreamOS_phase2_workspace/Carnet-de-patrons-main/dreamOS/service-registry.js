/**
 * dreamOS — Service Registry (Phase 2.1)
 * Registre léger de services singleton. Aucun service legacy n’est remplacé.
 */
export class ServiceRegistry {
  #definitions = new Map();
  #instances = new Map();

  register(name, factory, options = {}) {
    if (typeof name !== 'string' || !name.trim()) {
      throw new TypeError('Le nom du service doit être une chaîne non vide.');
    }
    if (typeof factory !== 'function' && (factory === null || typeof factory !== 'object')) {
      throw new TypeError('Le service doit être une fabrique ou un objet.');
    }
    if (this.#definitions.has(name)) {
      throw new Error(`Le service "${name}" est déjà enregistré.`);
    }

    this.#definitions.set(name, {
      factory,
      eager: options.eager === true
    });
    return this;
  }

  has(name) {
    return this.#definitions.has(name);
  }

  get(name) {
    if (this.#instances.has(name)) return this.#instances.get(name);
    const definition = this.#definitions.get(name);
    if (!definition) throw new Error(`Service inconnu : "${name}".`);

    const instance = typeof definition.factory === 'function'
      ? definition.factory(this)
      : definition.factory;

    if (instance && typeof instance.then === 'function') {
      throw new TypeError(`La fabrique "${name}" est asynchrone ; utiliser resolve().`);
    }
    this.#instances.set(name, instance);
    return instance;
  }

  async resolve(name) {
    if (this.#instances.has(name)) return this.#instances.get(name);
    const definition = this.#definitions.get(name);
    if (!definition) throw new Error(`Service inconnu : "${name}".`);

    const instance = typeof definition.factory === 'function'
      ? await definition.factory(this)
      : definition.factory;
    this.#instances.set(name, instance);
    return instance;
  }

  async startEager() {
    for (const [name, definition] of this.#definitions) {
      if (definition.eager) await this.resolve(name);
    }
    return this;
  }

  async dispose() {
    const instances = [...this.#instances.values()].reverse();
    this.#instances.clear();
    for (const instance of instances) {
      if (instance && typeof instance.dispose === 'function') {
        await instance.dispose();
      } else if (instance && typeof instance.stop === 'function') {
        await instance.stop();
      }
    }
  }

  names() {
    return [...this.#definitions.keys()];
  }
}

export function createServiceRegistry() {
  return new ServiceRegistry();
}
