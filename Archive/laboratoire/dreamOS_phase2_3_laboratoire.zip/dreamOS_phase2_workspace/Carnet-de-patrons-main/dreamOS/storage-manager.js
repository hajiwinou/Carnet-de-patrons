/**
 * dreamOS — Storage Manager (Phase 2.2)
 * Couche IndexedDB additive : elle reprend la base historique sans migration.
 * Les valeurs sont conservées telles quelles (Blob, chaînes JSON, objets clonables…).
 */

const DEFAULT_DATABASE = 'carnet_patrons_db';
const DEFAULT_VERSION = 1;
const DEFAULT_STORE = 'blobs';

function makeError(message, cause) {
  const error = new Error(message);
  if (cause !== undefined) error.cause = cause;
  return error;
}

export class StorageManager {
  #indexedDB;
  #databaseName;
  #version;
  #storeName;
  #db = null;
  #opening = null;
  #disposed = false;

  constructor({
    indexedDB = globalThis.indexedDB,
    databaseName = DEFAULT_DATABASE,
    version = DEFAULT_VERSION,
    storeName = DEFAULT_STORE
  } = {}) {
    if (typeof databaseName !== 'string' || !databaseName.trim()) {
      throw new TypeError('Le nom de la base IndexedDB doit être une chaîne non vide.');
    }
    if (!Number.isInteger(version) || version < 1) {
      throw new TypeError('La version IndexedDB doit être un entier positif.');
    }
    if (typeof storeName !== 'string' || !storeName.trim()) {
      throw new TypeError('Le nom du magasin IndexedDB doit être une chaîne non vide.');
    }

    this.#indexedDB = indexedDB;
    this.#databaseName = databaseName;
    this.#version = version;
    this.#storeName = storeName;
  }

  open() {
    if (this.#disposed) return Promise.reject(new Error('StorageManager est fermé.'));
    if (this.#db) return Promise.resolve(this.#db);
    if (this.#opening) return this.#opening;
    if (!this.#indexedDB || typeof this.#indexedDB.open !== 'function') {
      return Promise.reject(new Error('IndexedDB non supporté dans cet environnement.'));
    }

    this.#opening = new Promise((resolve, reject) => {
      let request;
      let settled = false;
      const fail = (error) => {
        if (settled) return;
        settled = true;
        this.#opening = null;
        reject(error instanceof Error ? error : makeError('Ouverture IndexedDB impossible.', error));
      };

      try {
        request = this.#indexedDB.open(this.#databaseName, this.#version);
      } catch (error) {
        fail(makeError('Ouverture IndexedDB impossible.', error));
        return;
      }

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.#storeName)) {
          db.createObjectStore(this.#storeName);
        }
      };
      request.onsuccess = (event) => {
        const db = event.target.result;
        if (settled || this.#disposed) {
          db.close();
          return;
        }
        settled = true;
        this.#opening = null;
        this.#db = db;
        db.onversionchange = () => {
          db.close();
          if (this.#db === db) this.#db = null;
        };
        resolve(db);
      };
      request.onerror = () => fail(makeError('Erreur lors de l’ouverture IndexedDB.', request.error));
      request.onblocked = () => fail(makeError('Ouverture IndexedDB bloquée par une autre connexion.'));
    });

    return this.#opening;
  }

  async #run(mode, operation, resultFromRequest) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      let transaction;
      let request;
      let result;
      let settled = false;
      const fail = (error) => {
        if (settled) return;
        settled = true;
        reject(error instanceof Error ? error : makeError('Transaction IndexedDB échouée.', error));
      };

      try {
        transaction = db.transaction(this.#storeName, mode);
        const store = transaction.objectStore(this.#storeName);
        request = operation(store);
      } catch (error) {
        fail(makeError('Impossible de démarrer la transaction IndexedDB.', error));
        return;
      }

      if (request && resultFromRequest) {
        request.onsuccess = () => { result = resultFromRequest(request); };
        request.onerror = () => fail(makeError('Requête IndexedDB échouée.', request.error));
      }
      transaction.oncomplete = () => {
        if (settled) return;
        settled = true;
        resolve(result);
      };
      transaction.onerror = () => fail(makeError('Transaction IndexedDB échouée.', transaction.error));
      transaction.onabort = () => fail(makeError('Transaction IndexedDB interrompue.', transaction.error));
    });
  }

  async get(key) {
    if (key === undefined || key === null) throw new TypeError('Une clé de stockage est requise.');
    return this.#run('readonly', (store) => store.get(key), (request) => request.result);
  }

  async has(key) {
    if (key === undefined || key === null) throw new TypeError('Une clé de stockage est requise.');
    return this.#run('readonly', (store) =>
      typeof store.getKey === 'function' ? store.getKey(key) : store.get(key),
      (request) => request.result !== undefined
    );
  }

  async put(key, value) {
    if (key === undefined || key === null) throw new TypeError('Une clé de stockage est requise.');
    await this.#run('readwrite', (store) => store.put(value, key));
    return key;
  }

  async delete(key) {
    if (key === undefined || key === null) throw new TypeError('Une clé de stockage est requise.');
    await this.#run('readwrite', (store) => store.delete(key));
    return key;
  }

  async keys() {
    return this.#run('readonly', (store) => store.getAllKeys(), (request) => request.result || []);
  }

  close() {
    if (this.#db) this.#db.close();
    this.#db = null;
    this.#opening = null;
  }

  dispose() {
    this.close();
    this.#disposed = true;
  }
}

export function createStorageManager(options) {
  return new StorageManager(options);
}
