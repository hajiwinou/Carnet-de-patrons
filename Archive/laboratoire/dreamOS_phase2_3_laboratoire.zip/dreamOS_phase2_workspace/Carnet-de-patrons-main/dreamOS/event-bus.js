/**
 * dreamOS — Event Bus (Phase 2.1)
 * Communication locale, synchrone et indépendante du moteur historique.
 */
export class EventBus {
  #listeners = new Map();

  on(eventName, listener) {
    if (typeof eventName !== 'string' || !eventName.trim()) {
      throw new TypeError('Le nom de l’événement doit être une chaîne non vide.');
    }
    if (typeof listener !== 'function') {
      throw new TypeError('Le listener doit être une fonction.');
    }

    const listeners = this.#listeners.get(eventName) || new Set();
    listeners.add(listener);
    this.#listeners.set(eventName, listeners);

    let active = true;
    return () => {
      if (!active) return;
      active = false;
      this.off(eventName, listener);
    };
  }

  once(eventName, listener) {
    let unsubscribe;
    unsubscribe = this.on(eventName, (payload) => {
      unsubscribe();
      listener(payload);
    });
    return unsubscribe;
  }

  off(eventName, listener) {
    const listeners = this.#listeners.get(eventName);
    if (!listeners) return false;
    const removed = listeners.delete(listener);
    if (listeners.size === 0) this.#listeners.delete(eventName);
    return removed;
  }

  emit(eventName, payload) {
    const listeners = this.#listeners.get(eventName);
    if (!listeners) return 0;

    // Copie défensive : un listener peut se désabonner pendant l’émission.
    const snapshot = [...listeners];
    for (const listener of snapshot) {
      try {
        listener(payload);
      } catch (error) {
        // Une extension ne doit pas empêcher les autres abonnés de recevoir l’événement.
        console.error(`[dreamOS] Erreur dans le listener "${eventName}"`, error);
      }
    }
    return snapshot.length;
  }

  listenerCount(eventName) {
    return this.#listeners.get(eventName)?.size || 0;
  }

  clear(eventName) {
    if (typeof eventName === 'string') {
      this.#listeners.delete(eventName);
      return;
    }
    this.#listeners.clear();
  }
}

export function createEventBus() {
  return new EventBus();
}
