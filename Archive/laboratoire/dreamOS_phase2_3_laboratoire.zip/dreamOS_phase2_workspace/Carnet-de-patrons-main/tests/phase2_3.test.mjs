import assert from 'node:assert/strict';
import { MediaManager } from '../dreamOS/media-manager.js';

const records = new Map();
const storage = {
  async put(id, value) { records.set(id, value); return id; },
  async get(id) { return records.get(id); },
  async delete(id) { records.delete(id); return id; }
};
let nextUrl = 0;
const revoked = [];
const urlApi = {
  createObjectURL(blob) { assert.ok(blob); return `blob:test-${++nextUrl}`; },
  revokeObjectURL(url) { revoked.push(url); }
};
const media = new MediaManager({ storage, urlApi });
const blob = { type: 'image/jpeg', size: 3 };

assert.equal(await media.save('photo_1', blob), 'photo_1');
assert.equal(await media.load('photo_1'), blob);
assert.equal(await media.load('missing'), null);

const url1 = await media.getObjectURL('photo_1');
assert.equal(url1, 'blob:test-1');
assert.equal(await media.getObjectURL('photo_1'), url1, 'une URL existante doit être réutilisée');
assert.equal(media.activeURLCount, 1);

const url2 = media.createObjectURL({ type: 'application/pdf' }, 'preview');
assert.equal(url2, 'blob:test-2');
assert.equal(media.activeURLCount, 2);
assert.equal(media.revokeOwner('preview'), true);
assert.deepEqual(revoked, [url2]);
assert.equal(media.activeURLCount, 1);

const url3 = media.createObjectURL(blob, 'photo_1');
assert.equal(url3, 'blob:test-3');
assert.deepEqual(revoked, [url2, url1], 'remplacer une URL propriétaire révoque l’ancienne');
assert.equal(media.activeURLCount, 1);

await media.remove('photo_1');
assert.equal(records.has('photo_1'), false);
assert.equal(media.activeURLCount, 0);
assert.deepEqual(revoked, [url2, url1, url3]);

media.dispose();
assert.throws(() => media.createObjectURL(blob), /fermé/);
media.dispose();

assert.throws(() => new MediaManager({ storage: {}, urlApi }), /StorageManager/);
assert.throws(() => new MediaManager({ storage, urlApi: {} }), /URL temporaires/);
console.log('Phase 2.3 : tests MediaManager réussis.');
