import assert from 'node:assert/strict';
import { EventBus } from '../dreamOS/event-bus.js';
import { ServiceRegistry } from '../dreamOS/service-registry.js';

const bus = new EventBus();
let received = 0;
const unsubscribe = bus.on('sample', (value) => { received += value; });
assert.equal(bus.emit('sample', 2), 1);
assert.equal(received, 2);
unsubscribe();
assert.equal(bus.emit('sample', 3), 0);
assert.equal(received, 2);

let onceCount = 0;
bus.once('one-time', () => { onceCount += 1; });
bus.emit('one-time');
bus.emit('one-time');
assert.equal(onceCount, 1);

const registry = new ServiceRegistry();
let constructions = 0;
registry.register('counter', () => ({ id: ++constructions }));
assert.equal(registry.get('counter'), registry.get('counter'));
assert.equal(constructions, 1);

registry.register('async-value', async () => ({ ready: true }));
assert.deepEqual(await registry.resolve('async-value'), { ready: true });
assert.throws(() => registry.register('counter', () => ({})), /déjà enregistré/);
assert.deepEqual(registry.names(), ['counter', 'async-value']);

console.log('Phase 2.1 : tous les tests unitaires sont réussis.');
