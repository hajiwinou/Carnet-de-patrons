import assert from 'node:assert/strict';
import { StorageManager } from '../dreamOS/storage-manager.js';

function createFakeIndexedDB() {
  const records = new Map();
  let openCalls = 0;
  let closeCalls = 0;
  const storeNames = new Set();
  const db = {
    objectStoreNames: { contains: (name) => storeNames.has(name) },
    createObjectStore(name) { storeNames.add(name); },
    transaction(name, mode) {
      assert.equal(name, 'blobs');
      const tx = { error: null };
      const store = {
        get(key) { return makeRequest(tx, () => records.get(key)); },
        getKey(key) { return makeRequest(tx, () => records.has(key) ? key : undefined); },
        put(value, key) { return makeRequest(tx, () => { records.set(key, value); return key; }); },
        delete(key) { return makeRequest(tx, () => records.delete(key)); },
        getAllKeys() { return makeRequest(tx, () => [...records.keys()]); }
      };
      tx.objectStore = () => store;
      return tx;
    },
    close() { closeCalls += 1; }
  };

  function makeRequest(transaction, read) {
    const request = { transaction };
    queueMicrotask(() => {
      try {
        request.result = read();
        request.onsuccess?.();
      } catch (error) {
        request.error = error;
        request.onerror?.();
      }
      // Simule la fin de transaction après l'événement de requête.
      queueMicrotask(() => request.transaction?.oncomplete?.());
    });
    return request;
  }

  return {
    stats: () => ({ openCalls, closeCalls }),
    open(name, version) {
      openCalls += 1;
      assert.equal(name, 'carnet_patrons_db');
      assert.equal(version, 1);
      const request = {};
      queueMicrotask(() => {
        if (!storeNames.has('blobs')) {
          request.onupgradeneeded?.({ target: { result: db } });
        }
        request.result = db;
        request.onsuccess?.({ target: { result: db } });
      });
      return request;
    }
  };
}

// Une seule ouverture partagée même si plusieurs opérations démarrent ensemble.
const fake = createFakeIndexedDB();
const storage = new StorageManager({ indexedDB: fake });
await Promise.all([storage.open(), storage.open(), storage.open()]);
assert.equal(fake.stats().openCalls, 1);

const blobLike = { type: 'application/pdf', bytes: [1, 2, 3] };
assert.equal(await storage.put('pdf_demo', blobLike), 'pdf_demo');
assert.deepEqual(await storage.get('pdf_demo'), blobLike);
assert.equal(await storage.has('pdf_demo'), true);
assert.equal(await storage.get('missing'), undefined);
assert.equal(await storage.has('missing'), false);
assert.deepEqual(await storage.keys(), ['pdf_demo']);
assert.equal(await storage.delete('pdf_demo'), 'pdf_demo');
assert.equal(await storage.has('pdf_demo'), false);

storage.close();
assert.equal(fake.stats().closeCalls, 1);
await storage.open();
storage.dispose();
await assert.rejects(storage.open(), /fermé/);

const unsupported = new StorageManager({ indexedDB: null });
await assert.rejects(unsupported.open(), /non supporté/);

console.log('Phase 2.2 : tests StorageManager réussis.');
