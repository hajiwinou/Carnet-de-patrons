# Checklist manuelle — Phase 2.3

Utiliser une copie fraîche de l'archive. Ne pas supprimer les données du navigateur.

- [ ] L'application s'ouvre sans page blanche.
- [ ] La console affiche `window.dreamOS.version` → `"2.3.0"`.
- [ ] `window.dreamOS.services.names()` contient `"mediaManager"`.
- [ ] Le service se résout sans erreur :

```js
const media = await window.dreamOS.services.resolve('mediaManager');
```

- [ ] Le service annonce zéro URL temporaire au départ :

```js
media.activeURLCount
```

Résultat attendu : `0` (si aucun test de média n'a encore été effectué dans cette session).

- [ ] Les patrons et leurs photos s'affichent.
- [ ] Les PDF et autres documents s'ouvrent.
- [ ] Les projets, dossiers et onglets fonctionnent toujours.
- [ ] Après actualisation, les données sont toujours présentes.

À la fin, ne pas appeler `media.dispose()` pendant que l'application tourne : cela fermerait le service de cette session. Le service de phase 2.3 est ajouté en parallèle et le moteur historique conserve sa gestion actuelle des URL.
