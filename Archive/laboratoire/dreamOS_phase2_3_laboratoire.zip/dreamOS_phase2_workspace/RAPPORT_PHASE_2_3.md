# dreamOS — Phase 2.3 : Media Manager

## Objectif
Ajouter un service ESM de gestion des médias et du cycle de vie des URL temporaires, sans modifier le moteur métier historique ni déplacer les données.

## Changements
- Ajout de `dreamOS/media-manager.js`.
- Enregistrement paresseux du service `mediaManager` dans `dreamOS/bootstrap.js`.
- Version runtime portée à `2.3.0`.
- Ajout du module au précache du Service Worker.
- Ajout de `tests/phase2_3.test.mjs`.

## Contrat
- Les médias persistants restent dans `carnet_patrons_db`, magasin `blobs`, via `StorageManager`.
- `save`, `load` et `remove` délèguent au stockage existant.
- `getObjectURL` crée une URL temporaire réutilisable par identifiant.
- `revokeOwner`, `revokeObjectURL`, `revokeAll` et `dispose` assurent la révocation explicite.
- Le service est additif : le code legacy continue d'utiliser ses fonctions actuelles. Aucun appel legacy n'est redirigé dans cette phase.

## Validation automatisée
Lancer depuis la racine du projet :

```sh
node tests/phase2_1.test.mjs
node tests/phase2_2.test.mjs
node tests/phase2_3.test.mjs
node --check app.js
node --check app-late.js
```

## Validation manuelle
Voir `PHASE_2_3_CHECKLIST.md`. Ne pas vider le stockage du navigateur et conserver le dossier de la phase précédente comme sauvegarde.
