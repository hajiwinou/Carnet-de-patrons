# Rapport de clôture — Phase 2.1 (préparation technique)

## Résultat
Infrastructure ESM ajoutée à la copie de laboratoire :
- `dreamOS/bootstrap.js`
- `dreamOS/event-bus.js`
- `dreamOS/service-registry.js`

Intégration minimale :
- `index.html` : ajout d’un seul script module après `app.js` et `app-late.js`.
- `sw.js` : cache versionné `atelier-tricot-v5` et ajout des trois modules à la liste hors-ligne.
- `tests/phase2_1.test.mjs` : tests unitaires reproductibles.

## Vérifications exécutées
- Node.js utilisé : v22.16.0.
- Syntaxe ESM : 3/3 fichiers valides (`node --input-type=module --check`).
- Tests unitaires : réussis (EventBus et ServiceRegistry).
- Ordre de chargement : les deux scripts historiques restent avant le bootstrap.
- Modifications Git : limitées à `index.html`, `sw.js` et aux nouveaux dossiers `dreamOS/` et `tests/`.

## Limite importante
Aucun navigateur n’a été piloté dans cet environnement. Le démarrage réel de l’application, la console, le Service Worker et les parcours métier restent à valider manuellement avec `PHASE_2_1_CHECKLIST.md` et la checklist Phase 2.0. La Phase 2.1 est donc préparée et testée statiquement, mais pas déclarée validée fonctionnellement.

## Préservation
- `app.js` et `app-late.js` inchangés.
- Aucun code de données métier, stockage local ou IndexedDB modifié.
- Les fichiers d’origine de la Phase 2.0 et le dépôt Git sont conservés dans l’archive.
