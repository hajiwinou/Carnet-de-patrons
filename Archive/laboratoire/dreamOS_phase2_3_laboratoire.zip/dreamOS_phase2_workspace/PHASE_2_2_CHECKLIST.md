# Phase 2.2 — checklist de validation navigateur

À effectuer dans le dossier de laboratoire Phase 2.2, jamais dans le dossier original.

## Tests automatiques déjà exécutés
- [x] Syntaxe ESM du Storage Manager.
- [x] Ouverture IndexedDB partagée entre appels concurrents.
- [x] Écriture puis lecture d'une valeur.
- [x] Différenciation d'une clé absente.
- [x] Vérification d'existence et liste des clés.
- [x] Suppression et fermeture.
- [x] Gestion du cas IndexedDB indisponible.
- [x] Tests de Phase 2.1 toujours réussis.

## Test navigateur (lecture seule sur les données existantes)
1. Décompresser l'archive dans un nouveau dossier.
2. Ouvrir PowerShell dans `Carnet-de-patrons-main` et lancer `py -m http.server 8000`.
3. Ouvrir `http://localhost:8000/` et attendre le chargement complet de l'application.
4. Dans la console, vérifier `window.dreamOS.version` : résultat attendu `2.2.0`.
5. Vérifier `window.dreamOS.services.names()` : la liste doit maintenant aussi contenir `storageManager`.
6. Exécuter le test de lecture ci-dessous. Il ne modifie aucune donnée :

```js
const storage = await window.dreamOS.services.resolve('storageManager');
const keys = await storage.keys();
({ database: 'carnet_patrons_db', version: 1, keyCount: keys.length, hasPatternMirror: keys.includes('meta_patterns') });
```

7. Fermer proprement la connexion :

```js
storage.close();
```

8. Vérifier visuellement que les patrons, projets, dossiers, photos et PDF habituels sont toujours présents et ouvrables.
9. Recharger la page et vérifier une nouvelle fois les données.
10. Vérifier l'absence d'erreur rouge dans la console.

## Important
- Ne pas lancer de test `put`, `delete` ou de restauration sur la base contenant les vraies données.
- Ne pas effacer le stockage du navigateur.
- Si une erreur apparaît, arrêter le test et transmettre le message exact.

## Résultat manuel
- Navigateur / version :
- `storageManager` visible :
- Lecture IndexedDB réussie :
- `meta_patterns` présent (si des patrons sont enregistrés) :
- Patrons / projets / médias toujours accessibles :
- Erreurs console :
- Décision : [ ] validé  [ ] corrections nécessaires

## Retour arrière
Arrêter le serveur et revenir au dossier Phase 2.1. Ne pas supprimer les données du navigateur.
