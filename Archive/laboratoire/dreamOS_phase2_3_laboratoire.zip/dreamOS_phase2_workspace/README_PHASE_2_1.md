# dreamOS — Phase 2.1 : infrastructure ESM

## Objectif
Introduire un socle ESM isolé et additif, sans réécrire le moteur historique.

## Fichiers créés
- `Carnet-de-patrons-main/dreamOS/bootstrap.js` : point d’entrée ESM, expose `window.dreamOS`.
- `Carnet-de-patrons-main/dreamOS/event-bus.js` : bus d’événements local (`on`, `once`, `off`, `emit`).
- `Carnet-de-patrons-main/dreamOS/service-registry.js` : registre de services singleton (`register`, `get`, `resolve`, `dispose`).

## Intégration minimale
- `index.html` charge `app.js`, puis `app-late.js`, puis le bootstrap en `type="module"`.
- `sw.js` met en cache les trois nouveaux modules et utilise le cache `atelier-tricot-v5`.
- Aucun import ESM n’a été ajouté dans `app.js` ou `app-late.js`.
- Le bootstrap émet `dreamos:ready` et `dreamos:legacy-script-detected`. Ce dernier indique uniquement que la balise `app.js` est présente ; il ne signifie pas que la restauration IndexedDB et le rendu legacy sont terminés.

## Garanties et limites
- Aucun code métier legacy n’a été remplacé.
- Aucun schéma, stockage, donnée utilisateur ou clé API n’a été modifié.
- Les trois modules ne lisent ni n’écrivent dans `localStorage` ou IndexedDB.
- La validation automatique couvre la syntaxe et les contrats unitaires des modules. Elle ne remplace pas un essai réel dans un navigateur.
- La validation fonctionnelle Phase 2.0 étant encore marquée comme à effectuer dans le rapport fourni, elle doit être confirmée séparément sur la copie laboratoire.

## Retour arrière
Fermer l’application, puis restaurer la copie Phase 2.0 complète. Ne pas supprimer les caches navigateur ou les données du site pour effectuer le retour arrière : ce n’est pas nécessaire. La copie Phase 2.0 d’origine reste intacte dans cette archive de travail.
