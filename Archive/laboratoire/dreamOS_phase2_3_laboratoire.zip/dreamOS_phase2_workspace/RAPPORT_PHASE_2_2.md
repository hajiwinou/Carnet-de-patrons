# Rapport de préparation — Phase 2.2 (Storage Manager)

## Résultat
Ajout d'un service IndexedDB indépendant et paresseux :
- `dreamOS/storage-manager.js`
- Enregistrement dans le Service Registry sous `storageManager`.
- Ajout du module au précache du Service Worker et passage du cache à `atelier-tricot-v6`.
- Tests unitaires dans `tests/phase2_2.test.mjs`.

## Compatibilité de stockage
Le service cible exactement la base historique `carnet_patrons_db`, version `1`, magasin `blobs`.
Aucune nouvelle base, aucun changement de version, aucune suppression et aucune migration de données.
Les valeurs IndexedDB sont conservées telles quelles, y compris les Blob et les chaînes JSON utilisées par le moteur historique.

## API
- `open()` : ouvre la base et partage une ouverture concurrente.
- `get(key)` : lit une valeur ; renvoie `undefined` si la clé n'existe pas.
- `has(key)` : vérifie l'existence de la clé.
- `put(key, value)` : écrit une valeur et attend la fin de transaction.
- `delete(key)` : supprime une clé et attend la fin de transaction ; les erreurs sont propagées.
- `keys()` : retourne les clés du magasin.
- `close()` / `dispose()` : ferme la connexion.

## Préservation
- `app.js` et `app-late.js` restent inchangés.
- Les clés `carnet.*`, `meta_*`, les Blob et les sauvegardes existantes ne sont pas réécrits par cette phase.
- Le service n'est pas ouvert automatiquement au démarrage ; il est disponible via `window.dreamOS.services.resolve('storageManager')`.

## Vérifications automatiques
- Syntaxe ESM de `storage-manager.js` et `bootstrap.js`.
- Tests Phase 2.1 conservés.
- Tests Storage Manager : ouverture partagée, écriture/lecture, existence, lecture absente, liste des clés, suppression, fermeture et IndexedDB indisponible.

## Limite
Le test avec le navigateur et la base réelle reste à effectuer manuellement avec `PHASE_2_2_CHECKLIST.md`. La Phase 2.2 n'est pas déclarée validée avant ce contrôle.
