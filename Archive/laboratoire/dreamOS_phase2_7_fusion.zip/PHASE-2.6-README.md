# dreamOS — Phase 2.6 — Notes de laboratoire

Version : 2.6.0
Base : archive validée Phase 2.5

## Ajouts
- `dreamOS/notifications/notification-manager.js` : NotificationManager (success/error/warning/info/show/dismiss).
- `dreamOS/dialogs/dialog-manager.js` : DialogManager (confirm/alert/prompt/close), gestion Escape, Entrée, focus trap et restauration du focus.
- Enregistrement `notificationManager` et `dialogManager` dans le Service Registry.
- Service Worker `atelier-tricot-v7` avec les deux nouveaux modules dans le précache.

## Compatibilité
- `app.js` et `app-late.js` sont conservés sans modification.
- Les conteneurs HTML historiques `#toast` et `#dlg` sont réutilisés.
- Les services ne sont pas raccordés automatiquement aux fonctions métier legacy : aucune double écriture ni remplacement des gestionnaires historiques.
- Aucune donnée utilisateur, clé API ou configuration n'est modifiée.

## Test manuel
Voir la checklist de la Phase 2.6 fournie dans la conversation. Les méthodes de dialogue doivent être testées en interaction utilisateur ; ne pas lancer de confirmation destructive sur des données réelles.
