/**
 * dreamOS — Legacy Adapter (Phase 2.7)
 * Interface contrôlée vers le moteur historique : aucune référence à son état privé.
 */
export class LegacyAdapter {
  constructor({ bridge, eventBus } = {}) {
    if (!bridge || typeof bridge.getStateSnapshot !== 'function' || !bridge.ready) {
      throw new Error('Le pont DreamOSLegacy est absent ou incomplet.');
    }
    this.#bridge = bridge;
    this.#eventBus = eventBus || null;
    this.ready = Promise.resolve(bridge.ready).then((result) => {
      this.#eventBus?.emit('legacy:ready', {
        status: result?.status || bridge.status || 'ready'
      });
      return this;
    });
    this.ready.catch((error) => {
      this.#eventBus?.emit('legacy:error', { message: error?.message || String(error) });
    });
  }

  #bridge;
  #eventBus;

  get status() {
    return this.#bridge.status;
  }

  getStateSnapshot() {
    return this.#bridge.getStateSnapshot();
  }

  refresh() {
    return this.#bridge.refresh();
  }

  notify(message) {
    return this.#bridge.notify(message);
  }

  dispose() {
    // Le moteur historique appartient à l'application : l'adapter ne le détruit pas.
  }
}

export function createLegacyAdapter(options) {
  return new LegacyAdapter(options);
}
