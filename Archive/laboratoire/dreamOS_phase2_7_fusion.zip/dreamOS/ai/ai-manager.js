import { AI_PROVIDERS, PROVIDER_IDS } from './providers.js';
import { AIServiceError } from './ai-errors.js';
import { createGeminiAdapter } from './adapters/gemini.js';
import { createOpenAICompatibleAdapter } from './adapters/openai-compatible.js';

function omniChatEndpoint(value) {
  let url = String(value || '').trim().replace(/\/+$/, '');
  if (!url) return '';
  if (!/^https?:\/\//i.test(url)) url = (/^(localhost|127\.|192\.168\.|10\.)/i.test(url) ? 'http://' : 'https://') + url;
  if (/\/chat\/completions$/i.test(url)) return url;
  if (!/\/v1$/i.test(url)) url += '/v1';
  return url + '/chat/completions';
}
function parseJsonBlock(value) {
  const clean = String(value).trim().replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
  const start = clean.indexOf('{'); const end = clean.lastIndexOf('}');
  return JSON.parse(start >= 0 && end > start ? clean.slice(start, end + 1) : clean);
}
export class AIManager {
  #adapters; #timeoutMs; #active = 0; #disposed = false; #fetchImpl;
  constructor({ adapters = {}, timeoutMs = 90000, maxConcurrent = 1, fetchImpl = globalThis.fetch } = {}) {
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('timeoutMs doit être positif.');
    if (maxConcurrent !== 1) throw new TypeError('Cette première version limite volontairement les appels IA à un seul à la fois.');
    this.#timeoutMs = timeoutMs;
    this.#fetchImpl = fetchImpl;
    this.#adapters = {
      gemini: adapters.gemini || createGeminiAdapter(fetchImpl),
      groq: adapters.groq || createOpenAICompatibleAdapter({ id: 'groq', endpoint: 'https://api.groq.com/openai/v1/chat/completions', fetchImpl }),
      openrouter: adapters.openrouter || createOpenAICompatibleAdapter({ id: 'openrouter', endpoint: 'https://openrouter.ai/api/v1/chat/completions', fetchImpl }),
      openai: adapters.openai || createOpenAICompatibleAdapter({ id: 'openai', endpoint: 'https://api.openai.com/v1/chat/completions', fetchImpl }),
      omniroute: adapters.omniroute || null
    };
    if (adapters.omniroute) this.#adapters.omniroute = adapters.omniroute;
  }
  get providers() { return PROVIDER_IDS; }
  get isRunning() { return this.#active > 0; }
  async generate(request, config = {}) {
    if (this.#disposed) throw new AIServiceError('AIManager est fermé.', { code: 'disposed' });
    if (this.#active) throw new AIServiceError('Une requête IA est déjà en cours.', { code: 'busy' });
    if (!request || typeof request.prompt !== 'string' || !request.prompt.trim()) throw new TypeError('Une consigne IA est requise.');
    this.#active++;
    const images = Array.isArray(request.images) ? request.images : [];
    const preferred = images.length ? config.prefVision : config.prefText;
    const ready = (id) => id === 'omniroute' ? !!String(config.urls?.omniroute || '').trim() : !!String(config.keys?.[id] || '').trim();
    const supportsVision = (id) => id === 'groq' ? false : id === 'omniroute' ? config.omniVision !== false : AI_PROVIDERS[id].vision;
    const queue = [];
    if (PROVIDER_IDS.includes(preferred) && ready(preferred) && (!images.length || supportsVision(preferred))) queue.push(preferred);
    if (config.autoFailover !== false || !queue.length) for (const id of PROVIDER_IDS) if (!queue.includes(id) && ready(id) && (!images.length || supportsVision(id))) queue.push(id);
    if (!queue.length) { this.#active--; throw new AIServiceError(images.length ? 'Aucun fournisseur vision configuré.' : 'Aucun fournisseur IA configuré.', { code: 'missing_config' }); }
    const controller = new AbortController();
    const external = request.signal;
    const abort = () => controller.abort(external?.reason);
    if (external?.aborted) abort(); else external?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(() => controller.abort(new DOMException('Délai dépassé', 'TimeoutError')), this.#timeoutMs);
    let lastError;
    try {
      for (const id of queue) {
        if (controller.signal.aborted) throw new AIServiceError('Requête annulée ou délai dépassé.', { code: 'cancelled', provider: id });
        let adapter = this.#adapters[id];
        if (id === 'omniroute' && !adapter) {
          const endpoint = omniChatEndpoint(config.urls?.omniroute);
          if (endpoint) adapter = createOpenAICompatibleAdapter({ id: 'omniroute', endpoint, fetchImpl: this.#fetchImpl || globalThis.fetch });
        }
        if (!adapter || typeof adapter.generate !== 'function') { lastError = new AIServiceError(`Adaptateur ${id} indisponible.`, { code: 'adapter_unavailable', provider: id }); continue; }
        try {
          const raw = await adapter.generate({ ...request, images, signal: controller.signal }, config);
          return { data: request.json ? (typeof raw === 'string' ? parseJsonBlock(raw) : raw) : raw, provider: AI_PROVIDERS[id].name, providerId: id };
        } catch (error) {
          if (error?.name === 'AbortError' || controller.signal.aborted) throw new AIServiceError('Requête annulée ou délai dépassé.', { code: 'cancelled', provider: id });
          lastError = error;
        }
      }
      throw lastError || new AIServiceError('Tous les fournisseurs configurés ont échoué.');
    } finally {
      clearTimeout(timer); external?.removeEventListener('abort', abort); this.#active--;
    }
  }
  async testConnection(config = {}, providerId) {
    if (providerId) return this.generate({ prompt: 'Réponds uniquement par le mot OK.' }, { ...config, prefText: providerId, autoFailover: false });
    throw new TypeError('Indiquez le fournisseur à tester.');
  }
  dispose() { this.#disposed = true; }
}
export function createAIManager(options) { return new AIManager(options); }
