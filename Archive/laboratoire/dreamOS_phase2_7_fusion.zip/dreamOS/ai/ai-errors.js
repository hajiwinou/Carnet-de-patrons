/** Erreurs normalisées : ne jamais inclure les clés API dans les messages. */
export class AIServiceError extends Error {
  constructor(message, { code = 'provider_error', status, provider, cause } = {}) {
    super(message, cause ? { cause } : undefined);
    this.name = 'AIServiceError';
    this.code = code;
    if (status !== undefined) this.status = status;
    if (provider) this.provider = provider;
  }
}
export function safeProviderMessage(message, apiKey) {
  let value = String(message || 'Erreur du fournisseur IA');
  if (apiKey) value = value.split(apiKey).join('[clé masquée]');
  return value.slice(0, 500);
}
