/** Catalogue public des fournisseurs historiques dreamOS. Aucune clé n'est stockée ici. */
export const AI_PROVIDERS = Object.freeze({
  gemini: Object.freeze({ id: 'gemini', name: 'Google Gemini', model: 'gemini-2.5-flash', vision: true }),
  groq: Object.freeze({ id: 'groq', name: 'Groq (Llama 3.3 70B)', model: 'llama-3.3-70b-versatile', vision: false }),
  openrouter: Object.freeze({ id: 'openrouter', name: 'OpenRouter', model: 'google/gemini-2.0-flash-exp:free', vision: true }),
  openai: Object.freeze({ id: 'openai', name: 'OpenAI', model: 'gpt-4o-mini', vision: true }),
  omniroute: Object.freeze({ id: 'omniroute', name: 'OmniRoute', model: 'auto', vision: true })
});
export const PROVIDER_IDS = Object.freeze(Object.keys(AI_PROVIDERS));
