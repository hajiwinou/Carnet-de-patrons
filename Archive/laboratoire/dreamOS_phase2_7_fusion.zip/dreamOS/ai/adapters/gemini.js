import { AIServiceError, safeProviderMessage } from '../ai-errors.js';
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new AIServiceError('Lecture du média impossible.', { code: 'media_read' }));
    reader.readAsDataURL(blob);
  });
}
export function createGeminiAdapter(fetchImpl = globalThis.fetch) {
  return { async generate(request, config) {
    const key = String(config.keys?.gemini || '').trim();
    const model = String(config.models?.gemini || 'gemini-2.5-flash').trim();
    if (!key) throw new AIServiceError('Clé API non configurée.', { code: 'no_key', provider: 'gemini' });
    const parts = [{ text: String(request.prompt || '') }];
    for (const blob of request.images || []) {
      if (!(blob instanceof Blob)) throw new AIServiceError('Image invalide.', { code: 'invalid_media', provider: 'gemini' });
      parts.push({ inlineData: { mimeType: blob.type || 'image/jpeg', data: await blobToBase64(blob) } });
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    const response = await fetchImpl(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify({ contents: [{ role: 'user', parts }], ...(request.json ? { generationConfig: { responseMimeType: 'application/json' } } : {}) }), signal: request.signal });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new AIServiceError(safeProviderMessage(data?.error?.message || `Erreur HTTP ${response.status}`, key), { status: response.status, provider: 'gemini' });
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) throw new AIServiceError('Réponse vide de Gemini.', { code: 'empty_response', provider: 'gemini' });
    return text;
  } };
}
