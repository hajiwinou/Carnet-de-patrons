import { AIServiceError, safeProviderMessage } from '../ai-errors.js';

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new AIServiceError('Lecture du média impossible.', { code: 'media_read' }));
    reader.readAsDataURL(blob);
  });
}
export function createOpenAICompatibleAdapter({ id, endpoint, fetchImpl = globalThis.fetch, headers: extraHeaders = {} }) {
  return {
    async generate(request, config) {
      const key = String(config.keys?.[id] || '').trim();
      const model = String(config.models?.[id] || '').trim();
      if (!model) throw new AIServiceError('Modèle non configuré.', { code: 'missing_model', provider: id });
      if (id !== 'omniroute' && !key) throw new AIServiceError('Clé API non configurée.', { code: 'no_key', provider: id });
      const images = Array.isArray(request.images) ? request.images : [];
      if (images.length && id === 'groq') throw new AIServiceError('Ce fournisseur ne prend pas en charge les images.', { code: 'no_vision', provider: id });
      let content = request.prompt;
      if (images.length) {
        content = [{ type: 'text', text: String(request.prompt || '') }];
        for (const blob of images) {
          if (!(blob instanceof Blob)) throw new AIServiceError('Image invalide.', { code: 'invalid_media', provider: id });
          content.push({ type: 'image_url', image_url: { url: `data:${blob.type || 'image/jpeg'};base64,${await blobToBase64(blob)}` } });
        }
      }
      const headers = { 'Content-Type': 'application/json', ...extraHeaders };
      if (key || id !== 'omniroute') headers.Authorization = `Bearer ${key}`;
      if (id === 'openrouter') {
        headers['HTTP-Referer'] = request.referer || (globalThis.location?.href || 'https://dreamos.local');
        headers['X-Title'] = 'dreamKnittingOS';
      }
      const body = { model, messages: [{ role: 'user', content }], temperature: 0.1 };
      if (request.json && id !== 'openrouter' && id !== 'omniroute') body.response_format = { type: 'json_object' };
      let response;
      try {
        response = await fetchImpl(endpoint, { method: 'POST', headers, body: JSON.stringify(body), signal: request.signal });
      } catch (cause) {
        if (cause?.name === 'AbortError') throw cause;
        throw new AIServiceError(id === 'omniroute' ? 'OmniRoute injoignable. Vérifiez son adresse.' : 'Connexion au fournisseur IA impossible.', { code: 'network', provider: id, cause });
      }
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new AIServiceError(safeProviderMessage(data?.error?.message || `Erreur HTTP ${response.status}`, key), { status: response.status, provider: id });
      const text = data?.choices?.[0]?.message?.content;
      if (typeof text !== 'string' || !text.trim()) throw new AIServiceError('Réponse vide du fournisseur.', { code: 'empty_response', provider: id });
      return text;
    }
  };
}
