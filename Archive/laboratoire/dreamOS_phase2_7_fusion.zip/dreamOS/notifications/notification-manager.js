/**
 * dreamOS — Notification Manager (Phase 2.6)
 * Utilise le conteneur historique #toast sans remplacer toast()/toastAct().
 */
export class NotificationManager {
  #document; #element; #timer = null; #defaultDuration; #disposed = false; #events;
  constructor({ documentRef = globalThis.document, eventBus = null, duration = 3800 } = {}) {
    if (!documentRef || typeof documentRef.getElementById !== 'function') throw new TypeError('Un document est requis.');
    this.#document = documentRef;
    this.#element = documentRef.getElementById('toast');
    if (!this.#element) throw new Error('Conteneur historique #toast introuvable.');
    this.#events = eventBus;
    this.#defaultDuration = Number.isFinite(duration) && duration >= 0 ? duration : 3800;
  }
  show(message, { type = 'info', duration = this.#defaultDuration, action = null } = {}) {
    if (this.#disposed) throw new Error('NotificationManager est fermé.');
    const el = this.#element;
    if (this.#timer !== null) globalThis.clearTimeout(this.#timer);
    el.replaceChildren();
    const text = this.#document.createElement('span');
    text.textContent = String(message ?? '');
    el.appendChild(text);
    if (action && typeof action.callback === 'function') {
      const button = this.#document.createElement('button');
      button.type = 'button';
      button.textContent = String(action.label || 'OK');
      button.addEventListener('click', () => {
        try { action.callback(); } finally { this.dismiss(); }
      }, { once: true });
      el.appendChild(button);
    }
    el.dataset.type = ['success','error','warning','info'].includes(type) ? type : 'info';
    el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    el.style.display = 'block';
    this.#events?.emit?.('notification:shown', { type: el.dataset.type, message: String(message ?? '') });
    if (!action && duration > 0) this.#timer = globalThis.setTimeout(() => this.dismiss(), duration);
    return this;
  }
  success(message, options = {}) { return this.show(message, { ...options, type: 'success' }); }
  error(message, options = {}) { return this.show(message, { ...options, type: 'error' }); }
  warning(message, options = {}) { return this.show(message, { ...options, type: 'warning' }); }
  info(message, options = {}) { return this.show(message, { ...options, type: 'info' }); }
  dismiss() {
    if (this.#timer !== null) globalThis.clearTimeout(this.#timer);
    this.#timer = null;
    if (this.#element) { this.#element.style.display = 'none'; this.#element.replaceChildren(); }
  }
  dispose() { if (this.#disposed) return; this.dismiss(); this.#disposed = true; }
}
export function createNotificationManager(options) { return new NotificationManager(options); }
