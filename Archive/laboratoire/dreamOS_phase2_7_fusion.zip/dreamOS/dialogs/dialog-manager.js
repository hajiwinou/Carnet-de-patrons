/**
 * dreamOS — Dialog Manager (Phase 2.6)
 * API additive sur #dlg ; les fonctions historiques dlgOpen/askConfirm restent intactes.
 */
export class DialogManager {
  #document; #root; #active = null; #events; #disposed = false; #onKeydown;
  constructor({ documentRef = globalThis.document, eventBus = null } = {}) {
    if (!documentRef || typeof documentRef.getElementById !== 'function') throw new TypeError('Un document est requis.');
    this.#document = documentRef;
    this.#root = documentRef.getElementById('dlg');
    if (!this.#root) throw new Error('Conteneur historique #dlg introuvable.');
    this.#events = eventBus;
    this.#onKeydown = (event) => this.#handleKeydown(event);
    documentRef.addEventListener('keydown', this.#onKeydown, true);
    this.#root.addEventListener('click', (event) => { if (event.target === this.#root && this.#active) this.close(null); });
  }
  confirm({ title = 'Confirmation', message = '', confirmLabel = 'Confirmer', cancelLabel = 'Annuler', danger = false } = {}) {
    return this.#open({ kind: 'confirm', title, message, confirmLabel, cancelLabel, danger });
  }
  alert({ title = 'Information', message = '', okLabel = 'OK' } = {}) {
    return this.#open({ kind: 'alert', title, message, confirmLabel: okLabel, cancelLabel: null });
  }
  prompt({ title = 'Saisie', message = '', value = '', placeholder = '', confirmLabel = 'Valider', cancelLabel = 'Annuler', validate = null } = {}) {
    return this.#open({ kind: 'prompt', title, message, value, placeholder, confirmLabel, cancelLabel, validate });
  }
  #open(options) {
    if (this.#disposed) return Promise.reject(new Error('DialogManager est fermé.'));
    if (this.#active) this.close(null);
    return new Promise((resolve) => {
      const previous = this.#document.activeElement;
      const panel = this.#document.createElement('div');
      panel.className = 'box'; panel.setAttribute('role', options.kind === 'confirm' ? 'alertdialog' : 'dialog');
      panel.setAttribute('aria-modal', 'true');
      const heading = this.#document.createElement('h2'); heading.textContent = String(options.title); heading.id = 'dreamos-dialog-title';
      panel.setAttribute('aria-labelledby', heading.id); panel.appendChild(heading);
      if (options.message) { const p = this.#document.createElement('p'); p.className = 'sub'; p.textContent = String(options.message); p.id = 'dreamos-dialog-message'; panel.setAttribute('aria-describedby', p.id); panel.appendChild(p); }
      let input = null;
      if (options.kind === 'prompt') {
        input = this.#document.createElement('input'); input.className = 'in'; input.type = 'text'; input.maxLength = 500;
        input.value = String(options.value ?? ''); input.placeholder = String(options.placeholder || ''); input.setAttribute('aria-label', String(options.title));
        panel.appendChild(input);
        const error = this.#document.createElement('div'); error.className = 'note bad'; error.hidden = true; error.setAttribute('role','alert'); panel.appendChild(error);
        this.#active = { resolve, previous, options, panel, input, error };
      } else this.#active = { resolve, previous, options, panel, input: null, error: null };
      const row = this.#document.createElement('div'); row.className = 'row';
      if (options.cancelLabel !== null) {
        const cancel = this.#document.createElement('button'); cancel.type = 'button'; cancel.className = 'btn grow'; cancel.textContent = String(options.cancelLabel);
        cancel.addEventListener('click', () => this.close(null)); row.appendChild(cancel);
      }
      const accept = this.#document.createElement('button'); accept.type = 'button'; accept.className = 'btn grow ' + (options.danger ? 'danger' : 'primary');
      accept.textContent = String(options.confirmLabel); accept.addEventListener('click', () => this.#accept()); row.appendChild(accept);
      panel.appendChild(row); this.#root.replaceChildren(panel); this.#root.hidden = false;
      (input || accept).focus(); if (input) input.select();
      this.#events?.emit?.('dialog:opened', { kind: options.kind });
    });
  }
  #accept() {
    if (!this.#active) return;
    const a = this.#active;
    if (a.options.kind === 'prompt') {
      const value = String(a.input.value || '').trim();
      const error = value ? (typeof a.options.validate === 'function' ? a.options.validate(value) : '') : 'Veuillez saisir une valeur.';
      if (error) { a.error.textContent = String(error); a.error.hidden = false; a.input.focus(); return; }
      this.close(value); return;
    }
    this.close(true);
  }
  #handleKeydown(event) {
    if (!this.#active) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); this.close(null); return; }
    if (event.key === 'Enter' && this.#active.input && event.target === this.#active.input) { event.preventDefault(); this.#accept(); return; }
    if (event.key === 'Tab') {
      const focusable = [...this.#root.querySelectorAll('input,button')].filter((el) => !el.disabled && !el.hidden);
      if (!focusable.length) return;
      const index = focusable.indexOf(this.#document.activeElement);
      if (event.shiftKey && index <= 0) { event.preventDefault(); focusable[focusable.length - 1].focus(); }
      else if (!event.shiftKey && (index < 0 || index === focusable.length - 1)) { event.preventDefault(); focusable[0].focus(); }
    }
  }
  close(value = null) {
    if (!this.#active) return;
    const active = this.#active; this.#active = null;
    this.#root.hidden = true; this.#root.replaceChildren();
    if (active.previous && typeof active.previous.focus === 'function' && this.#document.contains(active.previous)) active.previous.focus();
    active.resolve(value);
    this.#events?.emit?.('dialog:closed', { kind: active.options.kind, confirmed: value !== null && value !== false });
  }
  get isOpen() { return Boolean(this.#active); }
  dispose() {
    if (this.#disposed) return;
    this.close(null); this.#document.removeEventListener('keydown', this.#onKeydown, true); this.#disposed = true;
  }
}
export function createDialogManager(options) { return new DialogManager(options); }
