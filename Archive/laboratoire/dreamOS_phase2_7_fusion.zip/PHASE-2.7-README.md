# dreamOS — Phase 2.7 — Legacy Adapter

Version : 2.7.0  
Base : laboratoire validé Phase 2.6

## Objectif
Créer un pont explicite et limité entre le moteur historique (IIFE `app.js`) et les modules ESM dreamOS. Le moteur historique reste propriétaire des données métier et de ses écritures.

## Interface exposée
- `window.DreamOSLegacy.ready` : Promise résolue après la restauration historique et le rendu initial.
- `window.DreamOSLegacy.status` : `loading`, `ready` ou `degraded`.
- `getStateSnapshot()` : copie JSON indépendante des collections métier (patrons, projets, dossiers, documentation, idées, tableaux, grilles), du bloc-notes, de l'UI et de la vue courante. Les clés API, le hash de verrouillage et l'objet privé `S` ne sont jamais exposés.
- `refresh()` : demande un rendu du moteur historique après sa disponibilité.
- `notify(message)` : délègue un message au toast historique.

Le service ESM `legacyAdapter` expose le même contrat et est également disponible via `window.dreamOS.legacy`.

## Cycle de vie
- `dreamos:legacy-script-loaded` (événement DOM) / `legacy:script-loaded` (Event Bus) : le pont historique est installé.
- `dreamos:legacy-ready` (événement DOM) / `legacy:ready` (Event Bus) : restauration terminée et rendu initial effectué.
- `window.dreamOS.legacy.ready` permet d'attendre ce point sans deviner le délai de chargement IndexedDB.
- `dreamos:ready` conserve son sens historique : le runtime ESM est initialisé, pas nécessairement les données legacy.

## Propriété et sécurité des données
- `app.js` ne transfère pas la propriété des données aux services ESM.
- Aucune nouvelle écriture vers localStorage ou IndexedDB n'est ajoutée par l'adapter.
- Aucun accès direct à `S`, aucune mutation de snapshot et aucune double écriture.
- Les services Storage, Media et Backup restent disponibles mais ne sont pas automatiquement raccordés aux écritures métier legacy.
- `app-late.js` reste inchangé.

## Fichiers modifiés
- `app.js` : installation additive du pont et signal de fin de restauration.
- `dreamOS/legacy-adapter.js` : wrapper ESM contrôlé.
- `dreamOS/bootstrap.js` : version 2.7.0 et service `legacyAdapter`.
- `sw.js` : cache `atelier-tricot-v8` et précache du nouvel adaptateur.

## Vérifications de construction
Syntaxe JavaScript des modules ESM vérifiée avec `node --check`; intégrité ZIP vérifiée. Les tests de navigateur et la checklist manuelle restent à effectuer.
