import assert from 'node:assert/strict';
import { BackupManager } from '../dreamOS/backup-manager.js';

const archives = new WeakMap();
class FakeZip {
  constructor() { this.entries = new Map(); }
  file(name, value) {
    if (arguments.length === 1) {
      const stored = this.entries.get(name);
      return stored === undefined ? null : { async: async (kind) => kind === 'blob' ? (stored instanceof Blob ? stored : new Blob([stored])) : (stored instanceof Blob ? stored.text() : String(stored)) };
    }
    this.entries.set(name, value);
    return this;
  }
  folder(prefix) {
    const base = `${prefix}/`;
    return { forEach: (callback) => {
      for (const name of this.entries.keys()) {
        if (name.startsWith(base)) callback(name.slice(base.length), { dir: false });
      }
    }};
  }
  async generateAsync() {
    const blob = new Blob(['fake-zip']);
    archives.set(blob, new Map(this.entries));
    return blob;
  }
  static async loadAsync(blob) {
    const entries = archives.get(blob);
    if (!entries) throw new Error('Archive de test inconnue');
    const zip = new FakeZip();
    zip.entries = new Map(entries);
    return zip;
  }
}

const records = new Map([
  ['meta_patterns', JSON.stringify({ ts: 1, list: [] })],
  ['pdf_demo', new Blob(['PDF test'], { type: 'application/pdf' })],
  ['img_demo', new Blob(['image test'], { type: 'image/jpeg' })]
]);
const storage = {
  async keys() { return [...records.keys()]; },
  async get(key) { return records.get(key); }
};
const manager = new BackupManager({ storage, zipProvider: () => FakeZip });
const data = {
  v: 1,
  at: 123,
  patterns: [{ id: 'p1', source: { pdf: 'pdf_demo' }, photos: [{ id: 'img_demo' }] }],
  folders: [], projects: [], grids: [], docs: [], ideas: [], boards: []
};

assert.deepEqual(manager.validateData(data), { valid: true, formatVersion: 1, patternCount: 1 });
assert.throws(() => manager.validateData({ v: 2, patterns: [] }), /non pris en charge/);
assert.throws(() => manager.validateData({ v: 1 }), /patrons est absente/);
const archive = await manager.createArchive(data);
assert.ok(archive instanceof Blob);
const report = await manager.inspectArchive(archive);
assert.equal(report.valid, true);
assert.equal(report.formatVersion, 1);
assert.equal(report.patternCount, 1);
assert.equal(report.mediaCount, 2);
assert.ok(report.mediaEntries.includes('blobs/pdf_demo'));
assert.ok(report.mediaEntries.includes('blobs/img_demo'));
assert.equal(records.has('meta_patterns'), true, 'aucune donnée de stockage ne doit être modifiée');

const missingStorage = new BackupManager({ storage: { keys: async () => [], get: async () => undefined }, zipProvider: () => FakeZip });
await assert.rejects(() => missingStorage.createArchive(data), /Fichier référencé manquant/);

const noZip = new BackupManager({ storage, zipProvider: () => null });
await assert.rejects(() => noZip.createArchive(data), /bibliothèque ZIP n’est pas chargée/);
manager.dispose();
assert.throws(() => manager.validateData(data), /fermé/);
console.log('Phase 2.4 : tests BackupManager réussis.');
