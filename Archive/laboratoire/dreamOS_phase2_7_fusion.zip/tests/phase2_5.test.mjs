import assert from 'node:assert/strict';
import { AIManager } from '../dreamOS/ai/ai-manager.js';
import { AI_PROVIDERS, PROVIDER_IDS } from '../dreamOS/ai/providers.js';

assert.deepEqual(PROVIDER_IDS, ['gemini', 'groq', 'openrouter', 'openai', 'omniroute']);
assert.equal(AI_PROVIDERS.gemini.model, 'gemini-2.5-flash');
assert.equal(AI_PROVIDERS.groq.model, 'llama-3.3-70b-versatile');
assert.equal(AI_PROVIDERS.openrouter.model, 'google/gemini-2.0-flash-exp:free');
assert.equal(AI_PROVIDERS.openai.model, 'gpt-4o-mini');
assert.equal(AI_PROVIDERS.omniroute.model, 'auto');

let called = [];
const adapters = Object.fromEntries(PROVIDER_IDS.map((id) => [id, {
  async generate(request, config) {
    called.push({ id, prompt: request.prompt, hasKey: !!config.keys?.[id] });
    return id === 'gemini' ? '{"answer":"OK"}' : 'OK';
  }
}]));
const manager = new AIManager({ adapters, timeoutMs: 1000 });
const config = {
  keys: { gemini: 'test-key', groq: 'groq-key', openrouter: 'or-key', openai: 'oa-key' },
  urls: { omniroute: 'https://example.test' },
  models: Object.fromEntries(PROVIDER_IDS.map((id) => [id, AI_PROVIDERS[id].model])),
  prefText: 'gemini', prefVision: 'gemini', autoFailover: true, omniVision: true
};
const jsonResult = await manager.generate({ prompt: 'Réponds en JSON', json: true }, config);
assert.deepEqual(jsonResult.data, { answer: 'OK' });
assert.equal(jsonResult.providerId, 'gemini');
assert.equal(called.length, 1);

const visionConfig = { ...config, prefVision: 'groq' };
const visionResult = await manager.generate({ prompt: 'Décris', images: [new Blob(['x'], { type: 'image/jpeg' })] }, visionConfig);
assert.equal(visionResult.providerId, 'gemini', 'Groq doit être exclu des requêtes vision');

const failoverAdapters = {
  gemini: { async generate() { throw new Error('provider down'); } },
  groq: { async generate() { return 'fallback'; } }
};
const failover = new AIManager({ adapters: failoverAdapters });
const fallbackResult = await failover.generate({ prompt: 'test' }, { ...config, prefText: 'gemini' });
assert.equal(fallbackResult.providerId, 'groq');

const noConfig = await assert.rejects(() => manager.generate({ prompt: 'test' }, { keys: {}, urls: {} }), /Aucun fournisseur IA configuré/);
assert.equal(noConfig, undefined);
manager.dispose();
await assert.rejects(() => manager.generate({ prompt: 'test' }, config), /fermé/);
failover.dispose();
console.log('Phase 2.5 : tests AIManager réussis.');
