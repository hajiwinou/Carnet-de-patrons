/**
 * dreamOS — Bootstrap ESM (Phase 2.1)
 *
 * Point d’entrée du futur environnement modulaire.
 * Le moteur historique (app.js / app-late.js) reste chargé séparément
 * et conserve la responsabilité du démarrage métier et des données.
 */
import { createEventBus } from './event-bus.js';
import { createServiceRegistry } from './service-registry.js';
import { createStorageManager } from './storage-manager.js';

const DREAMOS_VERSION = '2.2.0';

function domReady() {
  if (document.readyState !== 'loading') return Promise.resolve();
  return new Promise((resolve) => {
    document.addEventListener('DOMContentLoaded', resolve, { once: true });
  });
}

async function bootstrap() {
  if (window.dreamOS) return window.dreamOS;

  const events = createEventBus();
  const services = createServiceRegistry();

  services.register('eventBus', () => events);
  services.register('serviceRegistry', () => services);
  // Même base, même version et même magasin que le moteur historique.
  // Le service reste paresseux : aucune ouverture ni migration au bootstrap.
  services.register('storageManager', () => createStorageManager());

  const runtime = Object.freeze({
    version: DREAMOS_VERSION,
    events,
    services,
    status: 'ready'
  });

  // API additive, en lecture seule au niveau de la propriété globale.
  Object.defineProperty(window, 'dreamOS', {
    configurable: false,
    enumerable: true,
    writable: false,
    value: runtime
  });

  await services.startEager();
  await domReady();

  events.emit('dreamos:ready', {
    version: DREAMOS_VERSION,
    timestamp: Date.now()
  });

  // Simple constat de présence : ce signal ne prétend pas que le boot métier
  // asynchrone du legacy (IndexedDB/restauration/rendu) est terminé.
  const legacyScriptPresent = [...document.scripts].some((script) =>
    /(?:^|\/)app\.js(?:\?|$)/.test(script.getAttribute('src') || '')
  );
  events.emit('dreamos:legacy-script-detected', { present: legacyScriptPresent });

  document.dispatchEvent(new CustomEvent('dreamos:ready', {
    detail: { version: DREAMOS_VERSION }
  }));

  return runtime;
}

bootstrap().catch((error) => {
  console.error('[dreamOS] Échec du bootstrap ESM', error);
  document.dispatchEvent(new CustomEvent('dreamos:error', { detail: { error } }));
});
