/**
 * dreamOS — Registre des modules métier (Phase 3.1)
 * Déclare, pour chaque application, les ressources qu'elle possède et les services qu'elle utilise,
 * et applique la règle « une seule autorité d'écriture par ressource ».
 * Pendant la transition, toutes les ressources sont possédées par 'legacy' ; un transfert est une
 * opération explicite (transferOwnership) qui échoue si le propriétaire actuel n'est pas le bon.
 * Ce registre ne lit ni n'écrit aucune donnée.
 */
export const LEGACY_OWNER = 'legacy';

const matches = (resource, pattern) => (pattern.endsWith('*') ? resource.startsWith(pattern.slice(0, -1)) : resource === pattern);

export class ModuleRegistry {
  #modules = new Map();
  #owners = new Map(); // motif de ressource -> propriétaire

  /** @param {{name:string, title?:string, resources:{storage?:string[], media?:string[]}, uses?:string[], notes?:string}} descriptor */
  declare(descriptor) {
    const { name, resources = {}, uses = [] } = descriptor || {};
    if (typeof name !== 'string' || !name) throw new TypeError('Un module a besoin d’un nom.');
    if (this.#modules.has(name)) throw new Error(`Le module "${name}" est déjà déclaré.`);
    const patterns = [...(resources.storage || []).map((r) => `storage:${r}`), ...(resources.media || []).map((r) => `media:${r}`), ...(resources.dom || []).map((r) => `dom:${r}`)];
    for (const p of patterns) {
      if (this.#owners.has(p)) throw new Error(`Ressource "${p}" déjà revendiquée par "${this.#owners.get(p).module}".`);
    }
    this.#modules.set(name, Object.freeze({ ...descriptor, uses: [...uses], resources: Object.freeze({ storage: [...(resources.storage || [])], media: [...(resources.media || [])], dom: [...(resources.dom || [])] }) }));
    for (const p of patterns) this.#owners.set(p, { owner: LEGACY_OWNER, module: name });
    return this;
  }

  get(name) { const m = this.#modules.get(name); if (!m) throw new Error(`Module inconnu : "${name}".`); return m; }
  names() { return [...this.#modules.keys()]; }

  /** Propriétaire d'écriture d'une ressource concrète, ex. ownerOf('storage', 'carnet.projects'). */
  ownerOf(kind, resource) {
    const hits = [...this.#owners].filter(([p]) => p.startsWith(`${kind}:`) && matches(resource, p.slice(kind.length + 1)));
    if (!hits.length) return null;
    return hits.sort((a, b) => b[0].length - a[0].length)[0][1].owner;
  }
  /** Module métier auquel appartient la ressource. */
  moduleOf(kind, resource) {
    const hits = [...this.#owners].filter(([p]) => p.startsWith(`${kind}:`) && matches(resource, p.slice(kind.length + 1)));
    return hits.length ? hits.sort((a, b) => b[0].length - a[0].length)[0][1].module : null;
  }

  /** Transfert explicite et unique : legacy → service/module. Jamais de double propriétaire. */
  transferOwnership(kind, pattern, from, to) {
    const key = `${kind}:${pattern}`;
    const entry = this.#owners.get(key);
    if (!entry) throw new Error(`Ressource inconnue : "${key}".`);
    if (entry.owner !== from) throw new Error(`"${key}" appartient à "${entry.owner}", pas à "${from}" : transfert refusé.`);
    if (!to || to === from) throw new Error('Le nouveau propriétaire doit être différent.');
    entry.owner = to;
    return this;
  }

  /** Rapport de santé : ressources par propriétaire. */
  report() {
    const out = {};
    for (const [k, v] of this.#owners) (out[v.owner] ||= []).push(k);
    return out;
  }
  dispose() {}
}

export function createModuleRegistry() { return new ModuleRegistry(); }
