#!/usr/bin/env node
// dreamOS — Phase 3.0 : inventaire traçable de app.js (lecture seule, ne modifie rien).
// Usage : node tools/audit-app.mjs  → docs/phase3/inventory.json + docs/phase3/INVENTORY.md
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { ACTION_RULES } from './action-rules.mjs'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const lines = src.split('\n');

// Découpage heuristique par plages de lignes (validé à la main sur la liste des fonctions).
// Chaque plage = [début, fin, module cible]. À réviser si app.js change (le hash d'app.js est consigné).
export const RANGES = [
  [1, 177, 'core:loader'], [178, 260, 'service:media'], [261, 414, 'core:data-defs'],
  [415, 569, 'service:storage'], [570, 592, 'service:ai'], [593, 717, 'settings:theme'],
  [718, 820, 'settings:lock'], [821, 836, 'core:utils'], [837, 888, 'service:notifications'],
  [889, 928, 'core:utils'], [929, 1003, 'service:storage'], [1004, 1049, 'service:dialogs'],
  [1050, 1156, 'patterns:delete-folders'], [1157, 1323, 'patterns:import-text'],
  [1324, 1504, 'service:ai'], [1505, 1536, 'patterns:schema'], [1537, 2288, 'projects'],
  [2289, 2780, 'patterns:fiche-ai'], [2781, 2928, 'patterns:import-pdf'],
  [2929, 3499, 'pdf-reader'], [3500, 3889, 'service:backup'], [3890, 4214, 'tools'],
  [4215, 4339, 'downloads'], [4340, 4594, 'tools'], [4595, 4689, 'documentation'],
  [4690, 4909, 'library'], [4910, 4981, 'library'], [4982, 5155, 'settings'],
  [5156, 5701, 'patterns:views'], [5702, 6760, 'engine:event-handlers'], [6761, 6867, 'legacy:bridge'],
];
const moduleOf = (ln) => (RANGES.find(([a, b]) => ln >= a && ln <= b) || [0, 0, 'unclassified'])[2];

const fns = [];
lines.forEach((t, i) => {
  const m = t.match(/^(\s*)(async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(([^)]*)\)/);
  if (m) fns.push({ name: m[3], line: i + 1, depth: m[1].length, async: !!m[2], module: moduleOf(i + 1) });
});
// bornes de fonctions : jusqu'à la prochaine déclaration de même indentation ou moins
fns.forEach((f, i) => { const nxt = fns.slice(i + 1).find((g) => g.depth <= f.depth); f.end = nxt ? nxt.line - 1 : lines.length; f.size = f.end - f.line + 1; });

const names = new Set(fns.map((f) => f.name));
const top = fns.filter((f) => f.depth <= 2);          // fonctions de premier niveau de l'IIFE
const body = (f) => lines.slice(f.line - 1, f.end).join('\n');
const writes = { 'IDB.put': /IDB\.put\(\s*['"]?([A-Za-z0-9_]+)/g, 'IDB.del': /IDB\.del\(/g, keep: /keep\(\s*'(carnet\.[A-Za-z0-9_.]+)'/g, saveBlob: /saveBlob\(/g };
const stateKeys = (t) => [...new Set([...t.matchAll(/\bS\.([A-Za-z0-9_]+)/g)].map((m) => m[1]))].sort();
const lsKeys = (t) => [...new Set([...t.matchAll(/'(carnet\.[A-Za-z0-9_.]+)'/g)].map((m) => m[1]))].sort();

const byModule = {};
for (const f of top) {
  const b = body(f);
  const calls = [...new Set([...b.matchAll(/\b([A-Za-z0-9_$]+)\s*\(/g)].map((m) => m[1]).filter((n) => names.has(n) && n !== f.name))];
  const crossCalls = calls.filter((n) => { const g = fns.find((x) => x.name === n && x.depth <= 2); return g && g.module.split(':')[0] !== f.module.split(':')[0]; });
  const rec = { ...f, state: stateKeys(b), storageKeys: lsKeys(b), writesIdb: /IDB\.(put|del)\(|saveBlob\(|deleteBlob\(/.test(b), crossModuleCalls: crossCalls };
  (byModule[f.module] ||= []).push(rec);
}

// Gestionnaire de clics monolithique : actions (a === 'xxx') par module d'après la première fonction connue appelée sur la ligne
const actions = [];
lines.forEach((t, i) => {
  for (const m of t.matchAll(/\ba === '([A-Za-z0-9_]+)'/g)) {
    const called = [...t.matchAll(/\b([A-Za-z0-9_$]+)\s*\(/g)].map((x) => x[1]).find((n) => top.some((f) => f.name === n));
    const g = called && top.find((f) => f.name === called);
    const byName = ACTION_RULES.find(([re]) => re.test(m[1]));
    actions.push({ action: m[1], line: i + 1, via: called || null, module: byName ? byName[1] : g ? g.module.split(':')[0] : 'indéterminé', by: byName ? 'nom' : g ? 'appel' : '-' });
  }
});
const handlerBlocks = [];
lines.forEach((t, i) => { const m = t.match(/^\s*document\.addEventListener\('(\w+)'|^\s*\$\('([^']+)'\)\.addEventListener\('(\w+)'/); if (m) handlerBlocks.push({ line: i + 1, event: m[1] || m[3], target: m[2] || 'document' }); });

const prefixes = {}; for (const m of src.matchAll(/'([a-z]{1,6})_'\s*\+/g)) prefixes[m[1] + '_'] = (prefixes[m[1] + '_'] || 0) + 1;
const idGen = {}; for (const m of src.matchAll(/id:\s*'([a-z]{1,3})'\s*\+\s*uid\(\)/g)) idGen[m[1]] = (idGen[m[1]] || 0) + 1;
const storageKeys = {}; for (const m of src.matchAll(/'(carnet\.[A-Za-z0-9_.]+)'/g)) storageKeys[m[1]] = (storageKeys[m[1]] || 0) + 1;
const sha = crypto.createHash('sha256').update(src).digest('hex');

const summary = Object.fromEntries(Object.entries(byModule).map(([k, v]) => [k, { functions: v.length, lines: v.reduce((s, f) => s + f.size, 0), crossModuleCalls: v.reduce((s, f) => s + f.crossModuleCalls.length, 0) }]));
const out = { generatedFrom: 'app.js', sha256: sha, lineCount: lines.length, functionDeclarations: fns.length, topLevelFunctions: top.length, summary, modules: byModule, clickActions: actions, listeners: handlerBlocks, mediaPrefixesUsed: prefixes, idPrefixesUsed: idGen, storageKeys };
fs.mkdirSync(path.join(root, 'docs/phase3'), { recursive: true });
fs.writeFileSync(path.join(root, 'docs/phase3/inventory.json'), JSON.stringify(out, null, 1));

const md = [`# Inventaire app.js (généré — Phase 3.0)`, ``, `- sha256 : \`${sha.slice(0, 16)}…\` · ${lines.length} lignes · ${fns.length} déclarations de fonctions (${top.length} de premier niveau)`, `- Répartition heuristique par plage de lignes (voir \`RANGES\` dans tools/audit-app.mjs).`, ``, `| Module cible | Fonctions | Lignes | Appels vers d'autres modules |`, `|---|---:|---:|---:|`,
  ...Object.entries(summary).sort((a, b) => b[1].lines - a[1].lines).map(([k, v]) => `| ${k} | ${v.functions} | ${v.lines} | ${v.crossModuleCalls} |`), ``,
  `## Gestionnaires d'événements globaux`, ...handlerBlocks.map((h) => `- l.${h.line} \`${h.target}\` · ${h.event}`), ``,
  `## Actions du gestionnaire de clic (${new Set(actions.map((a) => a.action)).size} distinctes ; classement heuristique par nom puis par appel, à valider)`, ...Object.entries(actions.reduce((o, a) => ((o[a.module] ||= new Set()).add(a.action), o), {})).map(([m, s]) => `- **${m}** (${s.size}) : ${[...s].join(', ')}`), ``,
  `## Préfixes d'identifiants média réellement utilisés`, '`' + Object.keys(prefixes).sort().join('`, `') + '`', ``,
  `## Préfixes d'identifiants métier (\`id: 'x' + uid()\`)`, '`' + Object.keys(idGen).sort().join('`, `') + '`', ``,
  `## Clés carnet.*`, ...Object.entries(storageKeys).sort().map(([k, n]) => `- \`${k}\` (${n} occ.)`), ``,
  `## Fonctions les plus volumineuses`, ...top.slice().sort((a, b) => b.size - a.size).slice(0, 15).map((f) => `- \`${f.name}\` l.${f.line} · ${f.size} lignes · ${f.module}`), ``,
  `## Fonctions de premier niveau avec le plus d'appels inter-modules`, ...Object.values(byModule).flat().filter((f) => f.crossModuleCalls.length).sort((a, b) => b.crossModuleCalls.length - a.crossModuleCalls.length).slice(0, 15).map((f) => `- \`${f.name}\` (${f.module}) → ${f.crossModuleCalls.slice(0, 8).join(', ')}`), ''];
fs.writeFileSync(path.join(root, 'docs/phase3/INVENTORY.md'), md.join('\n'));
console.log(md.slice(0, 20).join('\n'));
