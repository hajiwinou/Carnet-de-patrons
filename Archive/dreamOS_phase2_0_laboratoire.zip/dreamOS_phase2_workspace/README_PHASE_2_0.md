# dreamOS — Phase 2.0 : laboratoire de migration

## Règle de sécurité
Cette copie a été extraite dans un nouveau dossier depuis `Zip pour analyse.zip`.
L'archive source n'a pas été modifiée.

- Empreinte SHA-256 de l'archive source : `085979d08a825eecc4cda0d41b6db430062632dd951a3f0208bbbb60ddddac6a`
- Nombre de fichiers extraits : 70
- Date de création UTC : 2026-11-17T21:21:55.748080+00:00

## Contenu
- `Carnet-de-patrons-main/` : copie de travail du projet.
- `BASELINE_MANIFEST.json` : inventaire et empreintes SHA-256 de chaque fichier, ainsi que les vérifications statiques disponibles.
- `PHASE_2_0_CHECKLIST.md` : étapes de validation manuelle restantes.

## Git
Le dépôt Git de la copie de travail est initialisé avec un commit de référence.
Le dépôt ne suit que le dossier du projet ; les documents de baseline restent à la racine du laboratoire.
