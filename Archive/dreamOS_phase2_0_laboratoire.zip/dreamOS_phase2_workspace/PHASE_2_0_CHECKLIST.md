# Phase 2.0 — checklist de validation manuelle

Les contrôles statiques ne remplacent pas un test dans un vrai navigateur.
À cocher après test sur la copie de travail uniquement.

## Avant lancement
- [ ] Ouvrir `Carnet-de-patrons-main/index.html` via un serveur local (pas nécessairement en double-cliquant le fichier).
- [ ] Vérifier la console du navigateur : aucune erreur bloquante au démarrage.
- [ ] Vérifier que le Service Worker s'enregistre et que les ressources sont servies correctement.

## Parcours métier de référence
- [ ] Ouvrir la vue principale et naviguer entre les onglets/vues.
- [ ] Créer, modifier, recharger et supprimer un patron de test.
- [ ] Créer, modifier et recharger un projet de test.
- [ ] Tester dossiers, grilles, documents, idées, tableaux et notes si ces vues sont activées.
- [ ] Ajouter et afficher une image.
- [ ] Ajouter et ouvrir un PDF ou document pris en charge.
- [ ] Exporter une sauvegarde complète.
- [ ] Restaurer cette sauvegarde dans un profil de navigateur de test ou un environnement jetable.
- [ ] Tester le comportement hors ligne après un premier chargement réussi.
- [ ] Vérifier les notifications, confirmations et dialogues.
- [ ] Tester les fonctions IA uniquement si une clé de test est disponible ; ne jamais inclure de vraie clé dans les captures, logs ou fichiers de test.

## Résultat
- Date du test :
- Navigateur / version :
- Système :
- Scénarios réussis :
- Scénarios échoués :
- Erreurs console :
- Décision : [ ] baseline validée  [ ] corrections nécessaires avant Phase 2.1
